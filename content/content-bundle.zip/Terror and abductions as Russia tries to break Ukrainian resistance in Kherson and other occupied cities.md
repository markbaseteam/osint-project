---
aliases: 
locations:
tag: 
date:
title: Terror and abductions as Russia tries to break Ukrainian resistance in Kherson and other occupied cities
---

Terror and abductions as Russia tries to break Ukrainian resistance in Kherson and other occupied cities

https://khpg.org/en/1608810189

Terror and abductions as Russia tries to break Ukrainian resistance in Kherson and other occupied cities

 

 https://khpg.org/en/1608810189
