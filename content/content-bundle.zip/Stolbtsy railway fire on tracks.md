---
locations:
aliases: ['Stolbtsy railway [[fire]] on tracks']
location: Stolbtsy, Belarus
title: 'Stolbtsy railway [[fire]] on tracks'
tag: fire, railway, infrastructure
date: 2022-03-01  
linter-yaml-title-alias: 'Stolbtsy railway [[fire]] on tracks'
---

# Stolbtsy railway [[fire]] on tracks

2022-03-01  
[[fire]]  
Railway,Infrastructure  
https://ru.wikipedia.org/wiki/Рельсовая_война_в_Белоруссии_(2022)# 30_марта  
On the night of March 1-2, husband and wife were [[arrested|detained]] in Stolbtsy, who set [[fire]] to logs on the railway tracks. As it became known to the human rights defenders of "Viasna", these are Sergei and Ekaterina Glebko. They have three minor children. In the "reprotant" video, it is noticeable that Sergei was beaten. "The man filmed everything on his mobile phone with the corresponding comment, where he openly expressed his terrorist intentions. He faces up to 20 years in [[prison]]," writes the Ministry of Internal Affairs. "I put two logs on the way, as I saw enough telegram channels and disagreed, I wanted to express my support and set [[fire]] to these logs," says the man on video. A criminal case has been initiated against Sergei Glebko under Art. 289 of the Criminal Code (act of terrorism)  
Stolbtsy, Belarus

~+~
