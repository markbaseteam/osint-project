---
locations:
aliases: 
location:
title: Farinovo - Zaguete section Vitebsk branch relay cabinet disabled
tag: 
date:
---

# Farinovo - Zaguete section Vitebsk branch relay cabinet disabled

2022-03-16  
[[fire]]  
Railway,Infrastructure  
https://ru.wikipedia.org/wiki/Рельсовая_война_в_Белоруссии_(2022)# 30_марта  
On the Farinovo - Zaguete section (Vitebsk branch), the relay cabinet of the SCB was destroyed. As a result, the train schedule, including military purposes, was disrupted. BYPOL took responsibility for the actions on the Domanovo - Lesnoye and Farinovo - Zaghate stages  
Zaguete section (Vitebsk branch), Belarus

~+~  
135
