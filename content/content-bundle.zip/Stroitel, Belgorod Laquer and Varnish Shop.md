---
locations:
aliases: 
location: 3rd Zavodskaya Street, Yakovlevsky, Belgorod
title: 'Stroitel, Belgorod Laquer and Varnish Shop'
tag: fire, chemical
date: 2022-05-16  
---

# Stroitel, Belgorod Laquer and Varnish Shop

2022-05-16  
[[fire]]  
Chemical  
https://thenewsglory.com/the-ministry-of-emergency-situations-spoke-about-the-fire-in-the-lacquer-production-shop-near-belgorod/  
In the city of Stroitel, Belgorod Region, a lacquer production shop caught [[fire]]. This was announced on Monday, May 16, in the regional Ministry of Emergency Situations. It is noted that a message about a [[fire]] on 3rd Zavodskaya Street in the Yakovlevsky city district was received at 1:36 a.m., the [[fire]] broke out in an unused varnish production workshop. On Monday night, the BelPlus Telegram channel published footage showing pillars of black smoke from a brick factory in the town of Stroitel, Belgorod Region. Local residents reported a [[fire|burning]] smell in the area.  
3rd Zavodskaya Street, Yakovlevsky, Belgorod

This may not be partisan activity, but it was shared on direct action channels which lends itself to potentially being an act of defiance.

~+~  
71
