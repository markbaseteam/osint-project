---
locations:
aliases: ['[[Maps/Komsomolsk-on-Amur, Khabarovsk Krai, Far Eastern Federal District, Russia430.3526436163887|Komsomolsk-on-Amur]] Rosgvardia Office']
location: Komsomolsk-on-Amur
title: '[[Maps/Komsomolsk-on-Amur, Khabarovsk Krai, Far Eastern Federal District, Russia430.3526436163887|Komsomolsk-on-Amur]] Rosgvardia Office'
tag: molotov, military
date: 2022-06-04  
linter-yaml-title-alias: '[[Maps/Komsomolsk-on-Amur, Khabarovsk Krai, Far Eastern Federal District, Russia430.3526436163887|Komsomolsk-on-Amur]] Rosgvardia Office'
---

# [[OSINT Project/Maps/Komsomolsk-on-Amur, Khabarovsk Krai, Far Eastern Federal District, Russia430.3526436163887|Komsomolsk-on-Amur]] Rosgvardia Office

2022-06-04  
Molotov  
Military  
https://t.me/BO_AK_reborn/1735  
a guerrilla attack was launched against the Rosgvardia office in [[OSINT Project/Maps/Komsomolsk-on-Amur, Khabarovsk Krai, Far Eastern Federal District, Russia430.3526436163887|Komsomolsk-on-Amur]]. The plan by the guerrilla militant was ambitious: as Baza reports, the daredevil wanted to get into the Rosgvardiya [1] building itself in order to ignite a canister with flammable liquid inside. The door was closed, so the guerrilla fighter set the canister on [[fire]] on the porch. A [[fire]] broke out. one partisan was [[arrested]]. His name is Vladimir Zolotorev and he is 50 years old. [[activism|Anarchist]] Fighter added “Note that a canister with a flammable liquid burns just as well as a Molotov. In addition, a fuse or simple detonator can be attached to a canister (or even several canisters tied together), which delays the moment of ignition for some time and thus greatly increases the chances of a safe getaway for the guerrillas,” in their Telegram post.  
[[OSINT Project/Maps/Komsomolsk-on-Amur, Khabarovsk Krai, Far Eastern Federal District, Russia430.3526436163887|Komsomolsk-on-Amur]]

Date discrepancy 4 or 5 June, 2022. Used earliest date. Also see BAZA https://t.me/bazabazon/11889 Rosgvardia = National Guard

~+~  
75
