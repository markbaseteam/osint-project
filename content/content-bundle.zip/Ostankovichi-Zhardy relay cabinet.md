---
locations:
aliases: 
location: Ostankovichi - Zherd section on Zhlobin - Kalinkovichi line, Gomel, Belarus
title: Ostankovichi-Zhardy relay cabinet
tag: fire, railway, infrastructure
date: 2022-03-04  
---

# Ostankovichi-Zhardy relay cabinet

2022-03-04  
[[fire]]  
Railway,Infrastructure  
https://ru.wikipedia.org/wiki/Рельсовая_война_в_Белоруссии_(2022)# 30_марта  
Ostankovichi-Zhardy section of the [[OSINT Project/Maps/Homyel, Homyel Region, Belarus|Gomel]] branch of the Belarusian Railways, the relay cabinet of signaling, centralization and blocking (SCB) was [[fire|burned]], and as a result, traffic lights and switches on this section were put into non-working. The Ostankovichi - Zherd section is located on the Zhlobin - Kalinkovichi line, which then continues to Ovruch (Zhytomyr region of Ukraine). The line was built as the shortest path for military echelons towards Ukraine during the First World War.  
Ostankovichi - Zherd section on Zhlobin - Kalinkovichi line, [[OSINT Project/Maps/Homyel, Homyel Region, Belarus|Gomel]], Belarus

~+~  
108
