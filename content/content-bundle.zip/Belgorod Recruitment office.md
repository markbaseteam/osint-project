---
locations:
aliases:
  - Belgorod Recruitment Office
location:
title: Belgorod Recruitment Office
tag: 
date:
linter-yaml-title-alias: Belgorod Recruitment Office
---

# Belgorod Recruitment Office

2022-06-24  
Molotov  
Recruitment  
https://news.bigmir.net/world/6330781-v-belgorode-i-permi-podozhgli-voenkomaty  
In Belgorod, a [[fire]] broke out on the first floor. An unidentified person broke a window of the building on the first floor and threw two Molotov cocktails into room 106. It is reported that a desk went up in flames. See also https://theins.ru/en/news/252560  
Belgorod

Also see https://www.newsweek.com/russia-dissent-putin-ukraine-war-man-molotov-cocktail-fsb-government-building-fire-1720900

~+~  
89
