---
locations:
aliases: ['Borisov-Novosady section Minsk branch relays [[fire|burned]]']
location:
title: 'Borisov-Novosady section Minsk branch relays [[fire|burned]]'
tag: 
date:
linter-yaml-title-alias: 'Borisov-Novosady section Minsk branch relays [[fire|burned]]'
---

# Borisov-Novosady section Minsk branch relays [[fire|burned]]

2022-03-25  
[[fire]]  
Railway,Infrastructure  
https://ru.wikipedia.org/wiki/Рельсовая_война_в_Белоруссии_(2022)# 30_марта  
2 relay alarm, centralization and blocking cabinets were [[fire|burned]] at the Borisov-Novosady section (Minsk branch of the Belarusian Railways)  
Borisov-Novosady section, Minsk branch, Belarus

~+~  
118
