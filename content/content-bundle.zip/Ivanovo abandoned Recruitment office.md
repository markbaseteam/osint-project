---
locations:
aliases: ['[[Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] abandoned Recruitment office']
location:
title: '[[Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] abandoned Recruitment office'
tag: molotov, recruitment
date: 2022-04-23  
linter-yaml-title-alias: '[[Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] abandoned Recruitment office'
---

# [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] abandoned Recruitment office

2022-04-23  
Molotov  
Recruitment

An abandoned enlistment office in [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] was hit with Molotov cocktails  
[[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]]

~+~  
60
