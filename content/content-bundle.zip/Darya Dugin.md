---
aliases: 
locations:
tag: 
date:
title: Darya Dugin
---

https://threadreaderapp.com/convos/1561318530284490752

https://threadreaderapp.com/thread/1561318530284490752.html

https://threadreaderapp.com/convos/1561677815187230720

https://threadreaderapp.com/thread/1561677815187230720.html

https://threadreaderapp.com/convos/1561343975176302593

https://threadreaderapp.com/thread/1561343975176302593.html

https://wartranslated.com/we-doubt-that-the-ukrainians-are-behind-the-murder-of-dasha-dugina-russian-military-experts-and-influencers-react-to-assassination-of-darya-dugina/

https://www.nytimes.com/2022/08/21/world/europe/ukraine-russia-car-bomb.html?smid=nytcore-ios-share&referringSource=articleShare

Darya Dugina: Ukraine killed Putin ally's daughter, Russia says

Journalist Darya Dugina, aged 29, died on Saturday when a vehicle she was driving exploded near Russia's capital.

Her prominent ultra-nationalist father, Alexander Dugin, said to be close to Mr Putin, may have been the intended target of the attack.

Ukrainian officials have denied any involvement in the explosion.

FSB told Russian media that a Ukrainian woman had moved to Russia in July alongside her young daughter - but that she was in fact a Ukrainian special services contractor.

The woman, it said, rented an apartment in the same building as Ms Dugina for a month, preparing for the attack. In that time, she allegedly followed the journalist through Moscow in a Mini Cooper - for which she used three different licence plates.

The suspect then escaped to Estonia after the explosion, the FSB said.

Ms Dugina and her father were attending a festival near Moscow on Saturday evening where Mr Dugin, a philosopher, gave a lecture. They had reportedly intended to leave in the same car, but changed their plans at the last minute.

Investigators said explosives had been planted underneath the Toyota Land Cruiser Ms Dugina was driving.

Video from the scene posted online appeared to show a shaken Mr Dugin watching emergency services attend the burning vehicle.

A family friend, Konstantin Malofeev, published a statement on behalf of Mr Dugin which branded his daughter's killing "a terrorist act by the Ukrainian Nazi regime".

One studio guest suggested the response would be "holy fury" and the programme showed a photograph of mortar shells, apparently belonging to pro-Russian forces in Ukraine, one of which had "This is for Darya!" scrawled on the side.

Analyst Yekaterina Shulman says the outpouring of anger amongst pro-Kremlin commentators in response to the car bomb attack appears suspicious: "The reaction…was immediate. It looks as if they were waiting for something like this to happen."

Whoever was responsible, says Ms Shulman, the killing "could possibly be used to ramp up some public outrage within the country to justify even more active repressive actions on the part of the state".  
https://www.bbc.co.uk/news/world-europe-62634359
