---
locations:
aliases: 
location:
title: Fedorovsky hydroelectric complex Bridge and Dam Collapse
tag: 
date:

---

# Fedorovsky hydroelectric complex Bridge and Dam Collapse

2022-04-22  
Mechanical  
Infrastructure  
https://russia.liveuamap.com/en/2022/22-april-krasnodar-krai-kuban-dam~+~collapsed-near-fyodorovska  
[[OSINT Project/Maps/Krasnodar Krai, Southern Federal District, Russia|Krasnodar Krai]], Kuban: Dam collapsed near Fyodorovska village. a bridge and a dam of a large Fedorovsky hydroelectric complex on the Kuban River in the Abinsk region, which has a capacity of 1.4 thousand cubic meters of [[water]] per second and supplies 130 thousand hectares of agricultural [[land]] in the [[OSINT Project/Maps/Krasnodar, Krasnodar Municipality, Krasnodar Krai, Southern Federal District, 350000, Russia|Krasnodar]] Territory. three new sections and one old section of the hydroelectric complex collapsed. At the same time, this bridge is the only one that crosses the Kuban River on the section from [[OSINT Project/Maps/Krasnodar, Krasnodar Municipality, Krasnodar Krai, Southern Federal District, 350000, Russia|Krasnodar]] to Slavyansk-on-Kuban.  
Fyodorovska, [[OSINT Project/Maps/Krasnodar Krai, Southern Federal District, Russia|Krasnodar Krai]], Abinsk region

[[OSINT Project/Maps/Krasnodar, Krasnodar Municipality, Krasnodar Krai, Southern Federal District, 350000, Russia|Krasnodar]] known as "Little Ukraine" according to the Kubanmeliovodkhoz Department, the hydroelectric facility actually supplies [[water]] to grow 80 percent of the rice in the entire [[OSINT Project/Maps/Krasnodar, Krasnodar Municipality, Krasnodar Krai, Southern Federal District, 350000, Russia|Krasnodar]] Territory. This is the largest hydraulic structure in the region. The Fedorovsky hydroelectric complex was built in the 60s of the 20th century and was designed for continuous [[operations|operation]] for 50 years. But that term has expired. In addition, since 2018, the hydroelectric complex has been in a pre-emergency state due to dynamic movements of the support structures. In 2021, it was closed for reconstruction, for which 638 million rubles were allocated. https://eprimefeed.com/latest-news/the-dam-of-the-fedorovsky-hydroelectric-complex-collapsed-into-the-kuban-river/67365/

~+~  
10
