---
locations:
aliases: ['[[Maps/Bogorodsky city district, Moscow Oblast, Central Federal District, Russia|Bogorodskoye]], Atlant Park industrial and warehouse complex']
location:
title: '[[Maps/Bogorodsky city district, Moscow Oblast, Central Federal District, Russia|Bogorodskoye]], Atlant Park industrial and warehouse complex'
tag: 
date:
linter-yaml-title-alias: '[[Maps/Bogorodsky city district, Moscow Oblast, Central Federal District, Russia|Bogorodskoye]], Atlant Park industrial and warehouse complex'
---

# [[OSINT Project/Maps/Bogorodsky city district, Moscow Oblast, Central Federal District, Russia|Bogorodskoye]], Atlant Park industrial and warehouse complex

2022-05-03  
[[fire]]  
Other  
https://www.world-today-news.com/in-the-suburbs-a-strong-fire-broke-out-in-a-huge-warehouse-mir-tsn-ua/  
Atlant Park industrial and warehouse complex in [[OSINT Project/Maps/Bogorodsky city district, Moscow Oblast, Central Federal District, Russia|Bogorodskoye]]. See also paper warehouse on Kudinovskoye [[roads|Highway]] same date  
[[OSINT Project/Maps/Bogorodsky city district, Moscow Oblast, Central Federal District, Russia|Bogorodskoye]], [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

located in a section dedicated to logistics and distribution. https://www.express.co.uk/news/world/1604413/russia-fire-vladimir-putin-news-industrial-building-Bogorodsky-moscow-oblast-latest

~+~  
29
