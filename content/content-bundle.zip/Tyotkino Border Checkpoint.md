---
locations:
aliases: 
location: Tyotkino border checkpoint
title: Tyotkino Border Checkpoint
tag: 
date: 2022-03-29
---

# Tyotkino Border Checkpoint

2022-03-29

Tyotkino border checkpoint was attacked, with no wounded as a result.  
Tyotkino Checkpoint

~+~  
82
