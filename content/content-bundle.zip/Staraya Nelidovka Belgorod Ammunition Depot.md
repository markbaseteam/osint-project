---
locations:
aliases: 
location:
title: Staraya Nelidovka Belgorod Ammunition Depot
tag: explosion, ammunition depot 
date: 2022-04-26 

---

# Staraya Nelidovka Belgorod Ammunition Depot

2022-04-26  
Explosion  
Ammunition Depot  
https://www.kyivpost.com/eastern-europe/probably-not-by-accident-new-mystery-explosions-ammo-dump-fires-in-russia.html  
flames and smoke rising over a Russian army ammunition depot near the village in Staraya Nedilovka. Firefighters were unable to control the blaze and detonations were still echoing by mid-morning and audible fifteen kilometers away. == After a series of four explosions at an ammunition depot near Staraya Nelidovka, in Russia’s Belgorod oblast, the facility is on [[fire]], regional governor Vyacheslav Gudkov said in a Telegram post on April 27.  
Staraya Nelidovka, Belgorod

Date disputed - 26 or 27 April. Used earliest one RF state [[All Satellite TV Channels Hacked|TV]] less than six hours after the explosions were airing images of two young men dressed in black being dragged into a Belgorod police station. They admitted to the camera they were Russian citizens supporting Nazi ideology, which was why they send Ukrainian spies information about Russian army rail movements and possible military targets. == Not covering Luhansk but…Earlier, Russian media reported a series of explosions at another ammunition stockpile in Irmino, near Luhansk, which is under Russian occupation since 2014. https://english.nv.ua/nation/ammo-depot-near-russia-s-belgorod-is-on-fire-50237257.html

—
178
