---
locations:
aliases: ['[[Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] Textile Shop [[Fire]]']
location: No. 70, Okulova Street, Ivanovo
title: '[[Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] Textile Shop [[Fire]]'
tag: fire
date: 2022-06-30  
linter-yaml-title-alias: '[[Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] Textile Shop [[Fire]]'
---

# [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] Textile Shop [[fire]]

2022-06-30  
[[fire]]

https://www.ivanovonews.ru/news/1152464/  
The message about the [[fire]] in building No. 70 on Okulova Street in [[Ivanovo]] was received by the Crisis Management Center on June 30 at 01.58. At the time of arrival of the first [[fire]] and [[rescue]] units, there was a [[fire|burning]] inside the workshop. According to the Ministry of Emergency Situations for the [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] region, at 03.04 the open [[fire|burning]] was liquidated. As a result of the [[fire]], [[textile]] waste on an area of 30 square meters was [[damaged]]. No one was hurt. 42 people and 14 pieces of equipment were involved in extinguishing.  
building No. 70 on Okulova Street, [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]]

Although [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Иваново]] ([[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]]) is not as prestigious as other cities of Золотое кольцо (the [[Golden Ring]]), it is still worth a stop. [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] is шутливо называют городом невест (jokingly called the “City of the brides”). The reason of such a nickname come from the fact that [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] is the leading national producer of cotton fabrics, and textile workers are mainly women. Thus, the main population of the city are women. https://ruslanguage.ru/blog/ivanovo-the-textile-capital-of-russia/

~+~  
146
