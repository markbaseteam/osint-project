---
locations:
aliases: ['[[Maps/Vyborgsky District, Saint Petersburg, Northwestern Federal District, Russia|Vyborgsky]] Orthodox Church St Petersburg']
location: Vyborgsky district, Priozerskoye [[roads|highway]], house 12, building 1, St Petersburg
title: '[[Maps/Vyborgsky District, Saint Petersburg, Northwestern Federal District, Russia|Vyborgsky]] Orthodox Church St Petersburg'
tag: fire, cultural
date: 2022-06-26  
linter-yaml-title-alias: '[[Maps/Vyborgsky District, Saint Petersburg, Northwestern Federal District, Russia|Vyborgsky]] Orthodox Church St Petersburg'
---

# [[OSINT Project/Maps/Vyborgsky District, Saint Petersburg, Northwestern Federal District, Russia|Vyborgsky]] Orthodox Church St Petersburg

2022-06-26  
[[fire]]  
Cultural  
https://apolline-petit.com/in-st-petersburg-eliminated-the-fire-in-the-orthodox-church  
Same church? Does not seem so. [[fire]] in an Orthodox church in the [[OSINT Project/Maps/Vyborgsky District, Saint Petersburg, Northwestern Federal District, Russia|Vyborgsky]] district of St. Petersburg has been extinguished. This was reported on June 26 by the press service of the Main Directorate of the Ministry of Emergency Situations in the city. It is noted that the message about the [[fire]] at the address: [[OSINT Project/Maps/Vyborgsky District, Saint Petersburg, Northwestern Federal District, Russia|Vyborgsky]] district, Priozerskoye [[roads|highway]], house 12, building 1 was received at 06:05. “In a brick, sheathed with wood, measuring 33 × 6 meters, built in 2016, the building of the church, the roof is on [[fire]] throughout the area”the message says.  
[[OSINT Project/Maps/Vyborgsky District, Saint Petersburg, Northwestern Federal District, Russia|Vyborgsky]] district, Priozerskoye [[roads|highway]], house 12, building 1, St Petersburg

~+~  
101
