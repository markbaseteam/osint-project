---
locations:
aliases: ['DM Tower Business Center on [[Moscow]]''s Novodanilovskaya embankment']
location:
title: 'DM Tower Business Center on [[Moscow]]''s Novodanilovskaya embankment'
tag: 
date:
linter-yaml-title-alias: 'DM Tower Business Center on [[Moscow]]''s Novodanilovskaya embankment'
---

# DM Tower Business Center on [[Moscow]]'s Novodanilovskaya embankment

2022-05-16  
[[fire]]  
Elite  
https://news.italy-24.com/world/452031.html  
DM Tower Business Center on [[Moscow]]'s Novodanilovskaya embankment is on [[fire]]. 18-stories & under construction. [[fire]] on the top floor according to a construction worker.  
Novodanilovskaya embankment, [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

~+~  
186
