---
locations:
aliases:
  - Voronezh Recruitment Office
location: No. 47, 9 Januwara Street, Voronezh
title: Voronezh Recruitment Office
tag: molotov
date: 2022-03-02  
linter-yaml-title-alias: Voronezh Recruitment Office
---

 90

# Voronezh Recruitment Office

2022-03-02  
Molotov  
Recruitment  
https://enoughisenough14.org/2022/06/26/shortly-after-the-longest-night-of-the-year-two-recruiting-offices-burned-at-once-chronicle-of-arson-attacks-until-june-25-2022-russia/  
On the evening of March 2, near the house No. 47 on 9 Januwara Street in Voronezh, an unknown person smashed a glass canister with a flammable liquid against the entrance door of the Office for Military Registration and Recruitment of two city districts, then set [[fire]] and fled. The [[fire]] damaged a part of the door; there were no casualties. The partisan escaped. Unfortunately, the face of the suspected arsonist was captured on a surveillance camera, and the police are now trying to identify him. https://enoughisenough14.org/2022/03/14/russia-new-guerrilla-attacks-on-military-recruiting-agencies/ An unknown person threw a canister with a flammable liquid against the door of a building, which then caught [[fire]] and was damaged by the [[fire]]. No one was injured. On March 3, pro-government telegram channels devoted to the work of law enforcement agencies reported that in Voronezh, an unknown person broke a can of flammable liquid at the front door of the military registration and enlistment office. When the [[fire]] went out, the arsonist fled, argued channel “OPER leaked”. “The [[fire]] damaged part of the door, fortunately, there is no damage,” the authors of the entry say. Accessing links to telegram channels wrote local edition “News of Voronezh”. There are no other details about the incident. https://europe-cities.com/2022/05/04/in-russia-after-the-invasion-of-ukraine-they-began-to-set-fire-to-military-registration-and-enlistment-offices/  
No. 47, 9 Januwara Street, Voronezh

Two dates - March 2 & 3. Used earliest date. On March 3, pro-government telegram channels devoted to the work of law enforcement agencies reported that in Voronezh, an unknown person broke a can of flammable liquid at the front door of the military registration and enlistment office. When the [[fire]] went out, the arsonist fled, argued channel “OPER leaked”. “The [[fire]] damaged part of the door, fortunately, there is no damage,” the authors of the entry say. Accessing links to telegram channels wrote local edition “News of Voronezh”. There are no other details about the incident. https://europe-cities.com/2022/05/04/in-russia-after-the-invasion-of-ukraine-they-began-to-set-fire-to-military-registration-and-enlistment-offices/  
~+~  
129
