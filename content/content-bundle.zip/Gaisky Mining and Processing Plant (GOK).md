---
locations:
aliases: 
location:
title: Gaisky Mining and Processing Plant (GOK)
tag: explosion, mining, metals, minerals
date:
---

# Gaisky Mining and Processing Plant (GOK)

2022-04-23  
Explosion  
Other  
https://www.republicworld.com/world-news/rest-of-the-world-news/russia-explosion-at-mining-plant-in-orenburg-kills-three-people-rescuers-working-on-site-articleshow.html  
loud explosion at the Gaisky Mining and Processing Plant (GOK) in the Orenburg Region. during mining and blasting, an emergency detonation of an explosive occurred at a depth of 1.2 km. An investigation was ordered into the incident to establish the cause of the blast. There were no external injuries on the bodies of the dead. After the explosion, the shift of the workers was already over, and hence no formal evacuation procedures had to be activated. A source from emergency services informed TASS that the explosion may have been caused due to violation of safety regulations during mining and blasting.  
Orenburg Region

Jury still out on cause/intention. Russia is the world’s sixth-largest coal producer Nearly 34% out of 58 coal mines in Russia are vulnerable and dangerous, and are reported of neglect and safety breaches. working conditions in the former Soviet Union are appalling and miners were forced to cut corners on safety and work in a dangerous environment for the sake of "productivity". Underground miners in Russia’s coal industry are paid 15,000 rubles ($575) while 70% of income is handed as “bonuses” which makes working conditions for the laborers worse.

~+~  
173
