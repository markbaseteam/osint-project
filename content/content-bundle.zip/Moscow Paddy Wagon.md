---
locations:
aliases: ['[[Maps/Moscow, Central Federal District, Russia|Moscow]] Paddy Wagon']
location:
title: '[[Maps/Moscow, Central Federal District, Russia|Moscow]] Paddy Wagon'
tag: molotov, government
date: 2022-05-02  
linter-yaml-title-alias: '[[Maps/Moscow, Central Federal District, Russia|Moscow]] Paddy Wagon'
---

# [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]] Paddy Wagon

2022-05-02  
Molotov  
Government  
https://libcom.org/article/anticipation-general-mobilization-7th-overview-anti-military-sabotage-russia  
The attacker of that paddy wagon yesterday was [[arrested|detained]] nearby. Telegram channel ASTRA writes that it was an [[anti-war]] action of a graduate of the Faculty of Philosophy of the [[Russian State University]] for the Humanities. His name is Vitaly Koltsov, to throw a Molotov cocktail he went in a suit and with a suitcase. Before it, he published a poetry about fiery hearts that illuminate the darkness: If the day goes out forever - our glory will not fade Death is given only once, we will choose it as we like To see in the end how the desert lit up Rising luminary of our fiery hearts  
[[Moscow]]?

See also https://t.me/astrapress/3794 45-years-old Vitaly Koltsov is the father of three children. A criminal case was initiated against him under Art. 317 of the Criminal Code (encroachment on the life of a law enforcement officer). Нe faces up to 20 years of [[prison]]. Previously, he had already participated in anti-government protests: in 2017 was [[arrested]] for disobeying the cops, and in 2019 for violating the “established order” for holding rallies.

~+~  
147
