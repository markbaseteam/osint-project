---
locations:
aliases: ['[[Maps/Khanty-Mansiysk, Khanty-Mansiysk Urban Okrug, Khanty-Mansiysk Autonomous Okrug – Ugra, Ural Federal District, 628000, Russia|Khanty-Mansi]] Autonomous Okrug Recruitment office']
location:
title: '[[Maps/Khanty-Mansiysk, Khanty-Mansiysk Urban Okrug, Khanty-Mansiysk Autonomous Okrug – Ugra, Ural Federal District, 628000, Russia|Khanty-Mansi]] Autonomous Okrug Recruitment office'
tag: molotov, recruitment
date: 2022-05-13  
linter-yaml-title-alias: '[[Maps/Khanty-Mansiysk, Khanty-Mansiysk Urban Okrug, Khanty-Mansiysk Autonomous Okrug – Ugra, Ural Federal District, 628000, Russia|Khanty-Mansi]] Autonomous Okrug Recruitment office'
---

# [[OSINT Project/Maps/Khanty-Mansiysk, Khanty-Mansiysk Urban Okrug, Khanty-Mansiysk Autonomous Okrug – Ugra, Ural Federal District, 628000, Russia|Khanty-Mansi]] Autonomous Okrug Recruitment office

2022-05-13  
Molotov  
Recruitment  
https://www.rferl.org/a/russia-enlistment-offices-arson/31851677.html

[[OSINT Project/Maps/Khanty-Mansiysk, Khanty-Mansiysk Urban Okrug, Khanty-Mansiysk Autonomous Okrug – Ugra, Ural Federal District, 628000, Russia|Khanty-Mansi]], Tyumen Oblast  
62°15′N 70°10′E  
[[OSINT Project/Maps/Khanty-Mansiysk, Khanty-Mansiysk Urban Okrug, Khanty-Mansiysk Autonomous Okrug – Ugra, Ural Federal District, 628000, Russia|Khanty-Mansi]]/Khanty-Mansiysky Autonomous Okrug-Yugra - Autonomous Okrug of Tyumen Oblast In 2012, the majority (51%) of the oil produced in Russia came from [[OSINT Project/Maps/Khanty-Mansiysk, Khanty-Mansiysk Urban Okrug, Khanty-Mansiysk Autonomous Okrug – Ugra, Ural Federal District, 628000, Russia|Khanty-Mansi Autonomous Okrug]] It borders Yamalo-Nenets Autonomous Okrug to the north, Komi Republic to the northwest, Sverdlovsk Oblast to the west, Tyumen Oblast to the south, Tomsk Oblast to the south and southeast and [[OSINT Project/Maps/Krasnoyarsk, Krasnoyarsk Urban Okrug, Krasnoyarsk Krai, Siberian Federal District, 660000, Russia|Krasnoyarsk]] Krai in the east. In [[OSINT Project/Maps/Khanty-Mansiysk, Khanty-Mansiysk Urban Okrug, Khanty-Mansiysk Autonomous Okrug – Ugra, Ural Federal District, 628000, Russia|Khanty-Mansi Autonomous Okrug]], the primary transport of goods is by [[water]] and railway transport; 29% is transported by [[roads|road]], and 2% by aviation. The total length of railway tracks is 1,106 km. The length of [[roads]] is more than 18,000 km.

~+~  
39
