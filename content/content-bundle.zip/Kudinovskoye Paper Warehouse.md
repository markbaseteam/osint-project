---
locations:
aliases: 
location: Kudinovskoye highway, Bogorodsky urban district, Moscow region
title: Kudinovskoye Paper Warehouse
tag: fire, warehouse, paper
date: 2022-05-03  
---

# Kudinovskoye Paper Warehouse

2022-05-03  
[[fire]]  
Other  
https://www.world-today-news.com/in-the-suburbs-a-strong-fire-broke-out-in-a-huge-warehouse-mir-tsn-ua/  
The area of ​​ignition is more than 25 thousand square meters. paper warehouse. On the night of May 3, a [[fire]] broke out in a warehouse on Kudinovskoye [[roads|highway]] in the [[OSINT Project/Maps/Bogorodsky city district, Moscow Oblast, Central Federal District, Russia|Bogorodsky]] urban district of the [[Moscow]] region, the building is [[fire|burning]] throughout the area. According to propaganda media, the [[fire]] started on the territory of the Atlant Park industrial and warehouse complex in [[OSINT Project/Maps/Bogorodsky city district, Moscow Oblast, Central Federal District, Russia|Bogorodskoye]]  
Kudinovskoye [[roads|highway]], [[OSINT Project/Maps/Bogorodsky city district, Moscow Oblast, Central Federal District, Russia|Bogorodsky]], [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

The warehouse is located in a section dedicated to logistics and distribution. https://www.express.co.uk/news/world/1604413/russia-fire-vladimir-putin-news-industrial-building-Bogorodsky-moscow-oblast-latest == Reported elsewhere in channels that the company had contracts for government paper supplies including conscript offices. This is not confirmed.

~+~  
65
