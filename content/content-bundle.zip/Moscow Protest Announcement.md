---
locations:
aliases: ['[[Maps/Moscow, Central Federal District, Russia|Moscow]] Protest Announcement']
location:
title: '[[Maps/Moscow, Central Federal District, Russia|Moscow]] Protest Announcement'
tag: protest
date: 2022-03-01 
linter-yaml-title-alias: '[[Maps/Moscow, Central Federal District, Russia|Moscow]] Protest Announcement'
---

# [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]] Protest Announcement

2022-03-01  
Protest  
Other  
https://libcom.org/article/new-bottom-resistance-russia-and-belarus-genocide-ukraine-part-5  
March 31, in [[Moscow]], Javid Mamedov from the Socialist Alternative was [[arrested|detained]] while leaving home for work. The next day, he was [[arrested]] for 30 days due to “repeating the rules for holding public actions" - because on March 1, he reposted on Instagram the announcement of March 6 protest rally with the inscription "Silence is war". Earlier, Javid was [[arrested|imprisoned]] for 7 days for participation in the [[anti-war]] campaign.  
[[Moscow]]

~+~  
124
