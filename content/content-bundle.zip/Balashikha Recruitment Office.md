---
locations:
aliases: 
location:
title: Balashikha Recruitment Office
tag: 
date:
---

# Balashikha Recruitment Office

2022-05-10  
Molotov  
Recruitment  
https://libcom.org/article/emancipative-fire-and-call-solidarity-persecuted-comrades-8th-review-anti-war-sabotage  
On the evening of May 10, a Molotov cocktail flew into the window of a similar facility in Balashikha. A [[fire]] started in the corridor, the [[fire]] was unfortunately extinguished by a guard who came to the rescue, but the arsonist was not captured. In addition to Balashikha, this office is also responsible for conscription in the neighboring town of Reutov.  
Balashikha

~+~  
37
