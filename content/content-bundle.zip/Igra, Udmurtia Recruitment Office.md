---
locations:
aliases: 
location:
title: 'Igra, Udmurtia Recruitment Office'
tag: molotov, recruitment
date:
---

# Igra, Udmurtia Recruitment Office

2022-05-21  
Molotov  
Recruitment  
https://theins.ru/news/251473  
in Udmurtia (Russia) on the night of May 22, there was a [[fire]] in the military registration and enlistment office, fragments of a Molotov cocktail were found at the scene. In Russia, such cases have become more frequent due to mobilization. https://globalhappenings.com/top-global-news/196541.html = the entire reserve room [[fire|burned]] out (a little over 9 square meters). Unfortunately, there were no documents in the room, only personal belongings of the employees. = On the night of May 21, unknown persons set [[fire]] to the military registration and conscription office in the settlement of Igra in Udmurtia by throwing a “Molotov cocktail” into the building. In a successful action, the room for reservists in the building went completely up in flames during the [[fire]]. https://enoughisenough14.org/2022/06/26/shortly-after-the-longest-night-of-the-year-two-recruiting-offices-burned-at-once-chronicle-of-arson-attacks-until-june-25-2022-russia/  
Igra, Udmurtia

Date discrepancy - 21 & 22 May. Used earliest date. AKA Udmurtskaya Rural teacher Ilya Farber, who is suspected of an [[fire|arson]] attack against a military call-up center in Udmirtiya is being held in remand [[prison]] # 1 in the city if Izhevsk. He is accused of ”destruction of property”. https://avtonom.org/en/news/support-suspected-arsonists-against-military-call-ups-and-other-russian-anti-war-prisoners A few days later, the FSB [[arrested|detained]] a suspect: 48-year-old Ilya Farber, who came to visit relatives living in Igra. The man has been searched, during it two canisters of gasoline, wire, potassium permanganate, funnels, five bank cards and three iPhones were seized. Farber is a painter and former director of a rural house of [[civilizations|culture]] in the Tver region. In 2013, he was convicted of abuse of office and taking a bribe. The case had clear signs of falsification and got a wide resonance. Even Putin called his sentence "outrageous"! https://libcom.org/article/arise-ukrainian-comrades-anti-war-direct-actions-russia-and-its-9th-review Video of interrogation https://t.me/bazabazon/11799

~+~  
49
