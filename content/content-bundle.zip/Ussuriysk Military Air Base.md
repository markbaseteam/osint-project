---
locations:
aliases: ['Ussuriysk Military [[Air Base]]']
location: Military Air Base in Ussuriysk
title: 'Ussuriysk Military [[Air Base]]'
tag: fire, military
date: 2022-04-25  
linter-yaml-title-alias: 'Ussuriysk Military [[Air Base]]'
---

# Ussuriysk Military [[air base]]

2022-04-25  
[[fire]]  
Military  
https://www.intellinews.com/russia-on-fire-is-ukraine-giving-moscow-a-taste-of-its-own-medicine-242882/  
Military [[air base]] in Ussuriysk. the [[fire]] in Ussuriysk thousands of kilometres from Ukraine's border and the discovery of a mine by a railway track in Bryansk the following day have added credibility to the theory that there are saboteurs carrying out attacks on the ground in Russia.  
Ussuriysk

According to InformNapalm, Russia is attacking itself with false flags & is preparing to bring in wreckage of Ukrainian [[aircraft|helicopters]] and drones to place as "proof". Other claims made are that top military and families were evacuated April 19th in preparation. Focus areas Belgorod, [[OSINT Project/Maps/Kursk, Kursk Oblast, Central Federal District, 305000, Russia|Kursk]], Bryansk Oblasts especially civilian and residential areas

~+~  
91
