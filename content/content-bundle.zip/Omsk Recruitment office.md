---
locations:
aliases: ['[[Maps/Omsk, Omsk Oblast, Siberian Federal District, 644000, Russia|Omsk]] Recruitment office']
location: Pushkin Street, 78, Omsk
title: '[[Maps/Omsk, Omsk Oblast, Siberian Federal District, 644000, Russia|Omsk]] Recruitment office'
tag: molotov, recruitment
date: 2022-05-13  
linter-yaml-title-alias: '[[Maps/Omsk, Omsk Oblast, Siberian Federal District, 644000, Russia|Omsk]] Recruitment office'
---

# [[OSINT Project/Maps/Omsk, Omsk Oblast, Siberian Federal District, 644000, Russia|Omsk]] Recruitment office

2022-05-13  
Molotov  
Recruitment  
https://enoughisenough14.org/2022/06/26/shortly-after-the-longest-night-of-the-year-two-recruiting-offices-burned-at-once-chronicle-of-arson-attacks-until-june-25-2022-russia/  
[[Omsk]] Molotov [[fire]] at Russian enlistment office in [[OSINT Project/Maps/Omsk, Omsk Oblast, Siberian Federal District, 644000, Russia|Omsk]] on Pushkin Street, 78. night of May 13, 2022 in [[OSINT Project/Maps/Omsk, Omsk Oblast, Siberian Federal District, 644000, Russia|Omsk]]. Two windows of the building were destroyed and traces of [[fire]] were found, but the [[fire]] was quickly extinguished. The suspects were not found. At least two windows were broken. A [[fire]] caught an area of 30 square meters and some archival documents were damaged.  
[[OSINT Project/Maps/Omsk, Omsk Oblast, Siberian Federal District, 644000, Russia|Omsk]] on Pushkin Street, 78

On the night of May 13, 2022 in [[OSINT Project/Maps/Omsk, Omsk Oblast, Siberian Federal District, 644000, Russia|Omsk]], [[Siberian Federal District|Siberia]], unknown individuals threw several molotovs through the windows of the Central District military registration and enlistment office at 74 Pushkin Street. At least two windows were broken. One of the premises of the military registration and enlistment office caught [[fire]] and an area of 30 square meters [[fire|burned]]. It is also reported that “some archive documents were damaged”. https://darknights.noblogs.org/post/2022/06/01/omsk-cherepovets-russia-two-new-recruitement-offices-hit-with-molotovs/

~+~  
24
