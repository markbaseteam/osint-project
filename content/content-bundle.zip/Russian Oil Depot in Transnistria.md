---
locations:
aliases: 
location:
title: Russian Oil Depot in Transnistria
tag: 
date:

---

# Russian Oil Depot in Transnistria

2022-05-12  
[[fire]]  
Gas/Oil

Occupied Transnistria - molotov attacks on Russian registration/enlistment office & an oil depot  
Transnistria

Suspected False Flag
