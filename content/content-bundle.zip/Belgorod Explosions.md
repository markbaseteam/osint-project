---
locations:
aliases: 
location:
title: Belgorod Explosions
tag: 
date:
---

# Belgorod Explosions

2022-03-29  
[[fire]]

local officials reported a series of explosions outside the Russian city of Belgorod, close to the border with Ukraine. It was later reported that those explosions may have been caused by a [[fire]] On 7 April, 2022:, the Investigative Committee of the Russian Federation claimed that the explosions were the result of a Ukrainian attack that used three Tochka-U tactical ballistic missiles. Eight people were injured and 21 [[automobiles|vehicles]] were destroyed.  
Belgorod

~+~  
177
