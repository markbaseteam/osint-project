---
aliases: 
location: Yаroslavl geo:57.6263877,39.8933705
category:Molotov
date:
tag: molotov, recruitment
---
[Yаroslavl](geo:57.6263877,39.8933705)

# Yаroslavl Recruitment Office

Molotov
Recruitment

[[fire]] at Yаroslavl Recruitment Office
Yаroslavl

Reported but need date