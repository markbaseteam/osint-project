---
locations:
aliases: ['[[Maps/Ishim, городской округ Ишим, Tyumen Oblast, Ural Federal District, 625756, Russia|Ishim]] shopping center']
location:
title: '[[Maps/Ishim, городской округ Ишим, Tyumen Oblast, Ural Federal District, 625756, Russia|Ishim]] shopping center'
tag: fire, political, elite
date: 2022-04-18 
linter-yaml-title-alias: '[[Maps/Ishim, городской округ Ишим, Tyumen Oblast, Ural Federal District, 625756, Russia|Ishim]] shopping center'
---

# [[OSINT Project/Maps/Ishim, городской округ Ишим, Tyumen Oblast, Ural Federal District, 625756, Russia|Ishim]] shopping center

2022-04-18  
[[fire]]  
Hearts & Minds,Elite  
https://news.cgtn.com/news/2022-04-28/Shopping-center-catches-fire-in-Russia-s-Ishim-19BAsIktOi4/index.html  
[[OSINT Project/Maps/Ishim, городской округ Ишим, Tyumen Oblast, Ural Federal District, 625756, Russia|Ishim]] shopping center A shopping center in [[OSINT Project/Maps/Ishim, городской округ Ишим, Tyumen Oblast, Ural Federal District, 625756, Russia|Ishim]] in Russia's Tyumen region caught [[fire]] on Thursday, RIA reported, citing the Ministry of Emergencies.  
[[OSINT Project/Maps/Ishim, городской округ Ишим, Tyumen Oblast, Ural Federal District, 625756, Russia|Ishim]], Tyumen

~+~  
5
