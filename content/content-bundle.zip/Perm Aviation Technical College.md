---
locations:
aliases: ['[[Maps/Perm, Perm Krai, Volga Federal District, Russia|Perm]] Aviation Technical College']
location:
title: '[[Maps/Perm, Perm Krai, Volga Federal District, Russia|Perm]] Aviation Technical College'
tag: fire, aerospace, aviation, education
date: 2022-05-08
linter-yaml-title-alias: '[[Maps/Perm, Perm Krai, Volga Federal District, Russia|Perm]] Aviation Technical College'
---

# [[OSINT Project/Maps/Perm, Perm Krai, Volga Federal District, Russia|Perm]] Aviation Technical College

2022-05-08  
[[fire]]  
Aerospace/Aviation,Education  
https://twitter.com/antiputler_news/status/1523279184369381378  
Construction site for the aviation technical school in [[Perm, Russia|Perm]] is [[fire|burning]]  
[[Perm, Russia|Perm]]

~+~  
17
