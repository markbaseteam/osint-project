---
locations:
aliases: ['FKP or PPZ Gunpowder Plant - [[Perm, Russia|Perm]]']
location: Perm, Russia
title: 'FKP or PPZ Gunpowder Plant - [[Perm, Russia|Perm]]'
tag: 
date:
linter-yaml-title-alias: 'FKP or PPZ Gunpowder Plant - [[Perm, Russia|Perm]]'
---

# FKP or PPZ Gunpowder Plant - [[Perm, Russia|Perm]]

2022-05-01  
[[fire]]  
Other Defence,Weapons

According to Newsweek, also on May 1, 2022:, at approximately 20:00 YEKT (15:00 UTC), the FPK [[OSINT Project/Maps/Perm, Perm Krai, Volga Federal District, Russia|Perm]] Powder plant in [[Perm, Russia]] exploded. According to official sources, a product caught [[fire]], causing the explosion. The resulting [[fire]] killed one worker instantly, gave one fatal injuries, and hospitalized another. Three other workers received injuries. The plant [[manufactured]] gunpowder. According to Newsweek, other sources allege that it may be the result of Ukrainian [[sabotage]]. == a [[fire]] occurred in the [[FKP Perm Powder Plant]] at the production site No. 12 of the [[Plastmassa]] production. As a result of the incident, 3 employees were injured, 1 of them died on the spot, 2 were taken to the hospital, ”the website of the inspection reports. Later, another worker died in the hospital. **Plastmassa are little tiny plastic pellets https://oopstop.com/due-to-an-emergency-at-the-perm-gunpowder-factory-workers-died/  
[[Perm, Russia|Perm]]

[[FKP AKA PPZ]] This same [[plant]] has had [[fires]] and [[explosions]] before (from [[waste water]]!!!) - The plant produces charges for multiple launch rocket systems, [[air defense systems]], [[engine charges]] for [[aircraft]] [[rockets]] & spherical [[gunpowder]] for [[small arms]]. - Described as "one of the greatest enterprises of the [[defense industry]] in Russia." - In addition to [[weapon systems]] - [[polyurethane]] [[elastoplastic]], [[coating]] systems, hard foam-[[polyurethane]] & [[shaft coatings]] Information on [[OSINT Project/Maps/Perm, Perm Krai, Volga Federal District, Russia|PERM]] Gunpowder Mill http://www.polyurethanex.com/13-perm-gunpowder-mill-federal-state-enterprise.html

~+~  
84
