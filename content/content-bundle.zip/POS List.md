---
aliases: ['Universal POS tags[home](http://universaldependencies.org/#language-u)']
locations:
tag: 
date:
title: 'Universal POS tags[home](http://universaldependencies.org/#language-u)'
linter-yaml-title-alias: 'Universal POS tags[home](http://universaldependencies.org/#language-u)'
---

[home](http://universaldependencies.org/#language-u) [issue tracker](https://github.com/universaldependencies/docs/issues)

---

This page pertains to UD version 2.

# Universal POS tags[](https://universaldependencies.org/u/pos/all.html#universal-pos-tags)

These tags mark the core part-of-speech categories. To distinguish additional lexical and grammatical properties of words, use the [universal features](https://universaldependencies.org/u/feat/index.html).

Open class words

Closed class words

Other

[ADJ](https://universaldependencies.org/u/pos/all.html#al-u-pos/ADJ "u-pos ADJ")

[ADP](https://universaldependencies.org/u/pos/all.html#al-u-pos/ADP "u-pos ADP")

[PUNCT](https://universaldependencies.org/u/pos/all.html#al-u-pos/PUNCT "u-pos PUNCT")

[ADV](https://universaldependencies.org/u/pos/all.html#al-u-pos/ADV "u-pos ADV")

[AUX](https://universaldependencies.org/u/pos/all.html#al-u-pos/AUX "u-pos AUX")

[SYM](https://universaldependencies.org/u/pos/all.html#al-u-pos/SYM "u-pos SYM")

[INTJ](https://universaldependencies.org/u/pos/all.html#al-u-pos/INTJ "u-pos INTJ")

[CCONJ](https://universaldependencies.org/u/pos/all.html#al-u-pos/CCONJ "u-pos CCONJ")

[X](https://universaldependencies.org/u/pos/all.html#al-u-pos/X "u-pos X")

[NOUN](https://universaldependencies.org/u/pos/all.html#al-u-pos/NOUN "u-pos NOUN")

[DET](https://universaldependencies.org/u/pos/all.html#al-u-pos/DET "u-pos DET")

 

[PROPN](https://universaldependencies.org/u/pos/all.html#al-u-pos/PROPN "u-pos PROPN")

[NUM](https://universaldependencies.org/u/pos/all.html#al-u-pos/NUM "u-pos NUM")

 

[VERB](https://universaldependencies.org/u/pos/all.html#al-u-pos/VERB "u-pos VERB")

[PART](https://universaldependencies.org/u/pos/all.html#al-u-pos/PART "u-pos PART")

 

 

[PRON](https://universaldependencies.org/u/pos/all.html#al-u-pos/PRON "u-pos PRON")

 

 

[SCONJ](https://universaldependencies.org/u/pos/all.html#al-u-pos/SCONJ "u-pos SCONJ")

 

---

## `ADJ`: adjective[](https://universaldependencies.org/u/pos/all.html#adj-adjective)

### Definition[](https://universaldependencies.org/u/pos/all.html#definition)

Adjectives are words that typically modify nouns and specify their properties or attributes:

_The **oldest French** bridge_

They may also function as predicates, as in:

_The car is **green**._

Some words that could be seen as adjectives (and are tagged as such in other annotation schemes) have a different tag in UD: See [DET](https://universaldependencies.org/u/pos/all.html#al-u-pos/DET "u-pos DET") for determiners and [NUM](https://universaldependencies.org/u/pos/all.html#al-u-pos/NUM "u-pos NUM") for (cardinal) numbers.

`ADJ` is also used for “proper adjectives” such as _European_ (“proper” as in proper nouns, i.e., words that are derived from names but are adjectives rather than nouns).

**Numbers vs. Adjectives:** In general, cardinal numbers receive the part of speech [NUM](https://universaldependencies.org/u/pos/all.html#al-u-pos/NUM "u-pos NUM"), while _ordinal numbers_ (more precisely _adjectival_ ordinal numerals) receive the tag `ADJ`.

There are words that may traditionally be called numerals in some languages (e.g., Czech) but which are treated as adjectives in our universal tagging scheme. In particular, the _adjectival_ ordinal numerals (note: Czech also has adverbial ones) behave both morphologically and syntactically as adjectives and are tagged `ADJ`.

**Nouns vs. Adjectives:** A noun modifying another noun to form a compound noun is given the tag [NOUN](https://universaldependencies.org/u/pos/all.html#al-u-pos/NOUN "u-pos NOUN") not `ADJ`. On the other hand, adjectives that exceptionally head a nominal phrase (as in _the sick, the healthy_) are still tagged `ADJ`.
**Participles:** Participles are word forms that may share properties and usage of any of adjectives, nouns, and verbs. Depending on the language and context, they may be classified as any of `ADJ`, [NOUN](https://universaldependencies.org/u/pos/all.html#al-u-pos/NOUN "u-pos NOUN") or [VERB](https://universaldependencies.org/u/pos/all.html#al-u-pos/VERB "u-pos VERB").
**Adjectival modifiers of adjectives:** In general, an `ADJ` is modified by an [ADV](https://universaldependencies.org/u/pos/all.html#al-u-pos/ADV "u-pos ADV") (_**very** strong_). However, sometimes a word modifying an `ADJ` is still regarded as an `ADJ`. These cases include: (i) ordinal numeral modifiers of a superlative adjective (_the **third** oldest bridge_) and (ii) when a pair of adjectives form a compound adjectival modifier (_an **African American** mayor_).

### Examples[](https://universaldependencies.org/u/pos/all.html#examples)

- _big_
- _old_
- _green_
- _African_
- _incomprehensible_
- _first, second, third_

### References[](https://universaldependencies.org/u/pos/all.html#references)

- [Loos, Eugene E., et al. 2003. Glossary of linguistic terms: What is an adjective?](https://glossary.sil.org/term/adjective)
- [Wikipedia](http://en.wikipedia.org/wiki/Adjective)

[edit ADJ](https://github.com/universaldependencies/docs/edit/pages-source/_u-pos/ADJ.md)

## `ADP`: adposition[](https://universaldependencies.org/u/pos/all.html#adp-adposition)

### Definition[](https://universaldependencies.org/u/pos/all.html#definition)

Adposition is a cover term for prepositions and postpositions. Adpositions belong to a closed set of items that occur before (preposition) or after (postposition) a complement composed of a noun phrase, noun, pronoun, or clause that functions as a noun phrase, and that form a single structure with the complement to express its grammatical and semantic relation to another unit within a clause.

In many languages, adpositions can take the form of fixed multiword expressions, such as _in spite of_, _because of_, _thanks to_. The component words are then still tagged according to their basic use (_in_ is `ADP`, _spite_ is [NOUN](https://universaldependencies.org/u/pos/all.html#al-u-pos/NOUN "u-pos NOUN"), etc.) and their status as multiword expressions are accounted for in the syntactic annotation.

Note that in Germanic languages, some prepositions may also function as verbal particles, as in _give **in**_ or _hold **on**_. They are still tagged `ADP` and not [PART](https://universaldependencies.org/u/pos/all.html#al-u-pos/PART "u-pos PART").

A common pathway of grammaticalization is from verbs to adpositions. Along this pathway of grammaticalization, it is common to have words with roughly their original verbal meaning and belonging to the inflectional paradigm of an extant verb with suitable verbal morphology but functioning in a sentence as a preposition, with certain syntactic tests or finer-grained semantic criteria suggesting that they are prepositions (for example, they have no understood subject). These words have variously been called **deverbal prepositions**, **deverbal connectives**, **quasi-prepositions**, or **pseudo-prepositions**. In English this includes words like _following_, _concerning_, _regarding_, and _given_. Similar cases occur in many other languages (such as French _concernant_ and _suivant_). For UD, we have decided that such words will be given the POS [VERB](https://universaldependencies.org/u/pos/all.html#al-u-pos/VERB "u-pos VERB") and normal verbal morphological features, but they can be recognized as syntactically adpositions by giving them the grammatical relation [case](https://universaldependencies.org/u/dep/case.html "u-dep case") or [mark](https://universaldependencies.org/u/dep/mark.html "u-dep mark"). Conversely, in cases where there is no longer an extant verb or any still existent verb has a quite different meaning, grammaticalization is viewed as complete and the POS should be [ADP](https://universaldependencies.org/u/pos/all.html#al-u-pos/ADP "u-pos ADP"). In English this would apply to _pending_ or _during_ (from the disused verb _dure_: “The wood being preserv’d dry will dure a very long time”–Evelyn 1664).

### Examples[](https://universaldependencies.org/u/pos/all.html#examples)

- _in_
- _to_
- _during_

### References[](https://universaldependencies.org/u/pos/all.html#references)

- [Loos, Eugene E., et al. 2003. Glossary of linguistic terms: What is an adposition?](https://glossary.sil.org/term/adposition)
- [Wikipedia](http://en.wikipedia.org/wiki/Preposition_and_postposition)

[edit ADP](https://github.com/universaldependencies/docs/edit/pages-source/_u-pos/ADP.md)

## `ADV`: adverb[](https://universaldependencies.org/u/pos/all.html#adv-adverb)

### Definition[](https://universaldependencies.org/u/pos/all.html#definition)

Adverbs are words that typically modify [verbs](https://universaldependencies.org/u/pos/all.html#al-u-pos/VERB "u-pos VERB") for such categories as time, place, direction or manner. They may also modify [adjectives](https://universaldependencies.org/u/pos/all.html#al-u-pos/ADJ "u-pos ADJ") and other adverbs, as in _**very briefly**_ or _**arguably** wrong_.

There is a closed subclass of _pronominal adverbs_ that refer to circumstances in context, rather than naming them directly; similarly to pronouns, these can be categorized as interrogative, relative, demonstrative etc. Pronominal adverbs also get the `ADV` part-of-speech tag but they are differentiated by additional features.

Note that in Germanic languages, some adverbs may also function as verbal particles, as in _write **down**_ or _end **up**_. They are still tagged `ADV` and not [PART](https://universaldependencies.org/u/pos/all.html#al-u-pos/PART "u-pos PART").

Note that there are words that may be traditionally called numerals in some languages (e.g. Czech) but they are treated as adverbs in our universal tagging scheme. In particular, _adverbial ordinal numerals_ ([cs] _poprvé_ “for the first time”) and _multiplicative numerals_ (e.g. _once, twice_) behave syntactically as adverbs and are tagged `ADV`.

Note that there are verb forms such as _transgressives_ or _adverbial participles_ that share properties and usage of adverbs and verbs. Depending on language and context, they may be classified as either [VERB](https://universaldependencies.org/u/pos/all.html#al-u-pos/VERB "u-pos VERB") or `ADV`.

### Examples[](https://universaldependencies.org/u/pos/all.html#examples)

- _very_
- _well_
- _exactly_
- _tomorrow_
- _up, down_
- interrogative adverbs: _where, when, how, why_
- demonstrative adverbs: _here, there, now, then_
- indefinite adverbs: _somewhere, sometime, anywhere, anytime_
- totality adverbs: _everywhere, always_
- negative adverbs: _nowhere, never_

### References[](https://universaldependencies.org/u/pos/all.html#references)

- [Loos, Eugene E., et al. 2003. Glossary of linguistic terms: What is an adverb?](https://glossary.sil.org/term/adverb-grammar)
- [Wikipedia](http://en.wikipedia.org/wiki/Adverb)

[edit ADV](https://github.com/universaldependencies/docs/edit/pages-source/_u-pos/ADV.md)

## `AUX`: auxiliary[](https://universaldependencies.org/u/pos/all.html#aux-auxiliary)

### Definition[](https://universaldependencies.org/u/pos/all.html#definition)

An auxiliary is a function word that accompanies the lexical verb of a verb phrase and expresses grammatical distinctions not carried by the lexical verb, such as person, number, tense, mood, aspect, voice or evidentiality. It is often a verb (which may have non-auxiliary uses as well) but many languages have nonverbal TAME markers and these should also be tagged `AUX`. The class `AUX` also include copulas (in the narrow sense of pure linking words for nonverbal predication).

_Modal verbs_ may count as auxiliaries in some languages (English). In other languages their behavior is not too different from the [main verbs](https://universaldependencies.org/u/pos/all.html#al-u-pos/VERB "u-pos VERB") and they are thus tagged `VERB`.

Note that not all languages have grammaticalized auxiliaries, and even where they exist the dividing line between full verbs and auxiliaries can be expected to vary between languages. Exactly which words are counted as `AUX` should be part of the language-specific documentation.

### Examples[](https://universaldependencies.org/u/pos/all.html#examples)

- Tense auxiliaries: _**has** (done), **is** (doing), **will** (do)_
- Passive auxiliaries: _**was** (done), **got** (done)_
- Modal auxiliaries: _**should** (do), **must** (do)_
- Verbal copulas: _He **is** a teacher._

### References[](https://universaldependencies.org/u/pos/all.html#references)

- [Loos, Eugene E., et al. 2003. Glossary of linguistic terms: What is an auxiliary verb?](http://www-01.sil.org/linguistics/GlossaryOfLinguisticTerms/WhatIsAnAuxiliaryVerb.htm)
- [Wikipedia](http://en.wikipedia.org/wiki/Auxiliary_verb)

[edit AUX](https://github.com/universaldependencies/docs/edit/pages-source/_u-pos/AUX_.md)

## `CCONJ`: coordinating conjunction[](https://universaldependencies.org/u/pos/all.html#cconj-coordinating-conjunction)

### Definition[](https://universaldependencies.org/u/pos/all.html#definition)

A coordinating conjunction is a word that links words or larger constituents without syntactically subordinating one to the other and expresses a semantic relationship between them.

For _subordinating conjunctions,_ see [SCONJ](https://universaldependencies.org/u/pos/all.html#al-u-pos/SCONJ "u-pos SCONJ").

### Examples[](https://universaldependencies.org/u/pos/all.html#examples)

- _and_
- _or_
- _but_

### References[](https://universaldependencies.org/u/pos/all.html#references)

- [Loos, Eugene E., et al. 2003. Glossary of linguistic terms: What is a coordinating conjunction?](http://www-01.sil.org/linguistics/GlossaryOfLinguisticTerms/WhatIsACoordinatingConjunction.htm)
- [Wikipedia](http://en.wikipedia.org/wiki/Conjunction_(grammar))

[edit CCONJ](https://github.com/universaldependencies/docs/edit/pages-source/_u-pos/CCONJ.md)

## `DET`: determiner[](https://universaldependencies.org/u/pos/all.html#det-determiner)

### Definition[](https://universaldependencies.org/u/pos/all.html#definition)

Determiners are words that modify [nouns](https://universaldependencies.org/u/pos/all.html#al-u-pos/NOUN "u-pos NOUN") or noun phrases and express the reference of the noun phrase in context. That is, a determiner may indicate whether the noun is referring to a definite or indefinite element of a class, to a closer or more distant element, to an element belonging to a specified person or thing, to a particular number or quantity, etc.

Determiners under this definition include both _articles_ and _pro-adjectives (pronominal adjectives)_, which is a slightly broader sense than what is usually regarded as determiners in English. In particular, there is no general requirement that a nominal can be modified by at most one determiner, although some languages may show a strong tendency towards such a constraint. (For example, an English nominal usually allows only one `DET`modifier, but there are occasional cases of _addeterminers_, which appear outside the usual determiner, such as [en] _all_ in _**all** the children survived_. In such cases, both _all_ and _the_ are given the POS `DET`.)

Note that the `DET` tag includes (pronominal) _quantifiers_ (words like _many, few, several),_ which are included among determiners in some languages but may belong to numerals in others. However, _cardinal numerals_ in the narrow sense _(one, five, hundred)_ are not tagged `DET` even though some authors would include them in quantifiers. Cardinal numbers have their own tag [NUM](https://universaldependencies.org/u/pos/all.html#al-u-pos/NUM "u-pos NUM").

Also note that the notion of determiners is unknown in traditional grammar of some languages (e.g. Czech); words equivalent to English determiners may be traditionally classified as [pronouns](https://universaldependencies.org/u/pos/all.html#al-u-pos/PRON "u-pos PRON") and/or [numerals](https://universaldependencies.org/u/pos/all.html#al-u-pos/NUM "u-pos NUM") in these languages. In order to annotate the same thing the same way across languages, the words satisfying our definition of determiners should be tagged `DET` in these languages as well.

It is not always crystal clear where pronouns end and determiners start. Unlike in UD v1 it is no longer required that they are told apart solely on the base of the context. The words can be pre-classified in the dictionary as either `PRON` or `DET`, based on their _typical_ syntactic distribution (and morphology, when applicable). Language-specific documentation should list all determiners (it is a closed class) and point out ambiguities, if any.

See also [general principles on pronominal words](https://universaldependencies.org/u/overview/morphology.html#pronominal-words) for more tips on how to define determiners. In particular:

- Articles _(the, a, an)_ are always tagged `DET`; their [PronType](https://universaldependencies.org/u/feat/PronType.html) is `Art`.
- Pronominal numerals (quantifiers) are tagged `DET`; besides `PronType`, they also use the [NumType](https://universaldependencies.org/u/feat/NumType.html) feature.
- Words that behave similar to adjectives are `DET`. Similar behavior means:
    - They are more likely to be used attributively (modifying a noun phrase) than substantively (replacing a noun phrase). They may occur alone, though. If they do, it is either because of ellipsis, or because the hypothetical modified noun is something unspecified and general, as in _All [visitors] must pay._
    - Their inflection (if applicable) is similar to that of adjectives, and distinct from nouns. They agree with the nouns they modify. Especially the ability to inflect for gender is typical for adjectives and determiners. (Gender of nouns is determined lexically and determiners may be required by the grammar to agree with their nouns in gender; therefore they need to inflect for gender.)
- Possessives vary across languages. In some languages the above tests put them in the `DET` category. In others, they are more like a normal personal pronoun in a specific case (often the genitive), or a personal pronoun with an adposition; they are tagged `PRON`.

### Examples[](https://universaldependencies.org/u/pos/all.html#examples)

- articles (a closed class indicating definiteness, specificity or givenness): _a, an, the_
- possessive determiners (which modify a nominal): [cs] _můj, tvůj, jeho, její, náš, váš, jejich_; [en] _my, your_
- demonstrative determiners: _this_ as in _I saw **this** car yesterday._
- interrogative determiners: _which_ as in _“**Which** car do you like?”_
- relative determiners: _which_ as in _“I wonder **which** car you like.”_
- quantity determiners (quantifiers): indefinite _any_, universal: _all_, and negative _no_ as in _“We have **no** cars available.”_

### References[](https://universaldependencies.org/u/pos/all.html#references)

- [Loos, Eugene E., et al. 2003. Glossary of linguistic terms: What is a determiner?](http://www-01.sil.org/linguistics/GlossaryOfLinguisticTerms/WhatIsADeterminer.htm)
- [Wikipedia](http://en.wikipedia.org/wiki/Determiner)

[edit DET](https://github.com/universaldependencies/docs/edit/pages-source/_u-pos/DET.md)

## `INTJ`: interjection[](https://universaldependencies.org/u/pos/all.html#intj-interjection)

### Definition[](https://universaldependencies.org/u/pos/all.html#definition)

An interjection is a word that is used most often as an exclamation or part of an exclamation. It typically expresses an emotional reaction, is not syntactically related to other accompanying expressions, and may include a combination of sounds not otherwise found in the language.

Note that words primarily belonging to another part of speech retains their original category when used in exclamations. For example, _God_ is a [NOUN](https://universaldependencies.org/u/pos/all.html#al-u-pos/NOUN "u-pos NOUN") even in exclamatory uses.

As a special case of interjections, we recognize feedback particles such as _yes_, _no_, _uhuh_, etc.

### Examples[](https://universaldependencies.org/u/pos/all.html#examples)

- _psst_
- _ouch_
- _bravo_
- _hello_

### References[](https://universaldependencies.org/u/pos/all.html#references)

- [Loos, Eugene E., et al. 2003. Glossary of linguistic terms: What is an interjection?](http://www-01.sil.org/linguistics/GlossaryOfLinguisticTerms/WhatIsAnInterjection.htm)
- [Wikipedia](http://en.wikipedia.org/wiki/Interjection)

[edit INTJ](https://github.com/universaldependencies/docs/edit/pages-source/_u-pos/INTJ.md)

## `NOUN`: noun[](https://universaldependencies.org/u/pos/all.html#noun-noun)

### Definition[](https://universaldependencies.org/u/pos/all.html#definition)

Nouns are a part of speech typically denoting a person, place, thing, [[animals|animal]] or idea.

The `NOUN` tag is intended for common nouns only. See [PROPN](https://universaldependencies.org/u/pos/all.html#al-u-pos/PROPN "u-pos PROPN") for proper nouns and [PRON](https://universaldependencies.org/u/pos/all.html#al-u-pos/PRON "u-pos PRON") for pronouns.

Note that some verb forms such as _gerunds_ and _infinitives_ may share properties and usage of nouns and verbs. Depending on language and context, they may be classified as either [VERB](https://universaldependencies.org/u/pos/all.html#al-u-pos/VERB "u-pos VERB") or `NOUN`.

### Examples[](https://universaldependencies.org/u/pos/all.html#examples)

- _girl_
- _[[animals|cat]]_
- _tree_
- _[[air]]_
- _beauty_

### References[](https://universaldependencies.org/u/pos/all.html#references)

- [Loos, Eugene E., et al. 2003. Glossary of linguistic terms: What is a noun?](http://www-01.sil.org/linguistics/GlossaryOfLinguisticTerms/WhatIsANoun.htm)
- [Wikipedia](http://en.wikipedia.org/wiki/Noun)

[edit NOUN](https://github.com/universaldependencies/docs/edit/pages-source/_u-pos/NOUN.md)

## `NUM`: numeral[](https://universaldependencies.org/u/pos/all.html#num-numeral)

### Definition[](https://universaldependencies.org/u/pos/all.html#definition)

A numeral is a word, functioning most typically as a determiner, adjective or pronoun, that expresses a number and a relation to the number, such as quantity, sequence, frequency or fraction.

Note that cardinal numerals are covered by `NUM` whether they are used as determiners or not (as in _Windows **Seven**_) and whether they are expressed as words _(four)_, digits _(4)_ or Roman numerals _(IV)_. Other words functioning as determiners (including quantifiers such as _many_ and _few_) are tagged [DET](https://universaldependencies.org/u/pos/all.html#al-u-pos/DET "u-pos DET").

Note that there are words that may be traditionally called numerals in some languages (e.g. Czech) but which are not tagged `NUM`. Such non-cardinal numerals belong to other parts of speech in our universal tagging scheme, based mainly on syntactic criteria: ordinal numerals are [adjectives](https://universaldependencies.org/u/pos/all.html#al-u-pos/ADJ "u-pos ADJ") _(first, second, third)_ or [adverbs](https://universaldependencies.org/u/pos/all.html#al-u-pos/ADV "u-pos ADV") ([cs] _poprvé_ “for the first time”), multiplicative numerals are adverbs _(once, twice)_ etc.

### Examples[](https://universaldependencies.org/u/pos/all.html#examples)

- _0, 1, 2, 3, 4, 5, 2014, 1000000, 3.14159265359_
- _one, two, three, seventy-seven_
- _I, II, III, IV, V, MMXIV_

### References[](https://universaldependencies.org/u/pos/all.html#references)

- [Loos, Eugene E., et al. 2003. Glossary of linguistic terms: What is a numeral?](http://www-01.sil.org/linguistics/GlossaryOfLinguisticTerms/WhatIsANumeral.htm)
- [Wikipedia: Numeral](http://en.wikipedia.org/wiki/Numeral_%28linguistics%29)

[edit NUM](https://github.com/universaldependencies/docs/edit/pages-source/_u-pos/NUM.md)

## `PART`: particle[](https://universaldependencies.org/u/pos/all.html#part-particle)

### Definition[](https://universaldependencies.org/u/pos/all.html#definition)

Particles are function words that must be associated with another word or phrase to impart meaning and that do not satisfy definitions of other universal parts of speech (e.g. [adpositions](https://universaldependencies.org/u/pos/all.html#al-u-pos/ADP "u-pos ADP"), [coordinating conjunctions](https://universaldependencies.org/u/pos/all.html#al-u-pos/CCONJ "u-pos CCONJ"), [subordinating conjunctions](https://universaldependencies.org/u/pos/all.html#al-u-pos/SCONJ "u-pos SCONJ") or [auxiliary verbs](https://universaldependencies.org/u/pos/all.html#al-u-pos/AUX "u-pos AUX")). Particles may encode grammatical categories such as negation, mood, tense etc. Particles are normally not inflected, although exceptions may occur.

Note that the `PART` tag does not cover so-called _verbal particles_ in Germanic languages, as in _give **in**_ or _end **up**_. These are adpositions or adverbs by origin and are tagged accordingly [ADP](https://universaldependencies.org/u/pos/all.html#al-u-pos/ADP "u-pos ADP") or [ADV](https://universaldependencies.org/u/pos/all.html#al-u-pos/ADV "u-pos ADV"). Separable verb prefixes in German are treated analogically.

Note that not all function words that are traditionally called particles in Japanese automatically qualify for the `PART` tag. Some of them do, e.g. the question particle か / _ka._ Others (e.g. に / _ni,_ の / _no_) are parallel to adpositions in other languages and should thus be tagged [ADP](https://universaldependencies.org/u/pos/all.html#al-u-pos/ADP "u-pos ADP").

In general, the `PART` tag should be used restrictively and only when no other tag is possible. The the language-specific documentation should list the words classified as `PART` in the given language.

### Examples[](https://universaldependencies.org/u/pos/all.html#examples)

- Possessive marker: [en] _‘s_
- Negation particle: [en] _not;_ [de] _nicht_
- Question particle: [ja] か / _ka_ (adding this particle to the end of a clause turns the clause into a question); [tr] _mu_
- Sentence modality: [cs] _ať, kéž, nechť_ (_Let’s_ do it! _If only_ I could do it over. _May you_ have an enjoyable stay!)

### References[](https://universaldependencies.org/u/pos/all.html#references)

- [Loos, Eugene E., et al. 2003. Glossary of linguistic terms: What is a particle?](http://www-01.sil.org/linguistics/GlossaryOfLinguisticTerms/WhatIsAParticle.htm)
- [Wikipedia](http://en.wikipedia.org/wiki/Grammatical_particle)

[edit PART](https://github.com/universaldependencies/docs/edit/pages-source/_u-pos/PART.md)

## `PRON`: pronoun[](https://universaldependencies.org/u/pos/all.html#pron-pronoun)

### Definition[](https://universaldependencies.org/u/pos/all.html#definition)

Pronouns are words that substitute for [nouns](https://universaldependencies.org/u/pos/all.html#al-u-pos/NOUN "u-pos NOUN") or noun phrases, whose meaning is recoverable from the linguistic or extralinguistic context.

Pronouns under this definition function like nouns. Note that some languages traditionally extend the term _pronoun_ to words that substitute for [adjectives](https://universaldependencies.org/u/pos/all.html#al-u-pos/ADJ "u-pos ADJ"). Such words are not tagged `PRON` under our universal scheme. They are tagged as [determiners](https://universaldependencies.org/u/pos/all.html#al-u-pos/DET "u-pos DET") in order to annotate the same thing the same way across languages.

It is not always crystal clear where pronouns end and determiners start. Unlike in UD v1 it is no longer required that they are told apart solely on the base of the context. The words can be pre-classified in the dictionary as either `PRON` or `DET`, based on their _typical_ syntactic distribution (and morphology, when applicable). Language-specific documentation should list all pronouns (it is a closed class) and point out ambiguities, if any.

See also [general principles on pronominal words](https://universaldependencies.org/u/overview/morphology.html#pronominal-words) for more tips on how to define pronouns. In particular:

- Non-possessive personal, reflexive or reciprocal pronouns are always tagged `PRON`.
- Possessives vary across languages. In some languages the above tests put them in the `DET` category. In others, they are more like a normal personal pronoun in a specific case (often the genitive), or a personal pronoun with an adposition; they are tagged `PRON`.

### Examples[](https://universaldependencies.org/u/pos/all.html#examples)

- personal pronouns: _I, you, he, she, it, we, they_
- reflexive pronouns: _myself, yourself, himself, herself, itself, ourselves, yourselves, theirselves_
- interrogative pronouns: _who, what_ as in _**What** do you think?_
- relative pronouns: _who, that, which_ as in _a [[animals|cat]] **who** eats fish_; _who, what_ as in _I wonder **what** you think._ (Unlike [SCONJ](https://universaldependencies.org/u/pos/all.html#al-u-pos/SCONJ "u-pos SCONJ") relativizers, relative pronouns play a nominal role in the relative clause.)
- indefinite pronouns: _somebody, something, anybody, anything_
- total pronouns: _everybody, everything_
- negative pronouns: _nobody, nothing_
- possessive pronouns (which usually stand alone as a nominal): _mine, yours, (his), hers, (its), ours, theirs_

### References[](https://universaldependencies.org/u/pos/all.html#references)

- [Loos, Eugene E., et al. 2003. Glossary of linguistic terms: What is a pronoun?](https://glossary.sil.org/term/pronoun)
- [Wikipedia](http://en.wikipedia.org/wiki/Pronoun)

[edit PRON](https://github.com/universaldependencies/docs/edit/pages-source/_u-pos/PRON.md)

## `PROPN`: proper noun[](https://universaldependencies.org/u/pos/all.html#propn-proper-noun)

### Definition[](https://universaldependencies.org/u/pos/all.html#definition)

A proper noun is a noun (or nominal content word) that is the name (or part of the name) of a specific individual, place, or object.

Note that `PROPN` is only used for the subclass of nouns that are used as names and that often exhibit special syntactic properties (such as occurring without an article in the singular in English). When other phrases or sentences are used as names, the component words retain their original tags. For example, in _Cat on a Hot Tin Roof_, _Cat_ is [NOUN](https://universaldependencies.org/u/pos/all.html#al-u-pos/NOUN "u-pos NOUN"), _on_ is [ADP](https://universaldependencies.org/u/pos/all.html#al-u-pos/ADP "u-pos ADP"), _a_ is [DET](https://universaldependencies.org/u/pos/all.html#al-u-pos/DET "u-pos DET"), etc.

A fine point is that it is not uncommon to regard words that are etymologically adjectives or participles as proper nouns when they appear as part of a multiword name that overall functions like a proper noun, for example in _the Yellow Pages_, _United Airlines_ or _Thrall Manufacturing Company_. This is certainly the practice for the English Penn Treebank tag set. However, the practice should not be copied from English to other languages if it is not linguistically justified there. For example, in Czech, _Spojené státy_ “United States” is an adjective followed by a common noun; their tags in UD are [ADJ](https://universaldependencies.org/u/pos/all.html#al-u-pos/ADJ "u-pos ADJ") [NOUN](https://universaldependencies.org/u/pos/all.html#al-u-pos/NOUN "u-pos NOUN") and the adjective modifies the noun via the [amod](https://universaldependencies.org/u/dep/amod.html "u-dep amod") relation.

Acronyms of proper nouns, such as _UN_ and _NATO_, should be tagged `PROPN`. Even if they contain numbers (as in various product names), they are tagged `PROPN` and not [SYM](https://universaldependencies.org/u/pos/all.html#al-u-pos/SYM "u-pos SYM"): _130XE_, _DC10_, _DC-10_. However, if the token consists entirely of digits (like _7_ in _Windows 7_), it is tagged [NUM](https://universaldependencies.org/u/pos/all.html#al-u-pos/NUM "u-pos NUM").

### Examples[](https://universaldependencies.org/u/pos/all.html#examples)

- _Mary_, _John_
- _London_
- _NATO_, _HBO_

### References[](https://universaldependencies.org/u/pos/all.html#references)

- [Loos, Eugene E., et al. 2003. Glossary of linguistic terms: What is a proper noun?](https://glossary.sil.org/term/proper-noun)
- [Wikipedia](http://en.wikipedia.org/wiki/Proper_noun)

[edit PROPN](https://github.com/universaldependencies/docs/edit/pages-source/_u-pos/PROPN.md)

## `PUNCT`: punctuation[](https://universaldependencies.org/u/pos/all.html#punct-punctuation)

### Definition[](https://universaldependencies.org/u/pos/all.html#definition)

Punctuation marks are non-alphabetical characters and character groups used in many languages to delimit linguistic units in printed text.

Punctuation is not taken to include logograms such as _$_, _%_, and _§_, which are instead tagged as [SYM](https://universaldependencies.org/u/pos/all.html#al-u-pos/SYM "u-pos SYM"). (Hint: if it corresponds to a word that you pronounce, such as _dollar_ or _percent_, it is `SYM` and not `PUNCT`.)

Spoken corpora contain symbols representing pauses, laughter and other sounds; we treat them as punctuation, too. In these cases it is even not required that all characters of the token are non-alphabetical. One can represent a pause using a special character such as _#_, or using some more descriptive coding such as _[:pause]_.

### Examples[](https://universaldependencies.org/u/pos/all.html#examples)

- Period: _**.**_
- Comma: _**,**_
- Parentheses: _**()**_

### References[](https://universaldependencies.org/u/pos/all.html#references)

- [Wikipedia](http://en.wikipedia.org/wiki/Punctuation)

[edit PUNCT](https://github.com/universaldependencies/docs/edit/pages-source/_u-pos/PUNCT.md)

## `SCONJ`: subordinating conjunction[](https://universaldependencies.org/u/pos/all.html#sconj-subordinating-conjunction)

### Definition[](https://universaldependencies.org/u/pos/all.html#definition)

A subordinating conjunction is a conjunction that links constructions by making one of them a constituent of the other. The subordinating conjunction typically marks the incorporated constituent which has the status of a (subordinate) clause.

We follow [Loos et al. 2003](http://www-01.sil.org/linguistics/GlossaryOfLinguisticTerms/WhatIsASubordinatingConjunctio.htm) in recognizing these three subclasses as subordinating conjunctions:

- Complementizers, like [en] _that_ or _if_
- Adverbial clause introducers, like [en] _when_, _since_, or _before_ (when introducing a clause, not a nominal)
- Non-pronominal relativizers, like [he] _še_. Words in this category simply introduce a relative clause (and normally don’t inflect). This excludes words that have a nominal function within the relative clause; relative and resumptive pronouns (e.g., English relative _that_ and _which_) are analyzed as [PRON](https://universaldependencies.org/u/pos/all.html#al-u-pos/PRON "u-pos PRON").

For _coordinating conjunctions,_ see [CCONJ](https://universaldependencies.org/u/pos/all.html#al-u-pos/CCONJ "u-pos CCONJ").

### Examples[](https://universaldependencies.org/u/pos/all.html#examples)

- _that_ as in _I believe **that** he will come._
- _if_
- _while_

### References[](https://universaldependencies.org/u/pos/all.html#references)

- [Loos, Eugene E., et al. 2003. Glossary of linguistic terms: What is a subordinating conjunction?](https://glossary.sil.org/term/subordinating-conjunction)
- [Wikipedia](http://en.wikipedia.org/wiki/Conjunction_(grammar))

[edit SCONJ](https://github.com/universaldependencies/docs/edit/pages-source/_u-pos/SCONJ.md)

## `SYM`: symbol[](https://universaldependencies.org/u/pos/all.html#sym-symbol)

### Definition[](https://universaldependencies.org/u/pos/all.html#definition)

A symbol is a word-like entity that differs from ordinary words by form, function, or both.

Many symbols are or contain special non-alphanumeric characters, similarly to [punctuation](https://universaldependencies.org/u/pos/all.html#al-u-pos/PUNCT "u-pos PUNCT"). What makes them different from punctuation is that they can be substituted by normal words. This involves all currency symbols, e.g. _$ 75_ is identical to _seventy-five dollars_.

Mathematical operators form another group of symbols.

Another group of symbols is emoticons and emoji.

Strings that consists entirely of alphanumeric characters are not symbols but they may be [proper nouns](https://universaldependencies.org/u/pos/all.html#al-u-pos/PROPN "u-pos PROPN"): _130XE_, _DC10_; others may be tagged `PROPN`(rather than `SYM`) even if they contain special characters: _DC-10_. Similarly, abbreviations for single words are not symbols but are assigned the part of speech of the full form. For example, _Mr._ (mister), _kg_ (kilogram), _km_ (kilometer), _Dr_ (Doctor) should be tagged [nouns](https://universaldependencies.org/u/pos/all.html#al-u-pos/NOUN "u-pos NOUN"). Acronyms for proper names such as _UN_ and _NATO_ should be tagged as [proper nouns](https://universaldependencies.org/u/pos/all.html#al-u-pos/PROPN "u-pos PROPN").

Characters used as bullets in itemized lists _(•, ‣)_ are not symbols, they are punctuation.

### Examples[](https://universaldependencies.org/u/pos/all.html#examples)

- _$, %, §, ©_
- _+, −, ×, ÷, =, <, >_
- :), ♥‿♥, 😝
- _john.doe@universal.org, http://universaldependencies.org/, 1-800-COMPANY_

[edit SYM](https://github.com/universaldependencies/docs/edit/pages-source/_u-pos/SYM.md)

## `VERB`: verb[](https://universaldependencies.org/u/pos/all.html#verb-verb)

### Definition[](https://universaldependencies.org/u/pos/all.html#definition)

A verb is a member of the syntactic class of words that typically signal events and actions, can constitute a minimal predicate in a clause, and govern the number and types of other constituents which may occur in the clause. Verbs are often associated with grammatical categories like tense, mood, aspect and voice, which can either be expressed inflectionally or using auxilliary verbs or particles.

Note that the `VERB` tag covers main verbs _(content verbs)_ but it does not cover _auxiliary verbs_ and verbal _copulas_ (in the narrow sense), for which there is the [AUX](https://universaldependencies.org/u/pos/all.html#al-u-pos/AUX "u-pos AUX") tag. _Modal verbs_ may be considered `VERB` or `AUX`, depending on their behavior in the given language. Language-specific documentation should specify which verbs are tagged `AUX` in which contexts.

Note that _participles_ are word forms that may share properties and usage of adjectives and verbs. Depending on language and context, they may be classified as either `VERB` or [ADJ](https://universaldependencies.org/u/pos/all.html#al-u-pos/ADJ "u-pos ADJ").

Note that some verb forms such as _gerunds_ and _infinitives_ may share properties and usage of nouns and verbs. Depending on language and context, they may be classified as either `VERB` or [NOUN](https://universaldependencies.org/u/pos/all.html#al-u-pos/NOUN "u-pos NOUN").

Note that there are verb forms such as _converbs (transgressives)_ or _adverbial participles_ that share properties and usage of adverbs and verbs. Depending on language and context, they may be classified as either `VERB` or [ADV](https://universaldependencies.org/u/pos/all.html#al-u-pos/ADV "u-pos ADV").

Deverbal connectives acting as adpositions or subordinators may be tagged `VERB` while participating in a [case](https://universaldependencies.org/u/dep/case.html "u-dep case") or [mark](https://universaldependencies.org/u/dep/mark.html "u-dep mark") relation: see [ADP](https://universaldependencies.org/u/pos/all.html#al-u-pos/ADP "u-pos ADP").

### Examples[](https://universaldependencies.org/u/pos/all.html#examples)

- _run, eat_
- _runs, ate_
- _running, eating_

### References[](https://universaldependencies.org/u/pos/all.html#references)

- [Loos, Eugene E., et al. 2003. Glossary of linguistic terms: What is a verb?](http://www-01.sil.org/linguistics/GlossaryOfLinguisticTerms/WhatIsAVerbLinguistics.htm)
- [Wikipedia](http://en.wikipedia.org/wiki/Verb)

[edit VERB](https://github.com/universaldependencies/docs/edit/pages-source/_u-pos/VERB.md)

## `X`: other[](https://universaldependencies.org/u/pos/all.html#x-other)

### Definition[](https://universaldependencies.org/u/pos/all.html#definition)

The tag `X` is used for words that for some reason cannot be assigned a real part-of-speech category. It should be used very restrictively.

A special usage of `X` is for cases of code-switching where it is not possible (or meaningful) to analyze the intervening language grammatically (and where the dependency relation [flat:foreign](https://universaldependencies.org/u/dep/flat.html "u-dep flat") is typically used in the syntactic analysis). This usage does not extend to ordinary loan words which should be assigned a normal part-of-speech. For example, in _he put on a large sombrero_, _sombrero_ is an ordinary [NOUN](https://universaldependencies.org/u/pos/all.html#al-u-pos/NOUN "u-pos NOUN").

### Examples[](https://universaldependencies.org/u/pos/all.html#examples)

- _And then he just **xfgh pdl jklw**_

[edit X](https://github.com/universaldependencies/docs/edit/pages-source/_u-pos/X.md)

© 2014–2021 [Universal Dependencies contributors](http://universaldependencies.org/introduction.html#contributors). Site powered by [Annodoc](http://spyysalo.github.io/annodoc) and [brat](http://brat.nlplab.org/)

.
