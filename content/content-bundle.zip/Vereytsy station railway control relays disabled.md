---
locations:
aliases: 
location: between the Sovetskiy stops and the Vereytsy station
title: Vereytsy station railway control relays disabled
tag: mechanical, railway, infrastructure
date: 2022-03-28  
---

# Vereytsy station railway control relays disabled

2022-03-28  
Mechanical  
Railway,Infrastructure  
https://ru.wikipedia.org/wiki/Рельсовая_война_в_Белоруссии_(2022)#30_марта  
On March 28, [[BYPOL]] announced another [[operations|operation]]. On the stage between the [[Sovetskiy]] stops and the [[Vereytsy]] station, in the area of the neutral insert, alarm, centralization and blocking devices (SCB) were disabled. This information was later confirmed by the Ministry of Emergency Situations of Belarus  
Vereytsy station, Belarus

~+~  
80
