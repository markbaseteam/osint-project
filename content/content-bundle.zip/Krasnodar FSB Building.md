---
locations:
aliases: ['[[Maps/Krasnodar, Krasnodar Municipality, Krasnodar Krai, Southern Federal District, 350000, Russia|Krasnodar]] FSB Building']
location: Krasnodar
title: '[[Maps/Krasnodar, Krasnodar Municipality, Krasnodar Krai, Southern Federal District, 350000, Russia|Krasnodar]] FSB Building'
tag: molotov, government
date: 2022-06-15 

linter-yaml-title-alias: '[[Maps/Krasnodar, Krasnodar Municipality, Krasnodar Krai, Southern Federal District, 350000, Russia|Krasnodar]] FSB Building'
---

# [[OSINT Project/Maps/Krasnodar, Krasnodar Municipality, Krasnodar Krai, Southern Federal District, 350000, Russia|Krasnodar]] FSB Building

2022-06-15  
Molotov  
Government  
https://enoughisenough14.org/2022/06/26/shortly-after-the-longest-night-of-the-year-two-recruiting-offices-burned-at-once-chronicle-of-arson-attacks-until-june-25-2022-russia/  
On June 15, an attempt was made to set [[fire]] to the FSB building in [[OSINT Project/Maps/Krasnodar, Krasnodar Municipality, Krasnodar Krai, Southern Federal District, 350000, Russia|Krasnodar]].  
[[OSINT Project/Maps/Krasnodar, Krasnodar Municipality, Krasnodar Krai, Southern Federal District, 350000, Russia|Krasnodar]]

~+~  
78
