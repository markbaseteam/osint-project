---
locations:
aliases: 
location: Transnistria 
title: Russian Recruitment Office in Transnistria
tag: molotov, recruitment
date: 2022-05-12  
---

# Russian Recruitment Office in Transnistria

2022-05-12  
Molotov  
Recruitment

Occupied Transnistria - molotov attacks on Russian registration/enlistment office & an oil depot.  
Transnistria

Suspected false flag

~+~  
36
