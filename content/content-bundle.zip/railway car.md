---
aliases: railway cars, railcar, rail car, box car, frieght car, gondola, gondola car, gondola cars, boxcar, boxcars, box cars, frieght cars, railway wagon, railcars, rail cars, railway wagons, rail carriage, rail carriages, railway carriage, railway carriages, railtruck, railtrucks, rail truck, rail trucks, railwagon, railwagons, railcarriage, railcarriages, train car, train cars, train truck, train trucks, train wagon, train wagons, train carriage, train carriages, freight railway car, frieght railway cars, freight railwaycar, frieght railwaycars, flat car, flat cars, flatcar, flatcars, rolling stock, rollingstock, truck trailer, truck trailers, trucktrailer, trucktrailers, coupler, couplers
locations:
tag: 
date:
title: railway car
---
> A railroad [[automobiles|car]], railcar (American and Canadian English), railway wagon, railway carriage, railway [[automobiles|truck]], railwagon, railcarriage or railtruck (British English and UIC), also called a train [[automobiles|car]], train wagon, train carriage or train [[automobiles|truck]], is a [[automobiles|vehicle]] used for the carrying of [[cargo]] or [[passengers]] on a rail [[transportation|transport]] system (a railroad/railway). Such [[automobiles|cars]], when coupled together and hauled by one or more locomotives, form a train. Alternatively, some [[passengers|passenger]] [[automobiles|cars]] are self-propelled in which case they may be either single railcars or make up multiple units.
>
> The term "[[automobiles|car]]" is commonly used by itself in American English when a rail context is implicit. Indian English sometimes uses "bogie" in the same manner, though the term has other meanings in other variants of English. In American English, "railcar" is a generic term for a railway [[automobiles|vehicle]]; in other countries "railcar" refers specifically to a self-propelled, powered, railway [[automobiles|vehicle]].
>
> Although some [[automobiles|cars]] exist for the railroad's own use–for track maintenance purposes, for example–most carry a revenue-earning load of [[passengers]] or [[cargo|freight]], and may be classified accordingly as [[passengers|passenger]] [[automobiles|cars]] or coaches on the one hand or [[cargo|freight]] [[automobiles|cars]] (or wagons) on the other.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Railroad%20car)
