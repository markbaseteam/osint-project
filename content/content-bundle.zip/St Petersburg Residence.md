---
locations:
aliases: 
location: Saint Petersburg
title: St Petersburg Residence
tag: 
date:
---

# St Petersburg Residence

2022-04-25  
Explosion  
Elite  
https://tass.ru/proisshestviya/14461897  
An explosion of an unidentified device occurred on the landing between the seventh and eighth floors of a residential nine-story building in St. Petersburg. 66 residents of the entrance, including 18 children, were evacuated, there were no injuries. There was no [[fire]] after the explosion, but the elevator doors were damaged, windows were broken, and a crack formed on the facade of the last three floors. explosion, according to preliminary data, occurred in an elevator. explosion occurred in the first entrance of the house. The windows of the stairwell at the level of the 8th and 9th floors were completely smashed out. None of the residents of the house was injured, two [[automobiles|cars]] parked nearby were damaged. The owner of one of them said that as a result of the explosion, the rear window of the [[automobiles|car]] was knocked out, and the roof, hood and [[passengers|passenger]] door were dented.  
St Petersburg

~+~  
170
