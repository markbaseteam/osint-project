---
locations:
aliases: 
location: Shcherbina street, Yasnogorsk, Tula region
title: Yasnogorsk Recruitment Office
tag: fire, recruitment
date: 2022-05-30  
---

# Yasnogorsk Recruitment Office

2022-05-30  
[[fire]]  
Recruitment  
https://enoughisenough14.org/2022/06/02/attack-on-military-recruitement-and-enlistment-office-with-an-axe-russia/  
Yasnogorsk. Russia. In the night from May 30 to 31 the building of military recruitement and enlistment office on Shcherbina street in Yasnogorsk (Tula region) was attacked. An unknown person smashed the window with an axe in order to [[fire|burn]] the enlistment office from inside. Usually such tactics (first break the window, then pour the flammable mixture and set it on [[fire]]) prove to be the most effective, but in this case, unfortunately, the staff of the institution managed to quickly put out the flames before the EMERCOM officers arrived to help. The attacker managed to escape, but he left an axe at the scene outside the military registration and enlistment office. We hope he will remain free and able to continue his fight.  
Shcherbina street, Yasnogorsk, Tula region

Date range May 30-31. Used earliest date. Yasnogorsk also is a notable place for ex-USSR revolutionary history: in 1999, in this town was а strike of machine-building plant's workers with the takeover of the enterprise…Other source https://newsbeezer.com/swedeneng/wave-of-molotov-attacks-on-russian-recruiting-offices/ 31-year-old Denis Arbarov was [[arrested|detained]] by the FSB as a suspect in this case. He's already confessed to everything. https://libcom.org/article/arise-ukrainian-comrades-anti-war-direct-actions-russia-and-its-9th-review

~+~  
148
