---
aliases: operation, op
locations:
tag: 
date:
title: operations
---
