---
locations:
aliases: 
location:
title: Bryansk Derailed Railway
tag:  
date:

---

# Bryansk Derailed Railway

2022-04-22  
Mechanical  
Railway,Infrastructure  
https://libcom.org/article/rail-war-russia-ukraine-borderland-facts-and-its-checking  
April 22, the railway was damaged in the direction of Bryansk military unit, along which equipment and ammunition are being transported to Ukraine. Local media say it was only because of the embankment was washed away  
Bryansk

~+~  
20
