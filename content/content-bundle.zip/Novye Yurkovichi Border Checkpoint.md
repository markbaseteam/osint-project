---
locations:
aliases: ['[[Maps/Novye Yurkovichi, Новоюрковичское сельское поселение, Klimovsky District, Bryansk Oblast, Central Federal District, 243046, Russia|Novye Yurkovichi]] Border Checkpoint']
location: border checkpoint Novye Yurkovichi, Bryansk Oblast
title: '[[Maps/Novye Yurkovichi, Новоюрковичское сельское поселение, Klimovsky District, Bryansk Oblast, Central Federal District, 243046, Russia|Novye Yurkovichi]] Border Checkpoint'
tag: checkpoint
date: 2022-04-13
linter-yaml-title-alias: '[[Maps/Novye Yurkovichi, Новоюрковичское сельское поселение, Klimovsky District, Bryansk Oblast, Central Federal District, 243046, Russia|Novye Yurkovichi]] Border Checkpoint'
---

# [[OSINT Project/Maps/Novye Yurkovichi, Новоюрковичское сельское поселение, Klimovsky District, Bryansk Oblast, Central Federal District, 243046, Russia|Novye Yurkovichi]] Border Checkpoint

2022-04-13  
Other

On 14 April, 2022:, the FSB border service reported: a [[border checkpoint]] near [[Novye Yurkovichi]] in [[Bryansk Oblast]] came under mortar [[fire]] from Ukraine while a group of around 30 Ukrainian refugees headed for Russia was present there. According to the official claims, two [[automobiles]] were damaged but no injuries were documented.  
[[OSINT Project/Maps/Novye Yurkovichi, Новоюрковичское сельское поселение, Klimovsky District, Bryansk Oblast, Central Federal District, 243046, Russia|Novye Yurkovichi]], Bryansk Oblast

~+~  
86
