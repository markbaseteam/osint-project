---
locations:
aliases: 
location:
title: Gukovo Recruitment Office
tag: molotov, recruitment
date:
---

# Gukovo Recruitment Office

2022-05-13  
Molotov  
Recruitment  
https://www.rferl.org/a/russia-enlistment-offices-arson/31851677.html  
On May 13, a military enlistment office in the town of Gukovo in the southern Rostov region was partially [[fire|burned]]. A Molotov cocktail is also believed to be the cause of that [[fire]], which was quickly put out. night of May 13, this time in the town of Gukovo in the Rostov region. The attack took place at about 02:05 in the morning. The [[fire]] was extinguished by the employees of the Registration and Recruitment Office themselves, and there was no property damage. The suspects were not found. https://enoughisenough14.org/2022/06/26/shortly-after-the-longest-night-of-the-year-two-recruiting-offices-burned-at-once-chronicle-of-arson-attacks-until-june-25-2022-russia/  
Gukovo, Rostov

Gukovo (Rostov) On May 13, at about 2:00 a.m., an attempt was made to set [[fire]] to the military registration and enlistment office in Gukovo, near Rostov. A flaming molotov hit the wall of the building. According to the state media, the perpetrator “disappeared in an unknown direction”. https://darknights.noblogs.org/post/tag/khanty-nansi/

~+~  
79
