---
locations:
aliases: ['FSB [[Moscow]] Special Ops Center [[automobiles|Vehicles]]']
location:
title: 'FSB [[Moscow]] Special Ops Center [[automobiles|Vehicles]]'
tag: fire, military, government
date:
linter-yaml-title-alias: 'FSB [[Moscow]] Special Ops Center [[automobiles|Vehicles]]'
---

# FSB [[Moscow]] Special Ops Center [[automobiles|Vehicles]]

2022-05-03  
[[fire]]  
Military,Government  
https://darknights.noblogs.org/post/2022/04/12/russia-military-cars-on-fire/  
At night on 03.04.22 there was an [[fire|arson]] in Russia–[[automobiles|cars]] belonging to the staff of the FSB Special Operations Center (military unit 35690, Balashikha, [[Moscow]] region) [[fire|burned]] down. At least four [[automobiles|cars]] were [[fire|burned]]. According to Ukrainian intelligence, the owners of the [[automobiles|cars]] were representatives of the executive staff of the Federal Security Service’s Central Intelligence Service.  
military unit 35690, Balashikha, [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]] region - FSB Special Ops Center

cases of deliberate [[fire|arson]] of [[automobiles|cars]] of Russian military and officials are becoming more frequent. In particular, [[automobiles|cars]] of servicemen of the [[95th Brigade Vehicles|95th Brigade]] (Gorelovo, St Petersburg Region) and the [[82nd Radio Technical Brigade Vehicles|82nd Radio]] Technical Brigade (Vyazma, Smolensk Region) have recently been set on [[fire]]. Russian servicemen speak of threats of physical reprisals if they agree to participate in the war against Ukraine.

~+~  
165
