---
locations:
aliases: ['Nizhny Novgorod Natalya Abieva [[automobiles|Vehicle]]']
location: Krasnykh Zor street, 24, Nizhny Novgorod
title: 'Nizhny Novgorod Natalya Abieva [[automobiles|Vehicle]]'
tag: fire, elite, vehicle
date: 2022-06-10  
linter-yaml-title-alias: 'Nizhny Novgorod Natalya Abieva [[automobiles|Vehicle]]'
---

# Nizhny Novgorod Natalya Abieva [[automobiles|Vehicle]]

2022-06-10  
[[fire]]  
Elite  
https://t.me/theblackheadquarter/238  
Toyota (Р561ХТ152) which belonged to [[Natalya Abieva]], the sponsor of Putinist occupiers, was [[fire|burned]] down in Nizhny Novgorod on 10.06.2022. It happened at 3 a.m., by the address Krasnykh Zor street, 24. Abieva is organizer of the foundation in support of Putin’s army, convinced supporter of ruling regime and of war. People like her don’t care about deaths of tens of thousands of people in Ukraine, millions of broken lifes. Abieva is interested just in artificial “greatness of Russia”. But is it possible to gain greatness, while you cover yourself with blood? We believe that this war brings death not only for Ukraine but for Russia as well. We must do all we can to stop it. There are no more means for peaceful protest in our country. We hope, that this clear message will be heared. Now we actively collect data base on regime supporters in our region. The struggle will continue. Dictatorship should be replaced by the society based on freedom, equality and solidarity. See you! Revolutionary cell of Volga region  
Krasnykh Zor street, 24, Nizhny Novgorod, Volga

Claimed by Revolutionary cell of Volga region English coverage https://enoughisenough14.org/2022/06/13/car-of-natalya-abieva-sponsor-of-the-russian-army-torched-in-nizhny-novgorod-russia/

~+~  
192
