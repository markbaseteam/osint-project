---
locations:
aliases: 
location: Svetofor Warehouse, Prosveshchenie publishing house, Bogorodsky, [[Moscow]]
title: Prosveshchenie Text Book Printer Warehouse
tag: fire, educational, cultural
date: 2022-05-03  
---

# Prosveshchenie Text Book Printer Warehouse

2022-05-03  
[[fire]]  
Education,Cultural  
https://www.themoscowtimes.com/2022/05/03/fire-hits-russian-publisher-embroiled-in-ukraine-textbook-controversy-a77563  
[[fire]] has ripped through a warehouse storing Russian schoolbooks, days after reports that publishers would remove mentions of Ukraine from the nation’s textbooks. textbooks and other printing materials had been stored in the warehouse  
Svetofor Warehouse, Prosveshchenie publishing house, [[OSINT Project/Maps/Bogorodsky city district, Moscow Oblast, Central Federal District, Russia|Bogorodsky]], [[Moscow]]

The [[fire]] follows reports that Prosveshchenie, one of Russia’s largest and oldest educational publishers, had ordered staff to remove "inappropriate" references to Ukraine and Kyiv from textbooks. == Svetofor Warehouse. A number of [[fire|fires]] were active at this warehouse per FIRMS

~+~  
104
