---
locations:
aliases: ['[[Maps/Mahilyow, Mahilyow Region, Belarus|Mogilev]] railway chain shortened']
location: Mogilev, Belarus
title: '[[Maps/Mahilyow, Mahilyow Region, Belarus|Mogilev]] railway chain shortened'
tag: mechanical, railway, infrastructure 
date: 2022-03-01  
linter-yaml-title-alias: '[[Maps/Mahilyow, Mahilyow Region, Belarus|Mogilev]] railway chain shortened'
---

# [[OSINT Project/Maps/Mahilyow, Mahilyow Region, Belarus|Mogilev]] railway chain shortened

2022-03-01  
Mechanical  
Railway,Infrastructure  
https://ru.wikipedia.org/wiki/Рельсовая_война_в_Белоруссии_(2022)#30_марта  

the rail chain was shortened with wire at the service area of the [[OSINT Project/Maps/Mahilyow, Mahilyow Region, Belarus|Mogilev]] branch of Belarusian Railways  
[[OSINT Project/Maps/Mahilyow, Mahilyow Region, Belarus|Mogilev]], Belarus

~+~  
128
