---
locations:
aliases: 
location:
title: Bryansk Railway Bomb
tag:
date:
---

# Bryansk Railway Bomb

2022-04-23  
Explosion  
Railway,Infrastructure  
https://libcom.org/article/rail-war-russia-ukraine-borderland-facts-and-its-checking  
Other date 26 April, 2022. Used earliest reported date. April 23, a hand-made bomb was found in a relay cabinet of the Bryansk railway. Experts came to the conclusion that in the relay cabinet there was an incendiary-type IED with a timer and a battery connected, presumably, to containers with gasoline. Traces of breaking into the relay cabinet, which is locked with a special key, were not found. The shift electrician who found the gift says he saw a suspicious man on a motorcycle in the forest near the site.  
Bryansk Railway

**According to InformNapalm, Russia is attacking itself with false flags & is preparing to bring in wreckage of Ukrainian [[aircraft|helicopters]] and drones to place as "proof". Other claims made are that top military and families were evacuated April 19th in preparation. Focus areas Belgorod, [[OSINT Project/Maps/Kursk, Kursk Oblast, Central Federal District, 305000, Russia|Kursk]], Bryansk Oblasts especially civilian and residential areas**

~+~  
161
