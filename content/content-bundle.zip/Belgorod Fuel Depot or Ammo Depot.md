---
locations:
aliases:
  - Belgorod Ammo Depot
location:
title: Belgorod Ammo Depot
tag:
date:

linter-yaml-title-alias: Belgorod Ammo Depot
---

# Belgorod Ammo Depot

2022-03-29  
[[fire]]  
Gas/Oil,Military  
https://english.nv.ua/nation/ammo-depot-near-russia-s-belgorod-is-on-fire-50237257.html  
On March 29, a fuel depot caught [[fire]] outside the city of Belgorod, following what the Russian authorities claimed was a Ukrainian attack. The Ukrainian government has denied all claims of its involvement on [[fire|fires]] and explosions around military infrastructure in Russian territory.  
Belgorod

~+~  
119
