---
locations:
aliases: 
location:
title: Urengoy Gas Field
tag: fire, gas, oil
date: 2022-06-16  
---

# Urengoy Gas Field

2022-06-16  
[[fire]]  
Gas/Oil  
https://en.m.wikipedia.org/wiki/2022_Russian_mystery_fires  
The largest natural gas field in Russia [[Urengoy]] gas field [[Novy Urengoy]], lies in [[Yamalo-Nenets Autonomous Okrug]] in [[Tyumen Oblast]] of Russia, just south of the Arctic circle and named after the settlement of Urengoy  
[[OSINT Project/Maps/Novy Urengoy, городской округ Новый Уренгой, Yamalo-Nenets Autonomous Okrug, Ural Federal District, 629300, Russia|Novy Urengoy]]

~+~  
53
