---
aliases: Perm
locations: Perm, Russia
tag: 
date:
location:  [58.02148705,56.23076652679421]
title: 'Perm, Russia'
---
