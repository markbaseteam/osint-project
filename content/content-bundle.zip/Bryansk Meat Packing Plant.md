---
locations:
aliases: 
location:
title: Bryansk Meat Packing Plant
tag: 
date:
---

# Bryansk Meat Packing Plant

2022-04-23  
[[fire]]  
Other  
https://www.kyivpost.com/eastern-europe/probably-not-by-accident-new-mystery-explosions-ammo-dump-fires-in-russia.html  
Bryansk meat-processing plant and an agricultural equipment factory also caught [[fire]] on the 23rd

Date discrepancy - 23rd or 25th **According to InformNapalm, Russia is attacking itself with false flags & is preparing to bring in wreckage of Ukrainian [[aircraft|helicopters]] and drones to place as "proof". Other claims made are that top military and families were evacuated April 19th in preparation. Focus areas Belgorod, [[OSINT Project/Maps/Kursk, Kursk Oblast, Central Federal District, 305000, Russia|Kursk]], Bryansk Oblasts especially civilian and residential areas**

~+~  
55
