---
aliases: 
locations:
tag: 
date:
title: Tenders
---

TI Ref No :

472597477

Date :

29 Apr 2022

Description :

The Acquisition Of A Dwelling (apartment) In The City Of Tarko-sale In The State Property Of The Yamal-nenets Autonomous Okrug As Part Of The Implementation Of The Housing Event For The Formation Of A Specialized Housing Stock For Orphans And Persons From, Russian federation

Deadline :

11 May 2022

Estimated Cost :

4.82 Million

Document Type :

Tender Notice

  

[Tender - The Acquisition Of A Dwelling (apartment) In The City Of Tarko-sale In The State Property Of The Yamal-nenets Autonomous Okrug As Part Of The Implementation Of The Housing Event For The Formation Of A Specialized Housing Stock For Orphans And Persons From, Russian federation (472597477)](https://www.tendersinfo.com/details/472597477?desc=The-Acquisition-Of-A-Dwelling-(apartment)-In-The-City-Of-Tarko-sale-In-The-State-Property-Of-The-Yamal-nenets-Autonomous-Okrug-As-Part-Of-The-Implementation-Of-The-Housing-Event-For-The-Formation-Of-A-Specialized-Housing-Stock-For-Orphans-And-Persons-From)

  

Tender Notice

TI Ref No :

472597539

Date :

29 Apr 2022

Description :

The Acquisition Of A Dwelling (apartment) In The City Of Salekhard In The State Property Of The Yamal-nenets Autonomous Okrug As Part Of The Implementation Of The Housing Event For The Formation Of A Specialized Housing Fund For Orphans And Persons From T, Russian federation

Deadline :

11 May 2022

Estimated Cost :

5.53 Million

Document Type :

Tender Notice

  

[Tender - The Acquisition Of A Dwelling (apartment) In The City Of Salekhard In The State Property Of The Yamal-nenets Autonomous Okrug As Part Of The Implementation Of The Housing Event For The Formation Of A Specialized Housing Fund For Orphans And Persons From T, Russian federation (472597539)](https://www.tendersinfo.com/details/472597539?desc=The-Acquisition-Of-A-Dwelling-(apartment)-In-The-City-Of-Salekhard-In-The-State-Property-Of-The-Yamal-nenets-Autonomous-Okrug-As-Part-Of-The-Implementation-Of-The-Housing-Event-For-The-Formation-Of-A-Specialized-Housing-Fund-For-Orphans-And-Persons-From-T)

  

[The Acquisition Of A Dwelling (apartment) In The City Of Tarko-sale In The State Property Of The Yamal-nenets Autonomous Okrug As Part Of The Implementation Of The Housing Acquisition For The Formation Of A Specialized Housing Fund For Orphans And Persons.](https://www.tendersinfo.com/details/472597460?desc=The-Acquisition-Of-A-Dwelling-(apartment)-In-The-City-Of-Tarko-sale-In-The-State-Property-Of-The-Yamal-nenets-Autonomous-Okrug-As-Part-Of-The-Implementation-Of-The-Housing-Acquisition-For-The-Formation-Of-A-Specialized-Housing-Fund-For-Orphans-And-Persons) 

  

Tender Notice

TI Ref No :

472597460

Date :

29 Apr 2022

Description :

The Acquisition Of A Dwelling (apartment) In The City Of Tarko-sale In The State Property Of The Yamal-nenets Autonomous Okrug As Part Of The Implementation Of The Housing Acquisition For The Formation Of A Specialized Housing Fund For Orphans And Persons, Russian federation

Deadline :

11 May 2022

Estimated Cost :

5.21 Million

Document Type :

Tender Notice

  

[Tender - The Acquisition Of A Dwelling (apartment) In The City Of Tarko-sale In The State Property Of The Yamal-nenets Autonomous Okrug As Part Of The Implementation Of The Housing Acquisition For The Formation Of A Specialized Housing Fund For Orphans And Persons, Russian federation (472597460)](https://www.tendersinfo.com/details/472597460?desc=The-Acquisition-Of-A-Dwelling-(apartment)-In-The-City-Of-Tarko-sale-In-The-State-Property-Of-The-Yamal-nenets-Autonomous-Okrug-As-Part-Of-The-Implementation-Of-The-Housing-Acquisition-For-The-Formation-Of-A-Specialized-Housing-Fund-For-Orphans-And-Persons)

  

Tender Notice

TI Ref No :

472597322

Date :

29 Apr 2022

Description :

Acquisition Of A Dwelling (apartment) In The Village. Guys Of The Shuryshkarsky District In The State Property Of The Yamalo-nenets Autonomous Okrug As Part Of The Implementation Of The Housing Acquisition For The Formation Of A Specialized Housing Fund F, Russian federation

Deadline :

11 May 2022

Estimated Cost :

2.86 Million

Document Type :

Tender Notice

  

[Tender - Acquisition Of A Dwelling (apartment) In The Village. Guys Of The Shuryshkarsky District In The State Property Of The Yamalo-nenets Autonomous Okrug As Part Of The Implementation Of The Housing Acquisition For The Formation Of A Specialized Housing Fund F, Russian federation (472597322)](https://www.tendersinfo.com/details/472597322?desc=Acquisition-Of-A-Dwelling-(apartment)-In-The-Village-Guys-Of-The-Shuryshkarsky-District-In-The-State-Property-Of-The-Yamalo-nenets-Autonomous-Okrug-As-Part-Of-The-Implementation-Of-The-Housing-Acquisition-For-The-Formation-Of-A-Specialized-Housing-Fund-F)

  

Tender Notice

TI Ref No :

472597337

Date :

29 Apr 2022

Description :

Acquisition Of A Dwelling (apartment) In The Village. Guys Of The Shuryshkarsky District In The State Property Of The Yamalo-nenets Autonomous Okrug As Part Of The Implementation Of The Housing Acquisition For The Formation Of A Specialized Housing Fund F, Russian federation

Deadline :

11 May 2022

Estimated Cost :

2.69 Million

Document Type :

Tender Notice

  

[Tender - Acquisition Of A Dwelling (apartment) In The Village. Guys Of The Shuryshkarsky District In The State Property Of The Yamalo-nenets Autonomous Okrug As Part Of The Implementation Of The Housing Acquisition For The Formation Of A Specialized Housing Fund F, Russian federation (472597337)](https://www.tendersinfo.com/details/472597337?desc=Acquisition-Of-A-Dwelling-(apartment)-In-The-Village-Guys-Of-The-Shuryshkarsky-District-In-The-State-Property-Of-The-Yamalo-nenets-Autonomous-Okrug-As-Part-Of-The-Implementation-Of-The-Housing-Acquisition-For-The-Formation-Of-A-Specialized-Housing-Fund-F)

  

Tender Notice

TI Ref No :

472597352

Date :

29 Apr 2022

Description :

Acquisition Of A Dwelling (apartment) In The Village. Guys Of The Shuryshkarsky District In The State Property Of The Yamalo-nenets Autonomous Okrug As Part Of The Implementation Of The Housing Acquisition For The Formation Of A Specialized Housing Fund F, Russian federation

Deadline :

11 May 2022

Estimated Cost :

3.26 Million

Document Type :

Tender Notice

  

[Tender - Acquisition Of A Dwelling (apartment) In The Village. Guys Of The Shuryshkarsky District In The State Property Of The Yamalo-nenets Autonomous Okrug As Part Of The Implementation Of The Housing Acquisition For The Formation Of A Specialized Housing Fund F, Russian federation (472597352)](https://www.tendersinfo.com/details/472597352?desc=Acquisition-Of-A-Dwelling-(apartment)-In-The-Village-Guys-Of-The-Shuryshkarsky-District-In-The-State-Property-Of-The-Yamalo-nenets-Autonomous-Okrug-As-Part-Of-The-Implementation-Of-The-Housing-Acquisition-For-The-Formation-Of-A-Specialized-Housing-Fund-F)

  

Tender Notice

TI Ref No :

472597403

Date :

29 Apr 2022

Description :

The Acquisition Of A Dwelling (apartment) In The City Of Tarko-sale In The State Property Of The Yamal-nenets Autonomous Okrug As Part Of The Implementation Of The Housing Event For The Formation Of A Specialized Housing Stock For Orphans And Persons From, Russian federation

Deadline :

11 May 2022

Estimated Cost :

5.60 Million

Document Type :

Tender Notice

  

[Tender - The Acquisition Of A Dwelling (apartment) In The City Of Tarko-sale In The State Property Of The Yamal-nenets Autonomous Okrug As Part Of The Implementation Of The Housing Event For The Formation Of A Specialized Housing Stock For Orphans And Persons From, Russian federation (472597403)](https://www.tendersinfo.com/details/472597403?desc=The-Acquisition-Of-A-Dwelling-(apartment)-In-The-City-Of-Tarko-sale-In-The-State-Property-Of-The-Yamal-nenets-Autonomous-Okrug-As-Part-Of-The-Implementation-Of-The-Housing-Event-For-The-Formation-Of-A-Specialized-Housing-Stock-For-Orphans-And-Persons-From)

  

Tender Notice

TI Ref No :

472597506

Date :

29 Apr 2022

Description :

The Acquisition Of A Dwelling (apartment) In The City Of Salekhard In The State Property Of The Yamal-nenets Autonomous Okrug As Part Of The Implementation Of The Housing Event For The Formation Of A Specialized Housing Fund For Orphans And Persons From T, Russian federation

Deadline :

11 May 2022

Estimated Cost :

5.45 Million

Document Type :

Tender Notice

  

[Tender - The Acquisition Of A Dwelling (apartment) In The City Of Salekhard In The State Property Of The Yamal-nenets Autonomous Okrug As Part Of The Implementation Of The Housing Event For The Formation Of A Specialized Housing Fund For Orphans And Persons From T, Russian federation (472597506)](https://www.tendersinfo.com/details/472597506?desc=The-Acquisition-Of-A-Dwelling-(apartment)-In-The-City-Of-Salekhard-In-The-State-Property-Of-The-Yamal-nenets-Autonomous-Okrug-As-Part-Of-The-Implementation-Of-The-Housing-Event-For-The-Formation-Of-A-Specialized-Housing-Fund-For-Orphans-And-Persons-From-T)

  

[The Acquisition Of A Dwelling (apartment) In The City Of Novy Urengoy In State Property Of The Yamalo-nenets Autonomous Okrug To Provide Housing Citizens Dismissed From Military Service (service) And Persons Equated To Them..](https://www.tendersinfo.com/details/472597584?desc=The-Acquisition-Of-A-Dwelling-(apartment)-In-The-City-Of-Novy-Urengoy-In-State-Property-Of-The-Yamalo-nenets-Autonomous-Okrug-To-Provide-Housing-Citizens-Dismissed-From-Military-Service-(service)-And-Persons-Equated-To-Them) 

  

Tender Notice

TI Ref No :

472597602

Date :

29 Apr 2022

Description :

The Acquisition Of A Dwelling (apartment) In The Village Of Tazovsky Tazovsky District In The State Property Of The Yamalo-nenets Autonomous Okrug As Part Of The Implementation Of The Housing Acquisition For The Formation Of A Specialized Housing Fund For, Russian federation

Deadline :

11 May 2022

Estimated Cost :

5.30 Million

Document Type :

Tender Notice

  

[The Acquisition Of A Dwelling (apartment) In The Village Of Tazovsky Tazovsky District In The State Property Of The Yamalo-nenets Autonomous Okrug As Part Of The Implementation Of The Housing Acquisition For The Formation Of A Specialized Housing Fund For.](https://www.tendersinfo.com/details/472597602?desc=The-Acquisition-Of-A-Dwelling-(apartment)-In-The-Village-Of-Tazovsky-Tazovsky-District-In-The-State-Property-Of-The-Yamalo-nenets-Autonomous-Okrug-As-Part-Of-The-Implementation-Of-The-Housing-Acquisition-For-The-Formation-Of-A-Specialized-Housing-Fund-For) 

  

  

Tender Notice

TI Ref No :

472597621

Date :

29 Apr 2022

Description :

The Acquisition Of A Dwelling (apartment) In The City Of Noyabrsk In The State Property Of The Yamal-nenets Autonomous Okrug As Part Of The Implementation Of The Housing Acquisition For The Formation Of A Specialized Housing Stock For Orphans And Persons, Russian federation

Deadline :

11 May 2022

Estimated Cost :

3.73 Million

Document Type :

Tender Notice

  

[Tender - The Acquisition Of A Dwelling (apartment) In The City Of Noyabrsk In The State Property Of The Yamal-nenets Autonomous Okrug As Part Of The Implementation Of The Housing Acquisition For The Formation Of A Specialized Housing Stock For Orphans And Persons, Russian federation (472597621)](https://www.tendersinfo.com/details/472597621?desc=The-Acquisition-Of-A-Dwelling-(apartment)-In-The-City-Of-Noyabrsk-In-The-State-Property-Of-The-Yamal-nenets-Autonomous-Okrug-As-Part-Of-The-Implementation-Of-The-Housing-Acquisition-For-The-Formation-Of-A-Specialized-Housing-Stock-For-Orphans-And-Persons)

  

Very high compared to housing

  

Tender Notice

TI Ref No :

472607386

Date :

29 Apr 2022

Description :

Performing Work On The Installation Of A Playground, Russian federation

Deadline :

18 May 2022

Estimated Cost :

11.43 Million

Document Type :

Tender Notice

  

[Tender - Performing Work On The Installation Of A Playground, Russian federation (472607386)](https://www.tendersinfo.com/details/472607386?desc=Performing-Work-On-The-Installation-Of-A-Playground)

  

Tender Notice

TI Ref No :

472607442

Date :

29 Apr 2022

Description :

The Provision Of Services For The Preparation And Delivery Of Food For Temporarily Detained In The Ivs, Russian federation

Deadline :

13 May 2022

Estimated Cost :

1.77 Million

Document Type :

Tender Notice

  

[Tender - The Provision Of Services For The Preparation And Delivery Of Food For Temporarily Detained In The Ivs, Russian federation (472607442)](https://www.tendersinfo.com/details/472607442?desc=The-Provision-Of-Services-For-The-Preparation-And-Delivery-Of-Food-For-Temporarily-Detained-In-The-Ivs)

  

Tender Notice

TI Ref No :

472607549

Date :

29 Apr 2022

Description :

The Provision Of Services For The Transportation Of Organized Groups Of Children In Difficult Life Situations To The Place Of Rest And Vice Versa, Russian federation

Deadline :

11 May 2022

Estimated Cost :

1.58 Million

Document Type :

Tender Notice

  

[Tender - The Provision Of Services For The Transportation Of Organized Groups Of Children In Difficult Life Situations To The Place Of Rest And Vice Versa, Russian federation (472607549)](https://www.tendersinfo.com/details/472607549?desc=The-Provision-Of-Services-For-The-Transportation-Of-Organized-Groups-Of-Children-In-Difficult-Life-Situations-To-The-Place-Of-Rest-And-Vice-Versa)

  

Tender Notice

TI Ref No :

472607577

Date :

29 Apr 2022

Description :

The Provision Of Services For The Transportation Of Organized Groups Of Children In Difficult Life Situations To The Place Of Rest And Vice Versa, Russian federation

Deadline :

11 May 2022

Estimated Cost :

1.42 Million

Document Type :

Tender Notice

  

[Tender - The Provision Of Services For The Transportation Of Organized Groups Of Children In Difficult Life Situations To The Place Of Rest And Vice Versa, Russian federation (472607577)](https://www.tendersinfo.com/details/472607577?desc=The-Provision-Of-Services-For-The-Transportation-Of-Organized-Groups-Of-Children-In-Difficult-Life-Situations-To-The-Place-Of-Rest-And-Vice-Versa)

  

Tender Notice

TI Ref No :

472607602

Date :

29 Apr 2022

Description :

The Provision Of Services For The Transportation Of Organized Groups Of Children In Difficult Life Situations To The Place Of Rest And Vice Versa, Russian federation

Deadline :

11 May 2022

Estimated Cost :

1.20 Million

Document Type :

Tender Notice

  

[Tender - The Provision Of Services For The Transportation Of Organized Groups Of Children In Difficult Life Situations To The Place Of Rest And Vice Versa, Russian federation (472607602)](https://www.tendersinfo.com/details/472607602?desc=The-Provision-Of-Services-For-The-Transportation-Of-Organized-Groups-Of-Children-In-Difficult-Life-Situations-To-The-Place-Of-Rest-And-Vice-Versa)

  

  

  

  

  

  

  

All

[https://www.tendersinfo.com/global-russian-federation-tenders.php](https://www.tendersinfo.com/global-russian-federation-tenders.php)

  

[https://www.tendersontime.com/russia-tenders/sectors/](https://www.tendersontime.com/russia-tenders/sectors/)

  

  
