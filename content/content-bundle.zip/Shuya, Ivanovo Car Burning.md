---
locations:
aliases: ['Shuya, [[Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] [[automobiles|Car]] [[fire|Burning]]']
location: Vasilyevsky Trakt, Shuya, Ivanovo
title: 'Shuya, [[Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] [[automobiles|Car]] [[fire|Burning]]'
tag: fire
date: 2022-06-30 
linter-yaml-title-alias: 'Shuya, [[Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] [[automobiles|Car]] [[fire|Burning]]'
---

# Shuya, [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] [[automobiles|Car]] [[fire|Burning]]

2022-06-30  
[[fire]]  
Other  
https://www.ivanovonews.ru/news/1152522/  
The [[fire]] on Vasilyevsky Trakt in Shuya occurred on June 30 around 19.20. A Ford Fiera [[automobiles|car]] broke out. According to the Ministry of Emergency Situations for the [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] region, by 19.34 the open [[fire|burning]] had been eliminated by [[fire]] and rescue units. As a result of the [[fire]], the [[automobiles|car]] [[fire|burned]] to the ground. No one was hurt. The cause of the [[fire]] is being established.  
Vasilyevsky Trakt, Shuya, [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]]

When [[automobiles|cars]] are identified as "foreign" which may mean not registered, out of area or out of country. This may or may not be related to other activities. Adding to see if there is a discernible pattern. There have been other reports in [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] of [[automobiles|car]] burnings & also "foreign" [[automobiles|cars]] having been used as "escape" for unmentioned activities. Highly Likely this has nothing to do with anything.

~+~  
100
