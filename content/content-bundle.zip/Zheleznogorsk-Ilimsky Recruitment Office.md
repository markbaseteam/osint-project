---
locations:
aliases: 
location: Zheleznogorsk-Ilimsky, Irkutsk Region
title: Zheleznogorsk-Ilimsky Recruitment Office
tag: recruitment
date: 2022-05-19  
---

# Zheleznogorsk-Ilimsky Recruitment Office

2022-05-19  
Other  
Recruitment  
https://enoughisenough14.org/2022/06/26/shortly-after-the-longest-night-of-the-year-two-recruiting-offices-burned-at-once-chronicle-of-arson-attacks-until-june-25-2022-russia/  
military enlistment office - shot at with pneumatic weapons in Zheleznogorsk-Ilimsky in [[OSINT Project/Maps/Irkutsk Oblast, Siberian Federal District, Russia|Irkutsk Region]] In the city of Zheleznogorsk-Ilimsky on the night of May 19-20, an army recruiting office was shot at with a BB gun.  
Zheleznogorsk-Ilimsky, [[OSINT Project/Maps/Irkutsk Oblast, Siberian Federal District, Russia|Irkutsk Region]]

See also https://theins.ru/news/251440

~+~  
179
