---
locations:
tag: mechanical, government
date:
aliases: 
location: downtown Tver
title: Tver Surveillance Camera Outage
---

# Tver Surveillance Camera Outage

2022-04-30  
Mechanical  
Government  
https://t.me/tversky/1826  
all online surveillance cameras were offed in the downtown of Tver - both on the city administration's website, and from private providers. Then turned out it was for putting up "Fuck the war" posters on the streets by unknown [[activism|activists]]. During the day the cameras resumed work.  
Tver

See also https://libcom.org/article/anticipation-general-mobilization-7th-overview-anti-military-sabotage-russia

~+~  
158
