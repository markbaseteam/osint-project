---
aliases: antiwar, anti war, peace
locations:
tag: 
date:
title: anti-war
---
> An **anti-war** [[movement]] (also antiwar) is a social [[movement]], usually in opposition to a particular nation's decision to start or carry on an armed conflict, unconditional of a maybe-existing just cause. The term anti-war can also refer to pacifism, which is the opposition to all use of [[Russian Military Industry|military]] force during conflicts, or to anti-war books, paintings, and other works of art. Many [[activism|activists]] distinguish between anti-war movements and peace movements. Anti-war [[activism|activists]] work through protest and other grassroots means to attempt to pressure a government (or governments) to put an end to a particular war or conflict or to prevent it in advance.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Anti-war%20movement)
