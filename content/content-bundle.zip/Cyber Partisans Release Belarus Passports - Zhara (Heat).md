---
locations:
aliases: 
location:
title: Cyber Partisans Release Belarus Passports - Zhara (Heat)
tag:
date:
---

# Cyber Partisans Release Belarus Passports - Zhara (Heat)

2022-07-26  
Mechanical  
Elite,Hearts & Minds  
https://en.currenttime.tv/a/seeking-change-anti-lukashenka-hackers-seize-senior-belarusian-officials-personal-data-/31392092.html  
July 26, the group’s Telegram channel teased passport data for KGB Chairman Ivan Tertel; Central Election Commission Chairwoman Lidiya Yermoshina; the chairwoman of the upper house of parliament, Natallya Kachanova; and ex-Kyrgyz President Kurmanbek Bakiyev, who has lived in Belarus since his 2010 overthrow from power. Belarusian passports are used both as a domestic identity document and for external travel. Each individual’s dossier, the hackers claim, contains passport photos and data; his or her residence permit; the name of the government body or military unit for which the person works; the names of family members, “and so on.” “Will many KGB agents be ready to operate abroad, knowing that data about them has already leaked?” Aside from passport data, the Cyberpartisans claim to have accessed the records of the Belarusian traffic police, which the hackers say include information on registered [[automobiles|cars]] for the KGB, the anti-corruption police, and tsikhary (“silent men”), masked muscle men in plainclothes known for brutally rounding up suspected protesters.Information was also seized about the KGB’s housing assignments, Cyber-Partisan added, which means “they’ll have to change all the apartments.” “Intelligence, counterintelligence, and KGB employees who have special notes (indicating their occupations) in their passports are completely compromised,” said Andriy Baranovych. “And [[activism|activists]], partisans got the data, not the special services. And now the people who are the backbone of the Lukashenka regime will not feel safe.”  
Belarus

This material is from a 2021 hack that penetrated every government agency, including [[air]] gapped intelligence. They have been very careful to release only the material that does not harm ordinary citizens. CP, [[BYPOL]], Flying Storks work with Railway Workers to cyber attack the Belarusian railway system in an effort to slow Russia's advances. This was instrumental in the early days of the war to give Ukraine time to organize and prepare.

~+~
