---
aliases: JSC NPK, NPK, Uralvagonzavod, FE Dzerzhinsky, F.E. Dzerzhinsky, Ural car-building design bureau, Ural Transport Engineering Design Bureau, Ural Scientific-technological complex, Center for Materials Research and Testing, Uralvagonzavod INTEGRATED STRUCTURE, ОАО, UVZ, UVZ-Nizhny Tagil, part of Rostec, part of Rostec Group, Ural Railroad Car Factory, Научно-производственная корпорация, УралВагонЗавод, Uralvagonzavod INTEGRATED, Research and Production Corporation Uralvagonzavod, Research & Production Corporation Uralvagonzavod, Ural Design Department of Railway Car, URALVAGONZAVOD, Ural Design Department of the Railway Car, Uralvagonzavod STRUCTURE
  - Military 
locations:
tag: 
date:
linter-yaml-title-alias: Military
---
    
    - Uralvagonzavod http://www.uvz.ru/
    - Uralvagonzavod INTEGRATED STRUCTURE https://web.archive.org/web/20180116090229/http://www.uvz.ru/structure

  > **Uralvagonzavod** ([[Russia|Russian]]: ОАО «Научно-производственная корпорация «УралВагонЗавод», lit. 'Open Joint Stock Company "Research and Production Corporation Uralvagonzavod"') is a [[Russia|Russian]] machine building company located in Nizhny Tagil, [[Russia]].
>
> It is one of the largest scientific and industrial complexes in [[Russia]] and the largest main battle tank manufacturer in the world.The name Уралвагонзавод means Ural Railroad [[automobiles|Car]] Factory.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Uralvagonzavod)

# JSC NPK Uralvagonzavod imeni F.E.Dzerzhinsky

Address: Vostochnoye Chaussee 28  
City: Nizhny Tagil  
Region: Sverdlovsk region  
Poste code: 622051  
Country: [[Russia|Russian]] Federation  
Phone: (3435) 23-17-74  
Fax: (3435) 23-34-92  


- [**JSC Plant #9**](zavod9.htm), Ekaterinburg
- Chelyabinsk Tractor Plant-URALTRAK, Chelyabinsk
- NPO Electromashina, Chelyabinsk
- [[OSINT Project/Maps/Kamensk-Uralsky, городской округ Каменск-Уральский, Sverdlovsk Oblast, Ural Federal District, 623428, Russia|Kamensk-Uralsky]] Foundry, [[OSINT Project/Maps/Kamensk-Uralsky, городской округ Каменск-Уральский, Sverdlovsk Oblast, Ural Federal District, 623428, Russia|Kamensk-Uralsky]]
- Omsktransmash, [[OSINT Project/Maps/Omsk, Omsk Oblast, Siberian Federal District, 644000, Russia|Omsk]]
- Spetsmash, St. Petersburg
- Tomsk Electrotechnical Plant, Tomsk
- Tver Wagon Works, Tver
- Uralkriomash, Nizhny Tagil
- [**UralTransMash**](uraltransmash.htm), Ekaterinburg
- UralVagonZavod-Trans, [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]
- Vityaz Machine Building Company, Ishimbay
- Yurga Machine-Building Plant, Yurga  
      
    
- [JSC TsNII Burevestnik](burevestnik-tsnii.htm) Nizhny Novgorod
- Central Research Institute of Materials, St. Petersburg
- Murom Special Design Bureau, Murom
- North-West Scientific and Technological Complex, St. Petersburg
- Research Institute of Engines, [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]
- VNIITransmash, St. Petersburg
- Ural Design Bureau of [[transportation|Transport]] Engineering, Nizhny Tagil
- Ural Design Bureau of Carriage Building, Nizhny Tagil
- Ural Scientific Research Technological Institute, Ekaterinburg  
      
    
- UBT-Ecology, Nizhny Tagil
- UBT-Uralvagonzavod, Nizhny Tagil
- UVZ-Logistic, [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]
- UVZ-Media Service, Nizhny Tagil
- UVZ-Energo, Nizhny Tagil  
      
    
- 41 Central Plant of Railway Engineering, [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]] Oblast
- 61 Armored Repair Plant, St. Petersburg
- 81 Armored Repair Plant, [[OSINT Project/Maps/Krasnodar Krai, Southern Federal District, Russia|Krasnodar Krai]]
- 103 Armored Repair Plant, Transbaikal Krai
- 144 Armored Repair Plant, Ekaterinburg
- 163 Armored Repair Plant, [[OSINT Project/Maps/Krasnodar Krai, Southern Federal District, Russia|Krasnodar Krai]]
- 192 Central Plant of Railway Engineering, Bryansk
- 560 Armored Repair Plant, Belogorsky District, [[OSINT Project/Maps/Omutnaya, городское поселение Ерофей Павлович, Skovorodinsky District, Amur Oblast, Far Eastern Federal District, Russia|Amur Oblast]]  
      
    

The intelligence of the Ministry of Defense of Ukraine reported on 15 April 2022 that [[Russia]] cannot produce new tanks due to lack of imported components and financial problems. The [[Russia|Russian]] Uralvagonzavod (UVZ - Nizhny Tagil, part of the Rostec Group of Companies) which produces armored [[automobiles|vehicles]], first of all the main T-72 tank, had already faced a financial crisis. Since the beginning of the full-scale [[Russia|Russian]] invasion of Ukraine, the company has faced numerous problems: rising interest rates on loans, lack of funds to service foreign currency loans, rising prices for materials and components, including armored steel. All this has significantly complicated the production of most types of [[Russian Military Industry|military]] equipment, according to the GUR.

Even despite the advertised "import substitution", [[Russia]] is not able to continue producing high-tech weapons on its own without supplies of imported components. Therefore, the plant must seek a solution to financial problems, requiring one hundred percent subscription to government contracts. According to the intelligence of Ukraine, currently in [[Russia]] the company stops production of new equipment, including tanks "T-90" and "T-14" ("Armata"). In addition, an "operational headquarters" has been set up to repair [[Russian Military Industry|military]] equipment damaged in the war against Ukraine.

Uralvagonzavod sent a train of the latest T-90M "Proryv" tanks to the troops . It is reported 17 May 2022 by "RIA Novosti" with reference to the press service of UVZ.  At Uralvagonzavod (part of the UVZ concern, part of Rostec), a ceremonial dispatch of a train of T-90M Proryv tanks to the RF Ministry of Defense took place,  the company said. The train left under the "Farewell of the Slav". Archpriest John Bragin, rector of the Demetrius Donskoy Church, who consecrated the structure, said  Good must always be able to defend itself. It is useless to persuade the evil forces to stop. And therefore there is such a tradition to consecrate weapons. So that God's help, blessing, protection help him defend his Fatherland, protect people who need help and protection".

Uralvagonzavod (Nizhny Tagil) faced a shortage of components due to the transition to import substitution, the representative of the trade union of the enterprise Alexander Ivanov.  There are no problems with the number of orders, there are problems with their fulfillment, as the plant is intensively switching to import substitution. The plant is looking for [[Russia|Russian]] suppliers, and ways are being developed to purchase raw materials from friendly countries that have not joined the sanctions,  Alexander Ivanov said. He added that in idle time with the preservation of two-thirds of the salary of the employees of the [[automobiles|car]] assembly shop, they are sent in large quantities, and not pointwise. Uralvagonzavod repeatedly reported that the company uses materials and components from  exclusively [[Russia|Russian]] suppliers  in the manufacture of [[railway car|railcars]].

[[Russia|Russian]] manufacturers of innovative wagons with increased payload, including UVZ, are experiencing difficulties in supplying cassette bearings, which are necessary for the production of such wagons. All three [[Russia|Russian]] enterprises producing bearings used foreign components, they have no analogues in [[Russia]]. All three enterprises are "daughters" of Western holdings or joint ventures, in which one share belongs to a [[Russia|Russian]] company, the other to a foreign one. So, EPK-Brenko in Samara is a joint venture of the [[Russia|Russian]] European Bearing Corporation and Brenco (part of the American Amsted Rail), the SKF plant in Tver is a structure of the Swedish SKF, Timken OVK in the Leningrad Region is a subsidiary of the American Timken and United Carriage Company. SKF and Amsted Railhave already announced that they are leaving the [[Russia|Russian]] market.

Uralvagonzavod is a [[Russia|Russian]] government-owned company that builds a variety of [[Russian Military Industry|military]] equipment, including tanks. The unique scientific-industrial complex of [[Russia]], the world's largest in terms of production and technological areas, Uralvagonzavod [UVZ (Ural Vagon Zavod) and not UAZ which is Ulyanovsk Avto Zavod] has always been at the forefront of the [[Russia|Russian]] industry. "The world's first, unique, one …" - these words for decades determined the biography of the company.

 NPK Uralvagonzavod, which is responsible for the production of [[Russia|Russian]] tanks, is again experiencing difficulties with the construction and re-equipment of specialized workshops. In the first case, during the year of work, the contractor was able to master a little more than 10% of the total amount of funds, but they decided to break off relations with him only on the eve of the completion of the construction period.  During the time of delays and unhurried work,  the prices for building materials increased significantly, the planned costs for the facility increased by more than a third, but UVZ classified information about the reasons for the rise in prices and planned changes in project documentation.

A similar situation may develop in another production facility, which is being reconstructed as part of the defense industry modernization program. For armored hull production, the Rostec asset ordered a "modern CNC machining complex", but six months before delivery, management decided to terminate the contract without explaining the reasons. In court, the company, referring to the violation of agreements, requires the termination of the contract and the payment of multi-million dollar compensation. The contractor cannot explain the reasons for such a step by UVZ, since, according to him, CNC equipment has already been put into production.

JSC NPK Uralvagonzavod demanded to terminate the contract for the supply of modern equipment and return more than 187 million rubles. The Arbitration Court of the Sverdlovsk Region considered the corresponding claim of tank builders against the [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]] JSC Gigant. The case file does not specify the essence of the company's claims, only the date of signing the contract - December 8, 2020.

In the past few years, Uralvagonzavod had attracted contractors for the same projects two or three times during the construction and reconstruction of defense workshops. Often this happens for objective reasons - contractors do not cope with the deadlines for work or perform their obligations poorly. But the professional community has long had questions about the choice of partners, as well as "control over their activities by the customer."

For example, in October 2021, UVZ sent Uralstroymontazh LLC a decision to unilaterally terminate the state contract for the reconstruction of special production (preparation production). As part of this project, the Tagil contractor had to build a new electroplating shop by the end of this year for 595 million rubles. As of October, the work was completed for only 65 million rubles, and referring to the impossibility of completing the facility on time, the state-owned enterprise refused to cooperate.

Even under the previous contractor, the company made adjustments to the project documentation, which repeatedly passed the state examination. UVZ did not explain exactly what changes were made to the documentation, perhaps it was about the price increase due to the rise in price of building materials.  Information about this object, its cost and implementation is in limited access,  summed up the representatives of the plant.

In response to [[Russia]] s continued attempts to destabilize eastern Ukraine and its ongoing occupation of Crimea, the U.S. Department of the Treasury on 16 July 2014 imposed a broad-based package of sanctions on entities in the financial services, energy, and arms or related materiel sectors of [[Russia]], and on those undermining Ukraine s sovereignty or misappropriating Ukrainian property. Treasury designated eight [[Russia|Russian]] arms firms, including Uralvagonzavod, which are responsible for the production of a range of materiel that includes small arms, mortar shells, and tanks.

By designating firms in the arms or related materiel sector, Treasury has cut these firms off from the U.S. financial system and the U.S. economy. Executive Order 13661 includes a directive that all property and interests in property that are in the United States, that hereafter come within the United States, or that are or thereafter come within the possession or control of any United States person (including any foreign branch) of the following persons are blocked and may not be transferred, paid, exported, withdrawn, or otherwise dealt in.

State Unitary Enterprise "Production Association "URALVAGONZAVOD" imeni Felix E. Dzerzhinsky, is one of the [[Russia|Russian]] leaders in developing and manufacturing high-quality machine-building products of world class. Besides it enjoys a firm reputation as careful and reliable partner. Its main activities are the following: production of [[railway car|railway cars]] and tanks, [[roads|road]]-building [[automobiles|vehicles]], metallurgical production, tool production, production of consumer goods.

"URALVAGONZAVOD" ["Ural wagon factory"] is a unique machine-building enterprise, one of the largest scientific and industrial complexes is [[Russia]] that possesses high-power technical and intellectual potential.

[![](images/map-nizhny-tagil-plant-1-s.jpg)](images/map-nizhny-tagil-plant-1.jpg) [![](images/map-nizhny-tagil-plant-2-s.jpg)](images/map-nizhny-tagil-plant-2.jpg) [![](images/map-nizhny-tagil-ammo-1-s.jpg)](images/map-nizhny-tagil-ammo-1.jpg) [![](images/map-nizhny-tagil-ammo-2-s.jpg)](images/map-nizhny-tagil-ammo-2.jpg) [![](images/map-nizhny-tagil-test-1-s.jpg)](images/map-nizhny-tagil-test-1.jpg) [![](images/)](images/) [![](images/)](images/)

There is stiff competition between different designers and manufacturers for almost all defense goods in [[Russia]], and there is not enough money to go around for everyone. This meant that when the [[Russian Military Industry|military]] decided to design new tanks at Nizhny Tagil's Uralvagonzavod, which produces the T-90 tank, it spelled disaster for the [[OSINT Project/Maps/Omsk, Omsk Oblast, Siberian Federal District, 644000, Russia|Omsk]]-based Transmash plant and its T-80 tank.

![](images/logo-uralvagonzavod.jpg)"URALVAGONZAVOD" is one of the [[Russia|Russian]] leaders in developing and manufacturing high-quality machine-building products of world class. Besides it enjoys a firm reputation as careful and reliable partner. Its main activities are the following: production of [[railway car|railway cars]] and tanks, [[roads|road]]-building [[automobiles|vehicles]], metallurgical production, tool production, production of consumer goods.

"URALVAGONZAVOD" was built in the years of the first Five-Year Plan (1931-1936) as an integral part of Ural-Kuzbas coal-metallurgical complex. On 11 October 1936, the first railway heavy-[[cargo|freight]] [[automobiles|cars]] came off the enterprise conveyor. During the incomplete five prewar years the enterprise produced in total 35.5 thousand of various [[railway car|railway cars]].

A singular role was played by "URALVAGONZAVOD" in the years of Great Patriotic War (1941-1945). Kharkov Locomotive Factory (KhPZ) merged with Uralvagonzavod in Nizhny Tagil to form Ural Tank Factory No. 183 (I.V. Stalin), 1941 - becoming the world's largest tank factory. Ural Tank Factory No. 183, developed from "URALVAGONZAVOD" in 1941 and was named for "Komintern". It became one of the largest defense factories of [[Russia]]. Every day it sent an echelon of T-34 tanks to the front from its conveyors. 35 thousand of these battle [[automobiles|vehicles]] were produced by the factory in the years of the war.

In August 1941, by the decision of the State Defense Committee on the basis of Uralvagonzavod and 12 evacuated enterprises was created Ural tank factory number 183 imeni Comintern. In just 2 months, production was rebuilt to [[Russian Military Industry|military]] production. Almost every third tank, which took part in the fighting, came off the line of the Ural tank factory. During the war in the squares UTZ has been collected 25 thousand combat [[automobiles|vehicles]]. This is more than in all plants in Germany (23 thousand. Tanks) combined.

For contribution to the team victory number 183 UTZ imeni The Communist International was awarded the Order of Red Banner of Labor (1942), the Red Banner (1943), World War 1 degree (1945). In 1944 the Tank Design Bureau was awarded the Order of Lenin.

![](images/uralvagonzavod-4.gif) With the T-34 actually started the domestic tank building design school, which has developed and strengthened within the walls of Uralvagonzavod. Postwar tanks of the T-44 to T-62 kept the fighting traditions "Thirty." [[fire]] armor maneuver embodied in the modern mass tank T-72, which provides the basis of ground forces in many countries. During its creation and organization of production Uralvagonzavod was awarded the Order of Lenin (1970) and the October [[revolutionaries|Revolution]] (1976).

The new generation of [[Russia|Russian]] tanks - rocket-gun tank T-90S with reactive armor, and opto-electronic system of [[fire]] suppression jointly combat and technical characteristics, not only to the best tanks in other countries, but in many ways superior to them. About 100 thousand units of armored [[automobiles|vehicles]] were produced at Uralvagonzavod, since 1941 - and it is an absolute world record in tank.

The continuation of design ideas began to tank builders [[automobiles|car]] logistics engineering equipment, which are used not only in the [[Russian Military Industry|military]] but also for peaceful purposes: to help in the aftermath of accidents, disasters, earthquakes.

After the War, A.A.Morozov took the core of the design team with him. The remainder of the design bureau in Nizhniy Tagil was tasked with ensuring that T-34, T-44, and T-54 blueprints used in production (recall that the T-54 was built at many factories, including ones in Poland, China, and Czechoslovakia) were identical to the originals. The bureau also had to improve and modernize the T-54 tank. However, the ambitious collective that remained, used to creative work, was not satisfied with this arrangement. Interestingly enough, factory management was also interested in changing tank models.

In March, 1946, "URALVAGONZAVOD" proceeded with production of [[cargo|freight]] [[railway car|railway cars]]. The [[JSC NPK Uralvagonzavod imeni F.E.Dzerzhinsky]] Building is at the head of [[cargo|freight]] [[automobiles|car]] building, both in undercarriage and automatic [[railway car|couplers]]. All the factories manufacturing [[automobiles|car]]-building products work by the documentation of this organization. Specialists of Design Department have developed a significant list of projects for [[cargo|freight]] [[automobiles|cars]], [[automobiles|trucks]], automatic [[railway car|couplers]] and braking devices. This list comprises 40 models of 4-axle [[railway car|gondola]] [[automobiles|cars]] different in design and carrying capacity, 12 models of 8-axle all-metal [[railway car|gondola]] cars, 5 models of 6-axle [[railway car|gondola cars]], several models of [[railway car|box cars]], tanks and [[railway car|flat cars]].

In the early fifties the enterprise began to fulfill important orders for the space service, including design and production of equipment for launching orbital vehicles "Vostok", "Voskhod", "Proton" and shuttle "Energy" - "Buran". Tsisternostroenie began with a cryogenic production association (created in 1954). Uralvagonzavod has made a significant contribution to the design and manufacture of systems and equipment for launch of artificial satellites (since the launch of the first 4 October 1957), and manned orbital [[automobiles|vehicles]], reusable space system "Energy-Buran", and also participated in the international program "Marine start".

Today UVZ is diversified engineering association, which produces about 200 kinds of products. The company has developed and in the 1990s put into production the most modern samples of high-performance [[roads|road]]-building and municipal machines. Being under conditions of a practical absence of financing (lack of state order) from the main customers and at the same time remaining the status of "State Enterprise" "URALVAGONZAVOD" has nevertheless sought funds. It has been proceeding to implement a general policy of further improvement of technical and specific characteristics of the main kinds of production almost at its own expense. In so doing, it has pursued a purpose to maintain and enhance competitiveness on the domestic market and especially on the foreign market thus making an essential contribution to the national economy.

![](images/uralvagonzavod.gif)For reshaping the structure of production, a program of conversion has been developed and approved at the enterprise. The first trend of conversion is development and production of [[roads|road]]-building [[automobiles|vehicles]] with the use of "double technologies". For this purpose the facilities have been reshaped, special equipment has been purchased and produced, assembly technological lines have been mounted.

In the context of conversion specialists of the State Unitary Enterprise "Production Association "URALVAGONZAVOD" designed and put into full production a family of [[roads|road]]-building [[automobiles|vehicles]] of various purposes. This family of [[roads|road]]-building [[automobiles|vehicles]], produced by "URALVAGONZAVOD", completely satisfies the basic requirements of national economy of all regions of [[Russia]]. The second trend of conversion is creation of facilities for production of special-purpose cars and tanks for mainline railways. [[railway car]] assembly production has put into production new models of [[automobiles|cars]] for the national economy.

In accordance with the objectives of the priority national project "Agro-industrial complex", experts Uralvagonzavod has been developed and put into mass production of universal tractors RTM-160. Despite his young age, he already has a prestigious award shows, and most importantly - has proven itself in the fields of the country.

UVZ is [[Russia|Russia's]] largest developer and manufacturer of various types of [[freight train|freight cars]], [[railway car|gondola cars]], [[automobiles|trucks]], trucks, tank containers. They - his business card. Since 1979, the company switched to production of all-metal [[railway car|gondola]]. Since the assembly line went off about a million [[automobiles|cars]] for different purposes.

![](images/uralvagonzavod-3.gif)URALVAGONZAVOD published its preliminary 2011 consolidated financial statement (apart from  CHTZ-URALTRACK  Ltd, JSC  Electric Machine Building Works LEPSE , OJSC  Specmash , OJSC  UralNITI , OJSC  Elektroavtomat ). The financials show that the year revenue in 2011 was up to $3 billion, profit on sales   $0.46 billion and net income   $0.33 billion.

Expressed in percentage terms the sales revenue has the following correlation: 68%   Division of Railway Vehicles, 30%   Division of Special Equipment, 2%   other. While the correlation of profit on sales is 85%   Division of Railway Vehicles, 15%   Division of Special Equipment. Return on sales amounts to 15.6% (19.2%   Division of Railway Vehicles, 8.4%   Division of Special Equipment). EBITDA equals 16 billion rubles, debt/EBITDA ratio   2, loan interest/EBITDA ratio   8.6%. In terms of financial and economic activity UVZ unified its budget and put into practice budget committees in 2011. Creditor position management is now centralized at the Corporation Management Center.

Oleg Sienko, UVZ Corporation CEO, emphasized at the 16 June 2015 enterprises executives meeting that despite complicated economic situation over 90% of the integrated structure enterprises had completed the year in the black, including for net profit. In general, the Corporation has been operating with net profit for five years in a row.

Sienko emphasized the large-scale work of the Corporation on Defense Procurement, its volume made up USD 1.55 bn. this year (2.7 times increase compared to 2013). In total, over 1,500 units of new and upgraded equipment were delivered to the forces. Besides, the CEO underlined that the Corporation executed export contracts for over USD 2.57 bn. in 2014.

Oleg Sienko set the objectives for the enterprises of the Corporation for 2015. In particular, he said:  Increase of export, including that of civil products, is becoming one of the priorities under current conditions . The Head of the Corporation also emphasized that  crisis period means not only new challenges but new opportunities, as well . He encouraged the executives of the enterprises to focus on absolute execution of the Defense Procurement, development of new promising products, cost reduction and expansion of the internal cooperation.

It was also said about increase of availability of railway vehicles, overall production whereof will make up 20,000 units next year with the preference given to manufacture of innovative [[railway car|railcars]].

Yuriy Bodyaev, First Deputy CEO, in his report on the Corporation s results in 2014 mentioned that the expected key financial and economic indicators of the Corporation will make up USD 3.86 bn. for revenue, USD 165 m. for sales profit, and USD 18.94 m. for net profit.

To carry out large-scale projects help unite a powerful intellectual and technological potential, Uralvagonzavod formed a strong scientific school represented by the Ural car-building design bureau, the Ural Transport Engineering Design Bureau, Ural Scientific-technological complex, the Center for Materials Research and Testing, and other experimental design offices nationwide level.

UVZ is a company with high quality production based on existing technology and intellectual traditions. Today Uralvagonzavod headed integrated structure, bringing together 40 industrial companies, research institutes and design offices in five federal districts of Russia and abroad.

  

  
  

**NEWS****LETTER**
**Join the GlobalSecurity.org mailing list**
   **Enter Your Email Address**  

 

  

  

![](https://cookie-cdn.cookiepro.com/ccpa-optout-solution/v1/assets/icon-do-not-sell.svg)Do Not Sell My Personal Information

[Advertise with Us](/org/advertise.htm "Advertise with GlobalSecurity.org") | [About Us](/org/index.html "About GlobalSecurity.org") | [GlobalSecurity.org In the News](/org/news/index.html "GlobalSecurity.org In the News") | [Site Map](/sitemap.htm "GlobalSecurity.org Site Map") | [Privacy](/privacy.htm "GlobalSecurity.org Privacy Policy")

[Copyright](https://www.globalsecurity.org/copyright.htm "Copyright") © 2000-2022 GlobalSecurity.org All rights reserved.  
Site maintained by: [John Pike](https://www.globalsecurity.org/org/staff/pike.htm "John Pike")  

 

Page last modified: 03-07-2022 15:25:02 ZULU

---
aliases: URALVAGONZAVOD, Ural Design Department of Railway Car, Ural Design Department, Ural Railway Car, Ural Design Department of the Railway Car, Ural Design Department of Railway Cars, Ural Design Department of the Railway Cars
locations:
tag: 
date:
title: Ural Design Department of Railway Car
---

Ural Design Department of Railway Car  
URALVAGONZAVOD
