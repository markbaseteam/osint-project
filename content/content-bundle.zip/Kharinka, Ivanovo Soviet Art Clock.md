---
locations:
aliases: ['Kharinka, [[Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] Soviet Art Clock', 'art clock, soviet art clock']
location: 54, 2nd Camp Street, Kharinka, Ivanovo
title: 'Kharinka, [[Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] Soviet Art Clock'
tag: cultural
date: 2022-07-01 
linter-yaml-title-alias: 'Kharinka, [[Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] Soviet Art Clock'
---

# Kharinka, [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] Soviet Art Clock

2022-07-01  
Other  
Cultural  
https://www.ivanovonews.ru/news/1152528/  
Another Soviet Art Object was dismantled in [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]]. In [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] publics there were reports that an art object was dismantled on Kharinka - a clock installed on the wall of house 54 on 2nd Camp Street. The metal watch was also illuminated, locals remember that on New Year's Eve it was included until the 90s. Why the design was decided to be removed is still unknown.  
54, 2nd Camp Street, Kharinka, [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]]

Reference to "another Soviet art object" indicates there are more mystery dismantlings.  
~+~

142
