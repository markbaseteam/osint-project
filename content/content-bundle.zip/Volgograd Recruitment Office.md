---
locations:
aliases: 
location:
title: Volgograd Recruitment Office
tag: molotov, recruitment
date: 2022-05-15  
---

# Volgograd Recruitment Office

2022-05-15  
Molotov  
Recruitment  
https://www.rferl.org/a/russia-enlistment-offices-arson/31851677.html  
At about the same time, a [[fire]] broke out in a similar center in [[Volgograd]], formerly [[Stalngrad]], in [[OSINT Project/Maps/Southern Russia, улица Степана Разина, Ворошиловский район, Volgograd, Volgograd Oblast, Southern Federal District, 400001, Russia]]. According to police, the culprits used a Molotov cocktail. Police believe a Molotov cocktail was tossed through the window. The [[fire]] damaged about 20 square meters.  
Volgograd

Volgograd On May 15, unknown individuals targeted the military registration office in Volgograd. At least one “molotov” flew into the basement of a recruitment center, where a [[fire]] broke out consuming the 20 square meter room. No one was [[arrested]]. https://darknights.noblogs.org/post/tag/khanty-nansi/ 30 year old Denis Serdyuk, suspected of an [[fire|arson]] attack against amilitary call-up center in Volgograd, is being held in remand [[prison]] # 1 of his town. He is being charged with ”destruction of property” and ”[[hooliganism]]”, and may be sentenced to 10 years in [[prison]]. https://avtonom.org/en/news/support-suspected-arsonists-against-military-call-ups-and-other-russian-anti-war-prisoners

~+~  
34
