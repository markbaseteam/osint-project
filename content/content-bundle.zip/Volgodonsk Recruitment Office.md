---
aliases: 
location: geo:47.5128177,42.1717606
category:molotov
date:
tag:
---
[Volgodonsk](geo:47.5128177,42.1717606)



# Volgodonsk Recruitment Office

Molotov  
Recruitment  
https://www.rferl.org/a/russia-enlistment-offices-arson/31851677.html  
Military enlistment offices in the northern [[OSINT Project/Maps/Khanty-Mansiysk, Khanty-Mansiysk Urban Okrug, Khanty-Mansiysk Autonomous Okrug – Ugra, Ural Federal District, 628000, Russia|Khanty-Mansi]] region in and Volgodonsk region in the south have also been attacked.  
Volgodonsk Region