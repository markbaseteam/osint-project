---
locations:
aliases: ['website: [izts.ru](https://izts.ru/)', 'Ivanovo Heavy Machine Tool Plant, Ivanovo Heavy Machine Plant, Ivanovo Heavy Machine Tool Factory, Ivanovo Heavy Machine Facotry, Ivanovo Heavy Machine Tool, Ivanovo Heavy Machine, Ivanovo Heavy Machine-Tool Plant Joint Stock, Ivanovo Heavy Machine-Tool Plant, Ivanovo Heavy Machine-Tool Plant Joint Factory']
location: Ivanovo Heavy Machine Tool Plant, Kinishma, Ivanovo
title: 'website: [izts.ru](https://izts.ru/)'
tag: fire, defense, defence
date: 2022-05-19  
linter-yaml-title-alias: 'website: [izts.ru](https://izts.ru/)'
---

#

website: [izts.ru](https://izts.ru/)  
Revenue: <$5 Million

[[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] Heavy Machine Tool Plant  
2022-05-19  
[[fire]]  
Other Defence  
https://www.dailykos.com/stories/2022/5/19/2098927/-Ivanovo-Heavy-Machine-Tool-Plant-is-the-Latest-Suspicious-Fire-at-a-Strategic-Site-in-Russia  
The [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] Heavy Machine Tool Plant is allegedly critical to several defense related products. A major [[fire]] at this plant was [[fire|burning]] for hours today.  
[[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]]

The chemical plant [[fire]] from April 21 in Kinishma & a conscript registration office hit April 22 are nearby.

~+~  
48
