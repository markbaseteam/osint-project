---
locations:
aliases: ['Kustanayskaya Street, [[Moscow]] Cars']
location: Kustanayskaya street, Moscow
title: 'Kustanayskaya Street, [[Moscow]] Cars'
tag: fire
date: 2022-04-27  
linter-yaml-title-alias: 'Kustanayskaya Street, [[Moscow]] Cars'
---

# Kustanayskaya Street, [[Moscow]] Cars

2022-04-27  
[[fire]]  
Other  
https://twitter.com/UKRWarSitRep/status/1519542788639105025  
Today in [[Moscow]] on Kustanayskaya street, several explosions were heard due to seven [[fire|burning]] [[automobiles|cars]] https://twitter.com/UKRWarSitRep/status/1519542788639105025  
Kustanayskaya street, [[Moscow]]

~+~  
156
