---
locations:
aliases: Kirzhach railway, Kirzhach train, Kirzhach rail
location: Kirzhach
title: Kirzhach railway track sabotage by BOAK
tag: military unit 55443 VD Barsovo, 55443 VD Barsovo, 51st arsenal, railway, infrastructure
date: 2022-06-28
---

# Kirzhach railway track sabotage by BOAK

2022-06-28  
Mechanical  
Railway,Infrastructure  
https://t.me/boakom/34  
Anarcho-Communists Combat Organisation (BOAK) reported on June 28 in own Telegram channel about their second act of railway blocking to the military objects after such action a month ago near Sergiyev Posad: “The BOAK-Vladimir cell takes responsibility for the sabotage on the railway line leading to military unit 55443 VD Barsovo (the 51st arsenal of the Main Rocket and Artillery Directorate of the Ministry of Defense of the RF) near Kirzhach. Unlike the previous attack, where we took responsibility without waiting for the result (decided to publish the information to show all the guerrillas how accessible the target was), for subsequent actions we chose the strategy of waiting for the result, not publishing the report until either success was achieved or the facts that the sabotage was discovered will not be received. Unfortunately, in this case, we received reliable information (a video in the offer from a subscriber, apparently, a driver who was driving along this branch) that the sabotage was discovered on the evening of June 25. However, even in this form, the sabotage caused harm to the enemy, delaying the [[movement]] of trains with military equipment, and causing economic damage due to the need to restore the railway lines. What has been done:–34 nuts (17 on each side) holding the rail are unscrewed–4 nuts connecting the joint are unscrewed–The rail at the junction is raised, laid on the connecting plate (so as not to fall into place) and set aside.–The rails were connected to each other with a wire, in case a signal current is transmitted along the rail, to detect an open (thanks to the advice from subscribers). We call on everyone to join the rail war! Each stopped train is a minus of shells and rockets that could fly into peaceful Ukrainian cities”.  
Sergiyev Posad near Kirzhach

See also https://enoughisenough14.org/2022/07/04/rail-war-belarusians-face-the-death-penalty-the-blocked-trans-sib-anarchists-work-around-moscow-belarus-russia/

~+~  
52
