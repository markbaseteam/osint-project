---
aliases: 
location: Transnistria
title: State Security Committee Building Transnistria
tag: explosion, government  
date: 2022-04-25  
locations: 46°50′N 29°37′E
---

# State Security Committee Building Transnistria

2022-04-25  
Explosion  
Government  
https://liveuamap.com/en/2022/25-april-explosions-reported-in-tiraspol-transnistria-near  
Explosions reported in Tiraspol, Transnistria near the building of State Security committee "MGB"  
Triaspol, Transnistria  
46°50′N 29°37′E  
It's important to be careful with Transnistria. High likelihood of false flags

~+~  
171
