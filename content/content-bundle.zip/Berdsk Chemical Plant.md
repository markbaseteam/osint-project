---
locations:
aliases: 
location:
title: Berdsk Chemical Plant
tag: 
date:
---

# Berdsk Chemical Plant

2022-05-17  
[[fire]]  
Chemical  
https://www.newsweek.com/russia-fire-berdsk-emergency-ministry-siberia-novosibirsk-1707193  
Industrial building with office space at Khimzavodskaya Street, Berdsk near [[OSINT Project/Maps/Novosibirsk, Novosibirsk Oblast, Siberian Federal District, 630000, Russia|Novosibirsk]] in [[Siberian Federal District|Siberia]] is on [[fire]] & damaged equipment. State emergency services says polyethylene (very common plastic) is the source. Unclear of origin. [[fire]] broke out in an industrial building. 22,000 square feet in a building with office space in Berdsk, near [[Siberian Federal District|Siberia]]'s largest city of [[OSINT Project/Maps/Novosibirsk, Novosibirsk Oblast, Siberian Federal District, 630000, Russia|Novosibirsk]] The regional department of Russia's emergency ministry said in a post on social media that the source of the [[fire]] were polyethylene products on the first floor of the building which was located on Khimzavodskaya Street.  
Khimzavodskaya Street, Berdsk

~+~  
103
