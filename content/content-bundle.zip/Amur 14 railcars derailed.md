---
aliases: Amur railcars, amur railcars, amur derailed, amur 19 railcars derailed
location: [Sgibeevo](geo:54.0722695,122.7113331) 
Bolshaya [[Maps/[[Maps/Omutnaya, городское поселение Ерофей Павлович, Skovorodinsky District, Amur Oblast, Far Eastern Federal District, [[Russia]]|[[Maps/[[Maps/Omutnaya, городское поселение Ерофей Павлович, Skovorodinsky District, Amur Oblast, Far Eastern Federal District, [[Russia]]|Omutnaya]], городское поселение Ерофей Павлович, Skovorodinsky District, Amur Oblast, Far Eastern Federal District, [[Russia]]|Omutnaya]], городское поселение Ерофей Павлович, Skovorodinsky District, Amur Oblast, Far Eastern Federal District, [[Russia]]]]|Omutnaya]] 
Sgibeevo – Bolshaya Omutnaya section in the Amur region
title: Amur 14 railcars derailed, Amur 19 railcars derailed
tag: railway, infrastructure, mechanical
date: 2022-07-02
locations: geo:54.0722695,122.7113331
---

Note - merged with Amur 19 [[railway car|railcars]] derailed
# Amur 14 [[railway car|railcars]] derailed

2022-07-02  
Mechanical  
Railway,Infrastructure  
https://t.me/ostanovivagonyy/114  
the supply of occupiers troops from the Far East is getting more and more difficult. Two days ago, 14 wagons of a [[freight train]] derailed on the Sgibeevo – Bolshaya [[OSINT Project/Maps/Omutnaya, городское поселение Ерофей Павлович, Skovorodinsky District, Amur Oblast, Far Eastern Federal District, Russia|Omutnaya]] section in the Amur region. Due to the incident, the dimensions of the adjacent track were violated and the contact network support was damaged. The [[movement]] on this section was stopped, [[passengers|passenger]] train [[Moscow]]-Vladivostok was delayed. Thus, the [[OSINT Project/Maps/Monument to the 170th anniversary of the Trans-Siberian Railway, улица Леконта, Привокзальный, Ленинский административный округ, Omsk, Omsk Oblast, Siberian Federal District, 644000, Russia|Trans-Siberian Railway]] – the largest railroad in the world and one of the most important [[transportation|transport]] routes between [[Russia]] and China – was temporarily stopped! 330 employees of the line and a lot of equipment, arrived from three other stations, were involved in the elimination of the consequences.  
Sgibeevo – Bolshaya, [[OSINT Project/Maps/Omutnaya, городское поселение Ерофей Павлович, Skovorodinsky District, Amur Oblast, Far Eastern Federal District, Russia|Omutnaya]] section, Amur region

Also see https://enoughisenough14.org/2022/07/04/rail-war-belarusians-face-the-death-penalty-the-blocked-trans-sib-anarchists-work-around-Moscow-belarus-russia/

~+~  
194

---
aliases: 
location:
[Sgibeevo](geo:54.0722695,122.7113331) 
Bolshaya [[Maps/[[Maps/Omutnaya, городское поселение Ерофей Павлович, Skovorodinsky District, Amur Oblast, Far Eastern Federal District, [[Russia]]|[[Maps/[[OSINT Project/Maps/Omutnaya, городское поселение Ерофей Павлович, Skovorodinsky District, Amur Oblast, Far Eastern Federal District, Russia|Omutnaya]], городское поселение Ерофей Павлович, Skovorodinsky District, Amur Oblast, Far Eastern Federal District, [[Russia]]|Omutnaya]], городское поселение Ерофей Павлович, Skovorodinsky District, Amur Oblast, Far Eastern Federal District, [[Russia]]]]|Omutnaya]] 
title:
tag:
date:
locations: geo:54.0722695,122.7113331
---


# Amur 19 railway [[automobiles|cars]] derail

2022-06-29  
Mechanical  
Railway,Infrastructure  
https://og.ru/ru/news/126845  
In the Amur region, 19 [[automobiles|cars]] of a [[freight train]] derailed on the Sgibeevo - Bolshaya [[OSINT Project/Maps/Omutnaya, городское поселение Ерофей Павлович, Skovorodinsky District, Amur Oblast, Far Eastern Federal District, Russia|Omutnaya]] section. Due to the accident that occurred on June 29, the size of the neighboring track was broken and the support of the contact network was damaged.  
Amur, [[Russia]]

as a result of the incident, traffic on the [[OSINT Project/Maps/Monument to the 170th anniversary of the Trans-Siberian Railway, улица Леконта, Привокзальный, Ленинский административный округ, Omsk, Omsk Oblast, Siberian Federal District, 644000, Russia|Trans-Siberian Railway]] had to be temporarily stopped. A group of [[anti-war]] [[activism|activists]] "Stop the [[automobiles|Cars]]" claimed responsibility for the derailment of the train. "If this goes wrong, the [[Russian Military Industry|military]] supply from the Far East will soon be covered with a copper basin," they said in their telegram channel. Earlier, participants of this [[movement]] hinted at their involvement in accidents on railway routes in Pskov, Rostov, Orenburg, Chelyabinsk regions, [[OSINT Project/Maps/Krasnoyarsk, Krasnoyarsk Urban Okrug, Krasnoyarsk Krai, Siberian Federal District, 660000, Russia|Krasnoyarsk]] Krai and other regions. The [[activism|activists]] call their goal to delay railway communication to stop [[Russia|Russian]] [[Russian Military Industry|military]] supplies to Ukraine.

~+~  
99