---
aliases: airport, aerobase, runway, airports, air bases, airbase, airbases, aerobases, airports, runways
locations:
tag: 
date:
title: air base
---
> An **[[air]] base** (sometimes referred to as a [[Russian Military Industry|military]] [[air]] base, [[Russian Military Industry|military]] airfield, [[Russian Military Industry|military]] airport, [[air]] station, naval [[air]] station, [[air]] force station, or [[air]] force base) is an aerodrome used as a [[Russian Military Industry|military]] base by a [[Russian Military Industry|military]] force for the [[operations|operation]] of [[Russian Military Industry|military]] [[aircraft]].
>
> [Wikipedia](https://en.wikipedia.org/wiki/Air%20base)
