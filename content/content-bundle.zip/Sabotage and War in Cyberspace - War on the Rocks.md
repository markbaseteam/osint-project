---
aliases: Sabotage and War in Cyberspace, Cyber Sabotage, cyberwarfare, cyberwar, cyber war, cyber warfare
locations:
tag: 
date:
title: Sabotage and War in Cyberspace
linter-yaml-title-alias: Sabotage and War in Cyberspace
---
                                              

# Sabotage and War in Cyberspace

Joshua Rovner

July 19, 2022

![cyber war](https://2k8r3p1401as2e1q7k14dguu-wpengine.netdna-ssl.com/wp-content/uploads/2022/07/cyber-war-1024x684.jpg)

Russia’s invasion of Ukraine is a terrible throwback to [[attrition warfare]]. Having failed in their opening salvo against Kyiv, Russian forces have settled into a grinding campaign in other parts of the country, using artillery bombardments in advance of slowly moving infantry. There is nothing elegant about their approach. After years of speculation about [[hybrid warfare]] and [[grey-zone tactics]], Russia has reverted to form. Its offensive cyberspace operations have been particularly marginal to its conventional military effort. Open sources suggest that Russia has rarely used destructive malware since the February invasion. Over the same period it fired millions of bullets, artillery shells, and rockets, with devastating effect. As Michael Kofman put it, “This is a heavy metal war.”

This has surprised many observers, who thought the war would follow a different path. I was one of them. I suspected that Russia would open the war with a burst of [[cyberspace operations]] designed to hobble Ukrainian communications and make it impossible for Kyiv to organize a coherent defense. It’s easy to see the allure of such a concept, though I doubted it would succeed because the technical demands are quite high. Nonetheless, Russian military doctrine stresses the importance of information dominance, and analysts have spent years sounding the alarm about the potential for large-scale digital disruption in the event of war. Instead, most Russian efforts appear to be related to [[espionage]] and [[propaganda]], with only a smattering of [[sabotage]].

Microsoft has issued two on Russian operations. Its data suggests that most Russian activities are about stealing information and influencing the public debate, not incapacitating information systems or causing physical harm. Russia may unleash such operations later, the authors warn, but so far, they have been largely absent. Indeed, it is telling that Microsoft devotes the lion’s share of its June report to Russian [[propaganda]], detailing the ways in which Russian agencies pre-positioned fake stories before the war to make them seem more credible later. Such public methods are easier to track, to be sure, which explains part of why they receive so much attention. But if disruptive operations were so important to Russian cyberspace activities, we should at least see their residue.

The June report also suggests a correlation between cyberspace operations and conventional campaigns, highlighting a half-dozen instances in which malware moved on a target in advance of military forces. Yet the link is tenuous in some cases, and in others it appears that Russian cyberspace efforts were simply aimed at gathering information. Efforts to use malware to disable Ukrainian communications, or to cause harm to Ukraine’s foreign supporters, have been infrequent and largely inconsequential. There is little evidence in open sources that Russian cyberspace operations have had a meaningful effect on Ukraine’s combat performance. Nor have they had much effect on the international response. Cyberspace operations, in short, have not played a key role in this war.

Why not? Observers have offered a host of plausible explanations. Aid from the United States and the private sector may have provided a critical bulwark against digital aggression, as Microsoft suggests. Or perhaps Ukraine’s defenders were better than expected. Maybe Russia restrained its activities because it feared destroying the networks it would need after occupying the country. Maybe Russia withheld damaging operations against the West because it wants to use the threat of cyberspace attacks to coerce Ukraine’s supporters. Russian cyber activities might have been ineffective because they are too reliant on hackers whose activities the Russian state cannot fully control. Going on the offensive in cyberspace is harder than we thought for these reasons. Defenders have key advantages in a conflict, not least their ability to move information into the cloud and otherwise make their communications redundant.

There may be truth in these claims—it is too soon to tell. But there is a simpler explanation. Because cyberspace is an information domain, cyberspace operations are about gaining information advantages. Intelligence agencies scour the domain in search of details that may be useful to strategists, diplomats, and military leaders. They want to know about the strength and disposition of enemy forces, as well as the capabilities and intentions of third parties. In this sense, Russian cyberspace activities are no different from intelligence gathering in past conflicts. Espionage—collecting and interpreting secret information to give political and military leaders decision advantage—is key. Sabotage remains secondary.

[[sabotage]]
