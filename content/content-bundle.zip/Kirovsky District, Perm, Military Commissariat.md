---
locations:
aliases: ['[[Maps/Kirovsky District, Stavropol Krai, North Caucasian Federal District, Russia|Kirovsky District]], [[Perm, Russia|Perm]], Military Commissariat']
location: Zakamskaya Street, Perm
title: '[[Maps/Kirovsky District, Stavropol Krai, North Caucasian Federal District, Russia|Kirovsky District]], [[Perm, Russia|Perm]], Military Commissariat'
tag: 
date:
linter-yaml-title-alias: '[[Maps/Kirovsky District, Stavropol Krai, North Caucasian Federal District, Russia|Kirovsky District]], [[Perm, Russia|Perm]], Military Commissariat'
---

# [[OSINT Project/Maps/Kirovsky District, Stavropol Krai, North Caucasian Federal District, Russia|Kirovsky District]], [[Perm, Russia|Perm]], Military Commissariat

2022-06-23  
Molotov  
Recruitment  
https://www.newsweek.com/russia-dissent-putin-ukraine-war-man-molotov-cocktail-fsb-government-building-fire-1720900  
4 Molotov cocktails thrown at the office of the Military Commissariat for [[OSINT Project/Maps/Kirovsky District, Stavropol Krai, North Caucasian Federal District, Russia|Kirovsky District]] in Zakamskaya Street in [[Perm, Russia|Perm]]. Baza reported that last week in the city of [[Perm, Russia|Perm]], more than 700 miles east of [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]], four bottles filled with inflammable liquid were thrown into the office of the Military Commissariat for [[OSINT Project/Maps/Kirovsky District, Stavropol Krai, North Caucasian Federal District, Russia|Kirovsky District]]. There was no [[fire]], and the attackers fled the scene See also https://theins.ru/en/news/252560  
Zakamskaya Street, [[OSINT Project/Maps/Kirovsky District, Stavropol Krai, North Caucasian Federal District, Russia|Kirovsky District]], [[Perm, Russia|Perm]]

June 23/24, 2022: 4 Molotov cocktails thrown at the office of the Military Commissariat for [[OSINT Project/Maps/Kirovsky District, Stavropol Krai, North Caucasian Federal District, Russia|Kirovsky District]] in Zakamskaya Street in [[Perm, Russia|Perm]].

~+~  
193
