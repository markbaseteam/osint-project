---
locations:
aliases: ['[[Maps/Kyzyl, Kyzyl City, Tuva Republic, Siberian Federal District, Russia|Kyzyl]] Warehouses']
location: Kyzyl, Republic of Tuva
title: '[[Maps/Kyzyl, Kyzyl City, Tuva Republic, Siberian Federal District, Russia|Kyzyl]] Warehouses'
tag: fire
date: 2022-07-04  
linter-yaml-title-alias: '[[Maps/Kyzyl, Kyzyl City, Tuva Republic, Siberian Federal District, Russia|Kyzyl]] Warehouses'
---

# [[OSINT Project/Maps/Kyzyl, Kyzyl City, Tuva Republic, Siberian Federal District, Russia|Kyzyl]] Warehouses

2022-07-04  
[[fire]]

https://globalhappenings.com/top-global-news/221879.html  
A massive [[fire]] broke out on Monday, July 4. The [[fire]] engulfed the warehouses of building materials. It spread to 2.8 thousand square meters. 2 am The [[fire]] spread throughout the warehouses of building materials.  
[[OSINT Project/Maps/Kyzyl, Kyzyl City, Tuva Republic, Siberian Federal District, Russia|Kyzyl]], Republic of Tuva

~+~  
95
