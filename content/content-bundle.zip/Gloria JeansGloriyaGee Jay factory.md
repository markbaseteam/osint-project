---
locations:
aliases:
  - Gloria Jeans/Gloriya/Gee Jay factory
location:
title: Gloria Jeans/Gloriya/Gee Jay factory
tag: fire, political, elite, other
date:
linter-yaml-title-alias: Gloria Jeans/Gloriya/Gee Jay factory
---

# Gloria Jeans/Gloriya/Gee Jay factory

2022-05-15  
[[fire]]  
Political,Elite,Other  
https://bykvu.com/eng/thoughts/645/  
Gloria Jeans/Gloriya/Gee Jay factory in Rostov-on-Don is on [[fire]]. [[Moscow]] based but profiteered off Donbas to avoid paying Ukraine taxes. ‘Gloria Jeans’ apparel is found to be made in Russia-occupied territories of Ukraine’s Donbas.  
Rostov-on-Don

Separatist Profiteering - Gloria ran 2 stores in Crimea & 5-7 factories in Russian-occupied DNR/LNR, paying almost half the wages in Russia or China. Gloria paid DNR/LNR taxes but not Ukrainian taxes.

~+~  
185
