---
aliases: 
locations:
tag: 
date:
title: Ukrainian journalist Oleh Baturin feared abducted by Russian invaders in Kherson oblast
---

Ukrainian journalist Oleh Baturin feared abducted by Russian invaders in Kherson oblast

https://khpg.org/en/1608810185
