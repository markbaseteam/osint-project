---
aliases: 
locations:
tag: 
date:
title: Omsk
---
> **[[OSINT Project/Maps/Omsk, Omsk Oblast, Siberian Federal District, 644000, Russia|Omsk]]** (; Russian: Омск, IPA: [omsk]) is the administrative center and largest city of [[OSINT Project/Maps/Omsk Oblast, Siberian Federal District, Russia|Omsk Oblast]], Russia. It is situated in southwestern [[Siberian Federal District|Siberia]], and has a population of over 1 million. [[OSINT Project/Maps/Omsk, Omsk Oblast, Siberian Federal District, 644000, Russia|Omsk]] is the second largest city in [[Siberian Federal District|Siberia]] after [[OSINT Project/Maps/Novosibirsk, Novosibirsk Oblast, Siberian Federal District, 630000, Russia|Novosibirsk]], and the ninth-largest city in Russia. It is an essential transport node, serving as a train station for the [[OSINT Project/Maps/Monument to the 170th anniversary of the Trans-Siberian Railway, улица Леконта, Привокзальный, Ленинский административный округ, Omsk, Omsk Oblast, Siberian Federal District, 644000, Russia|Trans-Siberian Railway]] and as a staging post for the Irtysh River.
>
> During the Imperial era, [[OSINT Project/Maps/Omsk, Omsk Oblast, Siberian Federal District, 644000, Russia|Omsk]] was the seat of the Governor General of Western [[Siberian Federal District|Siberia]] and, later, of the Governor General of the Steppes. For a brief period during the Russian Civil War in 1918–1920, it served as the capital of the anti-Bolshevik Russian State and held the imperial gold reserves.
>
> [[OSINT Project/Maps/Omsk, Omsk Oblast, Siberian Federal District, 644000, Russia|Omsk]] serves as the episcopal see of the bishop of [[OSINT Project/Maps/Omsk, Omsk Oblast, Siberian Federal District, 644000, Russia|Omsk]] and Tara, as well as the administrative seat of the Imam of [[Siberian Federal District|Siberia]]. The mayor is Sergey Shelest.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Omsk)
