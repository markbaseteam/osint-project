---
locations:
aliases: ['[[Maps/Krasnoyarsk, Krasnoyarsk Urban Okrug, Krasnoyarsk Krai, Siberian Federal District, 660000, Russia|Krasnoyarsk]] 24 [[railway car|railway cars]] derailed']
location: Krasnoyarsk railway section
title: '[[Maps/Krasnoyarsk, Krasnoyarsk Urban Okrug, Krasnoyarsk Krai, Siberian Federal District, 660000, Russia|Krasnoyarsk]] 24 [[railway car|railway cars]] derailed'
tag: mechanical, railway, infrastructure
date: 2022-06-11 
linter-yaml-title-alias: '[[Maps/Krasnoyarsk, Krasnoyarsk Urban Okrug, Krasnoyarsk Krai, Siberian Federal District, 660000, Russia|Krasnoyarsk]] 24 [[railway car|railway cars]] derailed'
---

# [[OSINT Project/Maps/Krasnoyarsk, Krasnoyarsk Urban Okrug, Krasnoyarsk Krai, Siberian Federal District, 660000, Russia|Krasnoyarsk]] 24 [[railway car|railway cars]] derailed

2022-06-11  
Mechanical  
Railway,Infrastructure  
https://enoughisenough14.org/2022/07/04/rail-war-belarusians-face-the-death-penalty-the-blocked-trans-sib-anarchists-work-around-moscow-belarus-russia/  
incident on the [[OSINT Project/Maps/Monument to the 170th anniversary of the Trans-Siberian Railway, улица Леконта, Привокзальный, Ленинский административный округ, Omsk, Omsk Oblast, Siberian Federal District, 644000, Russia|Trans-Siberian Railway]] involving [[freight train|freight trains]]: on June 11, another 24 [[freight train|freight wagons]] overturned on the [[OSINT Project/Maps/Krasnoyarsk, Krasnoyarsk Urban Okrug, Krasnoyarsk Krai, Siberian Federal District, 660000, Russia|Krasnoyarsk]] section of the [[roads|road]], the cause of the incident was not stated.  
[[OSINT Project/Maps/Krasnoyarsk, Krasnoyarsk Urban Okrug, Krasnoyarsk Krai, Siberian Federal District, 660000, Russia|Krasnoyarsk]]

~+~  
19
