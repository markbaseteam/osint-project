---
aliases: 
location: geo:53.200001,45
category:molotov
date:
tag: molotov, recruitment
---
[Penza](geo:53.200001,45)

# [[OSINT Project/Maps/Penza, Penza Oblast, Volga Federal District, 4400XX, Russia|Penza]] abandoned Recruitment office

Molotov  
 Recruitment

In [[OSINT Project/Maps/Penza, Penza Oblast, Volga Federal District, 4400XX, Russia|Penza]], an abandoned enlistment office was hit with Molotov cocktails  
[[OSINT Project/Maps/Penza, Penza Oblast, Volga Federal District, 4400XX, Russia|Penza]]

[[Penza]] is a major railway junction and lies on the M5 [[roads|highway]] linking [[Moscow]] and [[Chelyabinsk]]. [[Penza Airport ]]serves domestic flights.