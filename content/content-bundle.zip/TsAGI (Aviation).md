---
aliases: [[Maps/Central Aerohydrodynamic Institute, 1, ul. Zhukovskogo, Центр, Zhukovsky, [[Maps/Moscow, Central Federal District, Russia|Moscow]] Oblast, Central Federal District, 140181, Russia|TsAGI]] aviation institute  
[[Maps/Central Aerohydrodynamic Institute, 1, ul. Zhukovskogo, Центр, Zhukovsky, Moscow Oblast, Central Federal District, 140181, Russia|Zhukovsky]]
location:
title:
tag: [[fire]] aerospace, aviation, other defence  
date:
---
# [[OSINT Project/Maps/Central Aerohydrodynamic Institute, 1, ul. Zhukovskogo, Центр, Zhukovsky, Moscow Oblast, Central Federal District, 140181, Russia|TsAGI]] (Aviation)

2022-05-21  
[[fire]]  
Aerospace/Aviation,Other Defence  
https://globalhappenings.com/top-global-news/196541.html  
On May 21, the famous [[OSINT Project/Maps/Central Aerohydrodynamic Institute, 1, ul. Zhukovskogo, Центр, Zhukovsky, Moscow Oblast, Central Federal District, 140181, Russia|TsAGI]] [[fire|burned]] in the [[Moscow]] region. It is the largest research center in the field of aviation and astronautics. Also reported elsewhere - [[fire]] at the substation in [[OSINT Project/Maps/Central Aerohydrodynamic Institute, 1, ul. Zhukovskogo, Центр, Zhukovsky, Moscow Oblast, Central Federal District, 140181, Russia|TsAGI]] (aviation institute)  
[[OSINT Project/Maps/Central Aerohydrodynamic Institute, 1, ul. Zhukovskogo, Центр, Zhukovsky, Moscow Oblast, Central Federal District, 140181, Russia|Zhukovsky]]

~+~  
72