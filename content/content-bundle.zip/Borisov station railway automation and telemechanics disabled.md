---
locations:
aliases: 
location:
title: Borisov station railway automation and telemechanics disabled
tag: 
date:
---

# Borisov station railway automation and telemechanics disabled

2022-02-27  
Mechanical  
Railway,Infrastructure  
https://ru.wikipedia.org/wiki/Рельсовая_война_в_Белоруссии_(2022)# 30_марта  
The device of automation and telemechanics of the SCB near the Borisov station was disabled. the shutdown of the Neman dispatching centralization and related software. "Neman" is a software and hardware complex that controls the [[movement]] of trains from one central point with the help of automation and telemechanics. The system is critical, when it fails, you can only control traffic on the railway manually. As a result, a few days later, online ticketing services stopped working, cashiers had to issue them manually, which is why huge queues were collected at the ticket offices of the stations  
Borisov Station, Belarus

12 March, 2022 - Belarusian Railways said it had repaired ticket sales services. It took two weeks  
~+~  
122
