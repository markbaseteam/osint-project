---
aliases: 
locations:
tag: 
date:
title: Kaluga Oblast
---
