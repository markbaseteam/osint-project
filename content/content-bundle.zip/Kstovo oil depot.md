---
locations:
aliases: ['[[Maps/Kstovo, Kstovsky District, Nizhny Novgorod Oblast, Volga Federal District, Russia|Kstovo]] oil depot']
location: Kstovo, Nizhny Novgorod region
title: '[[Maps/Kstovo, Kstovsky District, Nizhny Novgorod Oblast, Volga Federal District, Russia|Kstovo]] oil depot'
tag: fire, gas/oil
date: 2022-03-22 
linter-yaml-title-alias: '[[Maps/Kstovo, Kstovsky District, Nizhny Novgorod Oblast, Volga Federal District, Russia|Kstovo]] oil depot'
---

# [[OSINT Project/Maps/Kstovo, Kstovsky District, Nizhny Novgorod Oblast, Volga Federal District, Russia|Kstovo]] oil depot

2022-03-22  
[[fire]]  
Gas/Oil  
https://www.rferl.org/a/russia-fires-mystery-ukraine-conflict/31884503.html  
A [[fire]] at an oil depot in [[OSINT Project/Maps/Kstovo, Kstovsky District, Nizhny Novgorod Oblast, Volga Federal District, Russia|Kstovo]], in Russia's Nizhny Novgorod region, on March 22. Seven diesel fuel storage tanks were reportedly engulfed in the blaze.  
[[OSINT Project/Maps/Kstovo, Kstovsky District, Nizhny Novgorod Oblast, Volga Federal District, Russia|Kstovo]], Nizhny Novgorod region

~+~  
149
