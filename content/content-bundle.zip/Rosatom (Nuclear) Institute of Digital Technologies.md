---
locations:
aliases: 
location:
title: Rosatom (Nuclear) Institute of Digital Technologies
tag: fire, education, other defence  
date: 2022-06-08  
---

# Rosatom (Nuclear) Institute of Digital Technologies

2022-06-08  
[[fire]]  
Education,Other Defence  
https://en.m.wikipedia.org/wiki/2022_Russian_mystery_fires  
??  
Sarov, Nizhny Novgorod

~+~  
58
