---
aliases: hooligan, hooligans
locations:
tag: 
date:
title: hooliganism
---
> **hooliganism** is disruptive or unlawful behavior such as rioting, bullying and vandalism, usually in connection with crowds at sporting events.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Hooliganism)
