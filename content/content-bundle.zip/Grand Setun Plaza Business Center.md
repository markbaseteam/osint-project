---
locations:
aliases: 
location:
title: Grand Setun Plaza Business Center
tag: fire, elite, government
date:
---

# Grand Setun Plaza Business Center

2022-06-03  
[[fire]]  
Elite,Government  
https://globalhappenings.com/top-global-news/195845.html  
Grand Setun Plaza business center caught [[fire]]. There were about 15 people inside. Propaganda media have already reported that the cause was a short circuit due to improper installation of lighting on the facade.

Building includes the offices of Pension Fund of Russia

~+~  
45
