---
locations:
aliases: ['38 [[automobiles|Trucks]] in Parking Lot', Tver trucks]
location: 56.858675,35.9208284
title: '38 [[automobiles|Trucks]] in Parking Lot'
tag: Fire, Other Defence
date: 2022-05-03  
Locations: Tver
linter-yaml-title-alias: '38 [[automobiles|Trucks]] in Parking Lot'
---

# 38 [[automobiles|Trucks]] in Parking Lot

2022-05-03  
[[fire]]  
Other Defence  
https://twitter.com/nexta_tv/status/1521416166786404354?s=20&t=TFVdFJgzVYdoZacC9SRyGA  
38 [[automobiles|trucks]] [[fire|burned]] overnight at the parking lot. Identified elsewhere as moving goods for [[Russian Military Industry|military]].  
Tver

~+~  
3
