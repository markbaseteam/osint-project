---
aliases: hybridwarfare, hybridwar, hybrid war
locations:
tag: 
date:
title: hybrid warfare
---
> **hybrid warfare** is a theory of military strategy, first proposed by Frank Hoffman, which employs political warfare and blends conventional warfare, irregular warfare, and cyberwarfare with other influencing methods, such as fake news, diplomacy, lawfare and foreign electoral intervention. By combining kinetic operations with subversive efforts, the aggressor intends to avoid attribution or retribution. The concept of hybrid warfare has been criticized by a number of academics and practitioners due to its alleged vagueness, its disputed constitutive elements, and its alleged historical distortions.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Hybrid%20warfare)
