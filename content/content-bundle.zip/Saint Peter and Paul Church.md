---
locations:
aliases: 
location:
title: Saint Peter and Paul Church
tag: fire, cultural
date: 2022-05-24  
---

# Saint Peter and Paul Church

2022-05-24  
[[fire]]  
Cultural

??  
[[Moscow]]

~+~  
14
