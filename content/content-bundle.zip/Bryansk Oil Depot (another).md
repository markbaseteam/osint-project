---
locations:
aliases: 
location:
title: Bryansk Oil Depot (another)
tag: 
date:
---

# Bryansk Oil Depot (another)

2022-04-23  
[[fire]]  
Gas/Oil  
https://www.kyivpost.com/eastern-europe/probably-not-by-accident-new-mystery-explosions-ammo-dump-fires-in-russia.html  
On 23 April in Bryansk, 150 km from the Ukrainian border, an oil storage depot caught [[fire]], as did buildings at a neighboring military base. Gas stations across the Bryansk region within hours saw massive queues as motorists rushed to top off fuel tanks.  
Bryansk

**According to InformNapalm, Russia is attacking itself with false flags & is preparing to bring in wreckage of Ukrainian [[aircraft|helicopters]] and drones to place as "proof". Other claims made are that top military and families were evacuated April 19th in preparation. Focus areas Belgorod, [[OSINT Project/Maps/Kursk, Kursk Oblast, Central Federal District, 305000, Russia|Kursk]], Bryansk Oblasts especially civilian and residential areas**

~+~  
174
