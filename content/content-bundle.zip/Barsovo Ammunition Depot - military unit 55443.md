---
locations:
aliases: 
location:
title: Barsovo Ammunition Depot - military unit 55443
tag:
date:
---

# Barsovo Ammunition Depot - military unit 55443

2022-06-22  
[[fire]]  
Military,Ammunition Depot  
https://globalhappenings.com/top-global-news/218355.html  
on June 22, in the village of Barsovo (Vladimir region), a [[fire]] broke out in the arsenal for the complex storage of missiles, ammunition and explosive materials (military unit 55443) of the main rocket and artillery department of the RF Ministry of Defense.  
Barsovo, Vladimir region

DURING THE [[fire]], AMMUNITION DETONATED, WHICH LED TO THE DESTRUCTION OF MORE THAN 400 9M113 (9M113K) KONKURS ANTI-TANK MISSILE SYSTEMS AND SHELLS FOR THEM, AS WELL AS TO THE DEATH OF MORE THAN 3 SERVICEMEN OF THE RF ARMED FORCES,

~+~  
54
