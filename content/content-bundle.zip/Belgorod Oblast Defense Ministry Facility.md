---
locations:
aliases: 
location:
title: Belgorod Oblast Defense Ministry Facility
tag:
date:
---

# Belgorod Oblast Defense Ministry Facility

2022-05-01  
[[fire]]  
Military  
https://en.wikipedia.org/wiki/2022_Western_Russia_attacks  
a [[fire]] broke out at at Russian Defense Ministry's facility in Belgorod Oblast, a local resident was slightly injured.  
Belgorod Oblast

~+~  
85
