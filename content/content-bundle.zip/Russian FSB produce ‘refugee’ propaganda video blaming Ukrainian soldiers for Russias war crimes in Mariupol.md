---
aliases: 
locations:
tag: 
date:
title: Russian FSB produce ‘refugee’ propaganda video blaming Ukrainian soldiers for Russias war crimes in Mariupol
---

Russian FSB produce ‘refugee’ propaganda video blaming Ukrainian soldiers for Russia"s war crimes in Mariupol

https://khpg.org/en/1608810325
