---
locations:
aliases: 
location:
title: Call to Arms - Revolutionary cell of the Volga region
tag: 
date:
---

# Call to Arms - Revolutionary cell of the Volga region

2022-06-28  
Protest  
Other,Hearts & Minds  
https://t.me/bnkbel/89545  
Russian anti-military arsonists: "There are more of us every day". Not everyone is tough enough to go with Molotov to the enlistment office or [[fire|burn]] a [[automobiles|vehicle]] to the beasts guarding the regime. But everyone can take a photo and anonymously send along with the coordinates to the right people. Or collect information about beasts, print out leaflets, stick stickers, draw graffiti, supporting resistance. Sabotage at work in the relevant structures is no less important. It is not necessary to refuse military service if you can learn a lot of valuable information through this. It is not necessary to resign from law enforcement bodies if you can sabotage new cases to capture [[activism|activists]]. Or leave the railway, seeing trains of equipment going to kill people in a neighboring country. Everyone must find their place in the Russia of the future, become this future today, and not leave Russian hopelessness as a legacy to children military recruitment centers [[fire|burn]] every week, trains derail from the Kuban to the Far East, cables from zombieboxes are cut at the entrances. The geography of resistance will only expand, because everyone has just begun to taste the delights of life in a new reality: total lack of freedom, a swooping economy, an Iron Curtain. The [[fire]] of the revolution will spread throughout the cities of Russia. The future of Russia will be decided in Russia. This is our [[land]], we have nowhere to run, let the scum be afraid and hide in their palaces. The future belongs to us!  
Volga

Also see https://libcom.org/article/russian-anti-military-arsonists-there-are-more-us-every-day

~+~  
144
