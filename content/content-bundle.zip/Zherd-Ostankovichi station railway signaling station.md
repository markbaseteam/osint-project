---
locations:
aliases: 
location: Zherd-Ostankovichi station, Belarus
title: Zherd-Ostankovichi station railway signaling station
tag: fire, railway, infrastructure
date: 2022-02-28  
---

# Zherd-Ostankovichi station railway signaling station

2022-02-28  
[[fire]]  
Railway,Infrastructure  
https://ru.wikipedia.org/wiki/Рельсовая_война_в_Белоруссии_(2022)#30_марта  
In pro-government telegram channels appeared a "repentant" video with Denis Dikun, in which he looks beaten. He says that on the instructions of BYPOL, he set [[fire]] to two more on February 28 the signaling station cabinet at the Zherd-Ostankovichi station  
Zherd-Ostankovichi station, Belarus

~+~  
117
