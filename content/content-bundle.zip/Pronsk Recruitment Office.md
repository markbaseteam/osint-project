---
locations:
aliases: ['[[Maps/Pronsk, Пронское городское поселение, Pronsky District, Ryazan Oblast, Central Federal District, Russia|Pronsk]] Recruitment Office']
location: Pronsk, Ryazan
title: '[[Maps/Pronsk, Пронское городское поселение, Pronsky District, Ryazan Oblast, Central Federal District, Russia|Pronsk]] Recruitment Office'
tag: molotov, recruitment
date: 2022-05-15 
linter-yaml-title-alias: '[[Maps/Pronsk, Пронское городское поселение, Pronsky District, Ryazan Oblast, Central Federal District, Russia|Pronsk]] Recruitment Office'
---

# [[OSINT Project/Maps/Pronsk, Пронское городское поселение, Pronsky District, Ryazan Oblast, Central Federal District, Russia|Pronsk]] Recruitment Office

2022-05-15  
Molotov  
Recruitment  
https://newsfounded.com/czechrepubliceng/the-russian-recruit-went-to-molotov-and-did-not-return-to-the-front-from-vacation/  
Molotov at enlistment registration office near [[Moscow]] in [[OSINT Project/Maps/Pronsk, Пронское городское поселение, Pronsky District, Ryazan Oblast, Central Federal District, Russia|Pronsk]], Ryazan. Attempt is reported as unsuccessful. On Sunday, two unknown people unsuccessfully tried to set [[fire]] to a recruitment office in the village of [[OSINT Project/Maps/Pronsk, Пронское городское поселение, Pronsky District, Ryazan Oblast, Central Federal District, Russia|Pronsk]] in the Ryazan region, located about 270 kilometers southeast of [[Moscow]]. See also https://westobserver.com/news/europe/in-the-ryazan-region-they-tried-to-set-fire-to-the-military-enlistment-office/  
[[OSINT Project/Maps/Pronsk, Пронское городское поселение, Pronsky District, Ryazan Oblast, Central Federal District, Russia|Pronsk]], Ryazan

Date discrepancy - May 14 or 15, 2022. Used later date as it is also described as "a few hours later" after an action on 15 May [[OSINT Project/Maps/Pronsk, Пронское городское поселение, Pronsky District, Ryazan Oblast, Central Federal District, Russia|Pronsk]] (Ryazan) Barely an hour later (after Volgorad), a message arrived about a [[fire]] in the door and window frame of the military registration and enlistment office in the village of [[OSINT Project/Maps/Pronsk, Пронское городское поселение, Pronsky District, Ryazan Oblast, Central Federal District, Russia|Pronsk]], Ryazan region. No one was [[arrested]]. https://darknights.noblogs.org/post/tag/khanty-nansi/

~+~  
184
