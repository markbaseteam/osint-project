---
locations:
aliases: Kohomskoye highway
  - 'Kohomskoye [[roads|highway]] "Paintographic"'
location: Kohomskoye highway, Ivanovo
title: 'Kohomskoye [[roads|highway]] "Paintographic"'
tag: protest, infrastructure, political
date: 2022-03-18
linter-yaml-title-alias: 'Kohomskoye [[roads|highway]] "Paintographic"'
---

# Kohomskoye [[roads|highway]] "Paintographic"

2022-03-18  
Protest  
Infrastructure,Hearts & Minds  
https://www.ivanovonews.ru/news/1140466/  
[[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] subscribers also sent a "paintographic" story of the slogan at a heat point on Kohomskoye [[roads|highway]]. It's not the first time that the inscription is covered with gray paint. The slogan persistently reappears.  
Kohomskoye highway, [[Ivanovo]]

~+~  
96
