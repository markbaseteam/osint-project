---
locations:
aliases: 
location:
title: Ryazan historic building
tag: fire, cultural  
date: 2022-04-01  
---

# Ryazan historic building

2022-04-01  
[[fire]]  
Cultural  
https://www.rferl.org/a/russia-fires-mystery-ukraine-conflict/31884503.html  
A historic building in Ryazan, 180 kilometers southeast of [[Moscow]], burns on April 1.

~+~  
43
