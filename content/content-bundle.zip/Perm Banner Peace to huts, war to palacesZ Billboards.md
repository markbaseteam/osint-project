---
locations:
aliases:
  - '[[Perm, Russia|Perm]] Banner [[anti-war|Peace]] to huts, war to palaces/Z Billboards'
  - '[[Perm, Russia|Perm]] Banner Peace to huts, war to palaces/Z Billboards'
location: Perm
title: '[[Perm, Russia|Perm]] Banner [[anti-war|Peace]] to huts, war to palaces/Z Billboards'
tag:
date:
linter-yaml-title-alias: '[[Perm, Russia|Perm]] Banner [[anti-war|Peace]] to huts, war to palaces/Z Billboards'
---

# [[Perm, Russia|Perm]] Banner [[anti-war|Peace]] to huts, war to palaces/Z Billboards

2022-04-30  
Protest  
Hearts & Minds  
https://libcom.org/article/anticipation-general-mobilization-7th-overview-anti-military-sabotage-russia  
[[Perm, Russia|Perm]], [[activism|anarchists]] dropped the banner "[[anti-war|Peace]] to huts, war to palaces" and decorated with paint one of the Z-billboards.

Next time they promised to commit such vandalism more aptly and on a larger scale: https://t.me/anarchy_perm/331

~+~  
181
