---
locations:
aliases: ['St. Basil the Great [[Maps/Osinovaya Roshcha, Pargolovo, Saint Petersburg, Northwestern Federal District, 194902, Russia|Aspen Grove]]']
location: Osinovaya Roshcha (Aspen Grove), Saint Petersburg
title: 'St. Basil the Great [[Maps/Osinovaya Roshcha, Pargolovo, Saint Petersburg, Northwestern Federal District, 194902, Russia|Aspen Grove]]'
tag: fire, cultural
date: 2022-06-26  
linter-yaml-title-alias: 'St. Basil the Great [[Maps/Osinovaya Roshcha, Pargolovo, Saint Petersburg, Northwestern Federal District, 194902, Russia|Aspen Grove]]'
---

# St. Basil the Great [[OSINT Project/Maps/Osinovaya Roshcha, Pargolovo, Saint Petersburg, Northwestern Federal District, 194902, Russia|Aspen Grove]]

2022-06-26  
Fire  
Cultural  
https://bb-cntv.com/news/fire-in-the-church-in-aspen-grove-details-of-the-russian-orthodox-church-told-june-26-2022-company-news-st-petersburg-news-79004/  
St. Basil the Great in [[OSINT Project/Maps/Osinovaya Roshcha, Pargolovo, Saint Petersburg, Northwestern Federal District, 194902, Russia|Osinovaya Roshcha]] ([[OSINT Project/Maps/Osinovaya Roshcha, Pargolovo, Saint Petersburg, Northwestern Federal District, 194902, Russia|Aspen Grove]]) is on [[fire]]. St. Petersburg Metropolis said that the church of St. Basil the Great in [[OSINT Project/Maps/Osinovaya Roshcha, Pargolovo, Saint Petersburg, Northwestern Federal District, 194902, Russia|Osinovaya Roshcha]], which caught [[fire]] on the morning of June 26 “The temple inside was not damaged. The iconostasis, throne, all liturgical items and vestments have been preserved,” Rodomanova wrote. She clarified that the [[fire]] was discovered at about 6 am by a priest who came to prepare for the early liturgy. As a result, the rector of the temple, Father Anatoly Pershin, served the Sunday Liturgy together with the parishioners in the open [[air]]. “There were 60 communicants. The parishioners expressed their readiness to participate in the restoration of their beloved temple, which has been active in educational, creative and social activities for 8 years now,”  
[[OSINT Project/Maps/Osinovaya Roshcha, Pargolovo, Saint Petersburg, Northwestern Federal District, 194902, Russia|Osinovaya Roshcha]], St Petersburg

"for 8 years now" - since 2014. Interesting statement. Photos shown by official Telegram channels show extensive damage.

~+~  
191
