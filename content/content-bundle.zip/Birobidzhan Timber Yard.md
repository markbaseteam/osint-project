---
locations:
aliases: 
location:
title: Birobidzhan Timber Yard
tag: 
date:
---

# Birobidzhan Timber Yard

2022-04-04  
[[fire]]  
Other  
https://www.rferl.org/a/russia-fires-mystery-ukraine-conflict/31884503.html  
A blaze at a timber yard in Birobidzhan on April 4. The town is the administrative capital of Russia's Jewish Autonomous Oblast in far eastern [[Siberian Federal District|Siberia]].  
Birobidzhan, Jewish Autonomous Oblast

~+~  
114
