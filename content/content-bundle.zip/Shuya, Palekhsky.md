---
aliases: 
locations:
tag: 
date:
title: 'Shuya, Palekhsky'
---
