---
locations:
aliases: 
location:
title: Cherepovets Recruitment Office
tag:
date:
---

# Cherepovets Recruitment Office

2022-05-08  
Molotov  
Recruitment  
https://newsbeezer.com/swedeneng/wave-of-molotov-attacks-on-russian-recruiting-offices/  
Another conscription office is pelted with Molotov cocktails in Cherepovets. May 8, 2022 at about 1 am in Cherepovets. The [[fire]] site had an area of one square meter. The flames damaged two window frames and smoked the facade of the building. Seven people were engaged in extinguishing the [[fire]]. On May 11, 2022, the arsonist* were [[arrested]]. They were two 16-year-olds who testified that they had committed the crime “on orders” and received 30,000 rubles for their deed. Criminal proceedings were initiated against the youths for property damage. Video https://t.me/truexanewsua/45920  
Cherepovets

People are [[fire|burning]] their military registration documents in order not to go to war,” said journalist Andrei Tsaplienko. https://amplifyukraine.eu/military-enlistment-offices-are-on-fire-in-russia-details-last-night-several-molotov-cocktails-were-thrown-at-the-cherepovets-station-pravda-gerashchenko-2/ Nearby is the Cherepovets Higher Military Engineering College of Radio Electronics. On another occasion, two 16-year-old boys who said they carried out the attack on the recruitment office in Cherepovets on May 8 on orders and received 30,000 rubles (equivalent to 4,500 SEK) were [[arrested]]. Also see https://enoughisenough14.org/2022/06/26/shortly-after-the-longest-night-of-the-year-two-recruiting-offices-burned-at-once-chronicle-of-arson-attacks-until-june-25-2022-russia/  
~+~  
68
