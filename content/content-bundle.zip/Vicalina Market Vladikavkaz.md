---
locations:
aliases: 
location: Vladikavkaz, North Ossetia-Alania
title: Vicalina Market Vladikavkaz
tag: fire
date: 2022-05-06  
---

# Vicalina Market Vladikavkaz

2022-05-06  
[[fire]]  
Other  
https://twitter.com/nexta_tv/status/1522507766165913602?s=20&t=rAnAi9isgrntoVpJvQiHsw  
Vicalina market in Vladikavkaz is on [[fire]] This is very close to Georgia - North Ossetia-Alania & a major transport hub with the North Caucus railway. South Ossetia is the [[land|lands]] Russia invaded in Georgia much like Crimea & Donsk.  
Vladikavkaz, North Ossetia-Alania

~+~  
30
