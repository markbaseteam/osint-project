---
locations:
aliases: ['BZhD [[transportation]] control center disabled']
location:
title: 'BZhD [[transportation]] control center disabled'
tag:
date:
linter-yaml-title-alias: 'BZhD [[transportation]] control center disabled'
---

# BZhD [[transportation]] control center disabled

2022-03-02  
Mechanical  
Railway,Infrastructure  
https://ru.wikipedia.org/wiki/Рельсовая_война_в_Белоруссии_(2022)# 30_марта  
Cyberpartisans of Belarus said that they had attacked the BZhD [[transportation]] control center. The "Neman" system was affected, the "Schedule of Executed Movement", "Manager's Notepad", "Subscriber' Point", the automated "Autodispatcher" system and other related software stopped working. Accordingly, many [[operations]] had to be done manually, which also greatly slows down the [[movement]] of trains  
Belarus

~+~  
188
