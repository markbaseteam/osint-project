---
locations:
aliases: Aerospace Defense Forces, Aerospace Defence Forces, Aerospace Defense Force, Aerospace Defence Force, Central Research Institute
location: Tver
title: Russian Defense Ministry's Aerospace Defense Force's Central Research Institute
tag: fire, other defense
date: 2022-04-21  
---

# Russian Defense Ministry's Aerospace Defense Force's Central Research Institute

2022-04-21  
[[fire]]  
Other Defence  
https://www.theguardian.com/world/2022/apr/22/die-in-fire-at-russia-defence-institute  
[[fire]] at [[Russian Defense Ministry]]'s [[Aerospace Defense Forces]] [[Central Research Institute]]. An electrical device short circuit is the cause of the [[fire]] that broke out at the central research institute of the Aerospace Defense Forces in [[Tver]] in central Russia, killing over 20 people. There were 175 people inside the building at the time when the [[fire]] started and 54 of them were rescued from the premises swept by the blaze while 98 others went out into the street themselves. The bodies of 22 people were found in the course of the efforts to clear the rubble and the search for those missing == On 21 Apr. in Tver’–a city deep in Russia a good 800 km. from Kyiv–a [[fire]] gutted a state-run military missile research institute, killing seventeen. The facility was responsible for the design and fielding of long-range Kinzhal missiles, with which the RF military has been bombarding Ukrainian homes and cities. Tver’s police have [[arrested]] no suspects. Internet theories on persons responsible, KP found, ranged from Russian scientists secretly sympathetic to Ukraine to intoxicated maintenance staff, to top-level managers covering up corruption, to British agents. Journalist Andriy Tsaplenko, a reporter for the UNIAN news agency with deep experience in Russia, said another possibility is the Kremlin, wishing to stoke public fear and antagonism towards Ukraine, is behind at least some of these attacks. https://www.kyivpost.com/eastern-europe/probably-not-by-accident-new-mystery-explosions-ammo-dump-fires-in-russia.html  
Tver

Research institute of the ministry of defense - Missile research. broke out on an area of 2,500 square meters on April 21. A criminal case has been opened under Part 3 of Article 219 of Russia’s Criminal Code (‘Violation of the [[fire]] Safety Rules that Entailed the Death of Two and More Individuals Through Negligence’). The case is being probed by military investigators. Also reference here https://www.rferl.org/a/russia-fires-mystery-ukraine-conflict/31884503.html and https://tass.com/russia/1445795 - Local journalists claim (according to Daily Mail) up to 25 people may have died, including top missile scientists. https://www.dailymail.co.uk/news/article-10746369/Cover-25-military-scientists-killed-fire-Russian-weapons-research-facility.html See also https://www.washingtonpost.com/politics/17-dead-in-russian-military-research-facility-fire-last-week/2022/04/25/6588df66-c491-11ec-8cff-33b059f4c1b7_story.html

~+~  
44
