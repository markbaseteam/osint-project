---
locations:
aliases: 
location:
title: Prometeya calls for direct action other than words
tag: event
date: 2022-05-31 
---

# Prometeya calls for direct action other than words

2022-05-31  
Other  
Other  
https://a2day.org/obrashhenie-administraczii-prometeya/  
However, we must point out that in a war where the Russian state is killing people in Ukraine, graffiti and leaflets are hardly a sufficient means to stop the killing. A word will not stop a bullet. If you really want to make a difference, you should look for other ways to fight dictatorship and war. Some of these measures are already relatively widespread and popular in Russia–for example, there are regular reports of incendiary attacks on military recruitment centers or acts of sabotage on railroad tracks that can disrupt the Russian army’s infrastructure and supply logistics. We would like to call on all sincere people not to limit themselves to expressing their discontent with the war and the dictatorship, whether on the Internet or in the streets. Words without actions are empty, and the dictatorship has reached the point where it is now or never to act.

prometeya is an [[activism|anarchist]]/community direct action group - The admins of Prometeya have been part of the [[activism|anarchist]] [[movement]] for many years and over the years we have directly participated in [[activism|anarchist]] activities, taking part in actions with varying degrees of radicalism and putting ourselves at risk. We have been persecuted and tortured, suffered many deprivations and had to leave the country because of our activities. In Russia, we face severe punishment and torture, and we live with the reality that this will happen to us if we are getting deported. “[[Narodnaya Samooborona]]” (People’s Self-Defense), our [[movement]], was destroyed due to repression and has suspended its activities for several years now. To a large extent, this also applies to [[Prometeya]]–it has practically stopped working as a media source. Nevertheless, the [[activism|activists]] of the former People’s Self-Defense and the admins of Prometeya are still active. Some are fighting against the Russian army in Ukraine, putting themselves in great danger. Others are organizing fundraising events for [[activism|anarchists]] who are fighting in Ukraine. We will not stay inactive.

~+~  
46
