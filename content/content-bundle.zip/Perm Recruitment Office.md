---
locations:
aliases: ['[[Perm, Russia|Perm]] Recruitment Office']
location:
title: '[[Perm, Russia|Perm]] Recruitment Office'
tag: molotov, recruitment
date: 2022-06-24  
linter-yaml-title-alias: '[[Perm, Russia|Perm]] Recruitment Office'
---

# [[Perm, Russia|Perm]] Recruitment Office

2022-06-24  
Molotov  
Recruitment  
https://news.bigmir.net/world/6330781-v-belgorode-i-permi-podozhgli-voenkomaty  
In [[Perm, Russia|Perm]], unknown persons also tried to set [[fire]] to the army recruitment office. Around 4 a.m. several Molotov cocktails flew into the recruitment office in the [[Kirovsky district]] on [[Zakamskaya Street]]. Four bottles were found on the spot–two broke, two remained in their original state, no [[fire]] broke out.  
Zakamskaya Street, [[OSINT Project/Maps/Kirovsky District, Stavropol Krai, North Caucasian Federal District, Russia|Kirovsky district]], [[Perm, Russia|Perm]]

Also see https://enoughisenough14.org/2022/06/26/shortly-after-the-longest-night-of-the-year-two-recruiting-offices-burned-at-once-chronicle-of-arson-attacks-until-june-25-2022-russia/

~+~  
109
