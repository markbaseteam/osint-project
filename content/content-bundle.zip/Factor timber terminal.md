---
locations:
aliases: 
location:
title: Factor timber terminal
tag: 
date:
---

# Factor timber terminal

2022-06-10  
[[fire]]

"Factor" timber terminal owned by oligarch Ramis Deberdeyev  
Ust-Luga

~+~  
152
