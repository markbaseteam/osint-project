---
locations:
aliases: 
location:
title: Bryansk Military Missile Manufacturing Base
tag:
date:
---

# Bryansk Military Missile Manufacturing Base

2022-04-23  
[[fire]]  
Military  
https://www.kyivpost.com/eastern-europe/probably-not-by-accident-new-mystery-explosions-ammo-dump-fires-in-russia.html  
Ukrainian media reported the Bryansk base manufactured long-range missiles used by Russia to bombard Ukrainian cities and hinted Ukrainian agents set the [[fire]]. More diligent Ukrainian news outlets noted a Bryansk meat-processing plant and an agricultural equipment factory also caught [[fire]] on the 23rd, leaving it to readers to decide how meat-processing and missile manufacturing might be linked.  
Bryansk Military Base Missile Manufacturer

**According to InformNapalm, Russia is attacking itself with false flags & is preparing to bring in wreckage of Ukrainian [[aircraft|helicopters]] and drones to place as "proof". Other claims made are that top military and families were evacuated April 19th in preparation. Focus areas Belgorod, [[OSINT Project/Maps/Kursk, Kursk Oblast, Central Federal District, 305000, Russia|Kursk]], Bryansk Oblasts especially civilian and residential areas**

~+~  
175
