---
locations:
aliases: ['Mystery [[Cargo]] [[aircraft|Plane]]']
location: Ryazan
title: 'Mystery [[Cargo]] [[aircraft|Plane]]'
tag: fire, military  
date: 2022-06-24 
linter-yaml-title-alias: 'Mystery [[Cargo]] [[aircraft|Plane]]'
---

# Mystery [[cargo]] [[aircraft|Plane]]

2022-06-24  
[[fire]]  
Military  
https://www.reuters.com/world/europe/cargo-plane-crash-lands-near-russias-ryazan-seven-injured-ifax-2022-06-24/  
Mystery military [[cargo]] [[aircraft|plane]] - no one knows which organization runs the [[aircraft|plane]] - crash [[land|lands]] in Ryazan & catches [[fire]] killing 3, injuring 6. Video shows [[aircraft|plane]] on [[fire]] before landing. Later this was identified as military related. Ilyushin Il-76 military [[cargo]] [[aircraft|plane]] crashed and caught [[fire]] while landing near Russia's western city of Ryazan on Friday, killing four of the nine people on board. Russia's defence ministry as saying the [[aircraft|plane]] had suffered an engine malfunction while on a training flight. (This appears to be in dispute)  
Ryazan

~+~  
190
