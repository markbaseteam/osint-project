---
locations:
aliases: ['[[Moscow]] Molotov [[arrested|detention]] [[buses]]']
location:
title: '[[Moscow]] Molotov [[arrested|detention]] [[buses]]'
tag: molotov, government 
date: 2022-03-06 
linter-yaml-title-alias: '[[Moscow]] Molotov [[arrested|detention]] [[buses]]'
---

# [[Moscow]] Molotov [[arrested|detention]] [[buses]]

2022-03-06  
Molotov  
Government  
https://avtonom.org/en/news/vladimir-sergeev-and-anton-zhuchkov-needs-your-support

~+~  
21
