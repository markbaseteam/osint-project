---
aliases: [6 Women Block Traffic Demanding Info on their Conscript Sons/Brothers, 'block traffic, stop traffic']
location: geo:43.8549752,41.5853611
title: 6 Women Block Traffic Demanding Info on their Conscript Sons/Brothers
tag: Protest, Military
date: 2022-03-20
locations: Zelenchukskaya, Karachay-Cherkessia
linter-yaml-title-alias: 6 Women Block Traffic Demanding Info on their Conscript Sons/Brothers
---

[Zelenchukskaya, Karachay-Cherkessia ](geo:43.8549752,41.5853611)

# 6 Women Block Traffic Demanding Info on their Conscript Sons/Brothers

2022-03-20  
Protest  
[[Russian Military Industry|Military]],Hearts & Minds  
https://libcom.org/article/radical-resistance-russia-invasion-ukraine-part-4  
March 20, in Karachay-Cherkessia Republic, six women blocked traffic on a [[water|river]] bridge in stanitsa Zelenchukskaya, demanding information about their sons and brothers served under contract in the [[Russian Military Industry|military]] unit 01485 and missed from communications. According to the protesters, their relatives were sent to war in Ukraine. Cops [[arrested|detained]] them all and drew up administrative protocols on "violation of the established procedure for organizing or holding a meeting".  
stanitsa Zelenchukskaya, Karachay-Cherkessia Republic
