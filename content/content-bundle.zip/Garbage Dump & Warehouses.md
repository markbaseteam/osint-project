---
locations:
aliases: 
location:
title: Garbage Dump & Warehouses
tag: fire, warehouse
date:
---

# Garbage Dump & Warehouses

2022-06-29  
[[fire]]  
Other  
https://globalhappenings.com/top-global-news/217932.html  
In the capital of Russia, a garbage dump caught [[fire]], and then the [[fire]] spread to a hangar where [[automobiles|car]] tires were stored. Strong smoke appeared at the site of the [[fire]], its column rose high into the [[air|sky]], which can be seen for several kilometers. It is noted that the [[fire]] area is about 500 square meters. There is also a threat that the [[fire]] will spread to other buildings nearby.  
[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

~+~  
141
