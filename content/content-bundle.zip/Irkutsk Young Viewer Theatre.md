---
locations:
aliases: 
location: Young Viewer Theatre, Krasnoarmejska 4B, Irkutsk
title: Irkutsk Young Viewer Theatre
tag: fire, cultural
date: 2022-05-13 
---

# Irkutsk Young Viewer Theatre

2022-05-13  
[[fire]]  
Cultural  
https://twitter.com/TWMCLtd/status/1525123225218342912  
2-story cultural building in Irkutsk at Krasnoarmejska 4B is ablaze & spread to Young Viewer Theatre. Building was empty & [[fire]] is difficult to contain.  
Krasnoarmejska 4B, Irkutsk

May be faulty wiring, but the area has had significant partisan chatter and actions

~+~  
69
