---
locations:
aliases: 
location: Kamensk-Uralsky, Sverdlovsk Oblast
title: 'SinTZ, Sinarsky Pipe Works'
tag: fire
date: 2022-05-12 
---

# SinTZ, Sinarsky Pipe Works

2022-05-12  
[[fire]]  
Other  
https://twitter.com/TolomeoNews/status/1525139692815011844  
[[fire]] at SinTZ, Sinarsky Pipe Works in [[OSINT Project/Maps/Kamensk-Uralsky, городской округ Каменск-Уральский, Sverdlovsk Oblast, Ural Federal District, 623428, Russia|Kamensk-Uralsky]], Sverdlovsk Oblast a [[fire]] on Sinarsky pipeline plant. According to the Ministry of Emergency Situations, the building and the roof of the factory are on [[fire]]. The [[fire]] area reached 800 square meters.  
[[OSINT Project/Maps/Kamensk-Uralsky, городской округ Каменск-Уральский, Sverdlovsk Oblast, Ural Federal District, 623428, Russia|Kamensk-Uralsky]], Sverdlovsk Oblast

One of the biggest specialty producers in Russia, SinTZ manufactures steel & cast iron pipes w/ 3,000+ contracts per yr. Sverdlovsk elsewhere produces semi-conductors.

~+~  
16
