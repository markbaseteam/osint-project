---
locations:
aliases: 
location:
title: Ivanono Cities Graffiti
tag: protest, political
date: 2022-03-18 
---

# Ivanono Cities Graffiti

2022-03-18  
Protest  
Hearts & Minds  
https://www.ivanovonews.ru/news/1140466/  
In the cities of the [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] region, inscriptions appear on the walls of public buildings expressing disapproval of the [[Special Military Operation|special operation]] in Ukraine.  
Shuya, [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]]

~+~  
94
