---
locations:
aliases: 
location: Ostankovichi-Zherd diagon, Belarus
title: Ostankovichi-Zherd diagon railway relay cabinet destroyed
tag: mechanical, railway, infrastructure
date: 2022-03-01  
---

# Ostankovichi-Zherd diagon railway relay cabinet destroyed

2022-03-01  
Mechanical  
Railway,Infrastructure  
https://ru.wikipedia.org/wiki/Рельсовая_война_в_Белоруссии_(2022)#30_марта  
On the Ostankovichi-Zherd diagon, the relay control cabinet of the SCB was destroyed  
Ostankovichi-Zherd diagon, Belarus

~+~  
125
