---
aliases: 
locations:
tag: 
date:
note to self - this was pages 1 and 2 of 13
---
- # CATALOGUE OF NUMBERED FACTORIES

Plant No. 1 of NKAP "Progress"
Pharmaceutical Plant No. 1 /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/
Obozny Zavod No. 1 /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/
Obozny Zavod No. 1 "Lenvagonmash"
Experimental Plant No. 1 NIOPIC
Plant "Voenprom No. 1" /g. Baku/
Leningrad [[air]] Defense Plant No. 1
Plant of military rifle devices No. 1
Cartographic Factory No. 1 "State Cartographic Survey"
Rybinsk Mechanical Plant No. 1 "VMZ"
Military Mechanical Plant No. 1 "Sokol"
Military horseshoe plant No. 1 "ZETA"

Plant No. 1 of Glavgaztopprom
Radio Plant No. 1 /g. Baku/
Plant No. 1 NKEP /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/
Plant No. 1 of the NCAP
Plant No. 1 NKS /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/
Pilot plant No. 1 MSM /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/
Pilot plant No. 1 /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/
Plant No. 1 MSM "Kaskor"
Plant No. 1 NKUP /g. Kizel/
Tashkent Mechanical Plant No. 1 "TOEMZ-1"
Tashkent Electromechanical Plant No. 1 "TOEMZ"
Plant of electrical installation products No. 1 MSM /g. [[OSINT Project/Maps/Novosibirsk, Novosibirsk Oblast, Siberian Federal District, 630000, Russia|Novosibirsk]]/
Arkhangelsk Shipyard No. 1 "Solombal Shipyard"
SB-1 NCOP /g. Bezhitsa/
KB-1 NPO
SB-1 MV "Almaz"
GTSKB-1 NKB "MIT"

OKB-1 MOS "Energy"
CPKB-1 MMF "Morsudoproekt"
CCTB-1 MMF Technomarine
STB-1 NKB
SKB-1 NKNP "Drilling Equipment"
SKB-1 MM "MosSKB ALIAS"
OKB-1 NKM "OKB SA"
OKB-1 NKMV "VNIIStroydormash"
TB-1 NKV /Germany/
OTB-1 of the Ministry of Internal Affairs "SibtsvetmetNIIproekt"
SKBD-1 /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/
OKB-1 MSDM "Stroydormash"
MNII-1 SME "Agat"
IMV-1 NKMV Gipropribor
NII-1 of the NKAP "Research Center named after M.V. Keldysh"
VNII-1 of the Ministry of Internal Affairs /c. Magadan/
NII-1 KGB "CNIIST"
NII-1 GUSS
GPI-1 of NKAP GiproNIIAaviaprom
GSPI-1 ICM Giprovolframredmet

GSPI-1 Giprolegprom
PI-1 /g. Leningrad/
Laboratory No. 1 of CCGT
Plant No. 2 "ZiD"
Plant No. 2 of the NCSS "Red Proletarian"
Plant No. 2 "Bogatyr"
Pharmaceutical Plant No. 2 /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/
Obozny Zavod No. 2 /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/
Pharmaceutical Plant No. 2 /g. Leningrad/
Plant No. 2 of NCCM "Redmet" /c. [[OSINT Project/Maps/Novosibirsk, Novosibirsk Oblast, Siberian Federal District, 630000, Russia|Novosibirsk]]/
Plant No. 2 /Lower Sarana/
Plant No. 2 of NKS "Radiorele" /g. Kharkiv/
Plant No. 2 NKZ /g. Tomsk/
Medical equipment plant No. 2
Special Plant No. 2 / Arkhangelsk region. /
Plant No. 2 NKS "Promsvyaz" /g. Ufa/
Semi-coking plant No. 2
Plant No. 2 MSM "ZEMI-2 "Electron"
Plant No. 2 MSM "NMMC"
KB-2 OJSC
OKB-2 NKOP /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/
KB-2 UVI NPO
CDB-2 NCOP
OKB-2 GKOT "KB "Khimmash" named after A.M. Isaeva"
OKB-2 MOP "Torch"

SKB-2 MMiP
OKB-2 of the Ministry of Internal Affairs /Beskudnikovo/
CPKB-2 MMF
OKTB-2 NKVD
SKB-2 "SKB TUS" /g. Leningrad/
SKB-2 "MKTEIavtoprom" /g. Minsk/
NII-2 NCOP "CHEM-2"
NII-2 MAP "GosNIIAS"
GosNII-2 "NIA" /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/
NII-2 KGB /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/
GPI-2 of the National Club "Soyuzproektverf"
GPI-2 Giprosvyaz
GSPI-2 MS /g. Tashkent/
GPI-2 /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/
PI-2 /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/

Plant No. 3 NKV "UMZ"
Factory No. 3 MMZ "Vympel"
Plant No. 3 "Red Rubber"
Military uniform factory No. 3   
Obozny Zavod No. 3
Plant No. 3 "Dynamo"
Pipe Plant No. 3 "Zenit"
Plant No. 3 "Autodiesel"
Sewing factory No. 3 "Flight"
Plant No. 3 of Osoaviakhima

Plant No. 3 of the NCOP /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/
Plant No. 3 /g. [[OSINT Project/Maps/Grozny, Chechen Republic, North Caucasian Federal District, Russia|Grozny]]/
Plant No. 3 NKVD /g. Kharkiv/
Factory No. 3 "NKF"
Plant No. 3 of NKEP "Signal" /g. Leningrad/
MEMZ No. 3 NCEP
Plant No. 3 of the NCAP /Lianozovo/
Semi-coking plant No. 3
Plant No. 3 MS "Sibpromsvyaz"
Plant No. 3 MSM "ZEMI-3 "Electron"
Plant No. 3 MSM "MRU"
EKB-3 NII GVF
OKB-3 MAP
CPKB-3 MMF
OKB-3 "LenOKB ARS"
OKB-3 MAP /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/
KB-3 "NII "Micropribor"
NII-3 NKB "GIRT"
NII-3 SCRE "PNIEI"
GSPI-3 "Sintezproekt"
GPI-3 MLP
PI-3
Laboratory No. 3 "ITEF"

Plant No. 4 of the NKB "Plant named after M.I. Kalinina"
Plant No. 4 "Provodnik"
Obozny Zavod No. 4 /g. Zhukov/
Phosgene Plant No. 4
Remvozdukhzavodavod No. 4
Plant No. 4 NKV /g. Kolomna/
Pharmaceutical Plant No. 4 "Tomskhimpharm"
Plant No. 4 of the NKVD "Electroshield"
Pilot Plant No. 4 of the NCAP /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/
Plant No. 4 of the NCAP /g. [[OSINT Project/Maps/Kamensk-Uralsky, городской округ Каменск-Уральский, Sverdlovsk Oblast, Ural Federal District, 623428, Russia|Kamensk-Uralsky]]/
Rybinsk Electric Repair Plant No. 4
Plant No. 4 NKZ /g. Leningrad/
Plant No. 4 MAP /g. Leningrad/
Plant No. 4 MSM "NTMZ "Venta"
Nakhodka SRZ No. 4 MMF
Factory No. 4 "OKF"
Separate plant No. 4 "Khimprom" /g. Novocheboksarsk/

Plant No. 4 MSM "CGCC"
OKB-4 OGPU
OKB-4 MAP /Tushino/
OKB-4 MAP "NPO "Lightning"
SKB-4
NII-4 of NKOP "Sudbasstroy"
GSPI-4 NKB "Projectmashpribor"
PI-4 "Far Eastern PromstroyNIIproekt"
Laboratory No. 4 of CCGT
Plant No. 5 of NKB "Krasnoznamenets"  
Pharmaceutical Plant No. 5 /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/
Plant "Remvozdukh No. 5"
Car Repair Plant No. 5
Plant No. 5 NKB /g. Kharkiv/
Plant No. 5 "[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]] Shot Blasting Plant"
Obozny Zavod No. 5 /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/
Plant No. 5 of the NCSP "SF "Almaz" 
Optical and Mechanical Plant No. 5 /g. Leningrad/ 

Plant No. 5 of the NCAP /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/
Plant No. 5 NKEP /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/
Plant No. 5 of NCCM
Plant No. 5 named after I.I. Lepse /g. Leningrad/
Gasoline plant No. 5 /g. [[OSINT Project/Maps/Grozny, Chechen Republic, North Caucasian Federal District, Russia|Grozny]]/
Plant No. 5 of the NCAP /g. [[OSINT Project/Maps/Kamensk-Uralsky, городской округ Каменск-Уральский, Sverdlovsk Oblast, Ural Federal District, 623428, Russia|Kamensk-Uralsky]]/
Sverdlovsk Electric Repair Plant No. 5
Semi-coking plant No. 5
Plant No. 5 MSM /g. Leninabad/
SKB-5 MM "SKB ZS"
NII-5 of NKHP "KazKhimNII"
NII-5 of the NCMV "NII "Chasprom"
NII-5 MCI "MNIIPA"
NII-5 SCIAE "SFTI"
GSPI-5 "Lenproektstalkonstruktsiya"  
GPI-5
PI-5 /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/

Plant No. 6 of the NKB "Plant named after Morozova"
Plant No. 6 "Slavich"
Obozny Zavod No. 6 /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/
Salicylic Plant No. 6
Plant No. 6 /g. Serdobsk/
Film Factory No. 6 "Svema"
Plant No. 6 of the NKTP
Pharmaceutical Plant No. 6 /g. Chelyabinsk/
Plant No. 6 of the NCAP /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/
Semi-coking plant No. 6
Plant No. 6 MPSS "Promsvyaz"
Cartographic Factory No. 6
Plant No. 6 of SME "BMZ"
Radio Plant No. 6 /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/
Plant No. 6 NCCM /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/
Plant No. 6 of the NCAP /g. Aktobe/
Serpukhov Electric Repair Plant No. 6
Plant No. 6 METP /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/
Plant No. 6 MSM "Vostokredmet"
SKTB-6 MPSAiSU /g. Leningrad/
SKBD-6 /g. Nalchik/
NII-6 of the National Clinical Hospital "TsNIIKHM named after D.I. Mendeleev"
NII-6 NCMV
GSPI-6 NKB "Giprospetskhim"
GSPI-6 GCRE "Moselektronproekt"
PI-6
GPI-6 "Ivproekt"

Plant No. 7 NKV "MZ "Arsenal"
[[aircraft]] Plant No. 7 "Swan" /g. [[OSINT Project/Maps/Penza, Penza Oblast, Volga Federal District, 4400XX, Russia|Penza]]/
GAM No. 7 /g. Odessa/
Pharmaceutical Plant No. 7 /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/
Obozny Zavod No. 7 /g. Yaroslavl/
Plant No. 7 NCAP /g. Baku/
Plant No. 7 of NCCM Kolchugtsvetmet
Plant No. 7 NKEP /g. Tula/
Plant No. 7 of the NKTP /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/
[[OSINT Project/Maps/Novosibirsk, Novosibirsk Oblast, Siberian Federal District, 630000, Russia|Novosibirsk]] Electric Repair Plant No. 7
Plant No. 7 of CCGT "SHMPO"
Enterprise No. 7 "Roskartografiya"
PKB-7 MMF/g. Vladivostok/
SKBD-7 /g. Petrozavodsk/
GPI-7 Mospromproekt
GSPI-7 "Ipromashprom"
Plant No. 8 NKV "ZiK"
Obozny Zavod No. 8

Pharmaceutical Plant No. 8 of the CPP named after L.Y. Karpova
Refinery No. 8 "AviaTechMas"
Plant No. 8 NKEP /g. Leningrad/
Plant No. 8 NCAP /g. Dnepropetrovsk/
Plant No. 8 "Red Chemist"
Plant No. 8 NCAP /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/
Tashkent Electric Repair Plant No. 8 MEP
Film Factory No. 8 "TASMA"
Plant No. 8 NCAP /g. Kazan/
Mining Administration No. 8 of CCGT
Enterprise No. 8 MION   
OKB-8 OGPU  
SKB-8 "Minsk SKB AL"
NII-8 NCAP /g. Leningrad/
NII-8 MSM "NIKIET named after N.A. Dollezhal"

GPI-8 Transmashproekt
Plant No. 9 NKB /g. Shostka/
Plant No. 9 "Zvezda"
Plant No. 9 NKOP /Podlipki/
Plant No. 9 NKV /g. Sverdlovsk/
Plant No. 9 "Sickle and Hammer"
Pharmaceutical Plant No. 9 /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/
Plant No. 9 "Neftemslozavod named after Shahumyan"
X-ray film factory No. 9 /g. Leningrad/
Plant No. 9 NCAP /g. Osipenko/
Plant No. 9 NKEP /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/
Plant No. 9 "Polymerphoto"
Plant No. 9 NCAP /g. [[OSINT Project/Maps/Kamensk-Uralsky, городской округ Каменск-Уральский, Sverdlovsk Oblast, Ural Federal District, 623428, Russia|Kamensk-Uralsky]]/
Kuibyshev Electric Repair Plant No. 9 of NKEP

Plant No. 9 Tallinn Machine Plant
Plant No. 9 of the Ministry of Internal Affairs "Kaliningrad Amber Combine"
Plant No. 9 MSM "Eastern GOK"
Cartographic Factory No. 9 "Lenkartfabrika"
NII-9 NKEP "LEFI"
NII-9 of PSU "VNIINM named after Academician A.A. Bochvara"
NII-9 GKOT "Altai"
SRC-9 FSB
GPI-9 NCSP "Akkproekt"
  
Plant No. 10 NKEP /g. Leningrad/
Plant No. 10 of NKB "ZiD" /g. [[OSINT Project/Maps/Perm, Perm Krai, Volga Federal District, Russia|Perm]]/
Pharmaceutical Plant No. 10 "Nizhpharm"
Thermal Appliance Plant No. 10 /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/
Plant No. 10 /g. Kiev/
Plant No. 10 NKLP /Tushino/
[[OSINT Project/Maps/Novosibirsk, Novosibirsk Oblast, Siberian Federal District, 630000, Russia|Novosibirsk]] Plant No. 10 "NZSM"
Plant No. 10 of the NCAP /g. Glazov/
Leningrad Electric Repair Plant No. 10 NKEP
Plant No. 10 MS "Index"
Kuibyshev Mechanical Plant No. 10 MAP
Mining Administration No. 10 MSM "GMZ"

SKB-10 GKOT /g. Pavlograd/  
OKB-10 GKOT "ISS named after Academician M.F. Reshetneva"
SKB-10 MM "SKB KM"
NII-10 NCSP "MNIIRE "Altair"
NII-10 MSM "VNIICHT"
GPI-10 NKAP "Aviapriborproekt"
Enterprise No. 10 of GUGK  
Plant No. 11 of NKB "KhZ"  
Pharmaceutical Plant No. 11 /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/  
Leningrad Electromechanical Plant No. 11  
Plant No. 11 NKS /g. Ulyanovsk/  
Plant No. 11 MS /g. Kharkiv/  
Plant No. 11 NKHP /g. Kemerovo/  
Plant No. 11 NKOP /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/  
Plant No. 11 Osoaviakhima / Gorky region. /  
Pharmaceutical Plant No. 11 "THFP"  
Plant No. 11 of NKAP "DOK-17"  
Plant No. 11 MAP "ZHMZ"  
Plant No. 11 Glavgaztopprom  
Saratov Electric Repair Plant No. 11 "SEZ"  
Plant No. 11 MSM "KGRK"  
KB-11 PSU "VNIIEF"  
SKB-11 MM "GSKB FS"  
NII-11 MPSS "NNIPI "Quartz"  
NITI-11 GKOT "NITI named after P.I. Snegirev"  
GSPI-11 PGU "VNIPIET"  
"Orgtechstroy-11" MSM

Plant No. 12 "Radio"  
Plant No. 12 of NKB "Elemash"  
Pharmaceutical Plant No. 12 /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/  
Plant No. 12 Glavgaztopprom  
Rostov Electric Repair Plant No. 12  
OKB-12 MAP AVEX  
OKTB-12 NKVD /g. Leningrad/  
CB-12 SME "Neptune"  
PKB-12 MAP "Projectmontazhavtomatika"  
NII-12 NKAP "NIISO"  
NII-12 NKV  
NII-12 NCSP  
GSPI-12 MSM "GSPI"  
GPI-12 Bellegpromproekt  
Laboratory No. 12 KGB

GAZ No. 13 /g. [[OSINT Project/Maps/Omsk, Omsk Oblast, Siberian Federal District, 644000, Russia|Omsk]]/  
Plant No. 13 NKV "UKVZ"  
Pharmaceutical Plant No. 13 /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/  
Plant No. 13 "[[OSINT Project/Maps/Perm, Perm Krai, Volga Federal District, Russia|Perm]] Plant of Lubricants and coolants"  
Plant No. 13 NKEP /g. Kharkiv/  
Plant No. 13 "Tyazhstankohydroppress"  
Kharkiv Plant No. 13 MEP  
Buzdyak Element Plant No. 13-bis NKEP  
CAL No. 13 of NCOP "TsNIIM"  
NTB No. 13 MEP

GAZ No. 14 /g. Sarapul/  
Plant No. 14 of the National Clinical Hospital "Roshal Chemical Plant named after A.A. Kosyakov"  
Pharmaceutical Plant No. 14 /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/  
Plant No. 14 NKHP /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/  
Plant No. 14 MPiSA "Neftepribor"  
Plant No. 14 of NKHP "Kana Biochemical Plant"  
Plant No. 14 MSM /g. Spassk-Dalny/  
Yerevan Electric Repair Plant No. 14  
CDB-14 NKV "KBP named after Academician A.G. Shipunova"  
CDB-14 "Central Design Bureau "Vostok"  
GSPI-14 VSU "VNIPIPromtekhnologii"

Simferopol Plant No. 15 of the Supreme Economic Court  
Plant No. 15 of NKB "Polymer"  
Plant No. 15 NKB / Chelyabinsk region. /  
Pharmaceutical Plant No. 15 /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/  
Electromechanical Plant No. 15 /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/  
Plant No. 15 NKS /g. Kirovabad/  
Plant No. 15 NKEP /Tokarevka/  
Plant No. 15 NKV /g. Belopolye/  
Plant No. 15 of NMIZ  
Plant No. 15 of NKEP "Electromashina"  
OSKB-15 MAP "NIIP named after V.V., Tikhomirova"  
CDB-15 SME "CB "Aisberg"  
NII-15 MSM "SverdNIIKhimmash"

Plant No. 16 of NKAP "KMPO"  
Pharmaceutical Plant No. 16 /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/  
Plant No. 16 of NKneft /g. Yaroslavl/  
Obozny Zavod No. 16  
Plant of medical tools No. 16 "EMA"  
Plant No. 16 of MNP "ANHK"  
Plant No. 16 MS Promsvyaz  
Mining Administration No. 16 of MSM "PPGHO"  
OKB-16 NKV "CB "Tochmash" named after A.E. Nudelman"  
CDB-16 SME "CPB "Wave"  
SKTB-16 /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/

Plant No. 17 NKV "BSZ"  
Pharmaceutical Plant No. 17 /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/  
Plant No. 17 NKS /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/  
Plant No. 17 MNP "NZSP"  
Plant No. 17 MEP "VEZ"  
Plant No. 17 "Suksun OMZ"  
CDB-17 of NKAP "MNIIP"

Plant No. 18 of NKAP "Aviakor"  
Plant No. 18 NKV  
[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]] Radio Plant No. 18 NKEP  
Plant No. 18 Glavgaztopprom /g. Chernogorsk/  
Plant No. 18 /g. Nizhny Tagil/  
Plant No. 18 /g. Ishimbay/  
Molotov Electric Repair Plant No. 18  
SKB-18 /g. Leningrad/  
NITI-18 MAP "LNITI"

Precision Mechanics Plant No. 19 of the NKTP  
Plant No. 19 of NKAP "PMZ"  
Plant No. 19 /g. Ussuriysk/  
Plant No. 19 NKS /g. Kirov/  
Poltava Electric Repair Plant No. 19  
Plant No. 19-bis NKTP  
SKTB-19 MAP "Avert"  
CDB-19 NCSP  
NII-19 MAP /g. [[OSINT Project/Maps/Novosibirsk, Novosibirsk Oblast, Siberian Federal District, 630000, Russia|Novosibirsk]]/

Plant No. 20 of NKAP "Omskagregat"  
Plant No. 20 NKB /g. Frontier/  
Plant No. 20 MS "Maykoppromsvyaz"  
Plant No. 20 "Sirocco"  
Taganrog Electric Repair Plant No. 20  
Plant No. 20 MGA /g. Kiev/  
CDB-20 NKV "NIEMI"  
CDB-20 SME "Vint"  
OKB-20 MSM "KB ATO"  
Telemechanical Institute No. 20 of the NCAP /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/

Plant No. 21 of NKAP "NAZ "Sokol"  
Plant No. 21 NKS Promsvyaz  
[[OSINT Project/Maps/Grozny, Chechen Republic, North Caucasian Federal District, Russia|Grozny]] Electric Repair Plant No. 21  
Plant No. 21 MGA "SPARK"  
KB-21 of the NKOP "Oskonburo"  
CCTB-21 /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/  
CPI-21 /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/

Plant No. 22 "KAPO named after S.P. Gorbunova"  
[[OSINT Project/Maps/Krasnodar, Krasnodar Municipality, Krasnodar Krai, Southern Federal District, 350000, Russia|Krasnodar]] Electric Repair Plant No. 22  
Plant No. 22 MS  
CDB-22 SMEs /g. Kherson/  
NII-22 NCAP /g. Leningrad/

Plant No. 23 "Red Pilot"  
Plant No. 23 of MAP "GKNPC named after M.V. Khrunichev"  
Plant No. 23 NKS "Delta"  
Dzaudjikau Electric Repair Plant No. 23

Plant No. 24 of NKAP "Motorostroitel"  
ARZ-24 MGA /g. Khabarovsk/  
KB-24 NCOP  
NII-24 NKB "NIMI"

Plant No. 25 "[[aircraft|Airplane]]"  
Plant No. 25 NCAP /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/  
Plant No. 25 NCAP /g. Stupino/  
Plant No. 25 MAP /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/  
Plant No. 25 NKUP "KMZ"  
Plant No. 25 MS /g. Tashkent/  
Konstantinovsky Plant No. 25 "Spetstekhsteklo"  
Plant No. 25bis /g. Balashikha/  
KB-25 NKB /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/  
NII-25 MAP "GNIP"

Plant No. 26 "UMPO"  
Plant No. 26 MGA /g. Tyumen/  
Institute No. 26 of NKHP "NITI"

Plant No. 27 of the NKTP  
Plant No. 27 NKAP /g. Kazan/  
Plant No. 27 MAP "Rassvet"  
KB-27 NKB /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/

Plant No. 28 of NKAP "Pneumostroymashina"  
Plant No. 28 named after Karakozova /g. Leningrad/  
Plant No. 28 "Criogenmash"  
KB-28 NCOP  
OKB-28 NCAP V.K. Gribovsky  
NII-28 GKET "NIIPP"

Plant No. 29 NKAP "OMPB"  
Plant No. 29 "Faneroproduct"  
Plant No. 29 NCOP /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/  
Factory No. 29 NKHP  
Plant No. 29 NKVD "PMZR"  
KB-29 NCAP  
CDB-29 NKVD /Bolshevo/  
OKB-29 NKVD /g. Kazan/

Plant No. 30 of the NCAP /Savelovo/  
Plant No. 30 of the NCAP /Savelovo/  
Plant No. 30 MAPO  
Plant No. 30 of NKlesa /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/  
GSKB-30 NCOP  
OKB-30 NCAP /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/  
NII-30 SCRE

Plant No. 31 "Tbilaviastroy"  
ZATO No. 31 /g. Novocherkassk/  
Plant No. 31 MGA /g. Shchelkovo/  
OKB-31 NCAP A.S. Moskalev  
GSKB-31 NKB /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/

Plant No. 32 of NCAP "Avitek"  
Plant No. 32 "DZFS"  
CCB-32 NCSP /g. Leningrad/

Plant No. 33 of NKAP "Inkar"  
Plant No. 33bis NKOP  
NII-33 "VNIIRA"

Plant No. 34 of NKAP "TEMZ"  
Plant No. 34 /g. Krasnogorsk/  
Plant No. 34 NKHP  
Plant No. 34bis NCAP /g. Ulyanovsk/  
Laboratory No. 34 of the NCOP /g. Leningrad/  
CDB-34 SME "CBSM"

Plant No. 35 NCAP /g. Smolensk/  
Plant No. 35 MAP "Aviaagregat"  
SKB-35 NKUP  
OKB-35 GKET "KBPM"  
NII-35 GKET "NPP "Pulsar"

Plant No. 36 "Lakokraska"  
Plant No. 36 "Rybinsk Motors"  
Plant No. 36 NKZ /g. Kemerovo/  
Plant No. 36 MS /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/  
SKB-36 NKNP /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/  
Institute No. 36 of the NCOP

Plant No. 37 of the NCSM  
Plant No. 37 MPSS "NIIDAR"  
Plant No. 37 "Ilyich"  
Plant No. 37 of the Aspharma NKZ  
Institute No. 37 of the NCOP

Plant No. 38 NKTP /Podlipki/  
Plant No. 38 NKV "YUMZ"  
Plant No. 38 NKTP /g. Kolomna/

Plant No. 39 "IAZ"  
Plant No. 39 "Moskvich"  
Plant No. 39 NKHP / Khabarovsk kr. /  
Plant No. 39 of NKHP "THFZ"

Plant No. 40 "KG KPZ"  
Plant No. 40 NKV /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/  
Plant No. 40 of NKTP "Metrovagonmash"  
Plant No. 40 of the NSM /g. Bitter/  
CPP No. 40 /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/  
TsKB-40 NKV "Technomash"

Plant No. 41 of the NCAP /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/  
Plant No. 41 MAP "Avangard"  
Plant No. 41 MGA "OZGA"  
Laboratory No. 41 of NCOP "CEL"

Plant No. 42 of NKB "ZIM"  
Plant No. 42 NKTP /g. Murom/

Plant No. 43 NCAP /g. Kiev/  
Plant No. 43 MAP "Kommunar"  
Plant No. 43 NKTP /g. Murom/  
OKB-43 NKV /g. Leningrad/

Plant No. 44 NKV /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/  
Plant No. 44 /g. Nikolaev/  
Plant No. 44 NKTP /g. Saratov/  
Plant No. 44 /g. Kuibyshev/

Plant No. 45 of the Supreme Economic Court  
Plant No. 45 NCAP /g. Sevastopol/  
Plant No. 45 NCAP /g. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]/  
Plant No. 45 of the NKTP "Volgodieselapparatus"  
Plant No. 45 MAP "Salyut"  
TsNII-45 NCSP "KGNC"

Plant No. 46 NKV /Kuntsevo/  
Plant No. 46 of the NKTP "Reductor"  
Plant No. 46 MV "KEMZ"

Plant No. 47 "Arrow"

Plant No. 48 of the NKTP /g. Kharkiv/  
Plant No. 48 /g. Mezen/  
Plant No. 48 MSM "MZ "Lightning"  
NII-48 of the NCSM "TsNIIKM "Prometheus"

Plant No. 49 NCAP /g. Osipenko/  
Plant No. 49 NCAP /g. Balashikha/  
Plant No. 49 MAP "TANTK named after G.M. Beriyeva"  
NII-49 of the National Club "TsNII "Granit"  
NII-49 GKS "NIIKP"

Plant No. 50 of NKB ZIF  
Plant No. 50 of NKTP "UZTM"  
Plant No. 50 of the NKTP  
Plant No. 50 /g. Yaroslavl/  
Tashkent Z-D No. 50 "TsNIIKlopkoprom"  
TsKB-50 NSC "ZPKB"  
NII-50 MSM "NIIIT"