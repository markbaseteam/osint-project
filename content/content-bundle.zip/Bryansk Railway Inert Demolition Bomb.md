---
locations:
aliases: 
location:
title: Bryansk Railway Inert Demolition Bomb
tag: 
date:
---

# Bryansk Railway Inert Demolition Bomb

2022-04-25  
Explosion  
Infrastructure,Railway  
https://twitter.com/UAWeapons/status/1518707949685850112  
Inert Soviet Demolition bomb found on railway track. Soviet SZ-6 demolition charge. And most interestingly - it is inert (bottom line says ИНЕРТН); so not dangerous at all. The real one, however, consists of 5.9 kg of TNT.  
Bryansk

**According to InformNapalm, Russia is attacking itself with false flags & is preparing to bring in wreckage of Ukrainian [[aircraft|helicopters]] and drones to place as "proof". Other claims made are that top military and families were evacuated April 19th in preparation. Focus areas Belgorod, [[OSINT Project/Maps/Kursk, Kursk Oblast, Central Federal District, 305000, Russia|Kursk]], Bryansk Oblasts especially civilian and residential areas** This was laid on the tracks in full view. It is suspected to either have been planted by Russians to justify [[arrested|arrests]] or by partisans to divert resources. There was some reporting from a sometimes reliable source that a "if our demands are not met" letter was sent with this dummy bomb with a list of targeted areas.

~+~  
62
