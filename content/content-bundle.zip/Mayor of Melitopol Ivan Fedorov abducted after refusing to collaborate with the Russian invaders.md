---
aliases: 
locations: Melitopol, Ukraine
tag: 
date: 2022.03.12
title: Mayor of Melitopol Ivan Fedorov abducted after refusing to collaborate with the Russian invaders
location: [46.8467267,35.3827281]
---
        

[[Russia is forcing Ukrainians from occupied Crimea and Donbas to fight in its invasion of Ukraine]]

[[Russia uses terror and abduction in attempt to force schools to collaborate in occupied Melitopol]]

# Mayor of Melitopol Ivan Fedorov abducted after refusing to collaborate with the Russian invaders

12.03.2022

Halya Coynash

![](https://khpg.org/files/img/1608812072.jpg)

Mayor of Melitopol Ivan Fedorov

Around two thousand Ukrainians [have come out in protest](https://twitter.com/ukrpravda_news/status/1502548897209663488?s=20&t=3vmBp3hctc-hUxhWQfSWMg) in Melitopol demanding that the Russian invaders release Melitopol Mayor, **Ivan Fedorov**.  He was abducted on 11 March from the Melitopol Crisis Centre by Russian soldiers who took him away with a bag over his head.  Fedorov had refused to collaborate with the Russians who have seized the city and there are serious grounds for concern about his safety. It was [also reported](https://www.pravda.com.ua/news/2022/03/12/7330665/) on 12 March that **Olha Haisumova**, the coordinator of the daily protests against the Russian invasion, had been abducted from the protest.  An hour after that news [first appeared on Facebook](https://www.facebook.com/100003097438400/posts/4813482112098322/), Haisumova’s Facebook page has been blocked.

![](https://khpg.org/files/img/1608812071.jpg)

Melitopol protest on 12.03.2022 demanding the release of abducted Mayor Ivan Fedorov Screenshot from video

Initial information about the abduction of Fedorov was reported by Kyrylo Tymoshenko, Deputy Head of the Office of the President, late in the afternoon of 11 March, with [a video later posted](https://t.me/kt20220224), which appears to confirm this.  Fedorov (or a man with a bag over his head) is being forced out of the Melitopol Crisis Centre by a large number of armed men.

[The last post](https://www.facebook.com/IvanFedorovMelitopol/posts/4918781898188475) on Fedorov’s Facebook page was around two hours before his disappearance and expresses gratitude to the huge number of local companies who have come forward to help those most in need of help. “_Together we will overcome everything!”,_ he concluded, adding the Ukrainian flag.

There have been protests every day since the Russian seizure of the city. Fedorov’s abduction came a day after Russian soldiers [burst](https://www.facebook.com/eskender.bariiev/posts/pfbid02WtHtHJAFdQzB72fna4egtFJaytapzW5tfVWPxrWm4J9CBjpXwDKgMbAipnFkgEBwl) into the Melitopol home of **Leila Ibragimova**, the Deputy Head of the Zaporizhya Regional Council, Director of the Melitopol City Museum and a member of the Crimean Tatar community.  The Russian intruders carried out a ‘search’, seized her mobile phone and took her away, reportedly with a bag over her head.  The armed men demanded that she give them names of local activists and also interrogated her about a local Crimean Tatar organization.  She refused to provide the names demanded and [was later released](https://media.az/politics/1067851069/v-ukrainskom-melitopole-rossiyskie-voennoluzhaschie-pohitili-deputata-leylu-ibragimovu/), but that abduction and now that of Fedorov and, seemingly, of Olha Haisumova, are chillingly reminiscent of the lawlessness, the abductions and enforced disappearances, especially of Crimean Tatars,  that Russia brought to Crimea with its invasion in 2014.

![](https://khpg.org/files/img/1608812070.jpg)

Leila Ibragimova

Just as in 2014, Russia tries to seize control of the media and Internet as soon as it seizes control of a city. On 4 March, the Melitopol City Council [reported](https://t.me/zoda_gov_ua/4939) that Russian military had seized the television tower in Melitopol. The aim here, [and in other seized cities](https://khpg.org/en/1608810175), is to replace Ukrainian media with Russian propaganda channels. 

They are, however, meeting with widespread opposition.  In Melitopol, for example, local residents [came out onto the street](https://lb.ua/society/2022/03/11/509065_okupanti_vikrali_mera_melitopolya.html) with Ukrainian flags and held a procession in support of Ukraine.  They chanted: ‘Melitopol is Ukraine’; ‘Glory to Ukraine!’ and ‘Death to the enemy!’   Typically, the Russians tried to stage a fake, during which the invaders were supposedly welcomed into the city, and were thwarted by Ukrainians shouting at them to “go home!”

The Office of the President’s Representative on Crimea [has reported](https://www.facebook.com/ppu.gov.ua/posts/328851965955502) that they are receiving a number of reports of abductions in the Kherson oblast.  Some people are seized at enemy checkpoints after the Russians rummage in their phones and cars and, in all probability, find evidence of the people’s opposition to Russia’s invasion.  In other cases, the Russians actually turn up at people’s homes.  Typically, as well as Ukrainian veterans of the war in Donbas and law enforcement officers, they also target Crimean Tatars.  The President’s Representative notes that it is clearly not looters that are of interest to these invading forces.  Quite the contrary, since the invaders who appeared at the home of a Security Service [SBU] officer, failed to find him, but robbed the house.

There are also reports in other places seized by the Russians of civilians being taken hostage, beaten and tortured.
