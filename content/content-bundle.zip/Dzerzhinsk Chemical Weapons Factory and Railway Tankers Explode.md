---
locations:
aliases: 
location:
title: Dzerzhinsk Chemical Weapons Factory and Railway Tankers Explode
tag: 
date:
---

# Dzerzhinsk Chemical Weapons Factory and Railway Tankers Explode

2022-05-06  
Explosion  
Railway,Chemical,Infrastructure,Other Defence  
https://www.express.co.uk/news/world/1606228/Russia-chemical-plant-fire-explosion-Dzerzhinsk-factory-Ukraine-war-attack-latest-Putin  
Multiple rail tankers containing solvents exploded at a factory in Dzerzhinsk. The [[fire]], which occurred at around 11am on Wednesday, was spread across 2,500 square metres. This comes as numerous facilities across Russia, many with military links, have been hit by mystery [[fire|fires]]. It was a railway tanker containing unspecified solvents on the territory of the former chemical weapons factory Kaprolaktam, in Dzerzhinsk. See also https://www.express.co.uk/news/world/1611630/mystery-fire-russia-claims-ukraine-sabotage  
Kaprolaktam Chemical Weapons Factory, Dzerzhinsk

~+~  
160
