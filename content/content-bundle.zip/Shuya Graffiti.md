---
locations:
aliases: 
location: Kohomskoye highway, Shuya
title: Shuya Graffiti
tag: protest, political
date: 2022-03-18 
---

# Shuya Graffiti

2022-03-18  
Protest  
Other  
https://www.ivanovonews.ru/news/1140466/  
In the cities of the [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] region, inscriptions appear on the walls of public buildings expressing disapproval of the [[Special Military Operation|special operation]] in Ukraine. In Shuya, unknown persons left slogans on the administration building, shops, tried to set [[fire]] to the military enlistment office. The inscriptions on the facades are promptly painted, the FSB and the police are actively looking for intruders. [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] subscribers also sent a "paintographic" story of the slogan at a heat point on Kohomskoye [[roads|highway]]. It's not the first time that the inscription is covered with gray paint. The slogan persistently reappears.  
Shuya, [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]]

~+~  
93
