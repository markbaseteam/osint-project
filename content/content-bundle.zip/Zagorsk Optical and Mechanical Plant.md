---
locations:
aliases: 
location:
title: Zagorsk Optical and Mechanical Plant
tag: fire, other defense
date: 2022-06-08  
---

# Zagorsk Optical and Mechanical Plant

2022-06-08  
[[fire]]  
Other Defence  
https://globalhappenings.com/top-global-news/200735.html  
a warehouse of the Zagorsk Optical and Mechanical Plant [[fire|burned]], which produces military optics for the Russian army–from binoculars to optical sights. According to preliminary information, the flames engulfed warehouses next to the administrative building. At first it was reported that the [[fire]] area was only 30 square meters. m., but the [[fire]] spread very quickly throughout the territory, covering 700 square meters of area.  
Sergiev Posad

military optics for the Russian army–from binoculars to optical sights. Zagorsk Optical & Mechanical Plant warehouse (optical, thermal & night-vision sighting systems)[33]

~+~  
74
