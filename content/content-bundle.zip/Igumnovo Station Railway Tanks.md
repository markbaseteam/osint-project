---
locations:
aliases: 
location:
title: Igumnovo Station Railway Tanks
tag: fire, infrastructure, railway, gas/oil, defence, defense
date:
---

# Igumnovo Station Railway Tanks

2022-05-04  
[[fire]]  
Infrastructure,Railway,Gas/Oil,Other Defence  
https://eprimefeed.com/latest-news/the-fire-area-in-the-dzerzhinsk-industrial-zone-has-reached-2000-square-meters/78082/  
The [[fire]] area in the Dzerzhinsk industrial zone, according to preliminary information, reached 2,000 square meters. [[fire|Burning]] railway tanks in the open area of ​​Igumnovo station. Cause being clarified  
​Igumnovo station, Dzerzhinsk, Nizhny Novgorod

These tanks are linked to several military and defence companies/providers

~+~  
66
