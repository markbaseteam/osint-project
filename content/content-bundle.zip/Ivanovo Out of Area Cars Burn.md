---
locations:
aliases: ['[[Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] Out of Area [[automobiles|Cars]] [[fire|Burn]]', 'foreign cars, foreign car, ivanovo car burning, ivanovo car burns, invanovo car on fire']
location:
title: '[[Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] Out of Area [[automobiles|Cars]] [[fire|Burn]]'
tag: fire
date: 2022-06-27  
linter-yaml-title-alias: '[[Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] Out of Area [[automobiles|Cars]] [[fire|Burn]]'
---

# [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] Out of Area [[automobiles|Cars]] [[fire|Burn]]

2022-06-27  
[[fire]]  
Other  
https://www.ivanovonews.ru/news/1152365/  
The message about the ignition of [[automobiles|cars]] near house No. 16 on Paris Commune Street in [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] arrived on June 27 at about 5 p.m. As IvanovoNews was informed in the press service of the Ministry of Emergency Situations for the [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] region, at first Volkswagen Golf caught [[fire]], from it the flame spread to the nearby Nissan Almera foreign [[automobiles|car]]. The total area of the [[fire]] was 12 square meters. The [[automobiles|cars]] [[fire|burned]] almost to the ground. According to the [[fire]] department, no one was injured. The preliminary cause of the [[fire]] is a malfunction of electrical wiring.  
No. 16, Paris Commune Street, [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]]

The two [[automobiles|cars]] were identified as "foreign" which may mean not registered, out of area or out of country. This may or may not be related to other activities. Adding to see if there is a discernible pattern. There have been other reports in [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] of [[automobiles|car]] burnings & also "foreign" [[automobiles|cars]] having been used as "escape" for unmentioned activities. Highly Likely this has nothing to do with anything.

~+~  
25
