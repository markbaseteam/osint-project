---
locations:
aliases: 
location:
title: Bryansk Border Checkpoint
tag: 
date:
---

# Bryansk Border Checkpoint

2022-04-13  
[[fire]]  
Other  
https://en.wikipedia.org/wiki/2022_Western_Russia_attacks  
In response to accusations regarding the April 13, 2022: Bryansk border checkpoint incident by Russia's FSB security service, Ukrainian interior ministry advisor Anton Herashchenko said that something "fell and caught [[fire]]" at a Russian military facility, without explicitly confirming or denying Ukrainian responsibility.  
Bryansk Check Point

~+~  
28
