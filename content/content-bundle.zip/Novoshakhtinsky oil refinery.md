---
locations:
aliases: 
location:
title: Novoshakhtinsky oil refinery
tag: fire, gas/oil, refinery
date: 2022-06-22  
---

# Novoshakhtinsky oil refinery

2022-06-22  
[[fire]]  
Gas/Oil  
https://globalhappenings.com/top-global-news/211867.html  
Earlier in the [[Rostov region]], after the “cotton”, the Novoshakhtinsky oil refinery caught [[fire]]. The area of ​​the [[fire]] was 50 square meters. Russian Telegram channels claim that a Ukrainian drone allegedly caused the “clap”. The Novoshakhtinsky Oil Refinery is located 150 kilometers from Donetsk and even further from the line where the fighting is taking place. === Russia claims it was hit by a Ukraine drone, but direct action groups have taken credit. https://www.themoscowtimes.com/2022/06/22/major-russian-oil-refinery-says-struck-by-ukrainian-drone-a78069  
Novoshakhtinsky, Rostov

This refinery is the largest supplier of petroleum products in the [[OSINT Project/Maps/Southern Russia, улица Степана Разина, Ворошиловский район, Volgograd, Volgograd Oblast, Southern Federal District, 400001, Russia|south of Russia]]. It specializes in the production of fuel oil, heating oil, marine and diesel fuel, straight-run gasoline. In April 2021, a large construction contractor of the Russian Federation PETON became the owner of the Novoshakhtinsk oil products plant, before that The refinery was registered to the wives of Viktor Medvedchuk and Taras Kozak.

~+~  
11
