---
locations:
aliases: ['[[Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] 3 [[automobiles|Cars]]']
location:
title: '[[Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] 3 [[automobiles|Cars]]'
tag: fire
date: 2022-05-19 
linter-yaml-title-alias: '[[Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] 3 [[automobiles|Cars]]'
---

# [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] 3 [[automobiles|Cars]]

2022-05-19  
[[fire]]  
Other  
https://ivteleradio.ru/news/2022/05/19/tri_avtomobilya_sgoreli_utrom_v_ivanove  
3 [[automobiles|cars]] on [[fire]].  
[[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]]

Note - [[fire|Burning]] [[automobiles|cars]] does not seem to be rare in Russia. These [[automobiles|cars]] were said elsewhere to have had Z iconography. It is also possible they were [[fire|burned]] as part of the Heavy Machine Tool Plant [[fire]] in the same area on the same day.

~+~  
180
