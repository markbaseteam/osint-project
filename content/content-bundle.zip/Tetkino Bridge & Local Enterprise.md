---
aliases: 
location:
title:
tag: 
date:
```
---
# Tetkino Bridge & Local Enterprise

2022-04-25  
Mechanical  
Infrastructure  
https://globalhappenings.com/top-global-news/217932.html  
Earlier we said that in the village of Tetkino in the Glushkovsky district of the [[OSINT Project/Maps/Kursk, Kursk Oblast, Central Federal District, 305000, Russia|Kursk]] region, they announced attacks on the bridge and local enterprises. There are no injured or dead.  
Tetkino, Glushkovsky district, [[OSINT Project/Maps/Kursk, Kursk Oblast, Central Federal District, 305000, Russia|Kursk]] region

**According to InformNapalm, Russia is attacking itself with false flags & is preparing to bring in wreckage of Ukrainian [[aircraft|helicopters]] and drones to place as "proof". Other claims made are that top military and families were evacuated April 19th in preparation. Focus areas Belgorod, [[OSINT Project/Maps/Kursk, Kursk Oblast, Central Federal District, 305000, Russia|Kursk]], Bryansk Oblasts especially civilian and residential areas** Double check names & dates

~+~  
61