---
aliases: prisons, jail, jails, gaol, gaols, penal colony, penal colonies, gulag, gulags, detention center, detention centers, correction facility, hoosegow, hoosegows
locations:
tag: 
date:
title: prison
---
> A **prison**, also known as a [[arrested|jail]] or gaol (dated, standard English, Australian, and historically in Canada), penitentiary (American English and Canadian English), [[arrested|detention]] center (or [[arrested|detention]] centre outside the US), correction center, correctional facility, lock-up, hoosegow or remand center, is a facility in which inmates (or prisoners) are confined against their will and usually denied a variety of freedoms under the authority of the state as punishment for various crimes. Prisons are most commonly used within a criminal justice system: people charged with crimes may be [[arrested|imprisoned]] until their trial; those pleading or being found guilty of crimes at trial may be sentenced to a specified period of imprisonment. In simplest terms, a prison can also be described as a building in which people are legally held as a punishment for a crime they have committed.
>
> Prisons can also be used as a tool of political repression by authoritarian regimes. Their perceived opponents may be [[arrested|imprisoned]] for political crimes, often without trial or other legal due process; this use is illegal under most forms of international law governing fair administration of justice. In times of war, prisoners of war or detainees may be [[arrested|detained]] in military prisons or prisoner of war camps, and large groups of civilians might be [[arrested|imprisoned]] in internment camps.
>
> In American English, the terms prison and [[arrested|jail]] have separate definitions, though this is not always followed in casual speech. A prison or penitentiary holds people for longer periods of time, such as many years, and is operated by a state or federal government. A [[arrested|jail]] holds people for shorter periods of time (e.g. for shorter sentences or pre-trial [[arrested|detention]]) and is usually operated by a local government, typically the county sheriff. Outside of North America, prison and [[arrested|jail]] often have the same meaning.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Prison)
