---
locations:
aliases: 
location: 23 Uborevicha Street, Vladivostok, Primorsky Krai
title: Vladivostok Recruitment Office
tag: fire, recruitment
date: 2022-06-06  
---

# Vladivostok Recruitment Office

2022-06-06  
[[fire]]  
Recruitment  
https://darknights.noblogs.org/post/2022/06/13/vladivostok-russia-military-recruitment-center-set-on-fire/  
Vladivostok. Russia. In the early morning hours of June 6, 2022, another office for military call-ups and recruitment was set on [[fire]], this time in the wooden building at 23 Uborevicha Street in Vladivostok. The facade of the building was damaged as a result of the [[fire]]. There is conflicting information about how exactly the attack was carried out. Komsomolskaya Pravda”, referring to the police, reports about two suspects who threw a bottle with a flammable liquid against the front wall of the building. Passers-by scared away the arsonists, so that the building did not completely went up in flames, the cladding boards [[fire|burned]]. The Telegram channel Shot reports about an arsonist who used a rag prepared with a flammable substance. The arsonists were able to escape. This is the 18th [[fire|arson]] attack on an enlistment office that has occurred in recent times. This does not even include the [[fire|arson]] attacks on other military and industrial facilities, which the authorities are trying to dismiss as accidents. the military had already begun replacing damaged wooden boards and the head of the regional [[OSINT Project/Maps/Primorsky Krai, Far Eastern Federal District, Russia|Primorsky Krai]] police, Maj. Gen. Oleg Stefankov, had registered the [[fire|arson]] incident and put the building "under control."  
23 Uborevicha Street, Vladivostok, [[OSINT Project/Maps/Primorsky Krai, Far Eastern Federal District, Russia|Primorsky Krai]]

Contrary dates. Used the earliest 6 or 8 June. Also see https://www.newsweek.com/military-enlistment-office-set-fire-russia-1713838

~+~  
59
