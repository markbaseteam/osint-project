---
locations:
aliases: 
location:
title: Belgorod Oil Depot
tag:
date:
---

# Belgorod Oil Depot

2022-04-01  
[[fire]]  
Gas/Oil  
https://www.rferl.org/a/russia-fires-mystery-ukraine-conflict/31884503.html  
Fireballs rise over an oil depot in Belgorod, a Russian city located 30 kilometers from the border with Ukraine, on April 1. According to a local official, the [[fire]] was caused by an [[air]] strike from two Ukrainian [[aircraft|helicopters]]. Video of the aftermath of the dawn incident shows two Hind [[aircraft|helicopter]] gunships skimming the rooftops of the southwestern Russian city. Ukraine denied any involvement.  
Belgorod  
50.591611; 36.670306  
The Ministry of Defense of Ukraine denied the statement of the Russian Federation and replied that our defenders had nothing to do with the emergency in Belgorod. High-ranking officials named two probable reasons for undermining the oil depot–the carelessness of the invaders or an attempt to hide someone’s corruption. On April 1, Russian media reported that a projectile allegedly “fired from Ukraine” fell in the Belgorod region. As a result of the explosion, a [[fire]] broke out at the oil depot, which destroyed several oil tanks. https://globalhappenings.com/top-global-news/217932.html according to Russian governor Vyacheslav Gladkov and an unnamed US official, two Ukrainian Mi-24 [[aircraft|Helicopters]] attacked and set [[fire]] to a fuel depot in Belgorod, Russia in a low-altitude airstrike with no reported casualties. Ukraine denied and dismissed this event on Russian territory as Russian propaganda. Ukrainian security official Oleksiy Danilov denied Ukraine was behind the [[aircraft|helicopter]] attack with a joke in which he blamed the "People's Republic of Belgorod" instead.

~+~  
42
