---
locations:
aliases: 
location: Talca-Vereytsa rail line
title: Talca-Vereytsa Railway automation and telemechanics disabled
tag: mechanical, railway, infrastructure
date: 2022-02-26  
---

# Talca-Vereytsa Railway automation and telemechanics disabled

2022-02-26  
Mechanical  
Railway,Infrastructure  
https://ru.wikipedia.org/wiki/Рельсовая_война_в_Белоруссии_(2022)#30_марта  
On the Talca-Vereytsa, the device of automation and telemechanics of the SCB was disabled  
Talca-Vereytsa

May be same as Talka-Vereytsa few days off  
~+~  
121
