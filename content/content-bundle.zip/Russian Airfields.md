---
aliases: Russian Air Bases, Russian Air Base, Russian Air Fields, Russian Air Field, Russian Airfield
locations:
tag: 
date:
title: 'Russian [[air base|Air Bases]]'
linter-yaml-title-alias: 'Russian [[air base|Air Bases]]'
---

# Russian [[air base|Air Bases]]

  
  

Airfield

Military District

ICAO

Latitude

Longitude

Afrikanda

Leningrad

  

  

  

  

Akthubinsk

North-Caucasian

  

  

  

  

Alabino

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Alakurtti

Leningrad

  

  

  

  

Alekseyevka

Far Eastern

  

  

  

  

Andreapol

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Apatity

Leningrad

  

  

  

  

Aramil

Volga-Ural

  

  

  

  

Arkhangelsk - Talagi

Leningrad

  

  

  

  

Armavir

North-Caucasian

  

  

  

  

Artyom - Knevichi

Far Eastern

  

  

  

  

Astrakhan - Ashchuluk

North-Caucasian

  

  

  

  

Astrakhan - Privolzhskiy

North-Caucasian

  

  

  

  

Bada

[[Siberian Federal District|Siberian]]

  

  

  

  

Balashov

Volga-Ural

  

  

  

  

Barnaul

[[Siberian Federal District|Siberian]]

  

  

  

  

Bataysk

North-Caucasian

  

  

  

  

Belaya

[[Siberian Federal District|Siberian]]

  

  

  

  

Belogorsk-9

Far Eastern

  

  

  

  

Belyy Klyuch

Volga-Ural

  

  

  

  

Berdsk

[[Siberian Federal District|Siberian]]

  

  

  

  

Besovets - Petrozavodsk-15

Leningrad

  

  

  

  

Bezenchuk

Volga-Ural

  

  

  

  

Bezhetsk - Dorokhovo

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Bobrovka

Volga-Ural

  

  

  

  

Bolshoye Savino - Sokol

Volga-Ural

  

  

  

  

Borisoglebsk

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Borzya

[[Siberian Federal District|Siberian]]

  

  

  

  

Bratsk

[[Siberian Federal District|Siberian]]

  

  

  

  

Budyonnovsk

North-Caucasian

  

  

  

  

Buturlinovka

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Chebenki

Volga-Ural

  

  

  

  

Chelyabinsk-15

Volga-Ural

  

  

  

  

Chernigovka

Far Eastern

  

  

  

  

Chornoye

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Chernyakhovsk

Kaliningrad KOR

  

  

  

  

Chita-45

[[Siberian Federal District|Siberian]]

  

  

  

  

[Chkalovsk - Lyublino-Novoye](chkalovsk.htm)

Kaliningrad KOR

  

  

  

  

Chkalovskiy

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Chuguevka - Sokolovka

Far Eastern

  

  

  

  

Dolinsk-Sokol

Far Eastern

  

  

  

  

Domna

[[Siberian Federal District|Siberian]]

  

  

  

  

Donskoye

Kaliningrad KOR

  

  

  

  

Dushanbe

CIS

  

  

  

  

DzidhaNyangi

[[Siberian Federal District|Siberian]]

  

  

  

  

Engels

Volga-Ural

  

  

  

  

Freetown - Lungi

CIS

  

  

  

  

Galenki

Far Eastern

  

  

  

  

Garovka-2

Far Eastern

  

  

  

  

Gatchina

Leningrad

  

  

  

  

Gdov - Smuravevo

Leningrad

  

  

  

  

Gromovo

Leningrad

  

  

  

  

Gudauta - Bombora

CIS

  

  

  

  

Gvardeyskoye

CIS

  

  

  

  

Irkutsk

[[Siberian Federal District|Siberian]]

  

  

  

  

[[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] - Severnyy

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

[[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] - Yuzhnyy

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Kacha

CIS

  

  

  

  

Kachalovka

Leningrad

  

  

  

  

Kaluga

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Kamen-na-Obi

[[Siberian Federal District|Siberian]]

  

  

  

  

Kansk

[[Siberian Federal District|Siberian]]

  

  

  

  

Kapustin Yar

North-Caucasian

  

  

  

  

Kasimovo - Agalatovo

Leningrad

  

  

  

  

Khabarovsk - Bolshoy

Far Eastern

  

  

  

  

Khotilovo

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Khrabrovo

Kaliningrad KOR

  

  

  

  

Khurba

Far Eastern

  

  

  

  

Kilp Yavr

Leningrad

  

  

  

  

Kinel-Cherkassy

Volga-Ural

  

  

  

  

Kipelovo - Fedotovo

Leningrad

  

  

  

  

Klin

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Kluchevoye - Pribylovo

Leningrad

  

  

  

  

Klyuchi-20 - Kura

Far Eastern

  

  

  

  

Komsomolsk na Amure - Dzemgi

Far Eastern

  

  

  

  

Korenovsk

North-Caucasian

  

  

  

  

Korsakov

Far Eastern

  

  

  

  

Kostroma

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Kotelnikovo

North-Caucasian

  

  

  

  

Kotlas - Savvatiya

Leningrad

  

  

  

  

[[OSINT Project/Maps/Krasnodar, Krasnodar Municipality, Krasnodar Krai, Southern Federal District, 350000, Russia|Krasnodar]] - Aviagorodok 5

North-Caucasian

  

  

  

  

[[OSINT Project/Maps/Krasnoyarsk, Krasnoyarsk Urban Okrug, Krasnoyarsk Krai, Siberian Federal District, 660000, Russia|Krasnoyarsk]]-Cheremshanka

[[Siberian Federal District|Siberian]]

  

  

  

  

Kremovo

Far Eastern

  

  

  

  

Krymsk

North-Caucasian

  

  

  

  

[Kubinka](kubinka.htm)

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Kubinka - Staryy Gorodok

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

[[OSINT Project/Maps/Kursk, Kursk Oblast, Central Federal District, 305000, Russia|Kursk]]

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

[[OSINT Project/Maps/Kursk, Kursk Oblast, Central Federal District, 305000, Russia|Kursk]] - Khalino

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Kushchovskaya

North-Caucasian

  

  

  

  

Kyaktha

[[Siberian Federal District|Siberian]]

  

  

  

  

Lakhta - Katunino

Leningrad

  

  

  

  

Levashovo

Leningrad

  

  

  

  

Lipetsk

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Lodeynoye Pole

Leningrad

  

  

  

  

Malino

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Marinovka

North-Caucasian

  

  

  

  

Maykop

North-Caucasian

  

  

  

  

Michurinsk

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Mikhaylovka - Lebyazhe

North-Caucasian

  

  

  

  

Millerovo

North-Caucasian

  

  

  

  

Monchegorsk

Leningrad

  

  

  

  

Mongokhto - Bolshoy Kamen

Far Eastern

  

  

  

  

Morozovsk

North-Caucasian

  

  

  

  

Morshansk

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moskva]] - Vnukovo

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moskva]] - Zhukovskiy

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Mozdok

North-Caucasian

  

  

  

  

Nerchinsk

[[Siberian Federal District|Siberian]]

  

  

  

  

Nikolayevka - Zolotaya Dolina

Far Eastern

  

  

  

  

Nivenskoye

Kaliningrad KOR

  

  

  

  

Nizhniy Novgorod

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Novaya

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Novgorod - Krechevitsy

Leningrad

  

  

  

  

Novocherkassk 14

North-Caucasian

  

  

  

  

Novonezhino

Far Eastern

  

  

  

  

[[OSINT Project/Maps/Novosibirsk, Novosibirsk Oblast, Siberian Federal District, 630000, Russia|Novosibirsk]]

[[Siberian Federal District|Siberian]]

  

  

  

  

Olenegorsk - Vysokiy

Leningrad

  

  

  

  

OmskSevernyy

[[Siberian Federal District|Siberian]]

  

  

  

  

Orenburg - Tsentralnyy

Volga-Ural

  

  

  

  

Ostafevo

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Ostrov

Leningrad

  

  

  

  

Ozinki

Volga-Ural

  

  

  

  

Pechora - Kamenka

Leningrad

  

  

  

  

Petrovsk

Volga-Ural

  

  

  

  

Plesetsk

Leningrad

  

  

  

  

Podolsk

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Pravdinsk

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Primorsko - Akhtarsk

North-Caucasian

  

  

  

  

Pristan

Far Eastern

  

  

  

  

Pristina - Vrele

CIS

  

  

  

  

Protasovo

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Pskov

Leningrad

  

  

  

  

Pskov - Polkavaya

Leningrad

  

  

  

  

Pugachov

Volga-Ural

  

  

  

  

Pushkin

Leningrad

  

  

  

  

Rostov na Donu

North-Caucasian

  

  

  

  

Rtishchevo

Volga-Ural

  

  

  

  

Ryazan - Dyagilevo

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Ryazhsk

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Rzhev-3

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Salsk

North-Caucasian

  

  

  

  

Saransk

Volga-Ural

  

  

  

  

Savasleyka

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Sennoy

Volga-Ural

  

  

  

  

Serdobsk

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Seshcha

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Severomorsk-1

Leningrad

  

  

  

  

Severomorsk-2 - Safonovo

Leningrad

  

  

  

  

Severomorsk-3 - Malyavr

Leningrad

  

  

  

  

Shatalovo

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Shaykovka

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Sheremetevo

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Siverskoye

Leningrad

  

  

  

  

Slavgorod

[[Siberian Federal District|Siberian]]

  

  

  

  

Smolensk - Severnyy

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Sochi

North-Caucasian

  

  

  

  

Soltsy

Leningrad

  

  

  

  

Sovetskaya Gavan

Far Eastern

  

  

  

  

Srednebeloye

Far Eastern

  

  

  

  

St. Petersburg - Gorelovo 2

Leningrad

  

  

  

  

Staraya Russa 1

Leningrad

  

  

  

  

Stavropol

North-Caucasian

  

  

  

  

Step-Olovyannaya

[[Siberian Federal District|Siberian]]

  

  

  

  

Stupino

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Syzran

Volga-Ural

  

  

  

  

Taganrog - Tsentralnyy

North-Caucasian

  

  

  

  

Taganrog - Yuzhnyy

North-Caucasian

  

  

  

  

Tambov

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Tikhoretsk

North-Caucasian

  

  

  

  

Tiraspol

CIS

  

  

  

  

[Torzhok](torzhok.htm)

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Totskiy-2

Volga-Ural

  

  

  

  

Tsentralnaya Uglovaya

Far Eastern

  

  

  

  

Tula - Klokovo

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Tver - Migalovo

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Ufa

Volga-Ural

  

  

  

  

Ukrainka - Seryshevo

Far Eastern

  

  

  

  

Uprun - Troitsk

Volga-Ural

  

  

  

  

Ussuriysk - Vozdvizhenka

Far Eastern

  

  

  

  

Vaziani

CIS

  

  

  

  

Verino - Pereyaslavka

Far Eastern

  

  

  

  

Vernoye - Orlovka

Far Eastern

  

  

  

  

Vladikavkaz

North-Caucasian

  

  

  

  

Vladimir - Sokol

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Vladimir-Dobrynskoye

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Volgograd

North-Caucasian

  

  

  

  

Vologda

Leningrad

  

  

  

  

[Voronezh - Baltimor](voronezh-ab.htm)

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Vorotynsk - Oreshkovo

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Vozzhayevka

Far Eastern

  

  

  

  

Vyazma

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Yefremov

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Yegorlykskaya

North-Caucasian

  

  

  

  

Yekaterinburg - Koltsovo

Volga-Ural

  

  

  

  

Yelizovo

Far Eastern

  

  

  

  

Yerevan - Erebuni

CIS

  

  

  

  

Yermolino

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

Yeysk

North-Caucasian

  

  

  

  

Zavitinsk

Far Eastern

  

  

  

  

Zernograd

North-Caucasian

  

  

  

  

Zheerdevka

[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

  

  

  

  

[Zhukovsky](zhukovsky.htm)

# Russian Airfields

Name

DAFIF

ICAO

Latitude

Longitude

Type

[[air base|Runway]] ft.

Elevation ft.

Abakan

RS96576

UNAA

53.74  
91.385

A

10,663

830

Alykel

RS00053

UOOO

69.3111  
87.3289

D

11,253

574

Astrakhan

RS00009

URWA

46.2833  
48.0064

A

8,202

(65)

Balandino

RS96578

USCC

55.3033  
61.5067

A

10,499

769

Barnaul

RS96592

UNBB

53.3639  
83.5419

A

9,350

837

Begishevo

RS00016

UWKE

55.5654  
52.092

A

8,222

643

Belgorod

RS96572

UUOB

50.6438  
36.5901

A

7,546

735

Beslan

RS96566

URMO

43.205  
44.6083

A

9,842

1,673

Besovets

RS33152

ULPB

61.885  
34.1572

A

8,202

151

Bolshoye Savino

RS00003

USPP

57.9167  
56.0256

A

8,209

404

Bratsk

RS96591

UIBB

56.3708  
101.699

A

10,367

1,611

Bryansk

RS00022

UUBP

53.2142  
34.1764

A

7,874

663

Cheboksary

RS96594

UWKS

56.0903  
47.3473

A

8,241

558

Chertovitskoye

RS96568

UUOO

51.8156  
39.23

A

7,546

514

Chulman

RS00052

UE

56.9136  
124.915

D

11,811

2,812

Domodedovo

RS96567

UUDD

55.4086  
37.9061

A

12,447

587

Elista

RS00007

URWI

46.3739  
44.3317

A

6,562

499

Gumrak

RS96569

URWW

48.7824  
44.3447

A

8,202

482

Ignatyevo

RS96593

UHBB

50.4217  
127.41

A

9,186

638

Irkutsk

RS80666

UIII

52.2672  
104.395

A

9,072

1,673

Kadala

RS68697

UIAA

52.0262  
113.305

A

9,186

2,270

Kazan

RS06330

UWKD

55.6033  
49.285

A

8,196

407

Kemerovo

RS00010

UNEE

55.2725  
86.1092

A

8,858

873

Khatanga

RS00051

US

71.9784  
102.491

D

8,222

98

Khomutovo

RS96588

UHSS

46.8887  
142.717

A

8,858

59

Khrabrovo

RS84082

UMKK

54.89  
20.5926

A

8,202

43

Knevichi

RS96595

UHWW

43.3992  
132.152

A

11,483

43

Kogalym

RS00001

USRK

62.1906  
74.5339

A

8,225

220

Koltsovo

RS96587

USSS

56.7414  
60.8036

A

9,882

764

[[OSINT Project/Maps/Krasnoyarsk, Krasnoyarsk Urban Okrug, Krasnoyarsk Krai, Siberian Federal District, 660000, Russia|Krasnoyarsk]]

RS00014

UNKL

56.175  
92.5199

A

12,139

942

[[OSINT Project/Maps/Kursk, Kursk Oblast, Central Federal District, 305000, Russia|Kursk]]

RS00031

UUOK

51.7511  
36.2964

A

8,202

686

Kurumoch

RS60241

UWWW

53.5056  
50.1644

A

9,846

476

Migalovo

RS00006

UUEM

56.8247  
35.7577

A

8,202

469

Mineralnyye Vody

RS96564

URMM

44.2258  
43.0819

A

12,795

1,053

Mirny

RS00056

US

62.5347  
114.039

B

9,186

1,155

Mukhino

RS31749

UIUU

51.8067  
107.438

A

9,832

1,690

Murmansk

RS82327

ULMM

68.7817  
32.7508

A

8,202

266

Nalchik

RS96565

URMN

43.5133  
43.6383

A

7,218

1,460

Novy

RS96579

UHHH

48.528  
135.188

A

13,123

246

Orsk

RS00017

UWOR

51.0728  
58.596

A

9,514

909

Pashkovsky

RS69801

URKK

45.035  
39.1717

A

9,842

118

Pevek

RS00055

US

69.7829  
170.593

D

8,202

11

Pskov

RS96570

ULOO

57.7839  
28.3956

A

6,562

154

Pulkovo

RS45559

ULLI

59.8004  
30.2633

A

12,401

79

[Ramenskoye](zhukovsky.htm)

Raduzhny

RS00004

USNR

62.1583  
77.3125

A

8,924

249

Roschino

RS96590

USTR

57.1896  
65.3243

A

9,842

371

Rostov Na Donu

RS33782

URRR

47.2582  
39.818

A

8,202

279

Salekhard

RS00057

USDD

66.5902  
66.6104

D

8,940

218

Sheremetyevo

RS30325

UUEE

55.9717  
37.415

A

12,139

630

Shpakovskoye

RS42770

URMT

45.1092  
42.1128

A

8,530

1,486

Sochi

RS08294

URSS

43.4458  
39.9475

A

9,350

89

Sokol

RS96581

UHMM

59.91  
150.717

A

11,325

574

Strigino

RS20803

UWGG

56.23  
43.7867

A

9,203

256

Surgut

RS00018

USRR

61.3437  
73.4018

A

9,121

200

Syktyvkar

RS02275

UUYY

61.6475  
50.8456

A

8,202

342

Talagi

RS96573

ULAA

64.6003  
40.7167

A

8,202

62

Tiksi

RS00015

UE

71.6966  
128.902

C

9,022

36

Tolmachevo

RS96574

UNNT

55.0226  
82.625

A

11,826

365

Tsentralny

RS00005

UWSS

51.5661  
46.0439

A

7,283

499

Tsentralny

RS00002

UNOO

54.9672  
73.3102

A

9,293

312

Tsentralny

RS96582

UWOO

51.7958  
55.4567

A

8,202

387

Tushino

Ufa

RS96585

UWUU

54.5575  
55.8744

A

12,336

450

Ugolny

RS96577

UHMA

64.735  
177.722

A

11,483

197

Uytash

RS00594

URML

42.8168  
47.6523

A

8,661

13

Vityazevo

RS90179

URKA

45.0021  
37.3473

A

8,202

174

Vnukovo

RS52144

UUWW

55.5915  
37.2615

A

10,039

686

Vostochny

RS00008

UWLW

54.4011  
48.8028

A

16,404

253

Yakutsk

RS96586

UEEE

62.0933  
129.771

A

11,155

325

Yelizovo

RS96583

UHPP

53.1665  
158.453

A

11,155

131

[Zhukovsky](zhukovsky.htm)

In August 1998 it was reported that more than 70 airfields would be closed as part of the [[air]] Force's larger effort to streamline its operations. According to the Defense Ministry, some 80 airfields with [[air base|runways]] longer than 1800 meters would remain open. The airfields' closure may free scarce budget funds for the maintenance and reconstruction of the remaining airfields, the bulk of which were constructed during the 1950s through 1970s and have exceeded their expected service life.

Russian [[air base|airbases]] generally have their own energy plant apart from the connection to the normal power grid, and of course plenty of mobile generators.

During mid 1993 at a Russian [[air base]] at Akhtubinsk, near Astrakhan, on the Volga River, a display of [[aircraft]] was permitted and only a few journalists new about it to come. Akhtubinsk [[air base]] up until this point was a "closed" facility for the testing or [[air]] weapons.

On 21 February 1994 five armed men forced their way into the guardhouse of the Russian [[air base]] at Amari (Suurkula), searched for weapons, and [[fire|burned]] down the post. The base was the last airfield still under Russian military control from which combat [[aircraft]] had been removed, but was still frequently used by military transport [[aircraft|planes]]. The Russian Foreign Ministry delivered an official protest to Estonian Ambassador Juri Kahn, demanding exhaustive explanations from Estonia and punishment for the organizers and participants in the attack that was described as an "extremely dangerous deliberate action which may lead to unpredictable consequences."

The Ukrainian defense ministry protested the alleged planned takeover of over 20 TU-22M Backfire [[aircraft]] by Russia in upcoming Black Sea Fleet military exercises on 4 May 1994. According to the defense ministry, Russia planned to have the [[aircraft|planes]], which belong to the naval aviation arm of the Black Sea Fleet, fly out of their [[air base|air bases]] at Oktyabrskoye and Vesoloye in Crimea to the Russian [[air base]] at Krymsk in [[OSINT Project/Maps/Krasnodar Krai, Southern Federal District, Russia|Krasnodar krai]]. The Ukrainian defense ministry said that any attempt to transfer military technology or other Black Sea Fleet assets outside Ukraine would be regarded as illegal acts by Ukraine and would worsen the problem of dividing the fleet. Andrei Grachev, head of the Black Sea Fleet press center, denied that there was any truth to the allegation. According to Grachev the charge was a "figment of the imagination" of the Ukrainian defense ministry.

The Russian Defence Minister, Army General Sergei Shoigu said in Ausut 2015 that about 100 [[air base|airports]] used by armed forces of Russia require major repairs or reconstruction. "Currently, aerospace forces used 125 airfields. Of these, 80% need major repairs or reconstruction," - the minister said at a conference at the National Control Center of Defense of Russia. In this regard, said Shoigu, until 2020 provided reconstruction and repair of 108 airfields. "State aerodrome is directly related to safety," - said the head of the military department.

The Ministry of Defense of the Russian Federation will carry out a large-scale reconstruction of the aerodrome network in the interests of more operational use of aviation and its safe operation. This was announced by the head of department, Sergei Shoigu, at a meeting of the board of the Ministry of Defense 26 April 2019. According to him, the Ministry of Defense is preparing a draft plan for the repair and reconstruction of 106 airfields.

In particular, the minister said, it is planned to repair more than 13 million square meters. m artificial airfields. In addition, more than 700 power supply facilities, [[air]] traffic control, [[aircraft]] maintenance and repair will be built, as well as an infrastructure has been created for promising airline complexes. Shoigu stressed that "the further development of the airfield network of the armed forces will allow for more operational use of aviation and its safe operation." The minister said that this work is carried out within the framework of the plan, its action is calculated until 2028.

Shoigu said that over the past five years, artificial [[air base|runways]] of 12 airfields were reconstructed: Vityazevo, Akhtubinsk, Eisk, Krymsk, Korenovsk, Lipetsk, Privolzhsky, Mozdok, Severomorsk-1, Chkalovsky, Chkalovsk and Engels. Currently, work is continuing on another four airfields - Steppe, Baltimore, Temp and Nagurskaya, the minister said, stressing that two of them are located in the Arctic zone. Shoigu also said that this year it is planned to commission six modern [[aircraft]] simulators at the airfields of Domna, Vyazma, Morozovsk, Torzhok, Pushkin and Ryazan.

  

© 2000-2022 GlobalSecurity.org All rights reserved.  

Page last modified: 13-09-2021 17:22:36 ZULU
