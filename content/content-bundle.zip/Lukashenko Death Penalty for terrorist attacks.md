---
locations:
aliases:
  - 'Lukashenko Death Penalty for "terrorist attacks"'
location: Belarus
title: Lukashenko Death Penalty for "terrorist attacks"
tag: death penalty, event
date: 2022-05-18
linter-yaml-title-alias: 'Lukashenko Death Penalty for "terrorist attacks"'
---

# Lukashenko Death Penalty for "terrorist attacks"

2022-05-18

https://www.dw.com/en/belarus-attempted-terrorism-to-be-punishable-by-death/a-61837461  
Not an act of defiance, but important in the time line. Belarus has introduced the death penalty for attempted terrorist attacks. The move could affect opposition [[activism|activists]] who are currently on trial. a "terrorist act" being a fluid definition.

~+~  
13
