---
locations:
aliases: ['[[Maps/Palekhsky District, Ivanovo Oblast, Central Federal District, Russia|Palekhsky]], [[Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] Recruitment Office']
location:
title: '[[Maps/Palekhsky District, Ivanovo Oblast, Central Federal District, Russia|Palekhsky]], [[Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] Recruitment Office'
tag: molotov, recruitment
date: 2022-03-18  
linter-yaml-title-alias: '[[Maps/Palekhsky District, Ivanovo Oblast, Central Federal District, Russia|Palekhsky]], [[Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] Recruitment Office'
---

# [[OSINT Project/Maps/Palekhsky District, Ivanovo Oblast, Central Federal District, Russia|Palekhsky]], [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] Recruitment Office

2022-03-18  
Molotov  
Recruitment  
https://www.ivanovonews.ru/news/1152616/  
In the [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] region, FSB officers stopped the illegal activities of a local resident who tried to commit a terrorist act. "A 31-year-old man, in order to destabilize the activities of the authorities, set [[fire]] to the military commissariat of the city of [[Shuya]], [[Palekhsky]] and [[Shuisky]] districts of [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] region by throwing a homemade incendiary device into the window of the building, which was localized in a timely manner," the press service of the regional FSB reports. On this fact, a criminal case has been initiated under Part 1 of Art. 205 of the Criminal Code of the Russian Federation - "Terrorist Act". Earlier, against the same defendant, the Investigative Committee initiated a criminal case under Part 3 of Article 30, Part 2 of Art. 167 of the Criminal Code of the Russian Federation (Deliberate destruction or damage to property). The court chose him a preventive measure in the form of [[arrested|detention]]. Maximum sanction for committing a crime under Part 1 of Art. 205 of the Criminal Code of the Russian Federation, is 15 years in [[prison]].  
[[OSINT Project/Maps/Palekhsky District, Ivanovo Oblast, Central Federal District, Russia|Palekhsky]], [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]]

~+~  
136
