---
aliases: 95th Brigade Vehicles, 95th brigade, 95th brigade cars, 95th brigade trucks
location: geo:59.7805181,30.1398847
locations: Gorelovo, St Petersburg
tag: Fire, Military
date: 2022-04-10
title: '95th Brigade [[automobiles|Vehicles]]'
linter-yaml-title-alias: '95th Brigade [[automobiles|Vehicles]]'
---

[Gorelovo, St Petersburg](geo:59.7805181,30.1398847)  
date approximate

# 95th Brigade [[automobiles|Vehicles]]

[[fire]]  
Military  
https://darknights.noblogs.org/post/2022/04/12/russia-military-cars-on-fire/  
in recent days, cases of deliberate [[fire|arson]] of [[automobiles|cars]] of [[Russia|Russian]] [[Russian Military Industry|military]] and officials are becoming more frequent. In particular, [[automobiles|cars]] of servicemen of the 95th Brigade (Gorelovo, St Petersburg Region) and the [[82nd Radio Technical Brigade Vehicles|82nd Radio]] Technical Brigade (Vyazma, Smolensk Region) have recently been set on [[fire]]. [[Russia|Russian]] servicemen speak of threats of physical reprisals if they agree to participate in the war against Ukraine.  
Gorelovo, St Petersburg Region
