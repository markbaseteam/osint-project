---
locations:
aliases: 
location:
title: Belarus Railway Cut Off from Ukraine
tag: 
date:

---

# Belarus Railway Cut Off from Ukraine

2022-03-19  
Mechanical  
Railway,Infrastructure  
https://libcom.org/article/russia-and-belarus-successes-rail-war-and-not-only-part-3  
March 19 Alexander Kamyshin, chairman of the board of Ukrainian Railways (Ukrzaliznytsia) JSC, there is no railway communication between Belarus and Ukraine now. According to him, “gratitude for this should be said to honest Belarusian railway workers”. The official refused to specify from what date it is not available, but confirmed that the railway tracks were in a state of disrepair: I believe honest Belarusian railway workers will be able to stop the work of the railways of Belarus in the direction of [[transportation]] of military trains towards Ukraine.  
Belarus Railway

Ukrainian presidential adviser Alexey Arestovich: such supplies can come from Belarus itself. It was not for nothing that the electric trains were repainted there…So, Belarusian brothers, if you are against this war, then do what you did best - a guerrilla rail war. And in Belarus itself, I emphasize, only on the routes of the transfer of Russian troops Disruption of the enemy's supply by rail (and this type of supply is the most effective) can radically change the situation in our favor  
~+~  
111
