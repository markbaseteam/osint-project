---
aliases: 
locations:
tag: 
date:
title: Russia is forcing Ukrainians from occupied Crimea and Donbas to fight in its invasion of Ukraine
---

Russia is forcing Ukrainians from occupied Crimea and Donbas to fight in its invasion of Ukraine

https://khpg.org/en/1608810165
