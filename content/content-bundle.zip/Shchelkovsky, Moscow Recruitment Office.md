---
locations:
aliases: ['Shchelkovsky, [[Moscow]] Recruitment Office']
location:
title: 'Shchelkovsky, [[Moscow]] Recruitment Office'
tag: molotov, recruitment
date: 2022-05-18 
linter-yaml-title-alias: 'Shchelkovsky, [[Moscow]] Recruitment Office'
---

# Shchelkovsky, [[Moscow]] Recruitment Office

2022-05-18  
Molotov  
Recruitment  
https://darknights.noblogs.org/post/tag/khanty-nansi/  
Shchelkovsky ([[Moscow]]) On May 18, two molotovs flew inside the military commissariat in Shchelkovsky, near [[Moscow]]. Both offices were damaged by the flames, including the archives of the military registration and enlistment office == Two offices are seriously damaged, including the archive with the data of conscripts. On this video we see smashing of its windows, after which the partisan pours incendiary mixture inside. Then comes the [[fire|arson]]. In all this cases, the punishers did not seize anyone. == Two offices of the building, including the archive, were damaged by the [[fire|arson]] attack. The arsonists have not been found yet. https://enoughisenough14.org/2022/06/26/shortly-after-the-longest-night-of-the-year-two-recruiting-offices-burned-at-once-chronicle-of-arson-attacks-until-june-25-2022-russia/  
Shchelkovsky, [[Moscow]]

AKA Shchelkovo or Shchyolkovo video https://t.me/live_corr/1831 See also https://meduza.io/news/2022/05/18/v-rossii-vnov-popytalis-podzhech-voenkomat-kokteylyami-molotova-zabrosali-zdanie-schelkovskogo-voennogo-komissariata-v-podmoskovie

~+~  
187
