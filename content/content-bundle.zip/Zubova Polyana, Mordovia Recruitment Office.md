---
locations:
aliases: ['Zubova Polyana, [[Maps/Republic of Mordovia, Volga Federal District, Russia|Mordovia]] Recruitment Office']
location:
title: 'Zubova Polyana, [[Maps/Republic of Mordovia, Volga Federal District, Russia|Mordovia]] Recruitment Office'
tag: molotov, recruitment
date: 2022-04-14  
linter-yaml-title-alias: 'Zubova Polyana, [[Maps/Republic of Mordovia, Volga Federal District, Russia|Mordovia]] Recruitment Office'
---

# Zubova Polyana, [[OSINT Project/Maps/Republic of Mordovia, Volga Federal District, Russia|Mordovia]] Recruitment Office

2022-04-14  
Molotov  
Recruitment  
https://sofrep.com/news/we-dont-wanna-go-russian-military-recruitment-offices-attacked-with-molotov-cocktails/  
The next attack happened in the [[OSINT Project/Maps/Republic of Mordovia, Volga Federal District, Russia|Mordovia]] region, where a group of unknown people threw Molotov cocktails at a military recruitment office in Zubova Polyana last April 14th or 18th. The group apparently targeted rooms where data of conscripts were stored. They then set [[fire]] to the computers that held the data. Before a watchman could report the incident, two floors had already been [[fire|burning]]. It was later revealed that four Molotov cocktails were used to set [[fire]] to the office. = “Military Commissariat of Zubovo-Polyansky and Torbeevsky districts”–it is located in Zubova Polyana village, 2,5 hours drive from Saransk. Unclear if Torbeevsky is a separate incident. https://a2day.org/v-mordovii-voenkomat-zabrosali-koktejlyami-molotova/  
Zubova Polyana [[OSINT Project/Maps/Republic of Mordovia, Volga Federal District, Russia|Mordovia]] region

At least 3 different dates reported. Used earliest date. April 14th, 17th or 18th. Sometimes referred to Zubovo-Polyansky and addition of Torbeevsky District https://darknights.noblogs.org/post/2022/04/20/russia-molotov-cocktails-were-thrown-at-the-military-registration-and-enlistment-office-in-mordovia/ April 18, 2022, in the village of Zubova Polyana in [[OSINT Project/Maps/Republic of Mordovia, Volga Federal District, Russia|Mordovia]], 40 square meters of the premises where the data of conscripts were stored were damaged by [[fire]]. A very successful attack–several computers were destroyed and one of the spaces in the office [[fire|burned]] out completely. Four Molotov cocktails were found at the scene. However, the attackers left no traces. Moreover, there were no video surveillance cameras or alarm systems in the recruitment office. Criminal proceedings were initiated for “intentional destruction of or damage to property”. https://enoughisenough14.org/2022/06/26/shortly-after-the-longest-night-of-the-year-two-recruiting-offices-burned-at-once-chronicle-of-arson-attacks-until-june-25-2022-russia/ On the night of April 18, unknown threw with Molotov cocktails, the recruiting office in the village of Zubova Polyana in [[OSINT Project/Maps/Republic of Mordovia, Volga Federal District, Russia|Mordovia]]. Details of what happened election channel “Caution, news”. As the authors of the channel said, the local watchman smells smoke in the morning. He ran outside and saw that the offices on the first and second floors of the building were on [[fire]]. Because of the [[fire]], the premises where the data of conscripts were stored appeared, and several computers [[fire|burned]] down. Later, the village administration confirmed edition 7×7 information that a [[fire]] broke out in the military registration and enlistment office. https://europe-cities.com/2022/05/04/in-russia-after-the-invasion-of-ukraine-they-began-to-set-fire-to-military-registration-and-enlistment-offices/  
~+~  
116
