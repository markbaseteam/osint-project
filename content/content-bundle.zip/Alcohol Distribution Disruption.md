---
locations:
aliases: Unified State Automated Alcohol Accounting Information System, EGAIS, alcohol, drunk, liquor, liqueur, drink, drinking, drinks, vodka, alcoholic, drunken
location: Cyber
title: Alcohol Distribution Disruption
tag: Mechanical 
date: 2022-05-02
---

# Alcohol Distribution Disruption

2022-05-02  
Mechanical  
Other  
https://www.hackread.com/ddos-attacks-hacktivist-disrupt-russia-alcohol-supply/  
[[Russia]]’s central alcohol distribution platform called Unified State Automated Alcohol Accounting Information System or EGAIS, taken down with DDoS attacks. EGAIS is an important portal since, as per the law, all alcohol producers and distributors must register their shipments at EGAIS. Therefore, an attack on this platform caused extensive service blockage across [[Russia]]. When checked on May 4th, two EGAIS sites gave the error “the server stopped responding,” and the third didn’t work. The attacks began on May 2nd and the next day system failures became more obvious. Wine trader Fort claimed that service disruption occurred on May 4th. 70% of the invoices failed to be uploaded to EGAIS on May 4th.  
https://www.hackread.com/ddos-attacks-hacktivist-disrupt-russia-alcohol-supply/

Not horribly significant but may have delayed booze to the front a few days.

~+~  
182
