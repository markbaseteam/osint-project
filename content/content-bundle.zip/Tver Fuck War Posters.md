---
locations:
aliases: 
location: Tver
title: Tver Fuck War Posters
tag: protest, political
date: 2022-04-30  
---

# Tver Fuck War Posters

2022-04-30  
Protest  
Hearts & Minds  
https://libcom.org/article/anticipation-general-mobilization-7th-overview-anti-military-sabotage-russia  
all online surveillance cameras were offed in the downtown of Tver - both on the city administration's website, and from private providers. Then turned out it was for putting up "Fuck the war" posters on the streets by unknown [[activism|activists]]. During the day the cameras resumed work.  
Tver

~+~  
157
