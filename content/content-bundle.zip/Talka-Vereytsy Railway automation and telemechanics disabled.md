---
locations:
aliases: 
location: Talka-Vereytsy trail, Belarus
title: Talka-Vereytsy Railway automation and telemechanics disabled
tag: mechanical, railway, infrastructure
date: 2022-02-28  
---

# Talka-Vereytsy Railway automation and telemechanics disabled

2022-02-28  
Mechanical  
Railway,Infrastructure  
https://ru.wikipedia.org/wiki/Рельсовая_война_в_Белоруссии_(2022)# 30_марта  
A device of automation and telemechanics of the SCB was brought out on the Talka-Vereytsy trail  
Talka-Vereytsy rail, Belarus

May be same as Talca-Vereytsa few days off  
~+~  
130
