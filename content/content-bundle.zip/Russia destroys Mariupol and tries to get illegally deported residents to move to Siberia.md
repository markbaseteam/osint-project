---
aliases: 
locations:
tag: 
date:
title: Russia destroys Mariupol and tries to get illegally deported residents to move to Siberia
---

Russia destroys Mariupol and tries to get illegally deported residents to move to Siberia

https://khpg.org/en/1608810402

Russia destroys Mariupol and tries to get illegally deported residents to move to Siberia

 

 https://khpg.org/en/1608810402
