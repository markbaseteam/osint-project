---
locations:
aliases: 
location:
title: Rogvardia - National Guard Building
tag: fire, military
date: 2022-06-04 
---

# Rogvardia - National Guard Building

2022-06-04  
[[fire]]  
Military  
https://globalhappenings.com/top-global-news/196541.html  
In Russia, the building of the Rogvardia was on [[fire]]. It is reported that it was set on [[fire]] by an unknown person in [[OSINT Project/Maps/Komsomolsk-on-Amur, Khabarovsk Krai, Far Eastern Federal District, Russia430.3526436163887|Komsomolsk-on-Amur]]. The Telegram channel “Ukraine 24” writes about this. The man approached the building with a canister. According to some reports, he was able to enter the lobby and spilled fuel there, according to others, he simply put the canister on the porch and set it on [[fire]].  
[[OSINT Project/Maps/Komsomolsk-on-Amur, Khabarovsk Krai, Far Eastern Federal District, Russia430.3526436163887|Komsomolsk-on-Amur]], in the Far East

Later, a 50-year-old local resident was [[arrested|detained]].

~+~  
154
