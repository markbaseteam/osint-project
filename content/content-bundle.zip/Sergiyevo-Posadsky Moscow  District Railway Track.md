---
locations:
aliases: ['Sergiyevo-Posadsky [[Maps/Moscow, Central Federal District, Russia|Moscow]] District Railway Track']
location: Sergiyevo-Posadsky District, Moscow Oblast
title: 'Sergiyevo-Posadsky [[Maps/Moscow, Central Federal District, Russia|Moscow]] District Railway Track'
tag: mechanical, infrastructure, railway 
date: 2022-05-23  
linter-yaml-title-alias: 'Sergiyevo-Posadsky [[Maps/Moscow, Central Federal District, Russia|Moscow]] District Railway Track'
---

# Sergiyevo-Posadsky [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]] District Railway Track

2022-05-23  
Mechanical  
Infrastructure,Railway  
https://a2day.org/ot-boevoj-gruppy-anarho-kommunistov/  
Sergiyevo-Posadsky District, [[Moscow]] Oblast, Russia We, the Militant Anarcho-Communist Organization, have carried out a sabotage [[operations|operation]] on the railroad track at coordinates 56 16’44″N 38 12’40.5″E on a sidetrack leading to a military facility of the 12th Main Directorate of the Russian Ministry of Defense. The rail junction was dismantled and the rail tracks were partially disconnected. It must be emphasized that we are not sure that this disconnection was sufficient to free the train from the tracks. But it was a test sabotage, if you will, where we tested the feasibility with the help of tools. We also wanted the sabotage to be as inconspicuous as possible so that the train would not have time to come to a stop. Moreover, it is not sure that a derailment in such a deserted area will reach the media, and we have no possibility to observe it with our own eyes. Therefore, it was decided to publish the result of the attack “as it was” to share the experience with other guerrillas.  
Sergiyevo-Posadsky District [[Moscow]] Oblast, Russia  
56 16’44″N 38 12’40.5″E, 56.278889, 38.211111  
Date discrepancy - 23 or 26 May, 2022. Used earliest date. Earliest date confirmed. This section of the [[roads|road]] leads to 14258 military unit. It's a secret training and tactical center of the 12th Main Directorate of the Ministry of Defense, which is responsible for Russian nuclear security: Some important aspects of this action are: 1) A track was chosen that leads to a military unit where no civilian trains operate in order to avoid innocent victims. We recommend using wikimapia.org for the search. There, military installations are marked that are not visible on conventional maps. You can also use satellite maps to judge whether a facility is “in [[operations|operation]].” For example, on the base to which the attacked sidetrack leads, you can see a collection of military equipment in open areas. 2) This immediately led to restrictions in the possible actions: On these lines, the wagons are pulled by diesel locomotives, so there are no signal cabinets and no power lines. The main point of attack is therefore the tracks themselves 3) We dismantled the rail connection part and unscrewed the screw nuts holding the rail to the railway sleepers. Normal construction tools, adjustable wrenches with a length of > 0.5 m, proved to be sufficient for this. An adjustable wrench is also required because the rail is fastened with 2 types of screw nuts. We recommend the use of a lubricant to make it easier to unscrew the nuts, as many of them are rusty and hardened. 4) Then the track can be lifted with levers and moved to the side. The more nuts that are used to fasten the rail to the sleepers are unscrewed, the easier it is to move it. The method has proven to be quite feasible and safe, although it could cause serious damage to the armed forces of the Russian Federation. We recommend it to all to use it. Source: tg channel Militant Anarcho-Communist Organization

~+~  
73
