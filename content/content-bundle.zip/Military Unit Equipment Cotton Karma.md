---
locations:
aliases: 
location: Klintsy, Bryansk Region near Chernihiv region
title: Military Unit Equipment Cotton Karma
tag: fire, military  
date: 2022-06-11
---

# Military Unit Equipment Cotton Karma

2022-06-11  
[[fire]]  
Military  
https://globalhappenings.com/top-global-news/202641.html  
COTTON KARMA. A MILITARY UNIT BURNS WITH A BLUE FLAME IN THE BRYANSK REGION. In Russia, a military unit with the equipment of the invaders caught [[fire]]. a large-scale [[fire]] broke out on the territory of a military unit. It is located about 50 kilometers from the border with Ukraine. The local military unit heard one strong explosion and three less loud ones. They say that military equipment that was used in Ukraine was damaged.  
[[OSINT Project/Maps/Klintsy, городской округ Клинцы, Bryansk Oblast, Central Federal District, 243140, Russia|Klintsy]], Bryansk Region

Military equipment used in Ukraine was damaged. The city where the explosions took place, near the border with the Chernihiv region

~+~  
77
