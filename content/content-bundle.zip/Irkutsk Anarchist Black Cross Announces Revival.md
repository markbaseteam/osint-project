---
locations:
aliases: ['Irkutsk [[activism|Anarchist]] Black Cross Announces Revival', 'Anarchist Black Cross, Black Cross, Irkutsk Anarchist Black Cross']
location:
title: 'Irkutsk [[activism|Anarchist]] Black Cross Announces Revival'
tag: event, political
date:
linter-yaml-title-alias: 'Irkutsk [[activism|Anarchist]] Black Cross Announces Revival'
---

# Irkutsk [[activism|Anarchist]] Black Cross Announces Revival

2022-03-23  
Other  
Hearts & Minds  
https://abc38.noblogs.org/анархистский-чёрный-крест/#more-1683  
We believe that the ABC should actively support people organizing against the regime and bring an [[activism|anarchist]] agenda to the defense against the state’s attack on the protesting population. The [[activism|Anarchist]] Black Cross in Irkutsk has its own history. After a period of being quiet, we believe that we should regroup and resume our activities in the face of the coming months and years, which could bring both a liberatory «[[Russia|Russian]] spring» and strengthening of the authoritarian regime. [[Russia]] must be free. In this respect, we join the international [[revolutionaries|revolutionary]] struggle in all the rest of the world—for a free society, dignity, self-determination and autonomy. No one is free until everyone is free. [[revolutionaries|Revolutionary]] greetings from [[Siberian Federal District|Siberia]], [[activism|Anarchist]] Black Cross—Irkutsk  
Irkutsk, [[Siberian Federal District|Siberia]]

NOTE the telegram channel posted last in 2019 and then this post once in March 2022. Collectively the work with community actions so outreach may be in person. Black Cross as a whole is active, mostly helping with prisoners and community support. In English https://enoughisenough14.org/2022/03/23/anarchist-black-cross-irkutsk-resumes-activities-russia/  
~+~  
138
