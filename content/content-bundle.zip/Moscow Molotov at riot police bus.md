---
locations:
aliases: ['[[Maps/Moscow, Central Federal District, Russia|Moscow]] Molotov at riot police [[buses|bus]]']
location:
title: '[[Maps/Moscow, Central Federal District, Russia|Moscow]] Molotov at riot police [[buses|bus]]'
tag: molotov, government 
date: 2022-05-02  
linter-yaml-title-alias: '[[Maps/Moscow, Central Federal District, Russia|Moscow]] Molotov at riot police [[buses|bus]]'
---

# [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]] Molotov at riot police [[buses|bus]]

2022-05-02  
Molotov  
Government  
https://www.newsweek.com/molotov-cocktial-thrown-russian-police-riot-bus-moscow-revolution-square-1702943  
man hurled a Molotov cocktail at a riot police [[automobiles|vehicle]] in central [[Moscow]] . Russian authorities reportedly [[arrested|detained]] a 45-year-old [[Moscow]] man after he threw the Molotov cocktail at a riot police [[buses|bus]] that was near the [[Karl Marx monument]] on [[Revolution Square]]. The [[automobiles|vehicle]] caught [[fire]], and "[[fire|burned]] for a couple of minutes," before the blaze was extinguished and the individual was [[arrested|detained]]. Two Russian security officials apprehended the man on a grassy area near the [[automobiles|vehicle]]. Videos obtained by MediaZona and Baza, a Telegram news channel with links to Russian security services, showed that the front part of a riot police [[automobiles|vehicle]] was charred in the incident. According to state-backed Russian news website Life.ru, the [[arrested|detained]] Muscovite had previously disobeyed police officers and "held rallies."  
[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

~+~  
162
