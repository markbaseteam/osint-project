---
locations:
aliases: 
location: Lunevo-Porkhov Rail, Pskov region 
title: 'Luveno-Porkhov, Pskov Railway Derailment'
tag: mechanical, railway,infrastructure  
date: 2022-06-24  
---

# Luveno-Porkhov, Pskov Railway Derailment

2022-06-24  
Mechanical  
Railway,Infrastructure  
https://libcom.org/article/rail-war-belarusians-face-death-penalty-blocked-trans-sib-anarchists-work-around-moscow  
Lunevo-Porkhov stretch in the Pskov region, where 13 wagons reportedly carrying explosives were derailed on June 24 (the brake did not work at the right time)  
Lunevo-Porkhov Rail, Pskov region
