---
locations:
aliases: 
location:
title: Belgorod Derailed Railway
tag: 
date:
---

# Belgorod Derailed Railway

2022-04-21  
Mechanical  
Railway,Infrastructure  
https://libcom.org/article/rail-war-russia-ukraine-borderland-facts-and-its-checking  
Kreida station in Belgorod (several dozens of kilometers to the Ukrainian border), three wagons with soybeans overturned. You can see it on the title photo. According to the official version, there are no traces of sabotage, the cause was a technical malfunction of the track section - rotten sleepers. At the same time, Russian oppositional channel Stop the Wagons today states that it was the work of Russian partisans.  
Kreida Station, Belgorod

Before it they have published a document in which the Directorate of Russian Railways obliges the heads of structural subdivisions to ensure interaction and informing the involved law enforcement agencies about a change in the degree of threat from illegal interference to the transport complex How does railway resistance work? Unsystematic. Scattered. Without a single command center. All around Russia! A single person can stop a huge [[freight train]] - with the help of wire and rubber gloves. And the less systematic and organized our work is, the more difficult it is to stop our protest.

~+~  
6
