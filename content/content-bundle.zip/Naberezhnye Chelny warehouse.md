---
locations:
aliases: ['[[Maps/Naberezhnye Chelny, Tatarstan, Volga Federal District, Russia|Naberezhnye Chelny]] warehouse']
location:
title: '[[Maps/Naberezhnye Chelny, Tatarstan, Volga Federal District, Russia|Naberezhnye Chelny]] warehouse'
tag: fire, warehouse, rubber, plastic
date: 2022-06-03  
linter-yaml-title-alias: '[[Maps/Naberezhnye Chelny, Tatarstan, Volga Federal District, Russia|Naberezhnye Chelny]] warehouse'
---

# [[OSINT Project/Maps/Naberezhnye Chelny, Tatarstan, Volga Federal District, Russia|Naberezhnye Chelny]] warehouse

2022-06-03  
[[fire]]

https://globalhappenings.com/top-global-news/195845.html  
[[OSINT Project/Maps/Naberezhnye Chelny, Tatarstan, Volga Federal District, Russia|Naberezhnye Chelny]], a warehouse with rubber and plastic [[fire|burned]] epic.  
[[OSINT Project/Maps/Naberezhnye Chelny, Tatarstan, Volga Federal District, Russia|Naberezhnye Chelny]]

~+~  
47
