---
aliases: 
locations:
tag: 
date:
title: Russia Ukraine war Russian climber Katya Lipka summits Everest unfurls Ukrainian flag
---

Russia Ukraine war: Russian climber Katya Lipka summits Everest, unfurls Ukrainian flag  
11 Jun, 2022 04:35 PM

The Russian mountaineer unfurled the Ukrainian flag at the top of Mt Everest. Photo / Instagram/lipka.fm  
A Russian mountain climber has made a stand against the war in Ukraine, by unfurling the Ukrainian flag when she reached the top of Mt Everest.

Ekaterina Lipka this week reached the summit of Everest, where she unveiled the Ukrainian flag she had carried all the way up with her.

The mountaineer's photo has gone viral after former Ukrainian Ambassador to Austria Olexander Scherba shared it on Twitter.

Lipka has been praised for her "courageous" photos as she opposed her president's actions in Ukraine.

"Wow! What a message. What a hero," one person wrote on Twitter.

"Very courageous lady! Congratulations on making it, literally, to the top of the world…you are an inspiration. Thank you as well, for your support of Ukraine," another Twitter user wrote.

"May God bless this wonderful Russian women, for scaling Mount Everest and unfurling the Ukrainian flag in protest at the Russian war in Ukraine. Putin needs stopped by whatever means necessary, to prevent mass extermination of Ukrainian's [sic] or the world will suffer," someone else wrote.

Keep up to date with the day's biggest stories

Sign up to our daily curated newsletter for the day's top stories straight to your inbox.

The climber also posted a photo of herself on the mountain with a sign that said "Free Navalny", in support of Alexei Navalny, anti-corruption activist and one of Vladimir Putin's enemies.

https://www.nzherald.co.nz/world/russia-ukraine-war-russian-climber-katya-lipka-summits-everest-unfurls-ukrainian-flag/5WIJGOO323A7X4VY2EBH33BF4E/
