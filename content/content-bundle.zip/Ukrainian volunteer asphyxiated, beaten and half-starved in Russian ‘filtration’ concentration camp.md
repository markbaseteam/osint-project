
18.08.2022


Kharkiv Human Rights Protection Group


#### Ukrainian volunteer asphyxiated, beaten and half-starved in Russian ‘filtration’ concentration camp

18.08.2022

Halya Coynash

![](https://khpg.org/files/img/1608813436.jpg)

Ihor Talalai Photo Media Initiative for Human Rights

25-year-old Ihor Talalai spent 88 days in Russian captivity after being seized by Russian-controlled soldiers as he tried to evacuate people from Mariupol.  Ihor is himself from Dnipro, however at the beginning of March he began working as a volunteer, taking humanitarian aid to and evacuating over 400 people from Kharkiv which was (and still is) coming under savage Russian attack.  When the number of people wanting to leave Kharkiv fell, Ihor joined a pool of volunteers helping people leave Mariupol.  The latter was facing relentless bombing and shelling, and Russia was blocking both humanitarian aid and evacuation by buses from the city.  Private vehicles and volunteers like Talalai thus played a vital role, but one that was very dangerous.  In Ihor Talalai’s case, he was taken prisoner even before he reached the civilians he was trying to help.

The Media Initiative for Human Rights (MIHR) [first reported](https://mipl.org.ua/vivoziv-civilnix-z-mariupolya-i-potrapiv-u-zaruchniki-istoriya-volontera-igorya-talalaya/) Talalai’s abduction back in May and [has managed to speak with him](https://mipl.org.ua/igor-talalaj-tri-misyaci-filtraci%d1%97-v-kativnyax-okupovano%d1%97-donechchini/) since his release.  The following is based on that account, as well as [his interview to Suspilne](https://suspilne.media/256142-dusili-bili-prikladom-morili-golodom-volonter-z-dnipra-pro-torturi-aki-pereziv-u-rosijskomu-poloni/).

The volunteers headed in the direction of Mariupol on 18 March, though Talalai says that from the very beginning, nothing went completely to plan.  He had the addresses of the people he was intending to help: an elderly woman with her son; a young couple and a family with children.  Since they would not all fit in the car, the plan was that he bring the first four people to Manhush, around 30 kilometres outside Mariupol, and then return for the family.

He set off early on 19 March, but never reached Mariupol.  There was a checkpoint near the village of Chervone, manned by Russian / pro-Russian fighters from the Russian proxy ‘Donetsk people’s republic’ [DNR].  He was told to get out of the car and open the book, with the fighter then noticing that Ihor was wearing boots and purportedly wanting to check that he was not a soldier, pretending to be a civilian.  The fighter also demanded to know why Ihor had tired and red eyes.  This was hardly surprising since he had turned down the offer of a place to sleep and food from the people in Manhush, feeling uncomfortable since there were others in real need, and had slept in his car before his fateful attempt to get to Mariupol. It was, however, almost certainly the Ukrainian flag and various patriotic images on his phone that made the militants decide to ‘interrogate’ him.  He was taken into a garage and forced to undress.  This is normally to check for ‘suspicious’ tattoos or for marks suggesting that a person has used firearms.  Ihor had spent the night in an uncomfortable position in his car, with this leaving red marks on his shoulders.  The militants decided that this could have been from holding a machine gun, and were also suspicious of the young man as he “was behaving too calmly”.

His captors threatened him with a gun.  One of them told him that he would shoot him in the knee and that he would be left to bleed behind the garages.  He assumed they were just trying to scare him, but could not be certain.  He tried to convince them that he was a civilian volunteer, even giving the number plates of the other cars in the group, but to no avail. 

He was flung into a kind of dark pit, covered by boards, where the fighters were also holding two conscripts and another civilian.  After around five hours, they were taken to Manhush, where he was held, together with 31 other hostages, aged from 18-66, in a cell intended for 5-6 people. The men were held in the cells, the women in the corridors. 

They were then taken to Dokuchaevsk (in ‘DNR’), where they were forced to stand on the street with their hands tied with scotch tape and freezing.  They were held near a high wall, and Ihor wondered for a moment whether they were planning to kill them.  Although he dismissed this as unlikely, it has since become clear that precisely such extrajudicial executions were carried out by the Russian invaders in Kyiv oblast.

The cell he was held in was the same size as in Manhush, but he was held there with 14 other men, so they could at least lie down.  They were given a small piece of bread each and one bowl of soup for everybody, with only one spoon. They did later manage to persuade a woman working at the so-called ‘DNR police station’ to buy them a small amount of food with money some of them had on them.  

The real torture began when they were all taken to the so-called department for fighting organized crime in occupied Donetsk.  They were interrogated and held with almost no food (a small slice of bread a day) and very little water.  There were 25 men in a small cell with no ventilation, and no toilet (only a bottle!).

The worst treatment was meted out to Ukrainian defenders from the Azov Battalion and Right Sector, however all were beaten and tortured.

“_They began suffocating me, and then lifted me up and started beating me around the face.  One of their leaders ran in and told them not to touch the face.  Then they bound my hands, blindfolded me and got out an automatic rifle, and began beating me with it.  First on the back and I fell.  Then on the floor they again began hitting me with the rifle on various parts of the body.”_

The rest of the ‘interrogations’ involved Ihor being summoned, with an ‘investigator’ examining the contents of Ihor’s phone, while the latter sat there in silence.

MIHR suggests that the video clip about the evacuation which Ihor posted just before setting off on 19 March helped to avoid more trouble in the so-called ‘filtration camp’.

His captors turned up at Talalai’s cell one night and forced him to sign some paper claiming that he rejected the services of a lawyer.  He was then sent to the Olenivka former prison colony which is being used as one of the ‘filtration camps’.  He was held there for almost a month, from 23 March to 20 April.

Talalai estimates that there were about three thousand people there.  He says that there are a particularly large number of civilians who are all foisted ‘charges’ carrying ‘sentences’ of from 15 years to the death penalty.

Artur Prikhno from MIHR points out that these ‘filtration camps’ are officially not punishment, but ‘administrative detention’, where people can be held for up to 60 days.  If, during that time, they haven’t fabricated some kind of prosecution, the person is released.

Talalai essentially confirms reports [received earlier](https://khpg.org/en/1608810545) about the appalling conditions at Olenivka, and adds that they were never given anything like enough to eat. “_The feeling of hunger is there all the time, even when you’ve eat.  You stand, hungry, waiting until it’s your turn to eat and then be hungry again.”_

Some of the prisoners had obviously experienced even worse torture.  There was a military man who had been taken prisoner in Mariupol and savagely tortured, with the use of electric currents passed through wires attached to deliberately wetted hands and feet.  For all that, he was one of the people that Ihor says he wanted to speak with as he was able to fill others with his positive attitude to everything. 

It may seem incredible, yet even in this ‘Olenivka concentration camp’ there were people holding pro-Russian views, people who actually supported the so-called ‘Russian world’ ideology and tried to put pressure on others, like Talalai, who had just arrived.   Ihor recounts that he did not know how the propaganda works and tried to minimize it by singing the Ukrainian national anthem under his breath so that he didn’t have to hear the propaganda.  “_And in the morning, I awoke with the words ‘Glory to Ukraine’.  That gave me confidence that the propaganda would not work on me.”_

Ihor’s mother had spent the first months following his disappearance, not even knowing if her son was alive.  She had then received a phone call from somebody on occupied territory whom Ihor had asked to tell her that “all was fine”. Then in April, she saw a Russian video from Olenivka and recognized her son, looking gaunt, but at least alive. 

Ihor Talalai was, eventually, handed an indefinite document saying that he had undergone ‘filtration’ and released.  He spent some time in occupied Volnovakha, then (occupied) Berdyansk, but is now back on free Ukrainian territory.

## Similar articles

[[Russia sends relatives of Ukrainian soldiers and other Mariupol residents to ‘concentration camp’ in occupied Donbas]]


[[Horrific conditions and torture in Russian filtration camp ‘ghetto’ for Mariupol residents]]

[[Russia plans total ‘filtration’ of Mariupol men and forced ‘mobilization’]]

[[Russia destroys Mariupol and tries to get illegally deported residents to move to Siberia]]

[[Russian FSB produce ‘refugee’ propaganda video blaming Ukrainian soldiers for Russias war crimes in Mariupol]]

[[Terror and abductions as Russia tries to break Ukrainian resistance in Kherson and other occupied cities]]

[[Ukrainian journalist Oleh Baturin feared abducted by Russian invaders in Kherson oblast]]

[[Mayor of Melitopol Ivan Fedorov abducted after refusing to collaborate with the Russian invaders]]