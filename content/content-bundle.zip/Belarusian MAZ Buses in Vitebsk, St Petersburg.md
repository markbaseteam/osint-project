---
locations:
aliases: ['Belarusian MAZ [[Buses]] in Vitebsk, St Petersburg']
location:
title: 'Belarusian MAZ [[Buses]] in Vitebsk, St Petersburg'
tag:
date:
linter-yaml-title-alias: 'Belarusian MAZ [[Buses]] in Vitebsk, St Petersburg'
---

# Belarusian MAZ [[buses]] in Vitebsk, St Petersburg

2022-06-10  
[[fire]]  
Infrastructure  
https://charter97.org/en/news/2022/6/23/503601/  
Belarusian made MAZ [[buses|bus]] caught on [[fire]] on Vitebsk Ave in St Petersburg. June 10, MAZ caught [[fire]] on Vitebsk Ave. According to the Ministry of Emergency Situations, the [[buses|bus]] "burnt out parts". There were no casualties. There have been two accidents with Belarusian [[buses]] in a month in the Russian city. Russian transport company Domtransavto, serving several routes in St. Petersburg, will remove MAZ [[buses]] from the routes and send the entire batch for examination. The decision was made after the second [[fire]] in June  
Vitebsk Ave, St Petersburg

27 June 2022 Lukashenko meets with Alexander Beglov to discuss exploding & [[fire|burning]] MAZ [[buses]] in St Petersburg. Russia ordered 1,000 MAZ [[buses]]. Putin approved 15 Belarusian "substitution" projects…https://president.gov.by/en/events/vstrecha-s-gubernatorom-samarskoy-oblasti-dmitriem-azarovym-1656326969?TSPD_101_R0=08eaf62760ab20006371f9c526d3d319651ab964247994a4f1bfd0c756cde197e0d3d7f441c36dd408e75b61f214300084f02b2acbeebc7e5843aa2aa9675eecce27d1b81c6b0e84116e0fed59779d84fef6ae197f348d01a07206c8d22e8c78

~+~  
57
