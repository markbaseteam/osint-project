---
aliases: arrest, arresting, arrests, detain, detains, detaining, jailed, imprisoned, imprison, jail, behind bars, detained, detention
locations:
tag: 
date:
title: arrested
---

> An arrest is the act of apprehending and taking a person into custody (legal protection or control), usually because the person has been suspected of or observed committing a crime. After being taken into custody, the person can be questioned further and/or charged. An arrest is a procedure in a criminal justice system, sometimes it is also done after a court warrant for the arrest.
>
> [[police]] and various other officers have powers of arrest. In some places, a citizen's arrest is permitted; for example in England and Wales, any person can arrest "anyone whom he has reasonable grounds for suspecting to be committing, have committed or be guilty of committing an indictable offence", although certain conditions must be met before taking such action. Similar powers exist in France, Italy, Germany, Austria and Switzerland if a person is caught in an act of crime and not willing or able to produce valid ID.
>
> As a safeguard against the abuse of power, many countries require that an arrest must be made for a thoroughly justified reason, such as the requirement of probable cause in the United States. Furthermore, in most democracies, the time that a person can be detained in custody is relatively short (in most cases 24 hours in the United Kingdom and 24 or 48 hours in the United States and France) before the detained person must be either charged or released.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Arrest)

---
aliases: detained, detaining, detain, imprisonment
locations:
tag:
date:
title: detained
---
> **detained** may refer to Detention (imprisonment)
>
> [Wikipedia](https://en.wikipedia.org/wiki/Detained)

> An **arrest** is the act of apprehending and taking a person into custody (legal protection or control), usually because the person has been suspected of or observed committing a crime. After being taken into custody, the person can be questioned further and/or charged. An arrest is a procedure in a criminal justice system, sometimes it is also done after a court warrant for the arrest.
>
> [[police]] and various other officers have powers of arrest. In some places, a citizen's arrest is permitted; for example in England and Wales, any person can arrest "anyone whom he has reasonable grounds for suspecting to be committing, have committed or be guilty of committing an indictable offence", although certain conditions must be met before taking such action. Similar powers exist in France, Italy, Germany, Austria and Switzerland if a person is caught in an act of crime and not willing or able to produce valid ID.
>
> As a safeguard against the abuse of power, many countries require that an arrest must be made for a thoroughly justified reason, such as the requirement of probable cause in the United States. Furthermore, in most democracies, the time that a person can be detained in custody is relatively short (in most cases 24 hours in the United Kingdom and 24 or 48 hours in the United States and France) before the detained person must be either charged or released.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Arrest)
