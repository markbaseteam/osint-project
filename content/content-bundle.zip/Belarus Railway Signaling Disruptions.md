---
locations:
aliases: 
location:
title: Belarus Railway Signaling Disruptions
tag: 
date:
---

# Belarus Railway Signaling Disruptions

2022-03-28  
Mechanical  
Railway,Infrastructure  
https://libcom.org/article/new-bottom-resistance-russia-and-belarus-genocide-ukraine-part-5  
On March 28, signaling, centralization and blocking devices were disabled on the way between Sovietsky stopping points and Vereitsy station. This information was later confirmed by the Ministry of Emergency Situations. On the same day, one of the locomotive drivers was [[arrested|detained]] right in the railway depot in [[OSINT Project/Maps/Homyel, Homyel Region, Belarus|Gomel]]. Subsequently, the workers union learned that he is [[arrested]] by the KGB state securities and placed in their pre-trial [[prison|detention center]] NOTE: See March 30  
Sovietsky and Vereitsy Railway Stations Belarus

~+~  
139
