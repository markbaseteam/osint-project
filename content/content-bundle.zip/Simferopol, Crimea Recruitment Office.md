---
locations:
aliases: 
location: Selvinsky str. in Simferopol
title: 'Simferopol, Crimea Recruitment Office'
tag: molotov, recruitment
date: 2022-05-28  
---

# Simferopol, Crimea Recruitment Office

2022-05-28  
Molotov  
Recruitment  
https://enoughisenough14.org/2022/06/26/shortly-after-the-longest-night-of-the-year-two-recruiting-offices-burned-at-once-chronicle-of-arson-attacks-until-june-25-2022-russia/  
On May 28, there was an unsuccessful attempt to set [[fire]] to a military recruiting office in Simferopol. On the night of May 28, there was an attack in Crimea. An unidentified one climbed over the fence and entered the territory of the military enlistment office on Selvinsky str. in Simferopol, after which he threw a Molotov cocktail through the basement window. The bottle broke on the window bars and caused no damage to the building. The watchman on duty tried to [[arrested|detain]] the attacker, but he broke free and fled before the police arrived. Bottle fragments are seized. The place is symbolic: this street bears the name of a famous Soviet writer, however in his youth he was a Black Guard fighter in the squad of Maria Nikiforova.  
Simferopol, Crimea

See also https://libcom.org/article/arise-ukrainian-comrades-anti-war-direct-actions-russia-and-its-9th-review

~+~  
150
