---
locations:
aliases: 
location:
title: Belomestnoye Cell Tower
tag:
date:
---

# Belomestnoye Cell Tower

2022-04-17  
[[fire]]  
Infrastructure  
https://libcom.org/article/rail-war-russia-ukraine-borderland-facts-and-its-checking  
Anarcho-Communists Combat Organization - Slobozhanshchyna claimed the [[fire|arson]] attack on a cell tower in Belomestnoye (a village in Belgorod region) on the night of April 18. From their words, electric cables were wrapped in rags, doused with a flammable liquid and set on [[fire]]. == The attack on cell phone towers in border areas not only causes economic damage to Russia as a whole (especially significant due to sanctions and difficulties in purchasing new equipment), but also disrupts communication between police and military forces. Since the war in Georgia in 2008 (when a tank column heading for Gori was stopped only by an UAZ [[automobiles|truck]] with an officer with a cell phone who was able to catch up because military communications did not function), it is no secret that in view of the victorious optimization and plundering of military budgets, these budgets often have to be covered by civilian budgets.  
Belomestnoye, Belgorod

Dates discrepancy = 17-18 April, 2022. Used earliest date This was initially disputed. The claim was made by Slobozhanshchyna but there was no (or little) news coverage. Also covered in [[activism|Anarchist]] Militant Telegram Channel for BOAK Slobozhanshchyna here https://t.me/BO_AK_reborn Video and photos were later provided?? It was not without complications, in particular, with taking pictures and shooting a video. The preparation and execution of the action was analyzed, and decisions were made to improve the effectiveness of actions in the future. Stay tuned, there will be many more interesting things to come:) We would also like to note that the action was carried out during the yellow terror alert regime, which is in effect on the territory of Belgorod Oblast, but it did not stop the guerrillas.

~+~  
4
