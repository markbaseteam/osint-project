---
locations:
aliases: ['[[Maps/Mytishchi, Mytishchi Urban Okrug, Moscow Oblast, Central Federal District, Russia|Mytishchi]] Fuel Depot']
location:
title: '[[Maps/Mytishchi, Mytishchi Urban Okrug, Moscow Oblast, Central Federal District, Russia|Mytishchi]] Fuel Depot'
tag: fire, gas/oil  
date: 2022-05-02  
linter-yaml-title-alias: '[[Maps/Mytishchi, Mytishchi Urban Okrug, Moscow Oblast, Central Federal District, Russia|Mytishchi]] Fuel Depot'
---

# [[OSINT Project/Maps/Mytishchi, Mytishchi Urban Okrug, Moscow Oblast, Central Federal District, Russia|Mytishchi]] Fuel Depot

2022-05-02  
[[fire]]  
Gas/Oil  
https://twitter.com/visegrad24/status/1520875579175804929  
This area has several military units and is very close to [[Moscow]], including: - [[2366th Separate Cable Communications Battalion]] - [[52nd Radio-Technical Brigade]] - [[Mytishchi Machine-Building Plant]] (MMZ, now a [[Kalashnikov]] subsidiary) that designs and produces armoured chasis for Buk and other systems.  
[[OSINT Project/Maps/Mytishchi, Mytishchi Urban Okrug, Moscow Oblast, Central Federal District, Russia|Mytishchi]]

~+~  
7
