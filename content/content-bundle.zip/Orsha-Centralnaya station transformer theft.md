---
locations:
aliases: ['[[Maps/Orsha, Orsha District, Vitsebsk Region, Belarus|Orsha]]-Centralnaya station transformer theft']
location: Orsha-Centralnaya station, Belarus
title: '[[Maps/Orsha, Orsha District, Vitsebsk Region, Belarus|Orsha]]-Centralnaya station transformer theft'
tag: railway, infrastructure
date: 2022-03-17  
linter-yaml-title-alias: '[[Maps/Orsha, Orsha District, Vitsebsk Region, Belarus|Orsha]]-Centralnaya station transformer theft'
---

# [[OSINT Project/Maps/Orsha, Orsha District, Vitsebsk Region, Belarus|Orsha]]-Centralnaya station transformer theft

2022-03-17  
Other  
Railway,Infrastructure  
https://ru.wikipedia.org/wiki/Рельсовая_война_в_Белоруссии_(2022)#30_марта  
At night, 6 signal transformers of the SOS2-50 type were dismantled and stolen from the relay cabinet by unknown persons at the [[OSINT Project/Maps/Orsha, Orsha District, Vitsebsk Region, Belarus|Orsha]]-Centralnaya station. In this regard, from 21:36 to 03:00, railway communication in this direction was stopped  
[[OSINT Project/Maps/Orsha, Orsha District, Vitsebsk Region, Belarus|Orsha]]-Centralnaya station, Belarus

~+~  
23
