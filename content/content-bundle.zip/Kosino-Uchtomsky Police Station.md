---
locations:
aliases: 
location: Kosino-Uchtomsky police station, Moscow
title: Kosino-Uchtomsky Police Station
tag: fire, government
date: 2022-04-25  
---

# Kosino-Uchtomsky Police Station

2022-04-25  
[[fire]]  
Government  
https://enoughisenough14.org/2022/06/26/shortly-after-the-longest-night-of-the-year-two-recruiting-offices-burned-at-once-chronicle-of-arson-attacks-until-june-25-2022-russia/  
On April 25, an unknown person in [[Moscow]] set [[fire]] to a checkpoint of the Kosino-Uchtomsky police station. He threw two Molotov cocktails; however, the [[fire]] was extinguished with own resources and nobody was injured. A guy, dressed in beige pants and a blue hooded jacket, threw two Molotov cocktails at the police building. The bottles bounced off and hit the asphalt. A small [[fire]] was quickly extinguished, and next to the department, operatives found an inscription against [[Special Military Operation|military operations]] in Ukraine. The attacker is now being searched - a criminal case has already begun for “[[hooliganism]]”.  
Kosino-Uchtomsky, [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

Also known as Kosino-Ukhtomsky

~+~  
163
