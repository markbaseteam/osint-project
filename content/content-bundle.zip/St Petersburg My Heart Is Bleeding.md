---
locations:
aliases: 
location: St. Petersburg 
title: St Petersburg My Heart Is Bleeding
tag: protest, political
date: 2022-02-01  
---

# St Petersburg My Heart Is Bleeding

2022-02-01  
Protest  
Hearts & Minds  
https://enoughisenough14.org/2022/03/27/st-petersburg-my-heart-is-bleeding-russia/  
In St. Petersburg there was an action against the war in Ukraine today. A woman in a white dress doused herself with red paint and chanted “My heart is bleeding.” The text on her banner reads: “My heart is bleeding. I think it’s useless to appeal to reason, so I appeal to your hearts. Every day in Ukraine women, children, old men and old women die from bombings, hunger, the impossibility to get out of the debris or to get medicine. Their graves with homemade crosses can be found in public spaces. Thousands of injured and mutilated, millions of lives destroyed. If you invent excuses for this, it means that your heart is rotten. Find the strength to be merciful and compassionate. Don’t support the bloodshed.”  
St Petersburg

~+~  
27
