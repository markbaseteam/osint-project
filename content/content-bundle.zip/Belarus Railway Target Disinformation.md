---
locations:
aliases: 
location:
title: Belarus Railway Target Disinformation
tag:
date:
---

# Belarus Railway Target Disinformation

2022-03-24  
Other  
Railway,Infrastructure  
https://t.me/belzhd_live/1418  
Telegram channel of the community of railway workers of Belarus reports that on March 24, the State Security Committee of the Republic of Belarus had information about the upcoming sabotage at the stop of the Grove (Minsk-Sortirovochny-Pomyslishche section). As a result, forces were sent there to protect the area. But at this time, saboteurs were preparing for a sabotage [[operations|operation]] between the stops of Berezina and Nemanitsa on the Novosady-Borisov stage, which was eventually carried out  
Novosady-Borisov station, Belarus

~+~  
107
