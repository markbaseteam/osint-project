---
aliases: special military operations, special operation, special operations, military operation, military operations
locations: Ukraine
tag: 
date:
location: [49.4871968,31.2718321]
title: Special Military Operation
---
