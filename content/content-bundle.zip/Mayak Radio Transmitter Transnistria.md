---
locations:
aliases: ['[[Maps/Mayak, Grigoriopol District, Administrative-Territorial Units from the Left Bank of the Dniester, Transnistria, 4006, Moldova|Mayak]] Radio Transmitter Transnistria']
location: Mayak, Transnistria
title: '[[Maps/Mayak, Grigoriopol District, Administrative-Territorial Units from the Left Bank of the Dniester, Transnistria, 4006, Moldova|Mayak]] Radio Transmitter Transnistria'
tag: explosion, infrastructure, radio, transmitter, occupied
date: 2022-04-25
linter-yaml-title-alias: '[[Maps/Mayak, Grigoriopol District, Administrative-Territorial Units from the Left Bank of the Dniester, Transnistria, 4006, Moldova|Mayak]] Radio Transmitter Transnistria'
---

# [[OSINT Project/Maps/Mayak, Grigoriopol District, Administrative-Territorial Units from the Left Bank of the Dniester, Transnistria, 4006, Moldova|Mayak]] Radio Transmitter Transnistria

2022-04-25  
Explosion  
Infrastructure  
https://liveuamap.com/en/2022/25-april-explosions-reported-in-tiraspol-transnistria-near  
2 radio transmitters near [[OSINT Project/Maps/Mayak, Grigoriopol District, Administrative-Territorial Units from the Left Bank of the Dniester, Transnistria, 4006, Moldova|Mayak]]  
[[OSINT Project/Maps/Mayak, Grigoriopol District, Administrative-Territorial Units from the Left Bank of the Dniester, Transnistria, 4006, Moldova|Mayak]] Transnistria

It's important to be careful with Transnistria. High likelihood of false flags

~+~  
172
