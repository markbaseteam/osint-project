---
locations:
aliases: ['[[Maps/Novosibirsk, Novosibirsk Oblast, Siberian Federal District, 630000, Russia|Novosibirsk]] Police Station']
location: Novosibirsk
title: '[[Maps/Novosibirsk, Novosibirsk Oblast, Siberian Federal District, 630000, Russia|Novosibirsk]] Police Station'
tag: fire, government, police station
date: 2022-04-25  
linter-yaml-title-alias: '[[Maps/Novosibirsk, Novosibirsk Oblast, Siberian Federal District, 630000, Russia|Novosibirsk]] Police Station'
---

# [[OSINT Project/Maps/Novosibirsk, Novosibirsk Oblast, Siberian Federal District, 630000, Russia|Novosibirsk]] Police Station

2022-04-25  
[[fire]]  
Government  
https://news.storyua.com/news/14107.html  
In addition, for unknown reasons, [[fire]] broke out in one of the houses in St. Petersburg, the [[air base]] in Ussuriysk, as well as in police stations in [[Moscow]], Irkutsk and [[OSINT Project/Maps/Novosibirsk, Novosibirsk Oblast, Siberian Federal District, 630000, Russia|Novosibirsk]]  
[[OSINT Project/Maps/Novosibirsk, Novosibirsk Oblast, Siberian Federal District, 630000, Russia|Novosibirsk]]

~+~  
169
