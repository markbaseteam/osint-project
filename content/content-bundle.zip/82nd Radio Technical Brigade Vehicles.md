---
aliases: ['82nd Radio Technical Brigade [[automobiles|Vehicles]]', '82nd brigade, 82nd radio, 82nd technical,']
location: 55.1975149,34.3176239
title: '82nd Radio Technical Brigade [[automobiles|Vehicles]]'
tag: Fire, Military
date: 2022-04-10
locations: Vyazma, Smolensk geo:55.1835215,34.33816673607038
linter-yaml-title-alias: '82nd Radio Technical Brigade [[automobiles|Vehicles]]'
---

[Vyazma, Smolensk](geo:55.1835215,34.33816673607038)  
Date Approximate

# 82nd Radio Technical Brigade [[automobiles|Vehicles]]

[[fire]]  
[[Russian Military Industry|Military]]  
https://darknights.noblogs.org/post/2022/04/12/russia-military-cars-on-[[fire]]/  
in recent days, cases of deliberate [[fire|arson]] of [[automobiles|cars]] of [[Russia|Russian]] [[Russian Military Industry|military]] and officials are becoming more frequent. In particular, [[automobiles|cars]] of servicemen of the [[95th Brigade Vehicles|95th Brigade]] (Gorelovo, St Petersburg Region) and the 82nd Radio Technical Brigade (Vyazma, Smolensk Region) have recently been set on [[fire]]. [[Russia|Russian]] servicemen speak of threats of physical reprisals if they agree to participate in the war against Ukraine.  
Vyazma, Smolensk Region

~+~  
12
