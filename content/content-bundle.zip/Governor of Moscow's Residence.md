---
locations:
aliases: ['Governor of [[Maps/Moscow, Central Federal District, Russia|Moscow]]''s Residence']
location:
title: 'Governor of [[Maps/Moscow, Central Federal District, Russia|Moscow]]''s Residence'
tag: fire, elite, political
date:
linter-yaml-title-alias: 'Governor of [[Maps/Moscow, Central Federal District, Russia|Moscow]]''s Residence'
---

# Governor of [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]'s Residence

2022-04-23  
[[fire]]  
Elite,Political  
https://www.ruscrime.com/politics/in-barvikha-the-house-of-the-governor-of-the-moscow-region-andrey-vorobyov-is-on-fire/  
In the village of Barvikha on Klenovaya Street, a house caught [[fire]], which, according to media reports, belongs to the Governor of the [[Moscow]] Region Andrei Vorobyov. The [[fire]] has engulfed more than 100 square meters. m with a house area of ​​2 thousand square meters. No one was reported inside and no one was hurt.  
Klenovaya Street, Barvikha, [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

~+~  
115
