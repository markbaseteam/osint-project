---
locations:
aliases: 
location: Svetlogorsk, Belarus
title: Svetlogorsk railway signaling cabinets
tag: fire, railway, infrastructure
date: 2022-02-28  
---

# Svetlogorsk railway signaling cabinets

2022-02-28  
[[fire]]  
Railway,Infrastructure  
https://ru.wikipedia.org/wiki/Рельсовая_война_в_Белоруссии_(2022)#30_марта  
On March 4, three local residents were [[arrested|detained]] in Svetlogorsk. According to the press service of the Ministry of Internal Affairs, a 29-year-old resident of Svetlogorsk together with two acquaintances came to a railway stretch outside the city on the evening of February 28, two of them doused the relay cabinet of the signaling unit with combustible mixture and set it on [[fire]] - the equipment [[fire|burned]] out. They opened a criminal case for committing an act of terrorism. Since March 2, searches have been carried out in Svetlogorsk in connection with [[fire|burned]] equipment.  
Svetlogorsk, Belarus

~+~  
132
