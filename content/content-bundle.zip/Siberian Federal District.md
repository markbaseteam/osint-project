---
aliases: Siberian, Siberian District, Siberia
locations: "siberian, siberia, Сибирь, Sibir'"
tag: 
date:
location: [65.2729258,95.48990318530036]
title: Siberian Federal District
---

> **siberia** (; Russian: Сибирь, tr. Sibir', IPA: [sʲɪˈbʲirʲ] (listen)) is an extensive geographical region, constituting all of North Asia, from the Ural Mountains in the west to the Pacific Ocean in the east. It has been a part of Russia since the latter half of the 16th century, after the Russians conquered lands east of the Ural Mountains. Siberia is vast and sparsely populated, covering an area of over 13.1 million square kilometres (5,100,000 sq mi), but home to merely one-fifth of Russia's population. [[OSINT Project/Maps/Novosibirsk, Novosibirsk Oblast, Siberian Federal District, 630000, Russia|Novosibirsk]] and [[OSINT Project/Maps/Omsk, Omsk Oblast, Siberian Federal District, 644000, Russia|Omsk]] are the largest cities in the region.
>
> Because Siberia is a geographic and historic region and not a political entity, there is no single precise definition of its territorial borders. Traditionally, Siberia extends eastwards from the Ural Mountains to the Pacific Ocean, and includes most of the drainage basin of the Arctic Ocean. The river Yenisey divides Siberia into two parts, Western and Eastern. Siberia stretches southwards from the Arctic Ocean to the hills of north-central Kazakhstan and to the northern parts of Mongolia and China. The central part of Siberia (West and East Siberian economic regions) was considered the core part of the region in the Soviet Union. Beyond the core, Siberia's western part includes some territories of the Ural region, the far eastern part has been historically called the Russian Far East.Siberia is known worldwide primarily for its long, harsh winters, with a January average of −25 °C (−13 °F). It is geographically situated in Asia; however, due to it being colonized and incorporated into Russia, it is culturally and politically a part of Europe. European cultural influences, specifically Russian, predominate throughout the region, due to it having had Russian emigration from Europe since the 16th century, forming the Siberian Russian sub-ethnic group. Over 85% of the region's population is of European descent.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Siberia)
