---
locations:
aliases: 
location:
title: Belarusian Railways internal network attack
tag: 
date:
---

# Belarusian Railways internal network attack

2022-02-27  
Mechanical  
Railway,Infrastructure  
https://ru.wikipedia.org/wiki/Рельсовая_война_в_Белоруссии_(2022)# 30_марта  
On the eve of the referendum, the community of Cyber Guerrillas of Belarus said that the internal network of Belarusian Railways was attacked, all services do not work (a similar cyber attack was in January, then it took several weeks to troubleshoot).  
Belarus

~+~  
15
