---
aliases: Могилёв, Mogilyov, Molev, Mogilev, Магілёўская, Mahiloŭskaja, Могилёвская, Mogilyovskaya, Mogilyovskaya, Mahilyow, Mahilioŭ
locations:
tag: 
date:
location: [53.9090245,30.3429838]
title: 'Mahilyow, Mahilyow Region, Belarus'
---
> Mogilev ([[../Russia|Russian]]: Могилёв, romanized: Mogilyov, pronounced [məɡʲɪˈlʲɵf]), Mahilow (Belarusian: Магілёў, romanized: Mahilioŭ, pronounced [maɣʲiˈlʲou̯]) or Molev (Yiddish: מאָלעוו, romanized: Molev, pronounced [mɔˈlɛv]) is a city in eastern Belarus, on the Dnieper [[../water|River]], about 76 kilometres (47 miles) from the border with [[../Russia|Russia]]'s Smolensk Oblast and 105 km (65 miles) from the border with [[../Russia|Russia]]'s Bryansk Oblast. As of 2011, its population was 360,918, up from an estimated 106,000 in 1956. It is the administrative centre of the Mogilev Region and the third largest city in Belarus.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Mogilev)
