---
aliases: Central Aerohydrodynamic Institute, Zhukovsky, Central Institute of Aerodynamics, Центра́льный аэрогидродинами́ческий институ́т, Tsentralnyy Aerogidrodinamicheskiy Institut, TsAGI
locations: Moscow
tag: 
date:
location: [55.59270455,38.10673474589218]
title: 'Central Aerohydrodynamic Institute, 1, ul. Zhukovskogo, Центр, Zhukovsky, Moscow Oblast, Central Federal District, 140181, Russia'
---
> The **Central Aerohydrodynamic Institute** (also (Zhukovsky) Central Institute of Aerodynamics, [[../Russia|Russian]]: Центра́льный аэрогидродинами́ческий институ́т, ЦАГИ, romanized: Tsentral'nyy Aerogidrodinamicheskiy Institut, TsAGI) was founded in [[../Moscow|Moscow]] by [[../Russia|Russian]] aviation pioneer Nikolai Yegorovich Zhukovsky on December 1, 1918.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Central%20Aerohydrodynamic%20Institute)
