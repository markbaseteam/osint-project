---
aliases: Nizhnevartovsk, Нижневартовск
locations: Khanty-Mansi Autonomous Okrug
tag: 
date:
location: [60.9339411,76.5814274]
title: 'Nizhnevartovsk, городской округ Нижневартовск, Khanty-Mansiysk Autonomous Okrug – Ugra, Ural Federal District, Russia'
---

> **Nizhnevartovsk** (Russian: Нижневартовск, IPA: [nʲɪʐnʲɪˈvartəfsk]) is a city in [[Khanty-Mansi Autonomous Okrug]], Russia. Since the 1960s, the Western Siberian oil boom led to Nizhnevartovsk's rapid growth from a small settlement to a city due to its location beside the [[Samotlor oil field]] along the right bank of the [[Ob River]], 30 kilometers (19 mi) from the border with [[Tomsk Oblast]], and the presence of the petroleum industry has made it one of the wealthiest cities in Russia.
>
> Nizhnevartovsk is one of the few cities in Russia that exceeds the population of the administrative center of its federal subject: 251,694 (2010 Census); 239,044 (2002 Census); 241,457 (1989 Census).
>
> [Wikipedia](https://en.wikipedia.org/wiki/Nizhnevartovsk)
