---
aliases: Beryozovsky, Берёзовский городской округ
locations:
tag: 
date:
title: 'Beryozovsky, Берёзовский городской округ, Sverdlovsk Oblast, Ural Federal District, 623700, Russia'
---
---
aliases: Beryozovsky, Berezovsky
locations:
tag:
date:
location: [56.90979,60.812012]
title: 'Beryozovsky, Берёзовский городской округ, Sverdlovsk Oblast, Ural Federal District, 623700, Russia'
---

           

 
