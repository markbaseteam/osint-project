---
aliases: Irkutsk Oblast, Irkutsk Region, Irkutsk Division
locations:
tag: 
date:
location: [56.6370122,104.719221]
title: 'Irkutsk Oblast, Siberian Federal District, Russia'
---
---
aliases: Irkutsk Oblast, Ирку́тская о́бласть, Irkutskaya oblast, Эрхүү можо, Erkhüü mojo
locations:
tag:
date:
location: [56.6370122,104.719221]
title: 'Irkutsk Oblast, Siberian Federal District, Russia423.6721563835628'
---
> **Irkutsk Oblast** ([[../Russia|Russian]]: Ирку́тская о́бласть, romanized: Irkutskaya oblast; Buryat: Эрхүү можо, romanized: Erkhüü mojo) is a federal subject of [[../Russia|Russia]] (an oblast), located in southeastern Siberia in the basins of the [[Angara River]], [[Lena River]], and [[Nizhnyaya Tunguska River]]. The administrative center is the city of Irkutsk. It borders the [[Republic of Buryatia]] and the [[Tuva Republic]] in the south and southwest, which separate it from [[Khövsgöl Province]] in [[Mongolia]]; [[Krasnoyarsk Krai]] in the west; the [[Sakha Republic]] in the northeast; and [[Zabaykalsky Krai]] in the east. It had a population of 2,428,750 at the 2010 Census.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Irkutsk%20Oblast)
