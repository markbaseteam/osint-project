---
aliases: Palekhsky, Па́лехский райо́н
locations: Ivanovo Oblasat
tag: 
date:
location: [56.83349985,41.96460712661761]
title: 'Palekhsky District, Ivanovo Oblast, Central Federal District, Russia'
---
> **Palekhsky** District (Russian: Па́лехский райо́н) is an administrative and municipal district (raion), one of the twenty-one in [[Ivanovo Oblast]], Russia. It is located in the center of the oblast. The area of the district is 853 square kilometers (329 sq mi). Its administrative center is the urban locality (a settlement) of Palekh. Population: 10,884 (2010 Census); 12,791 (2002 Census); 14,662 (1989 Census). The population of Palekh accounts for 49.0% of the district's total population.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Palekhsky%20District)
