---
aliases: Mordovia, Republic of Mordovia, Респу́блика Мордо́вия, Мордовия Республиксь, Mordoviya, Мордовия Республикась, Mordoviya Respublikas’
locations: Mordovia
tag: 
date:
location: [54.4419829,44.4661144]
title: 'Republic of Mordovia, Volga Federal District, Russia'
---

> The Republic of **mordovia** ([[../Russia|Russian]]: Респу́блика Мордо́вия; Moksha: Мордовия Республиксь, Mordoviya Respubliks’; Erzya: Мордовия Республикась, Mordoviya Respublikas’) is a federal subject of [[../Russia|Russia]] (a republic) in Eastern Europe. Its capital is the city of Saransk. As of the 2010 Census, the population of the republic was 834,755. Ethnic Russians (53.1%) and Mordvins (39.8%) account for the majority of the population.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Mordovia)
