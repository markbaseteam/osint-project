---
aliases: Lunevo, Porkhovsky 
locations: Lunevo-Porkhov, Pskov region 
tag: 
date:
location: [57.7308903,29.2675079]
title: 'Лунёво, Славковская волость, Porkhovsky District, Pskov Oblast, Northwestern Federal District, Russia'
---
> **Porkhovsky** District (Russian: По́рховский райо́н) is an administrative and municipal district (raion), one of the twenty-four in Pskov Oblast, Russia. It is located in the central and northeastern parts of the oblast and borders with Strugo-Krasnensky District in the north, Soletsky District of Novgorod Oblast in the northeast, Dnovsky District in the east, Dedovichsky District in the southeast, Novorzhevsky District in the south, Ostrovsky District in the southwest, and with Pskovsky District in the west. The area of the district is 3,190 square kilometers (1,230 sq mi). Its administrative center is the town of Porkhov. Population: 21,568 (2010 Census); 28,470 (2002 Census); 35,015 (1989 Census). The population of Porkhov accounts for 49.2% of the district's total population.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Porkhovsky%20District)
