---
aliases: Vyborgsky, Vyborgsky District
locations:
tag: 
date:
location: [60.0387013,30.335475765970834]
title: 'Vyborgsky District, Saint Petersburg, Northwestern Federal District, Russia'
---
