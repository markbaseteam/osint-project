---
aliases: Vladikavkaz, Владикавка́з, Dzæwdžyqæw, Dzaug settlement, Ordzhonikidze, Орджоники́дзе, Dzaudzhikau, Дзауджика́у
locations:
tag: 
date:
location: [43.024593,44.68211]
title: 'Vladikavkaz, Vladikavkaz City District, Republic of North Ossetia-Alania, North Caucasian Federal District, Russia'
---

North Ossetia-Alania

> **Vladikavkaz** (Russian: Владикавка́з, Russian pronunciation: [vlədʲɪkɐˈfkas], lit. "ruler of the Caucasus"; Ossetian: Дзæуджыхъæу, romanized: Dzæwdžyqæw, IPA: [ˈd͡zæwd͡ʒəqæw], lit. "Dzaug's settlement"), formerly known as Ordzhonikidze (Орджоники́дзе) and Dzaudzhikau (Дзауджика́у), is the capital city of the Republic of North Ossetia-Alania, Russia. It is located in the southeast of the republic at the foothills of the [[Caucasus Mountains]], situated on the [[Terek River]]. Population: 311,693 (2010 Census); 315,068 (2002 Census); 300,198 (1989 Census). [[Vladikavkaz]] is one of the most populous cities in the [[North Caucasus]].
>
> The city is an industrial and transportation centre. Manufactured products include processed zinc and lead, machinery, chemicals, clothing and food products.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Vladikavkaz)
