---
aliases: Лухови́цы, Lukhovitsy
locations:
tag: 
date:
location: [54.9655573,39.0277188]
title: 'Lukhovitsy, Lukhovitsky District, Moscow Oblast, Central Federal District, Russia'
---

> **Lukhovitsy** ([[../Russia|Russian]]: Лухови́цы) is a town and the administrative center of Lukhovitsky District in [[../Moscow|Moscow]] Oblast, [[../Russia|Russia]], located on the Oka [[../water|River]] 135 kilometers (84 mi) southeast of [[../Moscow|Moscow]]. Population: 29,850 (2010 Census); 32,403 (2002 Census); 32,501 (1989 Census).
>
> [Wikipedia](https://en.wikipedia.org/wiki/Lukhovitsy)
