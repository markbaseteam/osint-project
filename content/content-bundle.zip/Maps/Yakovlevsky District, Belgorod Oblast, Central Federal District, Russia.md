---
aliases: Yakovlevsky
locations:
tag: 
date:
location: [50.73210225,36.22901543726864]
title: 'Yakovlevsky District, Belgorod Oblast, Central Federal District, Russia'
---
