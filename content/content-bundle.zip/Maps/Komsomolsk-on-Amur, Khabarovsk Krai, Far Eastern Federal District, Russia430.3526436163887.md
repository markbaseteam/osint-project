---
aliases: Komsomolsk-on-Amur, Комсомольск-на-Амуре, Komsomolsk-na-Amure
locations: 
tag: 
date:
location: [50.550877,137.020782]
title: 'Komsomolsk-on-Amur, Khabarovsk Krai, Far Eastern Federal District, Russia430.3526436163887'
---
> **Komsomolsk-on-Amur** ([[../Russia|Russian]]: Комсомольск-на-Амуре, tr. Komsomolsk-na-Amure, IPA: [kəmsɐˈmolʲsk nɐɐˈmurʲə]) is a city in [[Khabarovsk Krai]], [[../Russia|Russia]], located on the west bank of the Amur [[../water|River]] in the [[../Russia|Russian]] Far East. It is located on the [[Baikal-Amur Mainline]], 356 kilometers (221 mi) northeast of [[Khabarovsk]]. As of 2010, it had a population of 263,906 (2010 Census); 281,035 (2002 Census); 315,325 (1989 Census).
>
> [Wikipedia](https://en.wikipedia.org/wiki/Komsomolsk-on-Amur)

---
aliases: Komsomolsk-on-Amur
locations:
tag:
date:
location: [50.550877,137.020782]
title: 'Komsomolsk-on-Amur, Khabarovsk Krai, Far Eastern Federal District, [[../Russia|Russia]]'
---
