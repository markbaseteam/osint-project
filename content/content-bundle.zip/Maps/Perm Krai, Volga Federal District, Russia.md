---
aliases: perm krai, Пе́рмский край, 
locations:
tag: 
date:
location: [58.5951603,56.3159546]
title: 'Perm Krai, Volga Federal District, Russia'
---

**Perm Krai** ([Russian](https://en.wikipedia.org/wiki/Russian_language "Russian language"): Пе́рмский край) is a [federal subject](https://en.wikipedia.org/wiki/Federal_subjects_of_Russia "Federal subjects of Russia") of [Russia](https://en.wikipedia.org/wiki/Russia "Russia") (a [krai](https://en.wikipedia.org/wiki/Krai "Krai")) that came into existence on December 1, 2005 as a result of the 2004 [referendum](https://en.wikipedia.org/wiki/Referendum "Referendum") on the merger of [Perm Oblast](https://en.wikipedia.org/wiki/Perm_Oblast "Perm Oblast") and [Komi-Permyak Autonomous Okrug](https://en.wikipedia.org/wiki/Komi-Permyak_Autonomous_Okrug "Komi-Permyak Autonomous Okrug"). The [city](https://en.wikipedia.org/wiki/Types_of_inhabited_localities_in_Russia "Types of inhabited localities in Russia") of [Perm](https://en.wikipedia.org/wiki/Perm,_Russia "Perm, Russia") is the [administrative center](https://en.wikipedia.org/wiki/Administrative_center "Administrative center"). The population of the krai was 2,635,276 according to the ([2010 Census](https://en.wikipedia.org/wiki/Russian_Census_(2010) "Russian Census (2010)")).[[6]](https://en.wikipedia.org/wiki/Perm_Krai#cite_note-2010Census-6)

Komi-Permyak Okrug retained its autonomous status within Perm Krai during the transitional period of 2006–2008. It also retained a budget separate from that of the krai, keeping all federal transfers. Starting in 2009, Komi-Permyak Okrug's budget became subject to the budgeting law of Perm Krai. The transitional period was implemented in part because Komi-Permyak Okrug relies heavily on federal subsidies, and an abrupt cut would have been detrimental to its economy.
