---
aliases: Krasnodar, Краснода́р, Краснодар, Yekaterinodar
locations: Krasnodar FSB
tag: 
date:
location: [45.0352718,38.9764814]
title: 'Krasnodar, Krasnodar Municipality, Krasnodar Krai, Southern Federal District, 350000, Russia'
---

> **krasnodar** (; Russian: Краснода́р, IPA: [krəsnɐˈdar]; Adyghe: Краснодар), formerly Yekaterinodar (until 1920), is the largest city and the administrative centre of Krasnodar Krai, Russia. The city stands on the Kuban River in southern Russia, with a population of 930,629 residents, and up to 1 million residents in the urban agglomeration. Krasnodar is the sixteenth-largest city in Russia, and the second-largest city in southern Russia, as well as the Southern Federal District.
>
> The city originated in 1793 as a fortress built by the Cossacks, and became a trading center for southern Russia. The city sustained heavy damage in World War II but was rebuilt and renovated after the war. Krasnodar is a major [[../economic hub]] in [[Southern Russia, улица Степана Разина, Ворошиловский район, Volgograd, Volgograd Oblast, Southern Federal District, 400001, Russia]]; In 2012, Forbes named Krasnodar the best city for business in Russia. Krasnodar is home to numerous sights, including the Krasnodar Stadium. Its main airport is Krasnodar International Airport.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Krasnodar)
