---
aliases: Novosibirsk, Новосиби́рск
locations:
tag: 
date:
location: [54.96781445,82.95159894278376]
title: 'Novosibirsk, Novosibirsk Oblast, Siberian Federal District, 630000, Russia'
---
> **Novosibirsk** (, also UK: ; Russian: Новосиби́рск, IPA: [nəvəsʲɪˈbʲirsk] (listen)) is the largest city and administrative centre of Novosibirsk Oblast and [[../Siberian Federal District ]]in Russia. It had a population of 1,612,833 in 2018, making it the most populous city in Siberia and the third-most populous city in Russia. The city is located in southwestern Siberia, on the banks of the Ob River.Novosibirsk was founded in 1893 on the Ob River crossing point of the future Trans-Siberian Railway, where the Novosibirsk Rail Bridge was constructed. Originally named Novonikolayevsk, the city grew rapidly into a major transport, commercial, and industrial hub. The city was ravaged by the Russian Civil War but recovered during the early Soviet period, and gained its present name in 1926. Under the leadership of Joseph Stalin, Novosibirsk became one of the largest industrial centers of Siberia. Following the outbreak of World War II, the city hosted many factories relocated from the Russian core.
>
> Novosibirsk is home to numerous Russian corporations, the neo-Byzantine Alexander Nevsky Cathedral, the Novosibirsk Opera and Ballet Theatre, as well as the world-renowned Novosibirsk Zoo. It is served by Tolmachevo Airport, the busiest airport in Siberia.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Novosibirsk)
