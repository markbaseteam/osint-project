---
aliases: Omsk, Омск
locations:
tag: 
date:
location: [54.991375,73.371529]
title: 'Omsk, Omsk Oblast, Siberian Federal District, 644000, Russia'
---
> **omsk** (; Russian: Омск, IPA: [omsk]) is the administrative center and largest city of Omsk Oblast, Russia. It is situated in southwestern Siberia, and has a population of over 1 million. Omsk is the largest city in Siberia after Novosibirsk, and the ninth-largest city in Russia. It is an essential transport node, serving as a train station for the Trans-Siberian Railway and as a staging post for the Irtysh River.
>
>
>
>  
>
> During the Imperial era, Omsk was the seat of the Governor General of Western Siberia and, later, of the Governor General of the Steppes. For a brief period during the Russian Civil War in 1918–1920, it served as the capital of the anti-Bolshevik Russian State and held the imperial gold reserves.
>
> Omsk serves as the episcopal see of the bishop of Omsk and Tara, as well as the administrative seat of the Imam of Siberia. The mayor is
>
> Sergey Shelest.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Omsk)
