---
aliases: St. Petersburg, St Petersburg, Saint Petersburg, Санкт-Петербург, Sankt-Peterburg
locations:
tag: 
date:
location: [59.938732,30.316229]
title: 'Saint Petersburg, Northwestern Federal District, Russia'
---
> Saint Petersburg (Russian: Санкт-Петербург, tr. Sankt-Peterburg, IPA: [ˈsankt pʲɪtʲɪrˈburk] (listen)), formerly known as Petrograd (1914–1924) and later Leningrad (1924–1991), is the second-largest city in Russia. It is situated on the Neva River, at the head of the Gulf of Finland on the Baltic Sea, with a population of roughly 5.4 million residents. Saint Petersburg is the fourth-most populous city in Europe, the most populous city on the Baltic Sea, as well as the world's northernmost city of more than 1 million residents. As Russia's Imperial capital, and a historically strategic port, it is governed as a federal city.
>
> The city was founded by Tsar Peter the Great on 27 May 1703 on the site of a captured Swedish fortress, and was named after apostle Saint Peter. In Russia, Saint Petersburg is historically and culturally associated with the birth of the Russian Empire and Russia's entry into modern history as a European great power. It served as a capital of the Tsardom of Russia, and the subsequent Russian Empire, from 1713 to 1918 (being replaced by Moscow for a short period of time between 1728 and 1730). After the October Revolution in 1917, the Bolsheviks moved their government to Moscow.As Russia's cultural center, Saint Petersburg received over 15 million tourists in 2018. It is considered an important economic, scientific, and tourism centre of Russia and Europe. In modern times, the city has the nickname of being "the Northern Capital of Russia" and is home to notable federal government bodies such as the Constitutional Court of Russia and the Heraldic Council of the President of the Russian Federation. It is also a seat for the National Library of Russia and a planned location for the Supreme Court of Russia, as well as the home to the headquarters of the Russian Navy, and the Western Military District of the Russian Armed Forces. The Historic Centre of Saint Petersburg and Related Groups of Monuments constitute a UNESCO World Heritage Site. Saint Petersburg is home to the Hermitage, one of the largest art museums in the world, the Lakhta Center, the tallest skyscraper in Europe, and was one of the host cities of the 2018 FIFA World Cup and the UEFA Euro 2020.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Saint%20Petersburg)
