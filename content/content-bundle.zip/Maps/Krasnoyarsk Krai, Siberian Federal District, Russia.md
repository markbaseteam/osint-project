---
aliases: Krasnoyarsk Krai, Красноя́рский край, Krasnoyarskiy kray 
locations:
tag: 
date:
location: [63.3233807,97.0979974]
title: 'Krasnoyarsk Krai, Siberian Federal District, Russia'
---

> **Krasnoyarsk Krai** (Russian: Красноя́рский край, tr. Krasnoyarskiy kray, IPA: [krəsnɐˈjarskʲɪj ˈkraj]) is a federal subject of Russia (a krai), with its administrative center in the city of Krasnoyarsk, the third-largest city in Siberia (after Novosibirsk and Omsk). Comprising half of the Siberian Federal District, Krasnoyarsk Krai is the largest krai in the Russian Federation, the second largest federal subject (after neighboring Sakha) and the third largest subnational governing body by area in the world, after Sakha and the Australian state of Western Australia. The krai covers an area of 2,339,700 square kilometers (903,400 sq mi), which is nearly one quarter the size of the entire country of Canada (the next-largest country in the world after Russia), constituting roughly 13% of the Russian Federation's total area and containing a population of 2,828,187, or just under 2% of its population, per the 2010 Census.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Krasnoyarsk%20Krai)
