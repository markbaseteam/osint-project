---
aliases: Novy Urengoy, Но́вый Уренго́й, New Urengoy
locations: Novy Urengoy oil field
tag: oil, gas, arctic
date:
location: [66.085196,76.6799167]
title: 'Novy Urengoy, городской округ Новый Уренгой, Yamalo-Nenets Autonomous Okrug, Ural Federal District, 629300, Russia'
---
> **Novy Urengoy** (New Urengoy) (Russian: Но́вый Уренго́й) is a city in Yamalo-Nenets Autonomous Okrug, Russia. Population: 104,107 (2010 Census); 94,456 (2002 Census); 93,235 (1989 Census). It is the largest city in the autonomous okrug.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Novy%20Urengoy)
