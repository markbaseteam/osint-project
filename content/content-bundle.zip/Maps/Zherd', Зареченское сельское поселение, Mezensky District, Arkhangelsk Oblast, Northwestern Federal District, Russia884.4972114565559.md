---
aliases: Zherd
locations:
tag: 
date:
location: [65.5716346,44.6953044]
title: 'Zherd'', Зареченское сельское поселение, Mezensky District, Arkhangelsk Oblast, Northwestern Federal District, Russia884.4972114565559'
---
