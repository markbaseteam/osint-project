---
aliases: Svetlogorsk, Svietlahorsk, Светлаго́рск, Svetlogorsk, Šacilki, Шацілкі

locations: Svetlogorsk, Belarus
tag: 
date:
location: [52.6330338,29.7484282]
title: 'Svietlahоrsk, Svietlahorsk District, Homyel Region, Belarus'
---

Svietlahorsk (Belarusian: Светлаго́рск, Belarusian pronunciation: [sʲvʲetɫaˈɣorsk], Svetlogorsk (Russian: Светлого́рск), until 1961 Šacilki, Belarusian: Шацілкі) is a town in the Svietlahorsk District of Gomel Region, Belarus. It is the administrative center of the Svietlahorsk District. It is located by the Berezina River and has 67,054 inhabitants (2019 estimate).

>
> Svietlаhorsk-na-Biarezinie (Svietlаhorsk on Biarezina) is also a railroad station on the Zhlobin—Kalinkavichy railway line.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Svietlahorsk)
