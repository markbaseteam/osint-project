---
aliases: Kursk Oblast
locations: Kursk Oblast, Russia
tag: 
date:
location: [51.6568453,36.4852695]
title: 'Kursk Oblast, Central Federal District, Russia'
---

Nothing comes up in Wikipedia for Kursk Oblast
