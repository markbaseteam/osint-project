---
aliases: Naberezhnye Chelny, На́бережные Челны́, Яр Чаллы
locations: Republic of Tatarstan
tag: 
date:
location: [55.7419774,52.399207]
title: 'Naberezhnye Chelny, Tatarstan, Volga Federal District, Russia'
---
> **Naberezhnye Chelny** (Russian: На́бережные Челны́, IPA: [ˈnabʲɪrʲɪʐnɨjə tɕɪlˈnɨ]; Tatar: Яр Чаллы IPA: [ˈjar ɕɑlːɤ̆]) is the second largest city in the [[Republic of Tatarstan]], Russia. A major industrial center, Naberezhnye Chelny stands on the [[Kama River]] 225 kilometers (140 mi) east of [[Kazan]] near [[Nizhnekamsk Reservoir]].
>
> The population of the city over the years: 513,193 (2010 Census); 509,870 (2002 Census); 500,309 (1989 Census).The city was previously known as Naberezhnye Chelny (until November 18, 1982), [[Brezhnev]] (until 1988).
>
> [Wikipedia](https://en.wikipedia.org/wiki/Naberezhnye%20Chelny)
