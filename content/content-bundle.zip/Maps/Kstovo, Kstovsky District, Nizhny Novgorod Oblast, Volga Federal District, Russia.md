---
aliases: Kstovo, Ксто́во
locations:
tag: 
date:
location: [56.149551,44.198032]
title: 'Kstovo, Kstovsky District, Nizhny Novgorod Oblast, Volga Federal District, Russia'
---

> **kstovo** (Russian: Ксто́во) is a town and the administrative center of Kstovsky District in Nizhny Novgorod Oblast, Russia, located on the right bank of the Volga River, 22 kilometers (14 mi) southeast of Nizhny Novgorod, the administrative center of the oblast. Population: 66,657 (2010 Census); 66,944 (2002 Census); 62,414 (1989 Census).
>
> [Wikipedia](https://en.wikipedia.org/wiki/Kstovo)
