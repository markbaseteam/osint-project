---
aliases: 
locations:
tag: 
date:
location: [46.8467267,35.3827281]
title: 'Melitopol, Мелітопольська міська громада, Melitopol Raion, Zaporizhia Oblast, 72300-72324, Ukraine'
---
