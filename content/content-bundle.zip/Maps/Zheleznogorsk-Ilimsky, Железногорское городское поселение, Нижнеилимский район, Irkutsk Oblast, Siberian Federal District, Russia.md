---
aliases: Zheleznogorsk-Ilimsky, Железногорск-Илимский
locations:
tag: 
date:
location: [56.577915,104.12294]
title: 'Zheleznogorsk-Ilimsky, Железногорское городское поселение, Нижнеилимский район, Irkutsk Oblast, Siberian Federal District, Russia'
---
> **Zheleznogorsk-Ilimsky** (Russian: Железногорск-Илимский, IPA: [ʐɪlʲɪznɐˈgorsk ɪˈlʲimskʲɪj]) is a town and the administrative center of [[Nizhneilimsky District]] of [[Irkutsk Oblast]], Russia, located 478 kilometers (297 mi) north of [[Irkutsk]], the administrative center of the oblast. Population: 26,079 (2010 Census); 29,093 (2002 Census); 32,326 (1989 Census).
>
> [Wikipedia](https://en.wikipedia.org/wiki/Zheleznogorsk-Ilimsky)
