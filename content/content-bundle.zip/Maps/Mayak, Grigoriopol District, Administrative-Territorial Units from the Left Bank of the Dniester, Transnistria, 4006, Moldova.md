---
aliases: Mayak, Grigoriopol, Hryhoriopol, Григориопол, Григорио́поль, Григоріо́поль
locations: Mayak, Transnistria
tag: 
date:
location: [47.23736715,29.38709352509833]
title: 'Mayak, Grigoriopol District, Administrative-Territorial Units from the Left Bank of the Dniester, Transnistria, 4006, Moldova'
---
> **Grigoriopol** (Romanian pronunciation: [ɡriɡoriˈopol], Moldovan Cyrillic: Григориопол, [[../Russia|Russian]]: Григорио́поль, romanized: Grigoriopol, Ukrainian: Григоріо́поль, romanized: Hryhoriopol) is a town in the Administrative-Territorial Units of the Left Bank of the Dniester, Moldova. It is the seat of the Grigoriopol District of Transnistria. The city is located on the left (eastern) bank of the [[../water|river]] Dniester at 47°09′N 29°18′E, in central Transnistria.
>
> Grigoriopol is composed of the city itself, and a small village Crasnoe (Красное). The town itself had a population of 11,473 in 2004.
>
> In 1996 and in 2002, the town was the centre of a dispute regarding the attempts of local Moldavian inhabitants to use the Romanian language (written with Latin script characters) in the local Moldavian school, which is against the policy of the government of Transnistria. The Transnistrian press attacked the local authorities "that allowed the fifth column of Moldova in Transnistria to operate". The head of the Parent-Teacher Association of the Moldavian school, Mihai Speian, was [[../arrested|arrested]] by the Transnistrian authorities on August 28th, 2002. He was released on September 12th, following a protest by the Organization for Security and Co-[[../operations|operation]] in Europe mission in Moldova. The school was moved to the village of Doroţcaia, Dubăsari district, which is in the area controlled by the Republic of Moldova.
>
> In 1989, the population of the city was 11,712. According to the 2004 Census in Transnistria, the city itself had 11,473 inhabitants, including 5,570 Moldavians, 3,275 Russians, 2,248 Ukrainians, 83 Germans, 67 Belarusians, 63 Bulgarians, 46 Armenians, 39 Poles, 26 Gagauzians, 14 Jews, and 42 others and non-declared.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Grigoriopol)
