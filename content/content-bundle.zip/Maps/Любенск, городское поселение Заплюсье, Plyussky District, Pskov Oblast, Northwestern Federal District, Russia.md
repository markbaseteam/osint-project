---
aliases: Lyubensk, Plyussky, Lubensk, Lybensk, Luzhsky
locations:
tag: 
date:
location: [58.40057,29.600592]
title: 'Любенск, городское поселение Заплюсье, Plyussky District, Pskov Oblast, Northwestern Federal District, Russia'
---

> **plyussky** District (Russian: Плю́сский райо́н) is an administrative and municipal district (raion), one of the twenty-four in [[Pskov Oblast]], Russia. It is located in the northeast of the oblast and borders with [[Slantsevsky District ]]of [[Leningrad Oblast]] in the north, [[Luzhsky District]] of [[Leningrad Oblast]] in the northeast, [[Shimsky District]] of [[Novgorod Oblast]] in the east, [[Strugo-Krasnensky District]] in the south, and with [[Gdovsky District]] in the west. The area of the district is 2,767 square kilometers (1,068 sq mi). Its administrative center is the urban locality (a work settlement) of [[Plyussa]]. Population: 9,187 (2010 Census); 11,610 (2002 Census); 13,988 (1989 Census). The population of Plyussa accounts for 37.6% of the district's total population.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Plyussky%20District)
