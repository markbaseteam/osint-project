---
aliases: Kursk
locations:
tag: 
date:
location: [51.739433,36.179604]
title: 'Kursk, Kursk Oblast, Central Federal District, 305000, Russia'
---

> **kursk** (Russian: Курск, IPA: [ˈkursk]) is a city and the administrative center of Kursk Oblast, Russia, located at the confluence of the Kur, Tuskar, and Seym rivers. The area around Kursk was the site of a turning point in the Soviet–German struggle during World War II and the site of the largest tank battles in history. Population: 415,159 (2010 Census); 412,442 (2002 Census); 424,239 (1989 Census).
>
> [Wikipedia](https://en.wikipedia.org/wiki/Kursk)
