---
aliases: Кызыл, Kyzyl, Kyzyl City
locations: Kyzyl, Republic of Tuva
tag: capital
date:
location: [51.719079,94.4300679]
title: 'Kyzyl, Kyzyl City, Tuva Republic, Siberian Federal District, Russia'
---

> **Kyzyl** (; Tuvan and [[../Russia|Russian]]: Кызыл; Tuvan pronunciation: [qɤˈzɤɫ], [[../Russia|Russian]] pronunciation: [kɨˈzɨɫ]) is the capital city of the republic of Tuva, [[../Russia|Russia]]. The name of the city means "red" or "crimson" in Tuvan (and in many other Turkic languages). Its population was 104,105 (2002 Census); 84,641 (1989 Census).
>
> [Wikipedia](https://en.wikipedia.org/wiki/Kyzyl)
