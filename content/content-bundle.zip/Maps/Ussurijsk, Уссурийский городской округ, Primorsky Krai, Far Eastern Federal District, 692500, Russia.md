---
aliases: Ussuriysk, Уссури́йск, Nikolskoye, Nikolsk-Ussuriysky, Voroshilov
locations:
tag: 
date:
location: [43.7972447,131.9520752]
title: 'Ussurijsk, Уссурийский городской округ, Primorsky Krai, Far Eastern Federal District, 692500, Russia'
---
> **Ussuriysk** (Russian: Уссури́йск) is a city in [[Primorsky Krai]], Russia, located in the fertile valley of the [[Razdolnaya River]], 98 kilometers (61 mi) north of [[Vladivostok]], the administrative center of the krai, and about 60 kilometers (37 mi) from both the China–Russia border and the [[Pacific Ocean]]. Population: 158,004 (2010 Census); 157,759 (2002 Census); 158,016 (1989 Census).It was previously known as Nikolskoye (until 1898), Nikolsk-Ussuriysky (until 1935), Voroshilov (until 1957).
>
> [Wikipedia](https://en.wikipedia.org/wiki/Ussuriysk)
