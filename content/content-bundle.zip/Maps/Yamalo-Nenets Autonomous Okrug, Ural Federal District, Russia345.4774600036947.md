---
aliases: Yamaly-Nenyotsiye
locations:
tag: 
date:
location: [67.1471631,74.3415488]
title: 'Yamalo-Nenets Autonomous Okrug, Ural Federal District, Russia345.4774600036947'
---
> The **Yamalo-Nenets** Autonomous Okrug (YaNAO; Russian: Яма́ло-Не́нецкий автоно́мный о́круг (ЯНАО), Yamalo-Nenetsky Avtonomny Okrug (YaNAO); Nenets: Ямалы-Ненёцие автономной ӈокрук, Yamaly-Nenyotsiye avtonomnoy ŋokruk) is a federal subject of Russia (an autonomous okrug of Tyumen Oblast). Its administrative center is the town of Salekhard, and its largest city is Noyabrsk. The 2010 Russian Census recorded its population as 522,904.
>
> The Autonomous Okrug borders Krasnoyarsk Krai to the east, Khanty-Mansi Autonomous Okrug to the south, Nenets Autonomous Okrug and Komi Republic to the west.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Yamalo-Nenets%20Autonomous%20Okrug)
