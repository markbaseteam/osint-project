---
aliases: Khanty-Mansi Autonomous Okrug, Khanty-Mansi, Khanty-Mansiysk, Ха́нты-Манси́йск, Khánty-Mansíysk, Khanty-Mansi, Khanty-Mansiysk
locations:
tag: 
date:
location: [61.0034448,69.0190006]
title: 'Khanty-Mansiysk, Khanty-Mansiysk Urban Okrug, Khanty-Mansiysk Autonomous Okrug – Ugra, Ural Federal District, 628000, Russia'
---
> **Khanty-Mansiysk** ([[../Russia|Russian]]: Ха́нты-Манси́йск, tr. Khánty-Mansíysk, lit. Khanty-Mansi Town; Khanty: Ёмвоҷ, Jomvoćś; Mansi: Абга, Abga) is a city and the administrative center of Khanty-Mansi Autonomous Okrug–Yugra, [[../Russia|Russia]]. It stands on the eastern bank of the Irtysh [[../water|River]], 15 kilometers (9.3 mi) from its confluence with the Ob, in the oil-rich region of Western Siberia. Though an independent city, Khanty-Mansiysk also functions as the administrative center of Khanty-Mansiysky District.
>
> Khanty-Mansiysk is one of few capitals of [[../Russia|Russian]] regions that is not the largest city in the area, surpassed by [[Surgut]], Nizhnevartovsk and [[Nefteyugansk]].
>
> [Wikipedia](https://en.wikipedia.org/wiki/Khanty-Mansiysk)
