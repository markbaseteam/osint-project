---
aliases: Russian State University, RSUH, RGGU, Росси́йский госуда́рственный гуманита́рный университе́т, РГГУ, Rossijskij gosudarstvennyj gumanitarnyj universitet, Moscow Urban University of the People, Moscow State University for History and Archives
locations: Moscow
tag: 
date:
location: [55.77756875,37.59646061377177]
title: 'Russian State University for the Humanities, улица Орджоникидзе, Donskoy District, Moscow, Central Federal District, 117449, Russia'
---
> The **Russian State University for the Humanities** (RSUH, RGGU; Russian: Росси́йский госуда́рственный гуманита́рный университе́т, РГГУ, romanized: Rossijskij gosudarstvennyj gumanitarnyj universitet, RGGU), is a university in Moscow, Russia with over 25,000 students. It was created in 1991 as the result of the merger of the Moscow Urban University of the People (est. 1908) and the Moscow State University for History and Archives (est. 1930). It is one of the leading universities for humanities in the Russian Federation.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Russian%20State%20University%20for%20the%20Humanities)
