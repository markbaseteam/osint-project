---
aliases: Ishim, Иши́м, Есіл, Esil
locations:
tag: 
date:
location: [56.110912,69.473366]
title: 'Ishim, городской округ Ишим, Tyumen Oblast, Ural Federal District, 625756, Russia'
---
> The **ishim** (Russian: Иши́м, romanized: Ishim; Kazakh: Есіл, romanized: Esil) is a river running through Kazakhstan and Russia. It is 2,450 kilometres (1,520 mi) long, and has a drainage basin of 177,000 square kilometres (68,000 sq mi). Its average discharge is 56.3 cubic metres per second (1,990 cu ft/s). It is a left tributary of the Irtysh. The Ishim is partly navigable in its lower reaches. The upper course of the Ishim passes through Nur-Sultan, the capital of Kazakhstan. In Russia, the river travels through a vast marshland for its course, and has countless meanders and oxbow lakes. The river freezes from late November until March.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Ishim%20(river))
