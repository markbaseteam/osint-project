---
aliases: Ivanovo, Russian Manchester, City of Brides, Иваново
locations: Ivanovo
tag: 
date:
location: [57.0088004,40.96306331898382]
title: 'Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia'
---
> **Ivanovo** ([[../Russia|Russian]]: Иваново, IPA: [ɪˈvanəvə]) is a city in [[../Russia|Russia]]. It is the administrative center and largest city of Ivanovo Oblast, located 254 kilometers (158 mi) northeast of [[../Moscow|Moscow]] and approximately 100 kilometers (62 mi) from [[Yaroslavl]], [[Vladimir]] and [[Kostroma]]. Ivanovo has a population of 408,330 as of the 2010 Census, making it the 49th largest city in [[../Russia|Russia]]. Until 1932, it was previously known as Ivanovo-Voznesensk. The youngest city of the [[Golden Ring of Russia]].The city lies on the [[Uvod River]], in the centre of the eponymous oblast. Ivanovo gained city status in 1871, and emerged as a major centre for [[textile production]] and receiving a name of the "[[../Russia|Russian]] Manchester". The city is served by [[Ivanovo Yuzhny Airport]].
>
> [Wikipedia](https://en.wikipedia.org/wiki/Ivanovo)
