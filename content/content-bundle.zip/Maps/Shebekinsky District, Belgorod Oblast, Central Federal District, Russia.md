---
aliases: Shebekinsky, Шебекинский райо́н
locations:
tag: 
date:
location: [50.45714435,37.095966376687244]
title: 'Shebekinsky District, Belgorod Oblast, Central Federal District, Russia'
---
> **Shebekinsky** District (Russian: Шебекинский райо́н) is an administrative district (raion), one of the twenty-one in Belgorod Oblast, Russia. As a municipal division, it is incorporated as Shebekinsky Municipal District. It is located in the south of the oblast. The area of the district is 1,865.9 square kilometers (720.4 sq mi). Its administrative center is the town of Shebekino (which is not administratively a part of the district). Population: 47,889 (2010 Census); 47,345 (2002 Census); 44,668 (1989 Census).
>
> [Wikipedia](https://en.wikipedia.org/wiki/Shebekinsky%20District)
