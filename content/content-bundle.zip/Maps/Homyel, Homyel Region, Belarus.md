---
aliases: Gomel, Homyel, Гомель, Homiel
locations: Belarus
tag: 
date:
location: [52.4238936,31.0131698]
title: 'Homyel, Homyel Region, Belarus'
---
> **gomel** ([[../Russia|Russian]]: Гомель, pronounced [ˈɡomʲɪlʲ]) or Homiel (Belarusian: Гомель, pronounced [ˈɣomʲelʲ]) is the administrative centre of Gomel Region and the second-most populous city of Belarus with 526,872 inhabitants (2015 census).
>
> [Wikipedia](https://en.wikipedia.org/wiki/Gomel)
