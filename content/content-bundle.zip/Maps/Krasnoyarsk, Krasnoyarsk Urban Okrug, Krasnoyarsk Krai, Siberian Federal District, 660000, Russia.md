---
aliases: Krasnoyarsk, Красноя́рск, Red Ravine City
locations:
tag: 
date:
location: [56.0090968,92.8725147]
title: 'Krasnoyarsk, Krasnoyarsk Urban Okrug, Krasnoyarsk Krai, Siberian Federal District, 660000, Russia'
---
> **krasnoyarsk** ( KRA(H)SS-nə-YARSK; Russian: Красноя́рск, IPA: [krəsnɐˈjarsk] (listen)) ( in semantic translation - Red Ravine City) is the largest city and administrative center of [[Krasnoyarsk Krai]], Russia. It is situated along the Yenisey River, and is the third-largest city in Siberia after Novosibirsk and Omsk, with a population of over 1 million. Krasnoyarsk is an important junction of the renowned Trans-Siberian Railway, and is one of the largest producers of aluminium in the country.
>
> The city is known for its natural landscape; author Anton Chekhov judged Krasnoyarsk to be the most beautiful city in Siberia. The Stolby Nature Sanctuary is located 10 km south of the city. Krasnoyarsk is a major educational centre in Siberia, and hosts the Siberian Federal University. In 2019, Krasnoyarsk was the host city of the 2019 Winter Universiade, the third hosted in Russia.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Krasnoyarsk)
