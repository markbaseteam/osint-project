---
aliases: yauza, yauza river, 
locations:
tag: 
date:
location: [55.896662,37.7241025]
title: 'Yauza River, Mytishchi, Mytishchi Urban Okrug, Moscow Oblast, Central Federal District, 105094, Russia'
---

> The **yauza** (Russian: Я́уза) is a river in Moscow and Mytishchi, Russia, a tributary of the Moskva. It originates in the Losiny Ostrov National Park northeast of Moscow, flows through Mytishchi, enters Moscow in the Medvedkovo District and flows through the city in an irregular, meandering, generally north-south direction. The Yauza joins the Moskva River in Tagansky District just west of Tagansky Hill, now marked by the Kotelnicheskaya Embankment tower. Valleys of the Yauza, from the MKAD beltway in the north to the Moscow-Yaroslavl railway west of Sokolniki Park, are protected as natural reserves.The Yauza has been mentioned in Russian chronicles since 1156; the exact origin of the name is unknown. Moscow crossed its former natural eastern boundary (marked by the Yauza) in the beginning of the 16th century. The banks of the Yauza within the Garden Ring were densely urbanized by the middle of the 17th century; upstream valleys housed suburban residences of the House of Romanov, from Mikhail to Catherine II. Settlements along the Yauza (German Quarter, Lefortovo, Preobrazhenskoye) played a significant role in the history of Russia in the 17th and 18th centuries.
>
> Industrialization in the 19th and 20th centuries made the Yauza "the biggest gutter for waste in Moscow". In the 2000s the ecology improved, with the closing or conversion of old factories and cleanup efforts by the city government. In 2007 the Yauza waters were reclassified from "dirty" to "polluted" status, but in 2008 the trend reversed and pollution in the Yauza exceeded its 2006 levels. As of 2008, Yauza water passing the Moscow city boundary is rated as "polluted", and reaches a "very dirty" level at its inlet. Untreated surface runoff in the Central Administrative District remains the main source of pollution.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Yauza%20(river))
