---
aliases: Vladivostok, Владивосто́к
locations:
tag: 
date:
location: [43.1150678,131.8855768]
title: 'Vladivostok, Владивостокский городской округ, Primorsky Krai, Far Eastern Federal District, 690000, Russia'
---
> **Vladivostok** (Russian: Владивосто́к, IPA: [vɫədʲɪvɐˈstok] (listen)) is the largest city and the administrative centre of [[Primorsky Krai]], Russia. The city is located around the [[Golden Horn Bay]] on the Sea of Japan, covering an area of 331.16 square kilometers (127.86 square miles), with a population of 600,871 residents as of 2021. Vladivostok is the second-largest city in the [[Far Eastern Federal District]], as well as the Russian Far East, after [[Khabarovsk]].
>
> The city was founded in 1860 as a Russian military outpost. In 1872, the main Russian naval base on the Pacific Ocean was transferred to the city, and thereafter Vladivostok began to grow. After the outbreak of the Russian Revolution in 1917, Vladivostok was occupied in 1918 by foreign troops, the last of whom from Japan were not withdrawn until 1922; by that time the anti-revolutionary White Army forces in Vladivostok promptly collapsed, and Soviet power was established in the city. After the dissolution of the Soviet Union, Vladivostok became the administrative centre of Primorsky Krai.
>
> Vladivostok is the largest Russian port on the Pacific Ocean, and the chief economic, scientific and cultural center of the Russian Far East, as well as an important tourism centre in Russia. As the terminus of the Trans-Siberian Railway, the city was visited by over three million tourists in 2017. The city is the administrative center of the Far Eastern Federal District, and is the home to the headquarters of the Pacific Fleet of the Russian Navy. For its unique geographical location, and its Russian culture, the city has been called "Europe in the Orient". Many foreign consulates and businesses have offices in Vladivostok. With an annual mean temperature of around 5 °C (41 °F) Vladivostok has a cold climate for its mid-latitude coastal setting. This is due to winds from the vast Eurasian landmass in winter, also cooling the ocean temperatures.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Vladivostok)
