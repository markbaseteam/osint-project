---
aliases: Bogorodsky, Bogorodskoye
locations:
tag: 
date:
location: [55.8777984,38.4339279460588]
title: 'Bogorodsky city district, Moscow Oblast, Central Federal District, Russia'
---
---
aliases: Bogorodsky
locations: Bogorodsky, [[../Moscow|Moscow]]
tag:
date:
location: [55.8777984,38.4339279460588]
title: 'Bogorodsky city district, [[../Moscow|Moscow]] Oblast, Central Federal District, Russia885.0687733997489'
---
