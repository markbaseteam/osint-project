---
aliases:  Novye Yurkovichi, Новые Юрковичи
locations: Klimovsky District, Bryansk Oblast
tag: 
date:
location: [52.1197635,31.8567211]
title: 'Novye Yurkovichi, Новоюрковичское сельское поселение, Klimovsky District, Bryansk Oblast, Central Federal District, 243046, Russia'
---
> Novy Yurkovich (Russian: Новые Юрковичи) is a rural locality (a selo) in Klimovsky District, Bryansk Oblast, Russia. It is the administrative center of [[Yurkovichskoye Rural Settlement]] (Russian: сельское поселение Новоюрковичское).
>
> [Wikipedia](https://en.wikipedia.org/wiki/Novye%20Yurkovichi)
