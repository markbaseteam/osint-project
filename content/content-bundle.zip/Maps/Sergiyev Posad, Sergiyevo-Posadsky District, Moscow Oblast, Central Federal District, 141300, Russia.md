---
aliases: Sergiev Posad, Sergyev Posad, Се́ргиев Поса́д, Sergiyev-Posad, Sergiyev Posad, Sergiyev Posad, Sergiyev, Zagorsk, Zagorsky
locations:
tag: 
date:
location: [56.3153529,38.1358208]
title: 'Sergiyev Posad, Sergiyevo-Posadsky District, Moscow Oblast, Central Federal District, 141300, Russia'
---
> Sergiyev Posad (Russian: Се́ргиев Поса́д, IPA: [ˈsʲɛrgʲɪ(j)ɪf pɐˈsat]) is a city and the administrative center of [[Sergiyevo-Posadsky District]] in Moscow Oblast, Russia. Population: 111,179 (2010 Census); 113,581 (2002 Census); 114,696 (1989 Census).It was previously known as Sergiyev Posad (until 1919), Sergiyev (until 1930), Zagorsk (until 1991).
>
> [Wikipedia](https://en.wikipedia.org/wiki/Sergiyev%20Posad)
