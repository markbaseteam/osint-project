---
aliases: south of russia, south russia, Юг России, Yug Rossii, Southern Federal District
locations:
tag: 
date:
location: [48.6975445,44.5136113]
title: 'Southern Russia, улица Степана Разина, Ворошиловский район, Volgograd, Volgograd Oblast, Southern Federal District, 400001, Russia'
---
---

title: southern Russia
---

> **southern Russia** or the South of Russia (Russian: Юг России, Yug Rossii) is a colloquial term for the southernmost geographic portion of European Russia generally covering the Southern Federal District and the North Caucasian Federal District.The term does not conform to any official areas of the Russian Federation as designated by the Russian Classification on Objects of Administrative Division (OKATO).
>
> [Wikipedia](https://en.wikipedia.org/wiki/Southern%20Russia)
