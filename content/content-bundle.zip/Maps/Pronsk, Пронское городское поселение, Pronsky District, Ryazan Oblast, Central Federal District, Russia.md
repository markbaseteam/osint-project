---
aliases: Pronsk, Пронск
locations: Pronsk, Ryazan
tag: 
date:
location: [54.121353,39.605293]
title: 'Pronsk, Пронское городское поселение, Pronsky District, Ryazan Oblast, Central Federal District, Russia'
---
> **pronsk** (Russian: Пронск) is the name of several inhabited localities in Ryazan Oblast, Russia.
>
>
>
> Urban localities Pronsk, [[Pronsky District]], [[Ryazan Oblast]], a work settlement in Pronsky District Rural localities Pronsk, [[Ukholovsky District]], [[Ryazan Oblast]], a selo in [[Konoplinsky Rural Okrug]] of Ukholovsky District
>
> [Wikipedia](https://en.wikipedia.org/wiki/Pronsk)
