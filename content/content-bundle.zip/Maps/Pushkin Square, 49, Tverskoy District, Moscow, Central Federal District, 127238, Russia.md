---
aliases: Pushkin Square, Pushkinskaya, Пу́шкинская пло́щадь, Strastnaya Square
locations: Pushkin Sq, Moscow
tag: 
date:
location: [55.7652553,37.6053056]
title: 'Pushkin Square, 49, Tverskoy District, Moscow, Central Federal District, 127238, Russia'
---
> Pushkinskaya Square or **Pushkin Square** (Russian: Пу́шкинская пло́щадь) is a pedestrian open space in the Tverskoy District in central Moscow. Historically, it was known as Strastnaya Square before being renamed for Alexander Pushkin in 1937.It is located at the junction of the Boulevard Ring (Tverskoy Boulevard to the southwest and Strastnoy Boulevard to the northeast) and Tverskaya Street, 2 kilometres (1.2 mi) northwest of the Kremlin. It is not only one of the busiest city squares in Moscow, but also one of the busiest in the world.
>
> The former Strastnaya Square name originates from the Passion Monastery (Russian: Страстной монастырь, Strastnoy Monastery), which was demolished in the 1930s.
>
> At the center of the square is a statue of Pushkin, funded by public subscription and unveiled by Ivan Turgenev and Fyodor Dostoyevsky in 1880. In 1950, Joseph Stalin had the statue moved to the other side of the Tverskaya Street, where the Monastery of Christ's Passions had formerly stood. On 5 December 1965, Glasnost Meeting, the first spontaneous public political demonstration in the Soviet Union after the Second World War, took place here.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Pushkinskaya%20Square)

---
aliases: Pushkin Square, Pushkin Sq
locations: Pushkin Square, Moscow
tag:
date:
location: [55.7652553,37.6053056]
title: Pushkin Square, 49, Tverskoy District, Moscow, Central Federal District, 127238, Russia147.09804808109905
---
---
aliases: Pushkin Square, Pushkinskaya Square, Пу́шкинская пло́щадь
locations:
tag:
date:
location: [55.7652553,37.6053056]
title: 'Pushkin Square, 49, Tverskoy District, Moscow, Central Federal District, 127238, Russia411.8544548775107'
---

> Pushkinskaya Square or **Pushkin Square** (Russian: Пу́шкинская пло́щадь) is a pedestrian open space in the Tverskoy District in central Moscow. Historically, it was known as Strastnaya Square before being renamed for Alexander Pushkin in 1937.It is located at the junction of the Boulevard Ring (Tverskoy Boulevard to the southwest and Strastnoy Boulevard to the northeast) and Tverskaya Street, 2 kilometres (1.2 mi) northwest of the Kremlin. It is not only one of the busiest city squares in Moscow, but also one of the busiest in the world.
>
> The former Strastnaya Square name originates from the Passion Monastery (Russian: Страстной монастырь, Strastnoy Monastery), which was demolished in the 1930s.
>
> At the center of the square is a statue of Pushkin, funded by public subscription and unveiled by Ivan Turgenev and Fyodor Dostoyevsky in 1880. In 1950, Joseph Stalin had the statue moved to the other side of the Tverskaya Street, where the Monastery of Christ's Passions had formerly stood. On 5 December 1965, Glasnost Meeting, the first spontaneous public political demonstration in the Soviet Union after the Second World War, took place here.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Pushkinskaya%20Square)
