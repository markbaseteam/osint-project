---
aliases: Omutnaya, Омутная
locations: Skovorodinsky District, Amur Oblast, Verkh-Kamyshensky Selsoviet, Zarinsky District, Altai Krai
tag: 
date:
location: [53.5724782,122.5969712]
title: 'Omutnaya, городское поселение Ерофей Павлович, Skovorodinsky District, Amur Oblast, Far Eastern Federal District, Russia'
---
> **Omutnaya** (Russian: Омутная) is a rural locality (a settlement) in Verkh-Kamyshensky Selsoviet, Zarinsky District, Altai Krai, Russia. The population was 36 as of 2013. There are 3 streets.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Omutnaya)
