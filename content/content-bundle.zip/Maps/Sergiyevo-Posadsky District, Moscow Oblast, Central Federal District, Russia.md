---
aliases: Sergiyevo-Posadsky, Sergiyevo Posadsky, Се́ргиево-Поса́дский райо́н
locations:
tag: 
date:
location: [56.4812597,38.079089580558914]
title: 'Sergiyevo-Posadsky District, Moscow Oblast, Central Federal District, Russia'
---
> **Sergiyevo-Posadsky** District (Russian: Се́ргиево-Поса́дский райо́н) is an administrative and municipal district (raion), one of the thirty-six in Moscow Oblast, Russia. It is located in the north of the oblast. The area of the district is 1,997.14 square kilometers (771.10 sq mi). Its administrative center is the city of [[Sergiyev Posad]]. Population: 225,693 (2010 Census); 230,481 (2002 Census); 123,404 (1989 Census). The population of Sergiyev Posad accounts for 49.3% of the district's total population.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Sergiyevo-Posadsky%20District)
