---
aliases: Tver, Тверь, Kalinin, Кали́нин, Kalínin
locations:
tag: 
date:
location: [56.858675,35.9208284]
title: 'Tver, Tver Oblast, Central Federal District, 170100, Russia'
---
> **tver** (Russian: Тверь, tr. Tver', IPA: [tvʲerʲ]) is a city and the administrative centre of Tver Oblast, Russia. Population: 414,606 (2015 est.); 403,606 (2010 Census); 408,903 (2002 Census); 450,941 (1989 Census). It is 180 kilometres (110 mi) northwest of Moscow.
>
> Tver was formerly the capital of a powerful medieval state and a model provincial town in the Russian Empire, with a population of 60,000 on 14 January 1913. It is situated at the confluence of the Volga and Tvertsa Rivers. The city was known as Kalinin (Russian: Кали́нин, tr. Kalínin) from 1931 to 1990. The city is where three rivers meet, splitting the town into northern and southern parts by the [[Volga River]], and divided again into quarters by the [[Tvertsa River]], which splits the left (northern) bank into east and west halves, and the [[Tmaka River]] which does the same along the southern bank.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Tver)
