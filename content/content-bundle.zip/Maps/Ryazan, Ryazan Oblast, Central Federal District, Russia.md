---
aliases: Ryazan
locations:
tag: 
date:
location: [54.6702523,39.68844236231995]
title: 'Ryazan, Ryazan Oblast, Central Federal District, Russia'
---
