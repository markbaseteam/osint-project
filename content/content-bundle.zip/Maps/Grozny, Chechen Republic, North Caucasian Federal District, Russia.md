---
aliases: Grozny, Грозный, Соьлжа-ГӀала, Sölƶa-Ġala, Groznaya
locations: 
tag: 
date:
location: [43.3197031,45.6934308]
title: 'Grozny, Chechen Republic, North Caucasian Federal District, Russia'
---
> **grozny**, also Groznyy ([[../Russia|Russian]]: Грозный; Chechen: Соьлжа-ГӀала, romanized: Sölƶa-Ġala) is the capital city of [[Chechnya]].
>
> The city lies on the [[Sunzha River]]. According to the 2010 census, it had a population of 271,573—up from 210,720 recorded in the 2002 census, but still only about two-thirds of 399,688 recorded in the 1989 census. It was previously known as Groznaya (until 1870).
>
> [Wikipedia](https://en.wikipedia.org/wiki/Grozny)
