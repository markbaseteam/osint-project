---
aliases: Sarov, Саро́в, Gorkiy-130, Горький-130, Arzamas-16, Арзама́с-16, Kremlyov, Kremlev, Kremljov, Кремлёв
locations:
tag: 
date:
location: [54.934631,43.334606]
title: 'Sarov, Nizhny Novgorod Oblast, Volga Federal District, Russia'
---
> **Sarov** (Russian: Саро́в) is a closed town in Nizhny Novgorod Oblast, Russia. It was known as Gorkiy-130 (Горький-130) and Arzamas-16 (Арзама́с-16), after a (somewhat) nearby town of [[Arzamas]], from 1946 to 1991. Until 1995, it was known as Kremlyov/Kremlev/Kremljov (Кремлёв). The town is closed as it is the Russian center for nuclear research. Population: 92,047 (2010 Census); 87,652 (2002 Census)
>
> [Wikipedia](https://en.wikipedia.org/wiki/Sarov)
