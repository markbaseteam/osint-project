---
aliases: Kamensk-Uralsky, Ка́менск-Ура́льский, Kamensk
locations:
tag: 
date:
location: [56.415451,61.917797]
title: 'Kamensk-Uralsky, городской округ Каменск-Уральский, Sverdlovsk Oblast, Ural Federal District, 623428, Russia'
---
> **Kamensk-Uralsky** ([[../Russia|Russian]]: Ка́менск-Ура́льский) is a city in Sverdlovsk Oblast, [[../Russia|Russia]], located at the confluence of the [[Kamenka River]] and[[ Iset Rivers]] (Ob's basin). Population: 174,689 (2010 Census); 186,153 (2002 Census); 207,780 (1989 Census); 173,000 (1972); 51,000 (1939).
>
> [Wikipedia](https://en.wikipedia.org/wiki/Kamensk-Uralsky)
