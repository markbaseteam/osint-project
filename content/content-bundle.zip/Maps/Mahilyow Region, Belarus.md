---
aliases: Mogilev, Mogilev Region, Магілёўская вобласць, Mahiloŭskaja voblasć, Могилёвская область, Mogilyovskaya Oblast, Mogilyovskaya, Mahilyow, Mogilev Oblast, Mahilyow Voblasts
locations:
tag: 
date:
location: [53.7254147,30.3863145]
title: 'Mahilyow Region, Belarus'
---
> **Mogilev Region** or Mogilev Oblast or Mahilyow Voblasts (Belarusian: Магілёўская вобласць; Mahiloŭskaja voblasć; [[../Russia|Russian]]: Могилёвская область; Mogilyovskaya Oblast), is a region (oblast) of Belarus with its administrative center at Mogilev (Mahilyow).
>
> Both Mogilev and Gomel Regions suffered severely after the Chernobyl nuclear radioactive reactor catastrophe in April 1986.
>
> Important cities within the region include Mogilev, Asipovichy and Babruysk.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Mogilev%20Region)
