---
aliases: "Trans-Siberian Railway, Trans Siberian Railway, TransSiberian Railway, TSR, Transsib, Транссибирская магистраль,  Transsibirskaya magistral', Transsibirskaya"
locations:
tag: 
date:
location: [54.9408008,73.3859678]
title: 'Monument to the 170th anniversary of the Trans-Siberian Railway, улица Леконта, Привокзальный, Ленинский административный округ, Omsk, Omsk Oblast, Siberian Federal District, 644000, Russia'
---

Choices were end point, ticket station or the monument, so monument was selected for the location of the Trans-Siberian Railway on a map

> The Trans–Siberian Railway (TSR or Transsib; Russian: Транссибирская магистраль, tr. Transsibirskaya magistral', IPA: [trəns.sʲɪˈbʲirskəjə məɡʲɪˈstralʲ]) is a network of railways connecting Western Russia to the Russian Far East. It is the longest railway line in the world, with a length of over 9,289 kilometres (5,772 miles), stretching from Moscow, the capital of Russia and the largest city entirely within Europe, to Vladivostok, which is situated along the Sea of Japan.
>
> Russian Empire government ministers personally appointed by the Emperor Alexander III of Russia and by his son, the Tsarevich Nicholas (later Emperor Nicholas II from 1894), supervised the building of the railway between 1891 and 1916. Even before its completion, the line attracted travellers who wrote of their adventures.
>
> The **Trans-Siberian Railway** has directly connected Moscow with Vladivostok since 1916. Expansion of the railway system continues as of 2021, with connecting rails going into Asia, namely Mongolia, China and North Korea. There is talk of connecting to Tokyo via new bridges between the mainland and the islands of Sakhalin and Hokkaido.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Trans%E2%80%93Siberian%20Railway)
