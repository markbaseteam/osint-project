---
aliases: Simferopol
locations: Simferopol, Crimea
tag: 
date:
location: [44.98394515,34.12818156319529]
title: 'Simferopol (urban okrug), Republic of Crimea, Ukraine'
---
> **Simferopol** () is the second-largest city in Crimea. Simferopol, along with the rest of Crimea, is internationally recognised as part of Ukraine, and is considered the capital of the Autonomous Republic of Crimea. However, de facto it is administered by Russia, which annexed Crimea in 2014 and regards Simferopol as the capital of the Republic of Crimea. Simferopol is an important political, economic and transport hub of the peninsula, and serves as the administrative centre of both Simferopol Municipality and the surrounding Simferopol District.
>
> After the 1784 annexation of the Crimean Khanate by the Russian Empire, the Russian empress decreed the foundation of the city with the name Simferopol on the location of the Crimean Tatar town of Aqmescit ("White Mosque").
>
> The population was 332,317 (2014 Census).
>
> [Wikipedia](https://en.wikipedia.org/wiki/Simferopol)
