---
aliases: Staraya Nelidovka, 
locations: Staraya Nelidovka, Belgorod
tag: 
date:
location: [50.4604448,36.4926034]
title: 'Staraya Nelidovka, Головинское сельское поселение, Belgorodsky District, Belgorod Oblast, Central Federal District, Russia'
---
