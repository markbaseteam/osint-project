---
aliases: Tula Oblast, Ту́льская о́бласть, Tulskaya Oblast, Tulskaya, Tula
locations:
tag: 
date:
location: [53.89954505,37.390196029134785]
title: 'Tula Oblast, Central Federal District, Russia'
---
> **Tula Oblast** (Russian: Ту́льская о́бласть, Tulskaya oblast) is a federal subject (an oblast) of Russia. It is geographically in the European Russia region of the country and is part of the [[Central Federal District]], covering an area of 25,700 square kilometers (9,900 sq mi) and a population of 1,553,925 (2010).Tula is the largest city and the capital of Tula Oblast.
>
> Tula Oblast borders [[Moscow Oblast]] in the north, [[Ryazan Oblast]] in the east, [[Lipetsk Oblast]] in the southeast, [[Oryol Oblast]] in the southwest, and [[../Kaluga Oblast]] in the west. Tula Oblast is one of the most developed and urbanized territories in Russia, and the majority of the territory forms the [[Tula-Novomoskovsk Agglomeration]], an urban area with a population of over 1 million.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Tula%20Oblast)
