---
aliases: Yasnogorsk, Ясногорск
locations:
tag: 
date:
location: [54.4792708,37.693329]
title: 'Yasnogorsk, городское поселение Ясногорск, Yasnogorsky District, Tula Oblast, Central Federal District, Russia'
---
> **Yasnogorsk** (Russian: Ясногорск) is the name of several urban localities in Russia:
>
> Yasnogorsk, Tula Oblast, a town in Yasnogorsky District of Tula Oblast; administratively incorporated as a town under district jurisdiction
>
>
> [Wikipedia](https://en.wikipedia.org/wiki/Yasnogorsk)
