---
aliases: FSB Nizhny Novgorod, Nizhny Novgorod
locations: FSB Office Nizhny Novgorod
tag: FSB
date:
location: [55.9649007,43.063809]
title: 'ФСБ, Shmidta street, Шлаковый, Pavlovo, Pavlovsky District, Nizhny Novgorod Oblast, Volga Federal District, 606100, Russia'
---
> **Nizhny Novgorod** ( NIZH-nee NOV-gə-rod; Russian: Нижний Новгород, IPA: [ˈnʲiʐnʲɪj ˈnovɡərət] (listen) lit. 'Lower Novgorod/Lower New town'), colloquially shortened to Nizhny, from the 13th to the 17th century Novgorod of the Lower Land, formerly known as Gorky (Горький) (1932–1990), is the administrative centre of Nizhny Novgorod Oblast and the Volga Federal District. The city is located at the confluence of the Oka and the Volga rivers in Central Russia, with a population of over 1.2 million residents, up to roughly 1.7 million residents in the urban agglomeration. Nizhny Novgorod is the sixth-largest city in Russia, the second-most populous city on the Volga, as well as the Volga Federal District. It is an important economic, transportation, scientific, educational and cultural center in Russia and the vast Volga-Vyatka economic region, and is the main center of river tourism in Russia. In the historic part of the city there are many universities, theaters, museums and churches.
>
> The city was founded on 4 February 1221 by Prince Yuri II of Vladimir. In 1612, Kuzma Minin and Prince Dmitry Pozharsky organized an army for the liberation of Moscow from the Poles and Lithuanians. In 1817, Nizhny Novgorod became a great trade center of the Russian Empire. In 1896, at a fair, an All-Russia Exhibition was organized. During the Soviet period, the city turned into an important industrial center. In particular, the Gorky Automobile Plant was constructed in this period. Then the city was given the nickname "Russian Detroit". Shortly before the dissolution of the Soviet Union the city was renamed Nizhny Novgorod once again. In 1985, the Nizhny Novgorod Metro was opened. In 2016, Vladimir Putin opened the new 70th Anniversary of Victory Plant, which is part of the Almaz-Antey Air and Space Defence Corporation.
>
> The Kremlin–the main center of the city–contains the main government agencies of the city and the Volga Federal District. The demonym for a Nizhny Novgorod resident is "нижегородец" (nizhegorodets) for male or "нижегородка" (nizhegorodka) for female, rendered in English as Nizhegorodian. Novgorodian is inappropriate; it refers to a resident of Veliky Novgorod. Nizhny Novgorod was one of the host cities of the 2018 FIFA World Cup.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Nizhny%20Novgorod)
