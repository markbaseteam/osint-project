---
aliases: Клинцы́, Klintsy
locations: Klintsy, Bryansk
tag: 
date:
location: [52.7550561,32.246872612110465]
title: 'Klintsy, городской округ Клинцы, Bryansk Oblast, Central Federal District, 243140, Russia'
---
> **Klintsy** ([[../Russia|Russian]]: Клинцы́) is a town in Bryansk Oblast, [[../Russia|Russia]], located on the Turosna [[../water|River]], 164 kilometers (102 miles) southwest of Bryansk. Population: 62,510 (2010 Census); 67,325 (2002 Census); 71,161 (1989 Census); 60,000 (1972).
>
> [Wikipedia](https://en.wikipedia.org/wiki/Klintsy)
