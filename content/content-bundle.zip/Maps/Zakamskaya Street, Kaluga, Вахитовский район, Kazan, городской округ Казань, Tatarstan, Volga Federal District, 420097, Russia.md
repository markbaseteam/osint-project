---
aliases: Zakamskaya Street
locations:
tag: 
date:
location: [55.7779931,49.153872]
title: 'Zakamskaya Street, Kaluga, Вахитовский район, Kazan, городской округ Казань, Tatarstan, Volga Federal District, 420097, Russia'
---
