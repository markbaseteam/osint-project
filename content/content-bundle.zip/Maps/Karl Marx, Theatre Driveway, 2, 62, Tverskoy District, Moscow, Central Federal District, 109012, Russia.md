---
aliases: Karl Marx Monument, Revolution Square, Karl Marx Theatre, Karl Marx Theater, Theatre Driveway, Theater Driveway, Tverskoy, Tverskoy District, Тверско́й райо́н, Theatre Square, Theater Square, Theatre Sq, Theater Sq
locations:
tag: 
date:
location: [55.7583717,37.6195803]
title: 'Karl Marx, Theatre Driveway, 2, 62, Tverskoy District, Moscow, Central Federal District, 109012, Russia'
---
> **tverskoy** District (Russian: Тверско́й райо́н, IPA: [tvʲɪrˈskoj] (listen)) is a district of Central Administrative Okrug of the federal city of Moscow, Russia. Population: 75,378 (2010 Census); 75,955 (2002 Census).The district extends from Kitai-gorod northwest to Belorussky and Savyolovsky Rail Terminals . Its southern boundary runs one or two city blocks south from Tverskaya Street; eastern boundary follows the track of the Neglinnaya River now flowing in a tunnel under Samotechnaya Street, Tsvetnoy Boulevard, and Neglinnaya Street.
>
> Tverskoy District houses State Duma, Federation Council, the Mayor of Moscow, Moscow City Council, and Moscow Police Headquarters. It contains Theatre Square, the business district of Tverskaya Street with Pushkin Square, Petrovka Street, Dmitrovka Street, and the western part of Kuznetsky Most. It has the highest concentration of theatres, including Bolshoi Theatre and the historical Pillar Hall of the House of the Unions.
>
> Historical areas of Patriarshy Ponds, Malaya Bronnaya Street, and most of Tverskoy Boulevard, while closely associated with Tverskaya Street actually belong to Presnensky District. Since 2002 Tverskoy District also includes Kitai-gorod, which was once a separate territory managed directly by Central Administrative Okrug.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Tverskoy%20District)
