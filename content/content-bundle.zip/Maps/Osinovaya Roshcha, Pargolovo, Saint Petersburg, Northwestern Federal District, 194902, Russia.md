---
aliases: Osinovaya Roshcha, Aspen Grove, The E. I. Lopukhina, Levashov, Viazemsky, E I Lopukhina, EI Lopukhina, E.I. Lopukhina, Па́рголово, Pargola, Pargolovo, Parkala
locations: Vyborgsky District, Saint Petersburg
tag: 
date:
location: [60.109749,30.254259]
title: 'Osinovaya Roshcha, Pargolovo, Saint Petersburg, Northwestern Federal District, 194902, Russia'
---

> **Pargolovo** (Russian: Па́рголово, Finnish: Parkala, German: Pargola) is a municipal settlement in the Vyborgsky District of Saint Petersburg, Russia. Until the late 20th century, it was the city's northern suburb. The name derives from Parkola, a Karelian placename. Its population in 2010 was 15,852.
>
> Pargolovo was a family seat of the junior line of the Counts Shuvalov, starting with Peter Ivanovich Shuvalov who received the Pargolovo manor from Empress Elizabeth in 1746. His Baroque palace was rebuilt by Stepan Krichinsky (1874-1923) as a Neoclassical villa for the estate's last owner, Count Illarion Ivanovich Vorontsov-Dashkov. A smaller palace, designed by Harald Julius von Bosse, dates from the mid-19th century.The Shuvalov Park also contains a network of old ponds; the Yellow Dacha, a wooden lodge designed by Maximilian Messmacher for his own family; the Parnassus hill, which used to offer views of the capital's downtown; and the Church of Sts. Peter and Paul, built in the 1840s to a Gothic Revival design by Alexander Brullov. It was at this church that Nikolai Rimsky-Korsakov married Nadezhda Purgold in 1872.
>
> Just west of Pargolovo lies the Northern Cemetery, the second largest in Saint Petersburg. It was established in 1874. Notable burials include Georgy Gapon (1906), Vasily Vereshchagin (1909), Vladimir Propp (1970), Mikhail Artamonov (1972), Alexander Belov (1978), Sergey Filippov (1990).
>
> [Wikipedia](https://en.wikipedia.org/wiki/Pargolovo)
