---
aliases: Kirovsky District, Kirovsky
locations: Perm
tag: 
date:
location: [43.9799219,43.660392326738275]
title: 'Kirovsky District, Stavropol Krai, North Caucasian Federal District, Russia'
---
> **Kirovsky** District may refer to:
>
>
>
> Kirawsk Raion (Kirovsky District), a district of Mogilev Oblast, Belarus
>
> Kirovsky District, [[../Russia|Russia]], several districts and city districts in [[../Russia|Russia]]
>
> Kirovske Raion (Kirovsky District), a district in Crimea
>
> Kirovsky City District, Novosibirsk
>
> Kirov Raion (disambiguation)
>
> [Wikipedia](https://en.wikipedia.org/wiki/Kirovsky%20District)
