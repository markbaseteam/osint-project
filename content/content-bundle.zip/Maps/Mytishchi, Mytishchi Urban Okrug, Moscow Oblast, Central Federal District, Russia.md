---
aliases: Mytishchi, Мыти́щи, Mytishchinsky, Мыти́щи
locations:
tag: 
date:
location: [55.9094928,37.7339358]
title: 'Mytishchi, Mytishchi Urban Okrug, Moscow Oblast, Central Federal District, Russia'
---
> **Mytishchi** (Russian: Мыти́щи, IPA: [mɨˈtʲiɕːɪ]) is a city and the administrative center of Mytishchinsky District in Moscow Oblast, Russia, which lies 19 km northeast of Russia's capital Moscow on the Yauza River and the [[Moscow–Yaroslavl railway]]. The city was an important waypoint for traders on the [[Yauza River]], the Yaroslavl Highway passes through the city. Mytishchi is famous for its aqueduct, built in 1804, the first water supply pipeline to supply the growing population of Moscow. The city has a population of approximately 262,702 people as of 2022.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Mytishchi)
