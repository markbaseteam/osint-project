---
aliases: 
locations:
tag: 
date:
location: [65.2729258,95.48990318530036]
title: 'Siberian Federal District, Russia'
---

$CURSOR$
