---
aliases: 
locations:
tag: 
date:
location: [47.2213858,39.7114196]
title: 'Rostov-on-Don, Rostov Oblast, Southern Federal District, Russia'
---

> **rostov-on-don** (Russian: Ростов-на-Дону, tr. Rostov-na-Donu, IPA: [rɐˈstof nə dɐˈnu]) is a port city and the administrative centre of Rostov Oblast and the Southern Federal District of Russia. It lies in the southeastern part of the East European Plain on the Don River, 32 kilometers (20 mi) from the Sea of Azov, directly north of the North Caucasus. The southwestern suburbs of the city lie above the Don river delta. Rostov-on-Don has a population of over one million people, and is an important cultural centre of Southern Russia.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Rostov-on-Don)
