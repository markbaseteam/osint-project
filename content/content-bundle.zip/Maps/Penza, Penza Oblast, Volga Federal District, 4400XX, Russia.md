---
aliases: Penza, Пе́нза
locations: 
tag: 
date:
location: [53.200001,45]
title: 'Penza, Penza Oblast, Volga Federal District, 4400XX, Russia'
---
> **penza** (Russian: Пе́нза, IPA: [ˈpʲɛnzə]) is the largest city and administrative center of [[Penza Oblast]], Russia. It is located on the [[Sura River]], 625 kilometers (388 mi) southeast of Moscow. As of the 2010 Census, Penza had a population of 517,311, making it the 38th-largest city in Russia.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Penza)
