---
aliases: Orsha, О́рша, Во́рша, Orša, Vorša, О́рша, Orsza
locations: Belarus
tag: 
date:
location: [54.5119008,30.4254486]
title: 'Orsha, Orsha District, Vitsebsk Region, Belarus'
---
> **orsha** (Belarusian: О́рша, Во́рша, romanized: Orša, Vorša; Russian: О́рша [ˈorʂə]; Lithuanian: Orša, Polish: Orsza) is a city in Belarus in the [[Vitebsk Region]], on the fork of the [[Dnieper River]] and [[Arshytsa river]]s.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Orsha)
