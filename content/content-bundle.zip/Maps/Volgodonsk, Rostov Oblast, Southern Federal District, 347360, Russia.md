---
aliases: Volgodonsk, Волгодонск
locations:
tag: 
date:
location: [47.5128177,42.1717606]
title: 'Volgodonsk, Rostov Oblast, Southern Federal District, 347360, Russia'
---
> **Volgodonsk** (Russian: Волгодонск, IPA: [vəlgɐˈdonsk]) is a city in [[Rostov Oblast]], Russia, located in the east of the oblast on the west bank of the [[Tsimlyansk Reservoir]]. Population: 170,841 (2010 Census); 165,994 (2002 Census); 175,593 (1989 Census); 28,000 (1970).
>
> [Wikipedia](https://en.wikipedia.org/wiki/Volgodonsk)
