---
aliases: Omsk Oblast
locations:
tag: 
date:
location: [56.0935263,73.5099936]
title: 'Omsk Oblast, Siberian Federal District, Russia'
---

No Wikipedia for Omsk Oblast
