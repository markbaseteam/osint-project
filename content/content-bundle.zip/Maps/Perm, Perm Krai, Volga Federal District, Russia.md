---
aliases: Perm
locations:
tag: 
date:
location: [58.02148705,56.23076652679421]
title: 'Perm, Perm Krai, Volga Federal District, Russia'
---

Disambiguation error
