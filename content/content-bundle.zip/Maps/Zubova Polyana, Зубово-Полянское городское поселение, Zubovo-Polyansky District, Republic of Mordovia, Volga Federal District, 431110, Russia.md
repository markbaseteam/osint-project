---
aliases: Zubova Polyana, Zubova-Polyana, Зу́бова Поля́на, 
locations:
tag: 
date:
location: [54.079964,42.837425]
title: 'Zubova Polyana, Зубово-Полянское городское поселение, Zubovo-Polyansky District, Republic of Mordovia, Volga Federal District, 431110, Russia'
---

> **Zubova Polyana** (Russian: Зу́бова Поля́на; Moksha: Зубу) is an urban locality (a work settlement) and the administrative center of Zubovo-Polyansky District of the Republic of Mordovia, Russia. As of the 2010 Census, its population was 10,338.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Zubova%20Polyana)
