---
locations:
aliases: ['[[Maps/Republic of Mordovia, Volga Federal District, Russia|Mordovia]] Recruitment office']
location: Mordovia
title: '[[Maps/Republic of Mordovia, Volga Federal District, Russia|Mordovia]] Recruitment office'
tag: molotov, recruitment
date: 2022-04-18  
linter-yaml-title-alias: '[[Maps/Republic of Mordovia, Volga Federal District, Russia|Mordovia]] Recruitment office'
---

# [[OSINT Project/Maps/Republic of Mordovia, Volga Federal District, Russia|Mordovia]] Recruitment office

2022-04-18  
Molotov  
Recruitment  
https://scooptrade.com/firefighters-eliminated-the-fire-of-the-military-registration-and-enlistment-office-in-mordovia/  
[[OSINT Project/Maps/Republic of Mordovia, Volga Federal District, Russia|Mordovia]] enlistment office  
[[OSINT Project/Maps/Republic of Mordovia, Volga Federal District, Russia|Mordovia]] enlistment office

Date discrepancy 18 or 19 April, 2022. Used earliest reported date. More information here https://enoughisenough14.org/2022/04/18/molotov-cocktails-pelted-at-military-registration-and-enlistment-office-in-mordovia-russia

~+~  
8
