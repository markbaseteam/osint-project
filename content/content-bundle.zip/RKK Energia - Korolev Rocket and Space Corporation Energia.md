---
locations:
aliases: 
location:
title: RKK Energia - Korolev Rocket and Space Corporation Energia
tag: fire, weapons, other Defence 
date: 2022-04-22  
---

# RKK Energia - Korolev Rocket and Space Corporation Energia

2022-04-22  
[[fire]]  
Weapons,Other Defence  
https://redstate.com/streiff/2022/04/23/bad-luck-strikes-russia-as-three-major-fires-in-two-days-damage-defense-and-private-industry-n554988  
plant owned by Korolev Rocket and Space Corporation Energia. [[fire]] at massive plant owned by Korolev Rocket and Space Corporation Energia. also known as "RKK Energia," Russia’s primary manufacturer of ballistic missile, spacecraft, and space station components.  
Korolyov

Research center was designated NII-88 or POB 989. Russian state owned 38% in 2009.

~+~  
112

> PAO S. P. Korolev Rocket and Space Corporation Energia (Russian: Ракетно-космическая корпорация «Энергия» им. С. П. Королёва, romanized: Raketno-kosmicheskaya korporatsiya "Energiya" im. S. P. Korolyova), also known as RSC Energia (РКК «Энергия», RKK "Energiya"), is a Russian manufacturer of spacecraft and space station components. The company is the prime developer and contractor of the Russian crewed spaceflight program; it also owns a majority of Sea Launch. Its name is derived from Sergei Korolev, the first chief of its design bureau, and the Russian word for energy.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Energia%20(corporation))
