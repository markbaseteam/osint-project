---
locations:
aliases: conti
location:
title: Conti Hacker Releases Conti Code and Tools
tag:
date:
---

# Conti Hacker Releases Conti Code and Tools

2022-03-02  
Mechanical  
Other  
https://www.cyberark.com/resources/threat-research-blog/conti-group-leaked  
Ukrainian hacker in Conti Ransomeware Group Leaked Everything. Internal Chat Logs, Internal Tools, Credentials and Certificates, RocketChat including methods and means, Screenshots of panels of tools, training manuals leaked information about the inner workings of the group including its common tactics, techniques and procedures (TTPs). As cybersecurity researchers, we believe insight gained from these leaks is incredibly important to the cybersecurity community at large. Ongoing awareness and visibility into the leaked tools while supporting the need for continued vigilance is critical during this time It even extends to a Ukrainian hacker inside the Russian ransomware gang known as “Conti,” who leaked a “massive” amount of source code and other malware information https://www.washingtonpost.com/opinions/2022/06/21/russia-ukraine-cyberwar-intelligence-agencies-tech-companies/  
Russia

~+~  
102
