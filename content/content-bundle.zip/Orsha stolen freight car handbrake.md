---
locations:
aliases: ['[[Maps/Orsha, Orsha District, Vitsebsk Region, Belarus|Orsha]] stolen [[freight train|freight car]] handbrake']
location: Orsha, Belarus
title: '[[Maps/Orsha, Orsha District, Vitsebsk Region, Belarus|Orsha]] stolen [[freight train|freight car]] handbrake'
tag: railway, infrastructure
date: 2022-03-18 
linter-yaml-title-alias: '[[Maps/Orsha, Orsha District, Vitsebsk Region, Belarus|Orsha]] stolen [[freight train|freight car]] handbrake'
---

# [[OSINT Project/Maps/Orsha, Orsha District, Vitsebsk Region, Belarus|Orsha]] stolen [[freight train|freight car]] handbrake

2022-03-18  
Other  
Railway,Infrastructure  
https://ru.wikipedia.org/wiki/Рельсовая_война_в_Белоруссии_(2022)# 30_марта  
On March 18, a local railway employee was [[arrested|detained]] in [[OSINT Project/Maps/Orsha, Orsha District, Vitsebsk Region, Belarus|Orsha]] for damage to railway tracks. A "repentant" video appeared with him on the pro-government telegram channel. However, the man's face was not shown, and his last name was not given. The detainee himself admitted on video that he stole the thrust of the handbrake on the [[freight train|freight car]]  
[[OSINT Project/Maps/Orsha, Orsha District, Vitsebsk Region, Belarus|Orsha]], Belarus

~+~  
110
