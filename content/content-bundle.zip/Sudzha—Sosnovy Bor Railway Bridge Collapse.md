---
locations:
aliases:
  - "Sudzha—Sosnovy Bor\_Railway Bridge Collapse"
location:
title: "Sudzha—Sosnovy Bor\_Railway Bridge Collapse"
tag: 
date:

linter-yaml-title-alias: "Sudzha—Sosnovy Bor\_Railway Bridge Collapse"
---

# Sudzha—Sosnovy Bor Railway Bridge Collapse

2022-05-01  
Explosion  
Infrastructure,Railway  
https://www.marketwatch.com/story/explosion-damages-railway-bridge-in-russia-it-was-a-sabotage-01651446876  
On the same day, in [[OSINT Project/Maps/Kursk Oblast, Central Federal District, Russia|Kursk Oblast]], a bridge on the Sudzha—Sosnovy Bor railway collapsed. The governor declared it an act of sabotage. A criminal investigation was launched  
Sudzha—Sosnovy Bor, [[OSINT Project/Maps/Kursk, Kursk Oblast, Central Federal District, 305000, Russia|Kursk]]

A railway bridge in [[Kursk Oblast, Russia]], collapses. 🚃 connects to int'l markets. [[OSINT Project/Maps/Kursk, Kursk Oblast, Central Federal District, 305000, Russia|Kursk]] borders Bryansk. •lg iron-ore deposits •[[rare earth minerals]] •chalk •Industry: 70% [[agriculture]] •40% [[manufacturing]] esp [[metals]], [[chemicals]] & [[food processing]]

~+~  
63
