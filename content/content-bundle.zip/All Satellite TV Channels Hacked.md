---
locations:
aliases: TV, TVs, television, televisions, talk show, reality show, May 9, Victory Day, Day of Victory
location: Russia
title: All Satellite TV Channels Hacked
tag: Mechanical, Protest
date: 2022-05-09
---

# All Satellite TV Channels Hacked

2022-05-09  
Mechanical  
Hearts & Minds  
https://amplifyukraine.eu/you-have-the-blood-of-ukrainian-children-on-your-hands-russians-were-forced-to-face-the-truth-on-may-9-details-in-russia-this-line-ap-pravda-gerashchenko-2/  
You have the blood of Ukrainian children on your hands–Russians were forced to face the truth on May 9 Details: In [[Russia]], this line appeared on all satellite TV channels. Instead of the usual Rashist victory speech on May 9, they had to read the truth about the “deeds” of Putin’s army of murderers and looters.  
Russia

In addition Smart TVs, Internet Companies like Yandex and Rutube ([[Russia]]'s YouTube) not using satellite TV also received this message https://finance.yahoo.com/news/[[russia]]-smart-tv-hack-202422488.html  
~+~  
159
