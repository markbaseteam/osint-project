---
aliases: civilization, culture
locations:
tag: 
date:
title: civilizations
---
> A civilization (or civilisation) is any complex society characterized by the development of a political state, social stratification, urbanization, and symbolic systems of communication beyond natural spoken language (namely, a writing system).
>
>
>
> **civilizations** are intimately associated with additional characteristics such as centralization, the domestication of plant and [[animals|animal]] species (including humans), specialization of labour, culturally-ingrained ideologies of progress, monumental architecture, taxation, societal dependence upon farming, and expansionism.Historically, "a civilization" has often been understood as a larger and "more advanced" culture, in implied contrast to smaller, supposedly less advanced cultures. In this broad sense, a civilization contrasts with non-centralized tribal societies, including the cultures of nomadic pastoralists, Neolithic societies or hunter-gatherers; however, sometimes it also contrasts with the cultures found within civilizations themselves. Civilizations are organized densely-populated settlements divided into hierarchical social classes with a ruling elite and subordinate urban and rural populations, which engage in intensive agriculture, mining, small-scale manufacture and trade. Civilization concentrates power, extending human control over the rest of nature, including over other human beings.Civilization, as its etymology (see below) suggests, is a concept originally associated with towns and cities. The earliest emergence of civilizations is generally connected with the final stages of the Neolithic Revolution in West Asia, culminating in the relatively rapid process of urban revolution and state-formation, a political development associated with the appearance of a governing elite.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Civilization)
