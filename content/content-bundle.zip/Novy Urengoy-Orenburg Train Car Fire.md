---
locations:
aliases: ['[[Maps/Novy Urengoy, городской округ Новый Уренгой, Yamalo-Nenets Autonomous Okrug, Ural Federal District, 629300, Russia|Novy Urengoy]]-Orenburg [[railway car|Train Car]] [[Fire]]']
location: Hanymey - Noyabrsk-2 section, Yamalo-Nenets Autonomous District, Novy Urengoy-Orenburg train
title: '[[Maps/Novy Urengoy, городской округ Новый Уренгой, Yamalo-Nenets Autonomous Okrug, Ural Federal District, 629300, Russia|Novy Urengoy]]-Orenburg [[railway car|Train Car]] [[Fire]]'
tag: fire, infrastructure, railway 
date: 2022-06-24 
linter-yaml-title-alias: '[[Maps/Novy Urengoy, городской округ Новый Уренгой, Yamalo-Nenets Autonomous Okrug, Ural Federal District, 629300, Russia|Novy Urengoy]]-Orenburg [[railway car|Train Car]] [[Fire]]'
---

# [[OSINT Project/Maps/Novy Urengoy, городской округ Новый Уренгой, Yamalo-Nenets Autonomous Okrug, Ural Federal District, 629300, Russia|Novy Urengoy]]-Orenburg [[railway car|Train Car]] [[fire]]

2022-06-24  
[[fire]]  
Infrastructure,Railway  
https://ura.news/news/1052564729  
The emergency on the train occurred early in the morning of June 24. On the Hanymey - Noyabrsk-2 section in the Yamalo-Nenets Autonomous District, the 13th car of the [[OSINT Project/Maps/Novy Urengoy, городской округ Новый Уренгой, Yamalo-Nenets Autonomous Okrug, Ural Federal District, 629300, Russia|Novy Urengoy]]-Orenburg [[passengers|passenger]] train caught [[fire]]. According to the preliminary version, the cause of the [[fire]] is [[fire|arson]].  
[[Hanymey - Noyabrsk-2 section]] in the [[Yamalo-Nenets Autonomous District]] - [[Novy Urengoy-Orenburg]]

Residents of [[Nizhnevartovsk]] helped [[arrested|detain]] a man suspected of setting [[fire]] to a [[railway car|train car]]. This was reported to URA.RU by Anna Skala, who works together with [[Ugra]] residents.

~+~  
88
