---
aliases: revolutionary, revolt, revolution
locations:
tag: 
date:
title: revolutionaries
---
> A revolutionary is a person who either participates in, or advocates a revolution. The term revolutionary can also be used as an adjective, to refer to something that has a major, sudden impact on society or on some aspect of human endeavor.
>
> [Wikipedia](https://en.wikipedia.org/wiki/Revolutionary)
