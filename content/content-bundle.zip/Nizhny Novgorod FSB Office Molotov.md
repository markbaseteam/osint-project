---
locations:
aliases: 
location: Nizhny Novgorod
title: Nizhny Novgorod FSB Office Molotov
tag: molotov, government
date: 2022-06-30  
---

# Nizhny Novgorod FSB Office Molotov

2022-06-30  
Molotov  
Government  
https://www.newsweek.com/russia-dissent-putin-ukraine-war-man-molotov-cocktail-fsb-government-building-fire-1720900  
Thursday afternoon an unknown man hurled the [[fire]] bomb at a local office of Russia's Federal Security Service (FSB) in Nizhny Novgorod before fleeing the scene. According to the Russian language news agency, there was no [[fire]], and law enforcement officers are now searching for the man.  
Nizhny Novgorod

~+~  
98
