---
locations:
aliases: 
location:
title: Nikolai Rimsky-Korsakov Estate Museum
tag: fire, cultural, museum, music
date: 2022-07-02  
---

# Nikolai Rimsky-Korsakov Estate Museum

2022-07-02  
[[fire]]  
Cultural  
https://www.classicfm.com/composers/rimsky-korsakov/fire-memorial-museum-russia/  
Over half of the exhibits have been destroyed in the blaze, which has devastated more than 1,000 artefacts. Reports of the [[fire]] originally emerged from the governor of the district, Mikhail Vedernikov who posted a photo of the [[fire]] on his Telegram [social media] account, saying the damage was “significant”. The [[fire]] is said to have been started due to “the negligence of builders” who were repairing the roof of the museum using a ‘hot work’ technique–construction that uses open flames. Starting on the roof, the [[fire]] spread “very quickly” throughout the building according to Vedernikov, engulfing the estate before firefighters were able to arrive  
Lyubensk, Plyussky district, Pskovskaya, Paskov

Putin named his mega yacht Sherezade, an opera written by Rimsky-Korsakov. https://www.zyri.net/2022/03/09/a-mysterious-and-gigantic-yacht-is-disturbing-in-italy-is-it-putins/ Also see https://en.newizv.ru/news/incident/04-07-2022/the-fire-destroyed-over-a-thousand-exhibits-in-the-rimsky-korsakov-museum

~+~  
51
