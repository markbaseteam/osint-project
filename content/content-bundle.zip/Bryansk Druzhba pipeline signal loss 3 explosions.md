---
locations:
aliases: 
location:
title: Bryansk Druzhba pipeline signal loss 3 explosions
tag: 
date:

---

# Bryansk Druzhba pipeline signal loss 3 explosions

2022-06-11  
Explosion  
Gas/Oil  
https://news.yahoo.com/russia-tried-blow-druzhba-pipeline-103804242.html?guccounter=1  
Druzhba pipeline near Gulevka - means friendship Russian media write that on 11 June, three explosions took place near the village of Gulivka in the Bryansk region (40 km to the border with Ukraine). At the same time a signal indicated loss of communication with the latch of the Druzhba pipeline. It is reported that one of the explosions damaged the transformer substation with the power unit of the pipeline latch. Another explosion occurred in the place where the cable was laid. There was a shell hole [measuring] 40 by 20 cm. The third explosion damaged the anti-dig pipe (an additional means of protection which is in the ground at the regime facilities), leaving a shell-hole [measuring] 40 by 60 centimetres. It is noted that the Druzhba pipeline itself was not damaged, but the anti-dig pipe and the substation were damaged, and power was lost to the latch control unit.  
Gulevka or Gulivka, Bryansk

Gulivka AKA Gulevka it was possible to avoid an oil spill [as] the pipeline has been closed since 24 February, but there is diesel fuel inside. Druzhba is the world's largest network of main oil pipelines. It was built in the 1960s to supply oil to Eastern Europe to socialist countries that were at that time friendly to the Soviet Union.

~+~  
143
