---
aliases: 
locations:
tag: 
date:
title: Read Me
---

Hello. Glad you could make it.

On February 24, 2022, Russia invaded the sovereign nation of Ukraine giving any number of crazy excuses for their invasion, brutality, rape, looting, cultural genocide and indiscriminate slaughter of civilians and children.

Due to this, the OSINT (Open Source Intelligence) Community has banned together, combining specialties and tools in support of Ukraine. Sometimes, it takes a village.

We do not focus on military losses or troop movements. The information we seek with this project is different. For Russia losses, check out Ragnar's awesome dashboard where you can visualize multiple views for the same data in useful and insightful ways.

**A few points about this data.**

- This is a compilation of events that indicate citizens within Russia and Belarus may be taking action as [[anti-war]] direct action and sabotage.
- The goals of these attacks are to draw attention to the war, to make political and [[anti-war]] statements, to decrease the moral of the Russian people and soldiers, and to slow, delay, hinder or otherwise disable infrastructure, strategic targets, supplies, weapons and logistics required by Russia to fight in Ukraine.
- It is often impossible to verify whether or not an event is an act of sabotage or usual fall out from shoddy Russian building standards and materials. We make best-guess efforts, based on timing, location and targets (whether they might be strategic or political or protest related), claims of individuals or groups as to their direct action activities and legal case filings against people in Russia for "terrorism" or "hooliganism".
- As such, we include all reports if there is the potential of sabotage to leave room for more information to become available. It is up to you to include or exclude the events of your choice, based on your own criteria
- In all cases, we have taken steps to protect the identities of vulnerable individuals or groups. In cases where names and details linked to them have been made officially public in Russia or Belarus, we have retained that information. In cases of self-attribution, we have included this as well.
- This data was compiled from reporting in global media, local and regional reporting, curated Telegram channels, [[activism|activist]] websites, alert and monitoring programs and apps, and from curated accounts on Twitter from @AmplifyUkraine, @VelvetBlade, @DemeryUK, @TWMCLtd, @StillDelvingH, @HarladF, @Russiasonfire, @Bellingcat
- This data was augmented by several sources including lists of military contracting companies and factories within Russia, Wikipedia and CartoDB.
- This vault will be updated as more data becomes available and more "care and feeding" goes into drawing out meaning and connections

**How to Use this Vault**

This vault was created with Obsidian, a free and expandable open source markdown project. It has been Published through Markbase for Obsidian, which has allowed us to post these bits of data for you to enjoy without the hassles of coding or self hosting.

Obsidian is a rich community of enthusiasts and this project has been enhanced on the shoulders of several plug-ins most notably:

- Adjacency Matrix Viewer
- Breadcrumbs
- Dataview
- Find unlinked files and unresolved links
- NLP
- Obsidian 42 - BRAT
- Journey
- Translator
- Linter
- Note Refactor
- Map View
- Omni Search
- Graph Analysis
- Wikipedia
- WordNik
- Zootelkeeper
