---
locations:
aliases: 
location:
title: Bryansk Snezhetsky Val Refinery
tag: 
date:
---

# Bryansk Snezhetsky Val Refinery

2022-04-25  
[[fire]]  
Gas/Oil  
https://www.newsweek.com/explosion-oil-fires-erupt-russia-midpoint-between-moscow-kyiv-1700441  
NASA's [[fire]] Information for Resource Management System showed a satellite image of multiple [[fire|fires]] On the outskirts of Bryansk, two fuel tanks are [[fire|burning]] in a military unit on Moskovsky Prospekt and an oil refinery at Snezhetsky Val  
Snezhetsky Val Refinery, Bryansk

**According to InformNapalm, Russia is attacking itself with false flags & is preparing to bring in wreckage of Ukrainian [[aircraft|helicopters]] and drones to place as "proof". Other claims made are that top military and families were evacuated April 19th in preparation. Focus areas Belgorod, [[OSINT Project/Maps/Kursk, Kursk Oblast, Central Federal District, 305000, Russia|Kursk]], Bryansk Oblasts especially civilian and residential areas**

~+~  
166
