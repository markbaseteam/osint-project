---
aliases: personnel carrier, personnel carriers, APC
location:
title: Armored Personnel Carrier in Transit
tag: Fire, Military, Ammunition Depot
date: 2022-06-10 
locations: Rostov, Kazachy Camps, Cossack, Rostov region, near the village of Cossack camps
---

# Armored Personnel Carrier in Transit

2022-06-10  
[[fire]]  
[[Russian Military Industry|Military]], Ammunition Depot  
https://globalhappenings.com/top-global-news/202406.html  
In the [[OSINT Project/Maps/Rostov Oblast, Southern Federal District, Russia|Rostov region]] of [[Russia]] on June 10, an armored personnel carrier with ammunition caught [[fire]] on the [[roads|highway]]. Ammunition detonated in [[Russia|Russian]] [[automobiles|vehicles]] after a [[fire]]. An eyewitness to the incident said that the accident occurred near the village of Cossack camps. The scene was blocked by [[Russia|Russian]] [[police]]. After the [[fire]], he heard the sounds of explosions–detonated ammunition. Due to an accident, a traffic jam formed on the [[roads|highway]]. Drivers were not allowed to enter the scene of the accident.  
Kazachy Camps, Cossack, Rostov region

Some bloggers, spreading the video, erroneously indicated that the APC exploded in the Kuban, but this is not so.

~+~  
76
