---
locations:
aliases: 
location:
title: Capital Towers Complex
tag: 
date:
---

# Capital Towers Complex

2022-07-03  
[[fire]]  
Elite,Other  
https://globalhappenings.com/top-global-news/221879.html  
In the capital of Russia, [[Moscow]], on the evening of July 3, a [[fire]] broke out in one of the towers of the Capital Towers complex. According to the Telegram channel “Ukraine 24”, preliminary, the [[fire]] occurred on the 55th floor. Firefighters are on the scene. according to preliminary data, scaffolding was on [[fire]] on the roof of one of the Capital Towers in the center of [[Moscow]].  
[[Moscow]]

THE HIGHEST REGISTRATION IN [[Moscow]] IS ON [[fire]]–THIS IS WHAT THE CAPITAL TOWERS RESIDENTIAL COMPLEX IS CALLED. SMOKE IS COMING FROM THE ROOF OF ONE OF THE UNFINISHED SKYSCRAPERS. THERE ARE NO ACCIDENTS, THERE ARE PATTERNS. MORDOR MUST [[fire|BURN]] IN HELL,” ANTON GERASHCHENKO, ADVISER TO THE HEAD OF THE MINISTRY OF INTERNAL AFFAIRS OF UKRAINE, COMMENTED ON THE [[fire]].

~+~  
50
