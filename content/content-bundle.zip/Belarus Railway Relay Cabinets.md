---
locations:
aliases: 
location:
title: Belarus Railway Relay Cabinets
tag: 
date:
---

# Belarus Railway Relay Cabinets

2022-03-30  
[[fire]]  
Railway,Infrastructure  
https://libcom.org/article/new-bottom-resistance-russia-and-belarus-genocide-ukraine-part-5  
On the night of March 30, on the Savichy-Berezina stretch (Osipovichi-[[OSINT Project/Maps/Homyel, Homyel Region, Belarus|Gomel]] section), near the [[Babino stop railway relay cabinets disabled|Babino stopping point]], two relay cabinets were opened, one of them was set on [[fire]]. At that time, a patrol group of the Internal Troops was in the forest belt. Patrolmen opened [[fire]] from military weapons on the partisans. They managed to escape from persecution  
Savichy-Berezina stretch of Osipovichi-[[OSINT Project/Maps/Homyel, Homyel Region, Belarus|Gomel]] section near [[Babino stop railway relay cabinets disabled|Babino stopping point]] Belarus

~+~  
140
