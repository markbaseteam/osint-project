---
aliases: 
locations:
tag: 
author: "VelvetBIade 🧃"
handle: "@VelvetBlade"
source: "https://twitter.com/VelvetBlade/status/1518494756623765504"
date: "2022-04-25"
fetched: "2022-07-14"
likes: 197
retweets: 84
replies: 15
tags: ["twitter"]
title: "VelvetBIade \U0001F9C3 - VelvetBlade - 1518494756623765504"
---

![[assets/1131037589165658112-8RGoUMyN_normal.jpg]]  
VelvetBIade 🧃 ([@VelvetBlade](https://twitter.com/VelvetBlade)) - 2022-04-25

There's been a lot of [[../fire|fires]] & explosions in Russia in the last week. No one knows if this is Ukrainian, Belarusian or Russian sabotage or if, indeed, Russia has this many "faulty wiring" emergencies.

Let's go over some of them.

April 24: Still evolving near Bryansk - possible multiple incidents

- 2 fuel tanks [[../fire|burning]] in a military unit on Moskovsky Prospekt
- oil refinery at Snezhetsky Val
- Druzhba pipeline

[newsweek.com/explosion-oil-…](https://www.newsweek.com/explosion-oil-fires-erupt-russia-midpoint-between-moscow-kyiv-1700441)

April 23 -

Explosion at Gaisky Mining and Processing Plant in the Orenburg Region owned by the Ural Mining & Metallurgical Company

copper & zinc mine & mill complex, one of Russia's largest copper mines

Investigation into cause is pending.

[republicworld.com/world-news/res…](https://www.republicworld.com/world-news/rest-of-the-world-news/russia-explosion-at-mining-plant-in-orenburg-kills-three-people-rescuers-working-on-site-articleshow.html)

April 23

Molotov cocktails - 5 enlistment offices containing hard copy records  

Zubova Polyana, Voronezh, [[../Maps/Lukhovitsy, Lukhovitsky District, Moscow Oblast, Central Federal District, Russia|Lukhovitsy]], Sverdlovsk & [[../Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] regions

Several [[../arrested|detained]]. Wanted to disrupt recruitment to protest the war in Ukraine & destroy archives

[bipartisanreport.com/2022/04/23/mul…](https://bipartisanreport.com/2022/04/23/multiple-russian-military-offices-set-ablaze-in-possible-sabotage/)

April 22

[[../fire|Fire]] at Russian Defense Ministry's Aerospace Defense Forces’s Central Research Institute in Tver.

Missile research.

[theguardian.com/world/2022/apr…](https://www.theguardian.com/world/2022/apr/22/die-in-fire-at-russia-defence-institute)

April 22

[[../fire|Fire]] [[../Dmitrievsky Chemical Plant|Dmitrievsky chemical plant]] in Kinsehma

The largest producer of butyl acetate and industrial solvents in eastern Europe.

Speculation on [[../aircraft|jet]] propulsion, parts cleaning & rubber production.

[washingtonexaminer.com/news/russian-c…](https://www.washingtonexaminer.com/news/russian-chemical-plant-burns-down-hours-after-deadly-fire-at-military-facility)

April 22

[[../fire|Fire]] at massive plant owned by Korolev Rocket and Space Corporation Energia, or RKK Energia, Russia’s primary manufacturer of ballistic missile, spacecraft, and space station components.

[redstate.com/streiff/2022/0…](https://redstate.com/streiff/2022/04/23/bad-luck-strikes-russia-as-three-major-fires-in-two-days-damage-defense-and-private-industry-n554988)

April 22

[[../Maps/Krasnodar Krai, Southern Federal District, Russia|Krasnodar Krai]], Kuban: dam collapsed near Fyodorovska village

[[../Maps/Krasnodar, Krasnodar Municipality, Krasnodar Krai, Southern Federal District, 350000, Russia|Krasnodar]] is considered "Little Ukraine".

Unclear cause.

[russia.liveuamap.com/en/2022/22-apr…](https://russia.liveuamap.com/en/2022/22-april-krasnodar-krai-kuban-dam--collapsed-near-fyodorovska)

Regarding the mass [[../fire|fires]] & explosions in Bryansk.

According to [@InformNapalm](https://twitter.com/InformNapalm) Russia is attacking itself in a false flag & bringing in wrecked Ukrainian [[../aircraft|helicopters]] to place as "proof".

Other claims were made (below) that top military & families were evacuated on April 19th [twitter.com/EuromaidanPres…](https://twitter.com/EuromaidanPress/status/1517295115676528640)

> ![[assets/2595088842-hVN0_p9k_normal.jpg]]  
> Euromaidan Press ([@EuromaidanPress](https://twitter.com/EuromaidanPress)) - 2022-04-21
>
>
> Russia prepares large-scale provocations in 🇷🇺Belgorod, [[../Maps/Kursk, Kursk Oblast, Central Federal District, 305000, Russia|Kursk]], Bryansk oblasts at civilian infrastructure and in residential areas - Serhii Vysotskyi of [@InformNapalm](https://twitter.com/InformNapalm)
>
> Wreckage of downed 🇺🇦Bayraktars & [[../aircraft|helicopters]] are being brought there to blame Ukraine  
> [t.me/informnapalm/7…](https://t.me/informnapalm/7613)

Report of military officers & families being evacuated from Bryansk on April 19…

🤔 [twitter.com/OlgaNYC1211/st…](https://twitter.com/OlgaNYC1211/status/1516454620335415300)

> ![[assets/751283435382067202-9vXilrWc_normal.jpg]]  
> Olga Lautman 🇺🇦 ([@OlgaNYC1211](https://twitter.com/OlgaNYC1211)) - 2022-04-19
>
>
> Posting this in case Russia attacks Bryansk and tries to blame Ukraine. Again [pic.twitter.com/pxCvMbj988](https://twitter.com/OlgaNYC1211/status/1516454620335415300/photo/1)
>

![[assets/3_1516454603226759173.jpg]]

April 25 -

The following "[[../fire|fires]]" in Russia

- a house in St. Petersburg (unclear which house or if related)
- mid-sized [[../air base|air base]] in Ussuriysk
- multiple police stations in [[../Maps/Moscow, Central Federal District, Russia|Moscow]], Irkutsk & [[../Maps/Novosibirsk, Novosibirsk Oblast, Siberian Federal District, 630000, Russia|Novosibirsk]]

[news.storyua.com/news/14107.html](https://news.storyua.com/news/14107.html)

More on the St Petersburg apartment explosion.

TASS: Explosive planted in stairwell between 7th & 8th floor. Damaged elevator doors, windows & crack on 3 floor facade.  

[tass.ru/proisshestviya…](https://tass.ru/proisshestviya/14461897)

Update on [[../fire|fire]] in Second Central Research Institute of the Ministry of Defence of the Russian Federation in Tver

Local journalists claim (according to Daily Mail) up to 25 people may have died, including top missile scientists.

Might be big impact.

[dailymail.co.uk/news/article-1…](https://www.dailymail.co.uk/news/article-10746369/Cover-25-military-scientists-killed-fire-Russian-weapons-research-facility.html)

April 25

There also may be a [[../fire|fire]] in the basement of Silk Road shopping center in [[../Maps/Moscow, Central Federal District, Russia|Moscow]], however the only source is the same video & other reporting seems lacking so I am holding off sharing until I can confirm.

April 25

3 explosions in Transnistria - the Russian separatist area of Moldova

- 2 radio transmitters near [[../Maps/Mayak, Grigoriopol District, Administrative-Territorial Units from the Left Bank of the Dniester, Transnistria, 4006, Moldova|Mayak]]
- 2 explosions in Parkany
- State Security committee "MGB" building near Tiraspol

[liveuamap.com/en/2022/25-apr…](https://liveuamap.com/en/2022/25-april-explosions-reported-in-tiraspol-transnistria-near)

April 26

Ammo depot in Belgorod.

I count 19 now. Potentially 20 explosions and/or [[../fire|fires]] if the reports from Bryansk meat packing plant are accurate. [twitter.com/ASLuhn/status/…](https://twitter.com/ASLuhn/status/1519171248332451846)

> ![[assets/90275200-TLOxeGW4_normal.jpg]]  
> Alec Luhn ([@ASLuhn](https://twitter.com/ASLuhn)) - 2022-04-26
>
>
> Am ammo depot was [[../fire|burning]] in Belgorod region near Ukraine this morning after [[../air|air]] defenses were firing at something in the neighboring [[../Maps/Kursk, Kursk Oblast, Central Federal District, 305000, Russia|Kursk]] region. The authorities won't say what. Bryansk oil depot was on [[../fire|fire]] Monday. Has the war crossed into Russia? [pic.twitter.com/OfKQUqVLvh](https://twitter.com/ASLuhn/status/1519171248332451846/photo/1)
>

![[assets/3_1519171246327541760.jpg]]

April 27

Russian propaganda [[../All Satellite TV Channels Hacked|TV]] stations are reported down in Kherson after 2 [[../All Satellite TV Channels Hacked|TV]] towers & other Russian communications targets were hit. [twitter.com/TCG_CrisisRisk…](https://twitter.com/TCG_CrisisRisks/status/1519430240086355968)

> ![[assets/1212443950440599552-c2T28tqz_normal.jpg]]  
> The Cavell Group ([@TCG_CrisisRisks](https://twitter.com/TCG_CrisisRisks)) - 2022-04-27
>
>
> 5. Explosions have been heard in Kherson tonight after a day of significant shelling outside the city and fighting reported in a number of regions. There are reports Russian communications systems and the [[../All Satellite TV Channels Hacked|TV]] towers were sabotaged in Kherson taking Russian [[../All Satellite TV Channels Hacked|TV]] off the [[../air|air]].

April 27

Large [[../fire|fire]] after several explosions on Kustanataskaya Street. 7 cars catch [[../fire|fire]].

No one harmed. Reported as already extinguished. [twitter.com/UKRWarSitRep/s…](https://twitter.com/UKRWarSitRep/status/1519542788639105025)

> ![[assets/1497262491436519436-VhZC7rgM_normal.jpg]]  
> Ukraine War SitRep 🇺🇦 ([@UKRWarSitRep](https://twitter.com/UKRWarSitRep)) - 2022-04-27
>
>
> ⚡️Today in [[../Maps/Moscow, Central Federal District, Russia|Moscow]] on Kustanayskaya street, several explosions were heard due to seven [[../fire|burning]] cars. No one was hurt, the [[../fire|fire]] was extinguished, all the circumstances are being investigated now. 👉 Ax Live [#Ukraine](https://twitter.com/hashtag/Ukraine) [#UkraineWar](https://twitter.com/hashtag/UkraineWar) [#Russia](https://twitter.com/hashtag/Russia) [pic.twitter.com/JA1eofGoNH](https://twitter.com/UKRWarSitRep/status/1519542788639105025/video/1)

Oleksiy Arestovych, a military adviser to Zelensky, said he doubted Ukraine was involved in the [[../fire|fires]] at the defense-related facilities and suggested that Russian officials are setting [[../fire|fires]] to cover up evidence of corruption.

🤔

[washingtonpost.com/world/2022/04/…](https://www.washingtonpost.com/world/2022/04/27/mystery-fires-sensitive-facilities-compound-russias-war-challenge/)

Dear [@RFERL](https://twitter.com/RFERL) - You are way under counting the number of strategic [[../fire|fires]] & explosions in Russia.

In the past week there have been at least 20. We did not count the ones since February…

Also some of your other reporting has been debunked - ie [[../aircraft|helicopters]]

[rferl.org/a/ukraine-shad…](https://www.rferl.org/a/ukraine-shadow-war-russian-border-attacks/31827632.html)

April 30

Sakhalinskaya power plant on [[../fire|fire]].

Located in the Kuril Islands - In 1944 Soviets invaded & there has been a dispute between Russia & Japan ever since. Japan particularly claims the 4 southern islands.

Russia cut off treaty talks with Japan about Kuril over sanctions. [pic.twitter.com/OtdvDQ60Yd](https://twitter.com/VelvetBlade/status/1520337933831655424/photo/1) [twitter.com/tweet4anna/sta…](https://twitter.com/tweet4anna/status/1520230635981479937)

![[assets/3_1520337913657143297.jpg]]

> ![[assets/1491810034031939589-PaLe8tdL_normal.jpg]]  
> A n n a 🌻 ([@tweet4anna](https://twitter.com/tweet4anna)) - 2022-04-29
>
>
> Russia: [[../fire|fire]] at Sakhalinskaya Gres-2 (power plant) [pic.twitter.com/fM6SoHmLTp](https://twitter.com/tweet4anna/status/1520230635981479937/video/1)

This is where the sabotage campaign inside Russia can change the balance. Perhaps it's the only thing that can.

Russia can't hide attacks on its soil from its people…

[forbes.com/sites/melikkay…](https://www.forbes.com/sites/melikkaylan/2022/04/28/hidden-truths-of-the-ukraine-war-drunk-russian-soldiers-germanys-real-problem-sabotage-inside-russia/)

UPDATE to Bryansk [[../fire|fires]] & explosions.

If this was supposed to be a false flag things went exuberantly wrong…

😉 [twitter.com/KyleJGlen/stat…](https://twitter.com/KyleJGlen/status/1520681932782071808)

> ![[assets/2567654774--SnSSCYv_normal.jpg]]  
> Kyle Glen ([@KyleJGlen](https://twitter.com/KyleJGlen)) - 2022-05-01
>
>
> High res satellite imagery shows significant damage to the oil infrastructure in Bryansk that was struck by Ukraine last week. I'm counting at least 7 tanks damaged or destroyed. [pic.twitter.com/CSnSWld1YZ](https://twitter.com/KyleJGlen/status/1520681932782071808/photo/1)
>

![[assets/3_1520672151317233664.jpg]]

May 1

A railway bridge in [[../Maps/Kursk Oblast, Central Federal District, Russia|Kursk Oblast]], Russia, collapses. 🚃 connects to int'l markets.

[[../Maps/Kursk, Kursk Oblast, Central Federal District, 305000, Russia|Kursk]] borders Bryansk.  
-lg iron-ore deposits  
-rare earth minerals  
-chalk  
-Industry: 70% agriculture  
-40% manufacturing esp metals, chemicals & food processing

[twitter.com/andersostlund/…](https://twitter.com/andersostlund/status/1520721754225844224?s=10&t=qRO8gpUiKPRj87jREXG48A) [pic.twitter.com/XRxbEHAbsC](https://twitter.com/VelvetBlade/status/1521003218989371393/photo/1)

![[assets/3_1521003202736541696.jpg]]

> ![[assets/21575717-stTMe4ad_normal.jpg]]  
> Anders Östlund ([@andersostlund](https://twitter.com/andersostlund)) - 2022-05-01
>
>
> Railway bridge partially collapsed in [[../Maps/Kursk Oblast, Central Federal District, Russia|Kursk Oblast]].  
> Lots of accidents in Russia this spring. [pic.twitter.com/56nkHPGLrF](https://twitter.com/andersostlund/status/1520721754225844224/photo/1)
>

![[assets/3_1520721612932358144.jpg]]

May 2

Remotely locked heavy farm equipment stolen by the Russian military

 27 pieces of farm equipment from a John Deere dealership are currently unusable.

GPS tracking shows a good number ended up in [[../Maps/Chechen Republic, North Caucasian Federal District, Russia|Chechnya]].

[cnn.com/2022/05/01/eur…](https://www.cnn.com/2022/05/01/europe/russia-farm-vehicles-ukraine-disabled-melitopol-intl/index.html)

More on the [[../Maps/Kursk, Kursk Oblast, Central Federal District, 305000, Russia|Kursk]] railway bridge collapse…Governor confirms sabotage.

[[../Maps/Kursk, Kursk Oblast, Central Federal District, 305000, Russia|Kursk]] is covered by a network of railways…

Expecting more soon.

🤔 [twitter.com/nexta_tv/statu…](https://twitter.com/nexta_tv/status/1520804312317931522)

> ![[assets/1891490382-hL4PN7Hf_normal.jpg]]  
> NEXTA ([@nexta_tv](https://twitter.com/nexta_tv)) - 2022-05-01
>
>
> A railway bridge was destroyed in [[../Maps/Kursk, Kursk Oblast, Central Federal District, 305000, Russia|Kursk]] region
>
> Later, the governor of the region said that the collapse of the railway bridge in the [#[[../Maps/Kursk, Kursk Oblast, Central Federal District, 305000, Russia|Kursk]]](https://twitter.com/hashtag/Kursk) region, [#Russia](https://twitter.com/hashtag/Russia) was the result of sabotage. A criminal case has been opened. [pic.twitter.com/AIn0qFYlZ2](https://twitter.com/nexta_tv/status/1520804312317931522/photo/1)
>

![[assets/3_1520804307179814913.jpg]]

Update on [[../Maps/Kursk, Kursk Oblast, Central Federal District, 305000, Russia|Kursk]] railway bridge sabotage:

The bridge was used to transport Russian military equipment.

Russia relies heavily on its railroads. [twitter.com/visegrad24/sta…](https://twitter.com/visegrad24/status/1520929508630667264)

> ![[assets/1222773302441148416-2l00Uki5_normal.jpg]]  
> Visegrád 24 ([@visegrad24](https://twitter.com/visegrad24)) - 2022-05-01
>
>
> This railway bridge was destroyed in the [[../Maps/Kursk, Kursk Oblast, Central Federal District, 305000, Russia|Kursk]] region.
>
> It was actively used by Russia to transports military equipment to Ukraine.
>
> Local authorities have confirmed it happened due to sabotage.
>
> 3+ million Ukrainians live in Russia.
>
> Endless opportunities with infrastructure. [pic.twitter.com/ZhDCksiMLM](https://twitter.com/visegrad24/status/1520929508630667264/photo/1)
>

![[assets/3_1520929502678900736.jpg]]

May 2

Fuel depot in [[../Maps/Mytishchi, Mytishchi Urban Okrug, Moscow Oblast, Central Federal District, Russia|Mytishchi]] is on [[../fire|fire]]. This area has several military units.

This is very close to [[../Maps/Moscow, Central Federal District, Russia|Moscow]].

It’s been a very bad week for Russia at home…

🤔 [pic.twitter.com/U6jI9Rzqdd](https://twitter.com/VelvetBlade/status/1521077034964983811/photo/1) [twitter.com/Andy_Scollick/…](https://twitter.com/Andy_Scollick/status/1521064768261525504)

![[assets/3_1521077023480950785.jpg]]

> ![[assets/4473582389-AVtr2K2r_normal.jpg]]  
> Andy Scollick ([@Andy_Scollick](https://twitter.com/Andy_Scollick)) - 2022-05-02
>
>
> Military units in [[../Maps/Mytishchi, Mytishchi Urban Okrug, Moscow Oblast, Central Federal District, Russia|Mytishchi]] include: 2366th Separate Cable Communications Battalion; 52nd Radio-Technical Brigade. Plus [[../Maps/Mytishchi, Mytishchi Urban Okrug, Moscow Oblast, Central Federal District, Russia|Mytishchi]] Machine-Building Plant (MMZ, now a Kalashnikov subsidiary) that designs and produces armoured chasis for Buk and other systems. [twitter.com/visegrad24/sta…](https://twitter.com/visegrad24/status/1520875579175804929)
>

> ![[assets/1222773302441148416-2l00Uki5_normal.jpg]]  
> Visegrád 24 ([@visegrad24](https://twitter.com/visegrad24)) - 2022-05-01
>
>
> A fuel depot went up in flames in [[../Maps/Mytishchi, Mytishchi Urban Okrug, Moscow Oblast, Central Federal District, Russia|Mytishchi]] on the outskirts of [[../Maps/Moscow, Central Federal District, Russia|Moscow]] today.
>
> There have been too many [[../fire|fires]] in recent days for there not to be something going on.
>
> [pic.twitter.com/U3BwnTHv22](https://twitter.com/igorsushko/status/1520859285072265216/video/1)

The railway bridge collapse in [[../Maps/Kursk, Kursk Oblast, Central Federal District, 305000, Russia|Kursk]] was due to a bomb (explosive device).

The railway is near the village of Konopelka, on the Sudzha-Sosnovy Bor railway. Some people were trying to find better geo data earlier.

[marketwatch.com/story/explosio…](https://www.marketwatch.com/story/explosion-damages-railway-bridge-in-russia-it-was-a-sabotage-01651446876)

May 2 - UNCONFIRMED

[[../fire|Fire]] at [[../Maps/Perm, Perm Krai, Volga Federal District, Russia|Perm]] gunpowder plant. 2 dead.

The plant produces charges for multiple launch rocket systems, [[../air|air]] defense systems, engine charges for [[../aircraft|aircraft]] rockets & spherical gunpowder for small arms.

[twitter.com/cyberpuzo/stat…](https://twitter.com/cyberpuzo/status/1521110405493501952?s=21&t=nEgpDMy2unxIh50Y6K9YhQ) [pic.twitter.com/PsB1cNzbmT](https://twitter.com/VelvetBlade/status/1521118473526681600/photo/1)

![[assets/3_1521118457596678145.jpg]]

May 2  
MORE on [[../Maps/Perm, Perm Krai, Volga Federal District, Russia|Perm]] explosion. VERY SIGNIFICANT

From an expo:

"one of the greatest enterprises of the defense industry in Russia."

In addition to weapon systems - polyurethane elastoplastic, coating systems, hard foam-polyurethane & shaft coatings

[polyurethanex.com/13-perm-gunpow…](http://www.polyurethanex.com/13-perm-gunpowder-mill-federal-state-enterprise.html)

May 2 - now CONFIRMED. Happened May 1.

[[../Maps/Perm, Perm Krai, Volga Federal District, Russia|PERM]] Gunpowder Mill

2 dead, 1 injured

product caught [[../fire|fire]] at production site No. 12 of Plastmassa production.

Plasmassa seems to be small bits of plastics?

This plant regularly has [[../fire|fires]] & explosions.

[oopstop.com/due-to-an-emer…](https://oopstop.com/due-to-an-emergency-at-the-perm-gunpowder-factory-workers-died/)

April 25

Explosion & [[../fire|fire]] at an [[../air base|airbase]] in Ussuriysk, Russia’s Far East.

Thanks [@HarlanF](https://twitter.com/HarlanF) for pointing this out. I had missed it.

[intellinews.com/russia-on-fire…](https://www.intellinews.com/russia-on-fire-is-ukraine-giving-moscow-a-taste-of-its-own-medicine-242882/)

I count 38-40 [[../fire|fires]] and/or explosions in Russia since April 22…an average of 3.8-4 per day…

Which one am I missing? [twitter.com/VelvetBlade/st…](https://twitter.com/VelvetBlade/status/1521410054242545664)

> ![[assets/1131037589165658112-8RGoUMyN_normal.jpg]]  
> VelvetBIade 🧃 ([@VelvetBlade](https://twitter.com/VelvetBlade)) - 2022-05-03
>
>
> Can someone help me out? I just counted the [[../fire|fires]] & explosions in Russia since April 22.
>
> About 38-40 depending on what you include (I excluded the separatist areas in the count)
>
> I feel like I am missing one. [twitter.com/VelvetBlade/st…](https://twitter.com/VelvetBlade/status/1518494756623765504)
>

> ![[assets/1131037589165658112-8RGoUMyN_normal.jpg]]  
> VelvetBIade 🧃 ([@VelvetBlade](https://twitter.com/VelvetBlade)) - 2022-04-25
>
>
> There's been a lot of [[../fire|fires]] & explosions in Russia in the last week. No one knows if this is Ukrainian, Belarusian or Russian sabotage or if, indeed, Russia has this many "faulty wiring" emergencies.
>
> Let's go over some of them.

May 3  
[[../fire|Fire]] at Russian warehouse for text books.

The printer, Prosveshchenie, was preparing to remove all references to Ukraine & Kyiv.

[themoscowtimes.com/2022/05/03/fir…](https://www.themoscowtimes.com/2022/05/03/fire-hits-russian-publisher-embroiled-in-ukraine-textbook-controversy-a77563)

I don't think things were going well for the book [[../fire|burning]] Prosveshchenie (enlightenment).

Last year Sberbank, VEB & sovereign wealth fund RDIF bought 75% of it at 25% each.

[reuters.com/article/us-rus…](https://www.reuters.com/article/us-russia-prosveshchenie-idUSKCN2CZ26C)

I can't find it now, but I think there was another Russian text book publisher on [[../fire|fire]] about a month ago.

I'll add it as I can find it.

[[../fire|Fire]] Sale?

May 3

Back to Tver. Several Russian trucks have been [[../fire|burned]].

This is recent so I'll post an update as I get it [twitter.com/nexta_tv/statu…](https://twitter.com/nexta_tv/status/1521416166786404354)

> ![[assets/1891490382-hL4PN7Hf_normal.jpg]]  
> NEXTA ([@nexta_tv](https://twitter.com/nexta_tv)) - 2022-05-03
>
>
> In [#Russian](https://twitter.com/hashtag/Russian) [#Tver](https://twitter.com/hashtag/Tver) , 38 trucks burned overnight at the parking lot. [pic.twitter.com/pjFFGl5o8e](https://twitter.com/nexta_tv/status/1521416166786404354/photo/1)
>

![[assets/3_1521416103444025344.jpg]]

>

![[assets/3_1521416119537610753.jpg]]

>

![[assets/3_1521416120124719106.jpg]]

May 3

33,800 sq meter warehouse suspected to contain paper products is on [[../fire|fire]].

Location: Kudinovskoye Highway in district of [[../Maps/Bogorodsky city district, Moscow Oblast, Central Federal District, Russia|Bogorodsky]] In [[../Maps/Moscow, Central Federal District, Russia|Moscow]] region

100 people & 33 pieces of equipment involved

[world-today-news.com/in-the-suburbs…](https://www.world-today-news.com/in-the-suburbs-a-strong-fire-broke-out-in-a-huge-warehouse-mir-tsn-ua/)

[express.co.uk/news/world/160…](https://www.express.co.uk/news/world/1604413/russia-fire-vladimir-putin-news-industrial-building-Bogorodsky-moscow-oblast-latest)

Possible geolocation of the May 3 Prosveshchenie textbook warehouse [[../fire|fire]].

Can anyone confirm? [twitter.com/FlippinCoin/st…](https://twitter.com/FlippinCoin/status/1521495078203797504)

> ![[assets/2285942653-default_profile_normal.png]]  
> Flippin Coin ([@FlippinCoin](https://twitter.com/FlippinCoin)) - 2022-05-03
>
>
> [@KevinRothrock](https://twitter.com/KevinRothrock) [@EliotHiggins](https://twitter.com/EliotHiggins) This could be the geolocation: Svetofor Warehouse, a large discount chain that has expanded to Europe. As of Dec 2019 its network comprised approximately 1,400 locations. A number of [[../fire|fires]] appear to be active.  
> [firms.modaps.eosdis.nasa.gov/map/#t:adv;m:a…](https://firms.modaps.eosdis.nasa.gov/map/#t:adv;m:advanced;d:2022-05-02..2022-05-03;l:viirs,country-outline;@38.3,55.8,14z) [pic.twitter.com/YRN3YZKobA](https://twitter.com/FlippinCoin/status/1521495078203797504/photo/1)
>

![[assets/3_1521494107641819138.jpg]]

>

![[assets/3_1521494253339385856.jpg]]

Update on sabotaged [[../Maps/Kursk, Kursk Oblast, Central Federal District, 305000, Russia|Kursk]] railway bridge:

Russia states the bridge is rebuilt…that was fast. 🤔

This bridge is a key link to move supplies to Russian troops in Ukraine

[apnews.com/article/russia…](https://apnews.com/article/russia-ukraine-business-europe-sabotage-12d80456da90c8c42840f28319bace18)

May 4

[[../fire|Burning]] railway tanks in Dzerzhinsk [Nizhny Novgorod].

According to emergency services, 55 people & 17 teams are working to contain the [[../fire|fire]].

[eprimefeed.com/latest-news/th…](https://eprimefeed.com/latest-news/the-fire-area-in-the-dzerzhinsk-industrial-zone-has-reached-2000-square-meters/78082/)

May 4

Cars belonging to employees of the FSB Special Purpose Center in the [[../Maps/Moscow, Central Federal District, Russia|Moscow]] Region are on [[../fire|fire]].

Thanks [@fascinatorfun](https://twitter.com/fascinatorfun) for the heads up! [twitter.com/iponomarev/sta…](https://twitter.com/iponomarev/status/1521550921418878979)

> ![[assets/25461790-bKmU62SL_normal.jpeg]]  
> Илья Пономарев / Ілля Пономарьов ([@iponomarev](https://twitter.com/iponomarev)) - 2022-05-03
>
>
> Сегодня ночью горели машины, принадлежащие сотрудникам Центра специального назначения ФСБ в Московской области.
>
> Неужели в России началось партизанское движение? [pic.twitter.com/Ov7GrK5Pf4](https://twitter.com/iponomarev/status/1521550921418878979/video/1)

James created a useful map of the [[../fire|fires]] & explosions in Russia since May 2 [twitter.com/JamesSpackman/…](https://twitter.com/JamesSpackman/status/1521790878905479170)

> ![[assets/59583028-cUaIBk1l_normal.jpg]]  
> James Spackman ([@JamesSpackman](https://twitter.com/JamesSpackman)) - 2022-05-04
>
>
> [@theallineed](https://twitter.com/theallineed) Map of sabotage targets in Russia, as of May 2nd. [pic.twitter.com/Qdid2UuKpT](https://twitter.com/JamesSpackman/status/1521790878905479170/photo/1)
>

![[assets/3_1521790873511550976.jpg]]

May 3

According to Andrey Shipilov a mass strike of middle command & above is taking place within the troops in Russia.

Work is being sabotaged & orders are on hold.

This may be related to the recent ICBM crazy talk coming from Russia.

 [express.co.uk/news/world/160…](https://www.express.co.uk/news/world/1604029/Ukraine-live-vladimir-putin-russian-invasion-combat-ineffective-belgorod-mariupol-update)

The [[../fire|fires]] & explosions in Russia have triggered the first [[../air|air]] raid sirens in Russia since WWll.

Ukraine's response is "strategic ambiguity".

"If carried out by Ukraine, they represent acts of once nearly unimaginable audacity"

[nytimes.com/2022/04/30/wor…](https://www.nytimes.com/2022/04/30/world/europe/ukraine-russia-attack-denials.html)

By my count, we should start getting Russian [[../fire|fire]] & explosion reports in about 90 mins-two hours…

Let's see if I am right. [pic.twitter.com/5yakt0qSbW](https://twitter.com/VelvetBlade/status/1522128279397801984/photo/1)

May 4

Undescribed [[../fire|fire]] in [[../Maps/Kursk, Kursk Oblast, Central Federal District, 305000, Russia|Kursk]]. I will update with more info.

Thanks to [@TachankaKity](https://twitter.com/TachankaKity) for point out this happened within my target window. [twitter.com/DemeryUK/statu…](https://twitter.com/DemeryUK/status/1522168236275605504)

> ![[assets/19905143-auNyvDZU_normal.jpg]]  
> D.Emery ([@DemeryUK](https://twitter.com/DemeryUK)) - 2022-05-05
>
>
> Something's [[../fire|burning]] in [[../Maps/Kursk, Kursk Oblast, Central Federal District, 305000, Russia|Kursk]] - in Russia - quite what and precisely where is yet to be confirmed. [pic.twitter.com/MjSRTBaZqo](https://twitter.com/DemeryUK/status/1522168236275605504/video/1)

I started this thread for incidents April 22 onward. Belarus is absolutely in the mix.

If you see any [[../fire|fires]], explosions or sabotage of strategic targets in Belarus, please tap me in. [twitter.com/MotolkoHelp/st…](https://twitter.com/MotolkoHelp/status/1509915151562063882)

> ![[assets/1460377075882373121-bhkj9SAX_normal.jpg]]  
> Belarusian Hajun project ([@MotolkoHelp](https://twitter.com/MotolkoHelp)) - 2022-04-01
>
>
> ❗️Rail War: Belarusian partisans have committed at least 10 successful sabotages on the railway since the beginning of the war in Ukraine.
>
> This infographic shows the main events of the rail war over the past month.  
> 1/3 [pic.twitter.com/1Lfzjy5ScT](https://twitter.com/MotolkoHelp/status/1509915151562063882/video/1)

May 6

Back to Dzerzhinsk.

Explosion of rail tankers carrying solvents.

Area ~2500 sq meters or almost 27,000 sq feet.

Thanks [@JamesSpackman](https://twitter.com/JamesSpackman) for finding this

[express.co.uk/news/world/160…](https://www.express.co.uk/news/world/1606228/Russia-chemical-plant-fire-explosion-Dzerzhinsk-factory-Ukraine-war-attack-latest-Putin)

May 6

Vicalina market in Vladikavkaz is on [[../fire|fire]]

This is very close to Georgia - North Ossetia-Alania & a major transport hub with the North Caucus railway.

South Ossetia is the lands Russia invaded in Georgia much like Crimea & Donsk.

H/T [@JamesSpackman](https://twitter.com/JamesSpackman) [pic.twitter.com/qYa3HpsK6m](https://twitter.com/VelvetBlade/status/1522543995573866496/photo/1) [twitter.com/nexta_tv/statu…](https://twitter.com/nexta_tv/status/1522507766165913602)

![[assets/3_1522543978456838146.jpg]]

> ![[assets/1891490382-hL4PN7Hf_normal.jpg]]  
> NEXTA ([@nexta_tv](https://twitter.com/nexta_tv)) - 2022-05-06
>
>
> The Vicalina market in [#Vladikavkaz](https://twitter.com/hashtag/Vladikavkaz) , [#Russia](https://twitter.com/hashtag/Russia) is on fire. [pic.twitter.com/LqqFXTdfTr](https://twitter.com/nexta_tv/status/1522507766165913602/video/1)

Ongoing:

Feminist [[../anti-war|Anti-War]] Resistance leaves messages around Russia to bring home the reality of the war on Ukraine.

It may not be a [[../fire|fire]] or explosion, but it is definitely a strategic target & sabotage.

[@femagainstwar](https://twitter.com/femagainstwar)

[haaretz.com/world-news/eur…](https://www.haaretz.com/world-news/europe/.premium.HIGHLIGHT.MAGAZINE-russian-women-are-leading-the-underground-protest-against-putin-s-war-1.10770456)

April 30

Crisis Management Center of the Ministry of Emergencies of Russia

-2539 man-made [[../fire|fires]]
- 62 explosive objects

Not all of these will be sabotage but it is worth digging through

[en.mchs.gov.ru/for-mass-media…](https://en.mchs.gov.ru/for-mass-media/operativnaya-informaciya/4735482)

May 6

Russians go to their dachas to unwind.

Khakassia is in Eastern [[../Siberian Federal District|Siberia]]. It borders [[../Maps/Krasnoyarsk, Krasnoyarsk Urban Okrug, Krasnoyarsk Krai, Siberian Federal District, 660000, Russia|Krasnoyarsk]] Krai where we saw earlier activity.

Industry: coal & ore mining and timber [twitter.com/nexta_tv/statu…](https://twitter.com/nexta_tv/status/1522538889386278915)

> ![[assets/1891490382-hL4PN7Hf_normal.jpg]]  
> NEXTA ([@nexta_tv](https://twitter.com/nexta_tv)) - 2022-05-06
>
>
> Dacha communities in [#Khakassia](https://twitter.com/hashtag/Khakassia) , [#Russia](https://twitter.com/hashtag/Russia) are [[../fire|burning]]. The fire covered 225 hectares, and [[../aircraft|helicopters]] were brought in to extinguish it. [pic.twitter.com/ITCtNUeFAq](https://twitter.com/nexta_tv/status/1522538889386278915/video/1)

April 23

I missed this one

Governor of the [[../Maps/Moscow, Central Federal District, Russia|Moscow]] Region Andrei Vorobyov's house caught on [[../fire|fire]]

No one was home & no one was hurt

[ruscrime.com/politics/in-ba…](https://www.ruscrime.com/politics/in-barvikha-the-house-of-the-governor-of-the-moscow-region-andrey-vorobyov-is-on-fire/) [pic.twitter.com/WE1RHD7Z0b](https://twitter.com/VelvetBlade/status/1522571768438812672/photo/1)

![[assets/3_1522571749103079425.jpg]]

![[assets/3_1522571749170106369.jpg]]

.[@Newsweek](https://twitter.com/Newsweek) put out a fairly good list but despite stating it was "every [[../fire|fire]]" they missed a lot.

Since April 22 there have been over 40 strategic [[../fire|fires]] & explosions in Russia.

[newsweek.com/every-mysterio…](https://www.newsweek.com/every-mysterious-fire-break-out-russia-recently-full-list-1704100)

May 2 & 3  
[@itarmyofukraine](https://twitter.com/itarmyofukraine) DDoS attack of system where all [[../Alcohol Distribution Disruption|alcohol]] producers & distributors must register shipments

I'm not covering the vast number of cyber attacks, hacks, scrapes & leaks, but it's a good reminder effective sabotage comes in many forms

[hackread.com/ddos-attacks-h…](https://www.hackread.com/ddos-attacks-hacktivist-disrupt-russia-alcohol-supply/)

Ongoing

This is not sabotage inside Russia, but I add it because there are unconfirmed reports that the mid-range officers & above still in Russia are delaying & sabotaging orders.

If that is accurate, Russia is on the way to defeating itself.

[thedailybeast.com/intercepted-ca…](https://www.thedailybeast.com/intercepted-calls-catch-russian-troops-sabotaging-vladimir-putins-war-plans-by-breaking-tanks)

Some of these events took place in [[../Maps/Kursk, Kursk Oblast, Central Federal District, 305000, Russia|Kursk]].

[[../Maps/Kursk, Kursk Oblast, Central Federal District, 305000, Russia|Kursk]] may be the home of a torture & indoctrination camp for Ukrainians kidnapped from Ukraine by Russia. [twitter.com/JackDetsch/sta…](https://twitter.com/JackDetsch/status/1522680693402349574)

> ![[assets/785237870-EuSuuTqD_normal.jpg]]  
> Jack Detsch ([@JackDetsch](https://twitter.com/JackDetsch)) - 2022-05-06
>
>
> Another possible May 9th tie-in:
>
> Ukraine’s Ombudswoman for Human Rights Lyudmila Denisova said this week Ukrainians in Russian captivity had been shipped to the city of [[../Maps/Kursk, Kursk Oblast, Central Federal District, 305000, Russia|Kursk]], where they were tortured and forced to learn Russian patriotic songs.

Amazing investigation by [@deankirby_](https://twitter.com/deankirby_) finding 66 camps in Russia where Ukrainians are being held & uncovering a grassroots network helping them escape & cross the border.

[inews.co.uk/news/putin-mar…](https://inews.co.uk/news/putin-mariupol-survivors-remote-corners-russia-investigation-network-camps-1615516)

May 8

According to local media, a construction site for the aviation technical school in [[../Maps/Perm, Perm Krai, Volga Federal District, Russia|Perm]] is [[../fire|burning]].

A few days ago the [[../Maps/Perm, Perm Krai, Volga Federal District, Russia|Perm]] Powder plant was on fire. [twitter.com/antiputler_new…](https://twitter.com/antiputler_news/status/1523279184369381378)

> ![[assets/1258468662916374528-nxEQGshg_normal.jpg]]  
> Аслан ([@antiputler_news](https://twitter.com/antiputler_news)) - 2022-05-08
>
>
> россия снова горит🔥
>
> Местные СМИ сообщают о пожаре в Перми. Говорят, что на этот раз полыхает на стройке авиатехникума [pic.twitter.com/o7VrTgcEtN](https://twitter.com/antiputler_news/status/1523279184369381378/video/1)

It's nice to see Russia taking the raging [[../fire|fires]] in [[../Siberian Federal District|Siberia]] seriously.

Those [[../fire|fires]] are made worse by climate change, increased heat and [[../fire|fire]] storms from high winds. Also the troops that normally fight these [[../fire|fires]] have been sent to Ukraine…along with their equipment. [twitter.com/VelvetBlade/st…](https://twitter.com/VelvetBlade/status/1523305693851561985)

> ![[assets/1131037589165658112-8RGoUMyN_normal.jpg]]  
> VelvetBIade 🧃 ([@VelvetBlade](https://twitter.com/VelvetBlade)) - 2022-05-08
>
>
> [@StillDelvingH](https://twitter.com/StillDelvingH) Putin has the [[../fire|fires]] under control. He's buying a [[../fire|fire]] door and one [[../aircraft|helicopter]] with crew to fight them…🤔 [pic.twitter.com/ptpGQeSO4t](https://twitter.com/VelvetBlade/status/1523305693851561985/photo/1)
>

![[assets/3_1523305660246822915.jpg]]

>

![[assets/3_1523305662058754049.jpg]]

May 8

Severe wild [[../fire|fire]] in Uyar, [[../Maps/Krasnoyarsk, Krasnoyarsk Urban Okrug, Krasnoyarsk Krai, Siberian Federal District, 660000, Russia|Krasnoyarsk]]. Currently 16 [[../fire|fires]] in [[../Maps/Krasnoyarsk, Krasnoyarsk Urban Okrug, Krasnoyarsk Krai, Siberian Federal District, 660000, Russia|Krasnoyarsk]] attributed by Russia to downed power lines & wind.

Likely not sabotage but included because the people are very angry by lack of response.

[bb-cntv.com/news/the-fire-…](https://bb-cntv.com/news/the-fire-in-the-city-of-uyar-in-the-krasnoyarsk-territory-was-localized-41379/) [pic.twitter.com/vZABfC04ey](https://twitter.com/VelvetBlade/status/1523413441742249984/photo/1)

![[assets/3_1523413412524752896.jpg]]

![[assets/3_1523413412520538113.jpg]]

May 8

[[../Maps/Krasnoyarsk, Krasnoyarsk Urban Okrug, Krasnoyarsk Krai, Siberian Federal District, 660000, Russia|Krasnoyarsk]] region [[../fire|fires]] - Local branch of Russia's Investigative Committee launched criminal proceedings for causing death by negligence. This seems to conflict with other statements that the [[../fire|fires]] were caused by wind downing power lines.

[france24.com/en/europe/2022…](https://www.france24.com/en/europe/20220507-some-300-firefighters-battling-deadly-blazes-in-russia-s-siberia)

May 8 Update on [[../Maps/Krasnoyarsk, Krasnoyarsk Urban Okrug, Krasnoyarsk Krai, Siberian Federal District, 660000, Russia|Krasnoyarsk]] [[../fire|fires]]

A lot of conflicts in statements

Federal Forestry Agency said short circuits in power lines had caused 350 houses to catch [[../fire|fire]], and that strong winds had exacerbated the situation

[france24.com/en/europe/2022…](https://www.france24.com/en/europe/20220507-some-300-firefighters-battling-deadly-blazes-in-russia-s-siberia)

May 8

West of [[../Maps/Krasnoyarsk, Krasnoyarsk Urban Okrug, Krasnoyarsk Krai, Siberian Federal District, 660000, Russia|Krasnoyarsk]], Kemerovo also launched criminal proceedings regarding the [[../fire|fires]] & that the true cause remains unknown and part of the criminal investigation.

[france24.com/en/europe/2022…](https://www.france24.com/en/europe/20220507-some-300-firefighters-battling-deadly-blazes-in-russia-s-siberia) [pic.twitter.com/4N9FfimfQY](https://twitter.com/VelvetBlade/status/1523419157223833600/photo/1)

![[assets/3_1523419132351623168.jpg]]

May 8

Another conscription office is pelted with Molotov cocktails in Cherepovets. Nearby is the Cherepovets Higher Military Engineering College of Radio Electronics.

Destruction of paper records interferes with conscription & payment to family upon death.

Thx [@StillDelvingH](https://twitter.com/StillDelvingH) [pic.twitter.com/3N3TKimBJC](https://twitter.com/VelvetBlade/status/1523427790724698117/photo/1)

![[assets/3_1523427752879472640.jpg]]

A comprehensive list of potential sabotage within Russia & other acts of civil disobedience. [twitter.com/PucksReturn/st…](https://twitter.com/PucksReturn/status/1523134594979332098)

A story in 4 maps

-hometown of dead Russian soldiers
-2 places where wildfires rage because of manpower & [[../fire|fire]] equipment moved to Ukraine
-Camps kidnapped Ukrainians are sent to

How long will the caucuses comply?

[google.com/mymaps/viewer?…](https://www.google.com/mymaps/viewer?mid=1TJ8zbdzBV-Q5_WYUEtV13QGOL9LF8nbQ&hl=en_GB) [pic.twitter.com/SgrhCcxSlx](https://twitter.com/VelvetBlade/status/1523453272186441729/photo/1)

![[assets/3_1523453241442586625.jpg]]

![[assets/3_1523453241442594816.jpg]]

![[assets/3_1523453243212570624.jpg]]

![[assets/3_1523453243225153536.jpg]]

Update on the Cherepovets conscript office [[../fire|fire]]:

This is the 7th military recruitment office to meet Molotov cocktails

Journalist Andrei Tsaplienko reports that people are [[../fire|burning]] their military registration papers. [twitter.com/AmplifyUkraine…](https://twitter.com/AmplifyUkraine/status/1523550994734399488)

> ![[assets/1513885766937632770-ecX2qxAU_normal.jpg]]  
> AmplifyUkraine ([@AmplifyUkraine](https://twitter.com/AmplifyUkraine)) - 2022-05-08
>
>
> Military enlistment offices are on [[../fire|fire]] in Russia
>
> Details: “Last night several Molotov cocktails were thrown at the Cherepovets station. Pravda Gerashchenko  
> [amplifyukraine.eu/military-enlis…](https://amplifyukraine.eu/military-enlistment-offices-are-on-fire-in-russia-details-last-night-several-molotov-cocktails-were-thrown-at-the-cherepovets-station-pravda-gerashchenko-2/)

[[../All Satellite TV Channels Hacked|May 9]]

On Russia's [[../All Satellite TV Channels Hacked|Victory Day]], [[../All Satellite TV Channels Hacked|TV]] boxes were hacked to show the following message to Russians:

You kill children in Ukraine.

😮 [twitter.com/VelvetBlade/st…](https://twitter.com/VelvetBlade/status/1523560662617665536)

> ![[assets/1131037589165658112-8RGoUMyN_normal.jpg]]  
> VelvetBIade 🧃 ([@VelvetBlade](https://twitter.com/VelvetBlade)) - 2022-05-09
>
>
> [[../All Satellite TV Channels Hacked|May 9]], instead of parade coverage, all Russian satellite [[../All Satellite TV Channels Hacked|TV]] shows had this message:
>
> You have the blood of Ukrainian children on your hands [twitter.com/AmplifyUkraine…](https://twitter.com/AmplifyUkraine/status/1523551510482886657)
>

> ![[assets/1513885766937632770-ecX2qxAU_normal.jpg]]  
> AmplifyUkraine ([@AmplifyUkraine](https://twitter.com/AmplifyUkraine)) - 2022-05-08
>
>
> You have the blood of Ukrainian children on your hands–Russians were forced to face the truth on [[../All Satellite TV Channels Hacked|May 9]]
>
> Details: In Russia, this line ap Pravda Gerashchenko  
> [amplifyukraine.eu/you-have-the-b…](https://amplifyukraine.eu/you-have-the-blood-of-ukrainian-children-on-your-hands-russians-were-forced-to-face-the-truth-on-may-9-details-in-russia-this-line-ap-pravda-gerashchenko-2/)

[[../All Satellite TV Channels Hacked|May 9]]

Legion of Free Russia movement operates with in Russia - the sabotage recorded in this thread.

Pay in the military is so low Russia sends troops from poor regions.

- Advisor to the President of Ukraine [@arestovych](https://twitter.com/arestovych)

Found through [@AmplifyUkraine](https://twitter.com/AmplifyUkraine)

[world.segodnya.ua/world/russia/a…](https://world.segodnya.ua/world/russia/arestovich-v-rossii-razvernulos-dvizhenie-protiv-putina-legion-svobody-1619822.html?pathinfo=/ru/world/russia/arestovich-v-rossii-razvernulos-dvizhenie-protiv-putina-legion-svobody-1619822.html)

[[../All Satellite TV Channels Hacked|May 9]]

Russian Ambassador to Poland has red paint poured on him as he visits the graves of Soviet soldiers on Russia's [[../All Satellite TV Channels Hacked|Victory Day]]

While this does not fit my criteria of within Russia or Belarus, it is an import act of civil protest.

[world.segodnya.ua/world/russia/p…](https://world.segodnya.ua/world/russia/pozdravili-s-9-maya-v-polshe-posla-rf-oblili-krasnoy-kraskoy-video-1619783.html?pathinfo=/ru/world/russia/pozdravili-s-9-maya-v-polshe-posla-rf-oblili-krasnoy-kraskoy-video-1619783.html)

Update on Russian [[../All Satellite TV Channels Hacked|TV]] hack with "Ukrainian children's blood on your hands" message to Russians.

Other targets included:

-smart [[../All Satellite TV Channels Hacked|TVs]]  
-internet cos like Yandex  
-Rutube - Russia's YouTube

[finance.yahoo.com/news/russia-sm…](https://finance.yahoo.com/news/russia-smart-tv-hack-202422488.html)

May 10

Belgorod, which borders Ukraine and has been experiencing explosions & [[../fire|fires]], has been put on "yellow" terrorist alert.

Russia is using this to claim Ukraine has attacked them. Maybe they have…Maybe they haven't…

[amplifyukraine.eu/%F0%9F%98%81-a…](https://amplifyukraine.eu/%F0%9F%98%81-a-yellow-level-of-terrorist-danger-has-been-introduced-in-the-belgorod-region-of-the-russian-federation-bordering-ukraine-subscri-zn-ua-%D0%B7%D0%B5%D1%80%D0%BA%D0%B0%D0%BB-2/) [pic.twitter.com/GXx3W9l32h](https://twitter.com/VelvetBlade/status/1524276783977226242/photo/1)

![[assets/3_1524276770115137538.jpg]]

Ongoing

Ex-regime operatives Belarus Flying Storks continue partisan sabotage on Russian logistics, infrastructure & facilities in Russia & Belarus to slow/stop military routes to Ukraine in Belgorod, Bryansk, Voronezh, Kaluga, Saratov and Ryazan regions

[m.youtube.com/watch?v=qih4FS…](https://m.youtube.com/watch?v=qih4FSvDBBM) [pic.twitter.com/l0vwx4ZOMC](https://twitter.com/VelvetBlade/status/1524503079273512961/photo/1)

![[assets/3_1524503060755660806.jpg]]

![[assets/3_1524503060759863299.jpg]]

![[assets/3_1524503060801892352.jpg]]

![[assets/3_1524503060797603844.jpg]]

Flying Storks part of hacktivist consortium = gained access to all Belarus' gov systems

Goals:  
-preserve independence & sovereignty of Belarus  
-oust Lukashenko  
-democratic principles of governance

They R kicka55

[@PucksReturn](https://twitter.com/PucksReturn) [@ProjHastings](https://twitter.com/ProjHastings) ^^ 2 up  
[en.currenttime.tv/a/seeking-chan…](https://en.currenttime.tv/a/seeking-change-anti-lukashenka-hackers-seize-senior-belarusian-officials-personal-data-/31392092.html)

Belarus' People's Self Defense Squad (PPS) have railway tutorials…

Blocking rail traffic course [t.me/dns_chat/13268](https://t.me/dns_chat/13268)

May 12

Explosion in a powder warehouse in Khabarovsk Krai. Russian sources state this was due to "mishandling explosives".

Located in Russia's subarctic far east & shared border with China.

Industry:  
military [[../aircraft|aircraft]], shipbuilding & oil refining

 [ria.ru/20220512/vzryv…](https://ria.ru/20220512/vzryv-1788053221.html) [pic.twitter.com/72N1FSjCnP](https://twitter.com/VelvetBlade/status/1524882554070917125/photo/1)

![[assets/3_1524882540204548119.jpg]]

![[assets/3_1524882540275851280.jpg]]

May 12  
Update on explosion in powder warehouse

Warehouse located at a military base in Teysin, Khabarovsk. There are four military bases in this area.

Explosion happened during unloading munitions & sparked a large blaze. Soldiers killed & injured.

[tifnews.com/world/russia/1…](https://tifnews.com/world/russia/1-dead-7-injured-in-russia-military-base-explosion-the-moscow-times/) [pic.twitter.com/hpYL4aCXJi](https://twitter.com/VelvetBlade/status/1524887371610742790/photo/1)

![[assets/3_1524887343576014869.jpg]]

![[assets/3_1524887343647301632.jpg]]

![[assets/3_1524887343630540816.jpg]]

May 10

[[../fire|Fire]] broke out on Turkish cargo ship anchored off Temryuk Port on the Russian side of Azov Sea.

Likely Turkish freighter AKUA

Reports [[../fire|fire]] started on bridge & knocked out AIS systems (ship tracking) 🙄

Why is a Turkish freighter here?

[maritimebulletin.net/2022/05/10/fir…](http://www.maritimebulletin.net/2022/05/10/fire-on-board-of-turkish-ship-azov-sea-russia/) [pic.twitter.com/IDSspleZFg](https://twitter.com/VelvetBlade/status/1524895852858429440/photo/1)

![[assets/3_1524895837847011328.jpg]]

May13

Molotov [[../fire|fire]] at Russian enlistment office in [[../Maps/Omsk, Omsk Oblast, Siberian Federal District, 644000, Russia|Omsk]] on Pushkin Street, 78. I have not been able to geolocate this despite the address.

[[../Maps/Omsk, Omsk Oblast, Siberian Federal District, 644000, Russia|Omsk]] is a major transit hub on the [[../Maps/Monument to the 170th anniversary of the Trans-Siberian Railway, улица Леконта, Привокзальный, Ленинский административный округ, Omsk, Omsk Oblast, Siberian Federal District, 644000, Russia|Trans Siberian railway]] & primary industry is tank production.

[tayga.info/177521](https://tayga.info/177521)

May 12

Occupied Transnistria - molotov attacks on Russian registration/enlistment office & an oil depot.

Both appear unsuccessful.

We have to be careful with news about Transnistria. There are massive Russian efforts to false flag threats. [twitter.com/nexta_tv/statu…](https://twitter.com/nexta_tv/status/1524981272388505608)

> ![[assets/1891490382-hL4PN7Hf_normal.jpg]]  
> NEXTA ([@nexta_tv](https://twitter.com/nexta_tv)) - 2022-05-12
>
>
> Authorities in unrecognized [#Transnistria](https://twitter.com/hashtag/Transnistria) report an attempted [[../fire|arson]] with a Molotov cocktail at a military recruitment center and an oil depot last night. [pic.twitter.com/NRyiNYkyLu](https://twitter.com/nexta_tv/status/1524981272388505608/photo/1)
>

![[assets/3_1524981172417269766.jpg]]

May 13

[[../fire|Fire]] at SinTZ, Sinarsky Pipe Works in [[../Maps/Kamensk-Uralsky, городской округ Каменск-Уральский, Sverdlovsk Oblast, Ural Federal District, 623428, Russia|Kamensk-Uralsky]], Sverdlovsk Oblast

One of the biggest specialty producers in Russia, SinTZ manufactures steel & cast iron pipes w/ 3,000+ contracts per yr.

Sverdlovsk elsewhere produces semi-conductors.

[twitter.com/tolomeonews/st…](https://twitter.com/tolomeonews/status/1525139692815011844?s=21&t=cL1FUEDsgAFxtfENWW764w) [pic.twitter.com/1zeUuytmHU](https://twitter.com/VelvetBlade/status/1525170027028045824/photo/1)

![[assets/3_1525170012549439488.jpg]]

> ![[assets/808992203238424576-OnJR0eiV_normal.jpg]]  
> Tolomeo 🇪🇸 🇺🇦 ([@TolomeoNews](https://twitter.com/TolomeoNews)) - 2022-05-13
>
>
> [#Russia](https://twitter.com/hashtag/Russia) : In [[../Maps/Kamensk-Uralsky, городской округ Каменск-Уральский, Sverdlovsk Oblast, Ural Federal District, 623428, Russia|Kamensk-Uralsky]], Sverdlovsk region, a [[../fire|fire]] on Sinarsky pipeline plant.
>
> According to the Ministry of Emergency Situations, the building and the roof of the factory are on [[../fire|fire]]. The [[../fire|fire]] area reached 800 square meters. [pic.twitter.com/b97EtdlNgD](https://twitter.com/i/status/1525068664294232067/video/1)

May 13

The cause of this may be faulty wiring but I am including due to the next tweet.

A 2-story cultural building in Irkutsk at Krasnoarmejska 4B is ablaze & spread to Young Viewer Theatre.

Building was empty & [[../fire|fire]] is difficult to contain. [twitter.com/TWMCLtd/status…](https://twitter.com/TWMCLtd/status/1525123225218342912)

> ![[assets/268385416-Jkc0Lk2a_normal.jpeg]]  
> Tim White ([@TWMCLtd](https://twitter.com/TWMCLtd)) - 2022-05-13
>
>
> Another [[../fire|fire]] in [#Russia](https://twitter.com/hashtag/Russia) , and this one may be suspicious. Authorities have so far not given a reason for this blaze at an empty, but cultural heritage building in [#Irkutsk](https://twitter.com/hashtag/Irkutsk)
>
> It's next to a theatre in the city  
> [#RussiaOnFire](https://twitter.com/hashtag/RussiaOnFire) [#StandWithUkraine](https://twitter.com/hashtag/StandWithUkraine) [pic.twitter.com/MyPjzyd5MN](https://twitter.com/TWMCLtd/status/1525123225218342912/video/1)

May 13

Reported in Irkutsk - underground partisan paper "Free [[../Siberian Federal District|Siberia]]! Death to Katsapam" (anti-Russian slur) claims partisans disrupted a railway track by cutting circuit wires.

NOTE: There is no way to vet this information & attribution is spotty.

 [pic.twitter.com/Kady05uYt9](https://twitter.com/DailyTurkic/status/1524809989549850624/video/1)

NOTE to above tweet - "free [[../Siberian Federal District|Siberia]]! Death to Katsapam" may be a Russian info op to promote the narrative that Ukrainians murder Russians & justifying the war in a region not very supportive.

Katsapam=Ukrainian slur for Russians.

Partisan papers generally call for solidarity.

Update on report of partisan sabotage of railway in Irkutsk -

I may have had a translation error. It may not be cutting wires but jumping wires to create circuit blow out.

Please use caution with these assessments & attribution. See above Tweet why this report is suspect [twitter.com/vladKansanmurh…](https://twitter.com/vladKansanmurha/status/1525178740346585088)

> ![[assets/1510551101120077828-EvnNF-On_normal.jpg]]  
> Vladimir 'Kansanmurha' Putin ([@vladKansanmurha](https://twitter.com/vladKansanmurha)) - 2022-05-13
>
>
> [@VelvetBlade](https://twitter.com/VelvetBlade) AFAIK idea is short circuit two rail lines, no cutting wires. Somehow train interpreteds short circuit as stop. Not sure if [[../Siberian Federal District|siberian]] tracks are electrified, little odd

Update on Irkursk railway circuit short.

Videos did not circulate on Twitter until May 13th, it was reported verbatim twice on Telegram May 11 (RU Propaganda dashboard)

Flyers left at scene.

Still trying to establish if this is legit or Russian op.

[ruprop.live/source-seek-yo…](https://ruprop.live/source-seek-your-owntranslation-%E2%9D%97%EF%B8%8Fsiberian-partisans-in-the-irkutsk-region-they-stopped-a-train-with-the-help-of-wire-the-method-is-called-a-shorting-of-the-rail-circuit-the-2/) [pic.twitter.com/7j47QxdP14](https://twitter.com/VelvetBlade/status/1525242590861447168/photo/1)

![[assets/3_1525242574897913859.jpg]]

![[assets/3_1525242575011074054.jpg]]

![[assets/3_1525242574994296832.jpg]]

Map of the molotov attacks on conscription registration offices in Russia.

Several have [[../fire|burned]] in [[../fire|fire]], including paper documents that were stated not to be digitized. [pic.twitter.com/HnGTHacM0u](https://twitter.com/VelvetBlade/status/1525362705732882432/photo/1) [twitter.com/nexta_tv/statu…](https://twitter.com/nexta_tv/status/1525307630641680390)

![[assets/3_1525362692172787713.jpg]]

> ![[assets/1891490382-hL4PN7Hf_normal.jpg]]  
> NEXTA ([@nexta_tv](https://twitter.com/nexta_tv)) - 2022-05-13
>
>
> [[../All Satellite TV Channels Hacked|Television]] network RTVI published a map which shows where military commissariats in [#Russia](https://twitter.com/hashtag/Russia) were hit by Molotov cocktails within the last months. [pic.twitter.com/qFdOjorFCJ](https://twitter.com/nexta_tv/status/1525307630641680390/photo/1)
>

![[assets/3_1525307238746824704.jpg]]

May 15

Molotov at enlistment registration office near [[../Maps/Moscow, Central Federal District, Russia|Moscow]] in [[../Maps/Pronsk, Пронское городское поселение, Pronsky District, Ryazan Oblast, Central Federal District, Russia|Pronsk]], Ryazan. Attempt is reported as unsuccessful.

It sounds like door and windows caught [[../fire|fire]], but the office records are in tact.

[westobserver.com/news/europe/in…](https://westobserver.com/news/europe/in-the-ryazan-region-they-tried-to-set-fire-to-the-military-enlistment-office/) [pic.twitter.com/8GJ3O0NIuP](https://twitter.com/VelvetBlade/status/1525822300573995008/photo/1)

![[assets/3_1525822279170797570.jpg]]

May 14

The railway station in Belgorod on [[../fire|fire]] has been geolocated May 15

Belgorod is very near the Ukraine border.

[twitter.com/geoconfirmed/s…](https://twitter.com/geoconfirmed/status/1525823988122931200?s=21&t=-wjIyLX8NHyb9jp91RhLGw) [pic.twitter.com/J27xStPtnH](https://twitter.com/VelvetBlade/status/1525827823633477637/photo/1)

![[assets/3_1525827800544198657.jpg]]

> ![[assets/1499038738562920451-pwBSJ1up_normal.jpg]]  
> GeoConfirmed ([@GeoConfirmed](https://twitter.com/GeoConfirmed)) - 2022-05-15
>
>
> GeoConfirmed.
>
> "Fire near [#Belgorod](https://twitter.com/hashtag/Belgorod) Train Station, Russia"
>
> POV: 50.593006, 36.602231
>
> GeoLocated by [@neonhandrail](https://twitter.com/neonhandrail)
>
> [#GeoConfirmed](https://twitter.com/hashtag/GeoConfirmed) . [twitter.com/lilygrutcher/s…](https://twitter.com/lilygrutcher/status/1525518245150826496)
>

> ![[assets/89416857-9EUTFVLw_normal.png]]  
> Fuat ([@lilygrutcher](https://twitter.com/lilygrutcher)) - 2022-05-14
>
>
> Railway station in Belgorod in [[../fire|fire]], these minutes. [pic.twitter.com/cdfCU4uX2w](https://twitter.com/lilygrutcher/status/1525518245150826496/video/1)

May 15

Gloria Jeans/Gloriya/Gee Jay factory in Rostov-on-Don is on [[../fire|fire]].

Gloria ran 2 stores in Crimea & 5-7 factories in Russian-occupied DNR/LNR, paying almost half the wages in Russia or China.

Gloria paid DNR/LNR taxes but not Ukrainian taxes.

[bykvu.com/eng/thoughts/6…](https://bykvu.com/eng/thoughts/645/) [twitter.com/DemeryUK/statu…](https://twitter.com/DemeryUK/status/1525846716838207495)

> ![[assets/19905143-auNyvDZU_normal.jpg]]  
> D.Emery ([@DemeryUK](https://twitter.com/DemeryUK)) - 2022-05-15
>
>
> Another [[../fire|fire]] in Russia - this time at the Gloria Jeans factory in Rostov-on-Don; "manufacturer, suppliers and wholesale trader of apparel and garments" as they say. [pic.twitter.com/IdcLsnu1PN](https://twitter.com/DemeryUK/status/1525846716838207495/video/1)

May 14

Side note: Russia's getting desperate

Crimean health advocate who went missing April 29 after FSB searched her house & saying she passed info to an NGO, was found in an FSB basement tortured for a confession of explosives in her glass case.

[rferl.org/a/crimea-danyl…](https://www.rferl.org/a/crimea-danylovych-fsb-explosives-activist/31849449.html)

May 16

DM Tower Business Center on [[../Maps/Moscow, Central Federal District, Russia|Moscow]]'s Novodanilovskaya embankment is on [[../fire|fire]].

18-stories & under construction. [[../fire|Fire]] on the top floor according to a construction worker.

[news.italy-24.com/world/452031.h…](https://news.italy-24.com/world/452031.html)

May 16

A lacquer/varnish shop in Stroitel, Belgorod Region is on [[../fire|fire]]. Cause unknown.

It was empty at the time. Mention of "a metal container with thermal oil" which may be a translation mistake.

[thenewsglory.com/the-ministry-o…](https://thenewsglory.com/the-ministry-of-emergency-situations-spoke-about-the-fire-in-the-lacquer-production-shop-near-belgorod/)

May 17

Industrial building with office space at Khimzavodskaya Street, Berdsk near [[../Maps/Novosibirsk, Novosibirsk Oblast, Siberian Federal District, 630000, Russia|Novosibirsk]] in [[../Siberian Federal District|Siberia]] is on [[../fire|fire]] & damaged equipment.

State emergency services says polyethylene (very common plastic) is the source.

Unclear of origin.

[newsweek.com/russia-fire-be…](https://www.newsweek.com/russia-fire-berdsk-emergency-ministry-siberia-novosibirsk-1707193)

Excellent review of [[../fire|fires]] & explosions in Russia by [@MilAvHistory](https://twitter.com/MilAvHistory)

Keep in mind it's difficult to call these acts sabotage. We can catalog, wait for more data & make best-guess assessments.

I try to add references so you can investigate yourself.

[m.youtube.com/watch?v=dIGahE…](https://m.youtube.com/watch?v=dIGahE0sR9Y)

Update on railway car [[../fire|fire]]

It was a railway tanker containing unspecified solvents on the territory of the former chemical weapons factory Kaprolaktam, in Dzerzhinsk.

[express.co.uk/news/world/161…](https://www.express.co.uk/news/world/1611630/mystery-fire-russia-claims-ukraine-sabotage)

.[@douglaslondon5](https://twitter.com/douglaslondon5) posits that a sabotage campaign within Russia may be a double edged sword. Depending on how it is carried out, it may deter or it may solidify support.

Must also consider word spreads from demoralized troops to families to communities.

[foreignpolicy.com/2022/05/12/put…](https://foreignpolicy.com/2022/05/12/putin-russia-ukraine-sabotage-stop-putin-nuclear-option/)

May 18

Recruitment office in Shchelkovo near [[../Maps/Moscow, Central Federal District, Russia|Moscow]] is on [[../fire|fire]] from Molotov cocktails.

2 offices & commissariat archive are damaged.

[meduza.io/news/2022/05/1…](https://meduza.io/news/2022/05/18/v-rossii-vnov-popytalis-podzhech-voenkomat-kokteylyami-molotova-zabrosali-zdanie-schelkovskogo-voennogo-komissariata-v-podmoskovie) [pic.twitter.com/unNb329i9r](https://twitter.com/VelvetBlade/status/1527125896469041152/photo/1)

![[assets/3_1527125875627548675.jpg]]

Update on what seems to be the April 23 Molotov attack on the recruitment center in [[../Maps/Lukhovitsy, Lukhovitsky District, Moscow Oblast, Central Federal District, Russia|Lukhovitsy]].

The gate was painted like the Ukraine flag & the message "I will not go to kill my brothers" was also left.

[globalhappenings.com/top-global-new…](https://globalhappenings.com/top-global-news/119614.html)

Ukraine captured soldiers from a covert Russian mobilization effort. Attacks on registration offices seem to be in response.

VataHunters have taken credit for some of the Molotov [[../fire|fires]].

Destroying records stops the ability to mobilize.

[thereference-paris.com/19649](https://www.thereference-paris.com/19649)

May 19

Heavy machine tool plant in [[../Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] is on [[../fire|fire]].

The chemical plant [[../fire|fire]] from April 21 in Kinishma & a conscript registration office hit April 22 are nearby.

[dailykos.com/story/2022/5/1…](https://www.dailykos.com/story/2022/5/19/2098927/-Ivanovo-Heavy-Machine-Tool-Plant-is-the-Latest-Suspicious-Fire-at-a-Strategic-Site-in-Russia)

May 19

3 cars on [[../fire|fire]] from unknown cause also in [[../Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]], Russia.

Thanks [@TWMCLtd](https://twitter.com/TWMCLtd) for the spot. Tim is also keeping track of events. Give him a follow.

[ivteleradio.ru/news/2022/05/1…](https://ivteleradio.ru/news/2022/05/19/tri_avtomobilya_sgoreli_utrom_v_ivanove)

With the stroke of a pen frightened authoritarian Lukashenko (Belarus) adds the death penalty for attempted terrorismwith a "terrorist act" being a fluid definition.

This appears to be in response to the railway sabotage by Belarus [[../activism|activists]].

[dw.com/en/belarus-att…](https://www.dw.com/en/belarus-attempted-terrorism-to-be-punishable-by-death/a-61837461)

It's important to keep in mind the Caucuses have their own ethnic identities. Russia is sending a disproportionate amount of soldiers from there & they see Russia following an old ethnic cleansing playbook in Ukraine.

This creates friction…and opportunity. [twitter.com/VelvetBlade/st…](https://twitter.com/VelvetBlade/status/1527622917147836418)

> ![[assets/1131037589165658112-8RGoUMyN_normal.jpg]]  
> VelvetBIade 🧃 ([@VelvetBlade](https://twitter.com/VelvetBlade)) - 2022-05-20
>
>
> Circassia in the North Caucus region of Russia is set to clash with [[../Maps/Moscow, Central Federal District, Russia|Moscow]]. They had their lands & culture brutally stripped by Russia & are pro-Ukraine, seeing eerie parallels.
>
> [[../Maps/Moscow, Central Federal District, Russia|Moscow]] set up fake Circassian orgs to be pro-Russia but it's a lie. 😮
>
> [jamestown.org/program/tensio…](https://jamestown.org/program/tensions-between-moscow-and-circassians-reach-crisis-proportions/)

I took a bit of a hiatus. To catch up what I missed in between please check out threads by [@StillDelvingH](https://twitter.com/StillDelvingH) [@HarladF](https://twitter.com/HarladF) [@DemeryUK](https://twitter.com/DemeryUK) & [@TWMCLtd](https://twitter.com/TWMCLtd)

I'm back now 😉

June 3:  
Discontent within Russia grows for elite & political classes as well as PMCs.

Putin is not going to keep power. The fact that this is now openly discussed in Telegram channels is important. The effects of the war in Russia have been a disaster.

[nadinbrzezinski.medium.com/100-days-of-wa…](https://nadinbrzezinski.medium.com/100-days-of-war-discontent-is-growing-in-russia-b79563088a6b)

Russians keep protesting in Russia despite harsh crack downs.

- a street protest called Bucha-[[../Maps/Moscow, Central Federal District, Russia|Moscow]] shown on the Kholod journal Telegram channel
- The Feminist [[../anti-war|Anti-War]] Resistance placed 500+ grave markers in 50 Russian cities to protest Mariupol

[themoscowtimes.com/2022/04/05/rus…](https://www.themoscowtimes.com/2022/04/05/russian-activists-find-ways-to-protest-despite-the-bans-a77213) [pic.twitter.com/R04OhmHwuT](https://twitter.com/VelvetBlade/status/1538779988958142464/photo/1)

![[assets/3_1538779963121229825.jpg]]

![[assets/3_1538779963108626432.jpg]]

![[assets/3_1538779964551491584.jpg]]

![[assets/3_1538779964547342336.jpg]]

- In [[../Maps/Perm, Perm Krai, Volga Federal District, Russia|Perm]] (mentioned above in this thread) [[../activism|activists]] change grocery store prices to reflect the number killed in Ukraine from Russian bombings or actual war-related inflation numbers.

The very high prices come with a textual explanation.

[themoscowtimes.com/2022/04/05/rus…](https://www.themoscowtimes.com/2022/04/05/russian-activists-find-ways-to-protest-despite-the-bans-a77213) [pic.twitter.com/w5pPBG5s4Y](https://twitter.com/VelvetBlade/status/1538780011305771010/photo/1)

![[assets/3_1538779994951782401.jpg]]

![[assets/3_1538779994955972608.jpg]]

Moldova bans Russian war news and movies to counter propaganda.  
 According to NewsMaker, President Maia Sandu signed a law prohibiting the broadcasting of Russian news programs, political [[../All Satellite TV Channels Hacked|TV]] programs, and war movies in the country [twitter.com/propeertys/sta…](https://twitter.com/propeertys/status/1538635014480572417)

> ![[assets/1247260723480231939-xDwAYpYF_normal.jpg]]  
> ⬜️🟥⬜️#Belarus 🤍❤️🤍 ([@propeertys](https://twitter.com/propeertys)) - 2022-06-19
>
>
> ⚡️Mołdawia zakazuje rosyjskich wiadomości i filmów wojennych w celu przeciwdziałania propagandzie.  
> Według NewsMaker, prezydent Maia Sandu podpisała ustawę zakazującą nadawania rosyjskich programów informacyjnych, politycznych programów telewizyjnych i filmów wojennych w tym kraju

You know things aren't going well when Telegram decides to charge Russians…🤔

449 rubles (€7.54 / $7.94) a month

Side note: Russian intelligence uses Tele for people to submit Ukraine death list candidates & reporting Ukrainian troop movements.

[twitter.com/propeertys/sta…](https://twitter.com/propeertys/status/1538611221653557249?s=21&t=3vy69oJ7rWi5MTSgC4pZtg)

> ![[assets/1247260723480231939-xDwAYpYF_normal.jpg]]  
> ⬜️🟥⬜️#Belarus 🤍❤️🤍 ([@propeertys](https://twitter.com/propeertys)) - 2022-06-19
>
>
> Telegram wprowadził płatną subskrypcję za 449 rubli miesięcznie dla Rosjan 😂 [novayagazeta.eu/articles/2022/…](https://novayagazeta.eu/articles/2022/06/19/telegram-predstavil-platnuiu-podpisku-za-449-rublei-v-mesiats-news?utm_source=twitter.com&utm_medium=social&utm_campaign=telegram-predstavil-platnuyu-podpisku-za)

Anti-Russian sentiment over the illegal invasion of Ukraine leads to those within Russia to take action - including hackers.

In solidarity with Ukraine, a Ukrainian hacker inside Russian ransomware gang Conti leaked source code & malware.

[washingtonpost.com/opinions/2022/…](https://www.washingtonpost.com/opinions/2022/06/21/russia-ukraine-cyberwar-intelligence-agencies-tech-companies/)

June 22, 2022:

Explosion & [[../fire|fire]] at Novoshakhtinsk refinery in Russia's Rostov region allegedly from a suicide drone.

This is one S. Russia's largest refineries.

Original sources are Russian state.

[themoscowtimes.com/2022/06/22/maj…](https://www.themoscowtimes.com/2022/06/22/major-russian-oil-refinery-says-struck-by-ukrainian-drone-a78069)

23 June 2022 - Mystery cargo [[../aircraft|plane]] - no one knows which organization runs the [[../aircraft|plane]] - crash lands in Ryazan & catches [[../fire|fire]] killing 3, injuring 6.

[reuters.com/world/europe/c…](https://www.reuters.com/world/europe/cargo-plane-crash-lands-near-russias-ryazan-seven-injured-ifax-2022-06-24/) [pic.twitter.com/KDHYgW3mzk](https://twitter.com/VelvetBlade/status/1540178216425467904/photo/1)

![[assets/3_1540178185890893824.jpg]]

![[assets/3_1540178185895047168.jpg]]

23 June 2022:

A rare tornado hit Lazarevsky, [[../Maps/Krasnodar, Krasnodar Municipality, Krasnodar Krai, Southern Federal District, 350000, Russia|Krasnodar]] in Russia.

Even nature wants a piece of the action…[twitter.com/uasupport999/s…](https://twitter.com/uasupport999/status/1540112267047583747)

> ![[assets/1399327083617259521-e0t0H_Tm_normal.jpg]]  
> News from Ukraine ([@uasupport999](https://twitter.com/uasupport999)) - 2022-06-23
>
>
> Residents of Lazarevsky, in the [[../Maps/Krasnodar, Krasnodar Municipality, Krasnodar Krai, Southern Federal District, 350000, Russia|Krasnodar]] Territory in [#Russia](https://twitter.com/hashtag/Russia) , were frightened by a large tornado, which, according to local residents, was formed for the first time in these parts, scaring locals & visitors.
>
> We suspect that even nature is upset with [#Putin](https://twitter.com/hashtag/Putin) ’s Russia 🤔😅 [pic.twitter.com/AcHWhlWrld](https://twitter.com/uasupport999/status/1540112267047583747/photo/1)
>

![[assets/3_1540112255521624066.jpg]]

Video of the 23 June cargo [[../aircraft|plane]] explosion & [[../fire|fire]] in Ryazan near [[../Maps/Moscow, Central Federal District, Russia|Moscow]].

It was ablaze before touchdown. Amazing only 3 of the 9 passengers perished.

 [pic.twitter.com/UWuRx3Xtzg](https://twitter.com/Flash43191300/status/1540288069949177863/video/1)

Russian self-sabotage…

Thx [@richbyrne11](https://twitter.com/richbyrne11) [twitter.com/RALee85/status…](https://twitter.com/RALee85/status/1540214406549749766)

> ![[assets/4107939250-Y6ce6atF_normal.jpg]]  
> Rob Lee ([@RALee85](https://twitter.com/RALee85)) - 2022-06-23
>
>
> This is reportedly footage of a failed Russian [[../air|air]] defense system missile launch from Alchevsk, Luhansk Oblast.  
> [t.me/faceofwar/20692](https://t.me/faceofwar/20692) [pic.twitter.com/DvHf1heAR8](https://twitter.com/RALee85/status/1540214406549749766/video/1)

June 23/24, 2022  
 4 Molotov cocktails thrown at the office of the Military Commissariat for [[../Maps/Kirovsky District, Stavropol Krai, North Caucasian Federal District, Russia|Kirovsky District]] in Zakamskaya Street in [[../Maps/Perm, Perm Krai, Volga Federal District, Russia|Perm]].

2 did not smash.

Investigation is ongoing.

[t.me/bazabazon/12117](https://t.me/bazabazon/12117)

June 23/24, 2022:

Belgorod enlistment office in room 106 started a small [[../fire|fire]] lobbing a couple Molotov cocktails through a broken window.

[theins.ru/en/news/252560](https://theins.ru/en/news/252560)

Here are a few more enlistment office attacks - some before this thread was started.

-May 20, 2022: military enlistment office - shot at with pneumatic weapons in Zheleznogorsk-Ilimsky in [[../Maps/Irkutsk Oblast, Siberian Federal District, Russia|Irkutsk Region]]

[theins.ru/news/251440](https://theins.ru/news/251440)

-May 21, 2022: recruitment office in Igra in Udmurtia - Molotov

[theins.ru/news/251473](https://theins.ru/news/251473)

Feb 28, 2022: 1st recruitment office hit with Molotov cocktails in [[../Maps/Lukhovitsy, Lukhovitsky District, Moscow Oblast, Central Federal District, Russia|Lukhovitsy]] near [[../Maps/Moscow, Central Federal District, Russia|Moscow]].

Other Russian military enlistment offices Molotoved:

-[[../Maps/Omsk, Omsk Oblast, Siberian Federal District, 644000, Russia|Omsk]]  
-Balashikha  
-Yаroslavl  
-Nizhnevartovs  
-Voronezh  
-[[../Maps/Beryozovsky, Берёзовский городской округ, Sverdlovsk Oblast, Ural Federal District, 623700, Russia|Berezovsky]]  
-Shuya  
-Gukovo  
-Volgograd  
-Zubova Polyana  
-[[../Maps/Pronsk, Пронское городское поселение, Pronsky District, Ryazan Oblast, Central Federal District, Russia|Pronsk]]  
-Cherepovets  
-[[../Maps/Penza, Penza Oblast, Volga Federal District, 4400XX, Russia|Penza]]: abandoned enlistment office  
-[[../Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]]: abandoned enlistment office

More Molotoved Russian recruitment offices:

-Sverdlovsk  
-Rostov Region (May overlap a city above)

May 19, 2022 Oleksiy Gromov, Deputy Chief, Main Operations of the General Staff of the Armed Forces of Ukraine counted 12 enlistment offices targeted.

[newsweek.com/russians-setti…](https://www.newsweek.com/russians-setting-fire-military-enlistment-offices-reports-1708349)

1000+ Russian soldiers & members of the National Guard from 7+ regions refused go to Ukraine

-Lawyer Pavel Chikov, Agora

20-40% percent of ‘contract’ soldiers refuse to return to combat.

-Ruslan Leviyev, Conflict Intelligence Team

[newsfounded.com/czechrepublice…](https://newsfounded.com/czechrepubliceng/the-russian-recruit-went-to-molotov-and-did-not-return-to-the-front-from-vacation/)

TBH I never anticipated a reality where Molotov becomes a noun, adjective & verb…

🤔 [twitter.com/leonidragozin/…](https://twitter.com/leonidragozin/status/1540933518196441089)

> ![[assets/29010710-vBl5zWMc_normal.png]]  
> Leonid ХВ Ragozin ([@leonidragozin](https://twitter.com/leonidragozin)) - 2022-06-25
>
>
> In which Russian war propagandists complain that their classified video of what they claim to be the first HIMARS strike on the Russian troops was leaked to a Ukrainian TG channel via people in charge of Russian war propaganda effort. [pic.twitter.com/DiBs0gs9gt](https://twitter.com/leonidragozin/status/1540933518196441089/photo/1)
>

![[assets/3_1540933510277615616.jpg]]

June 26, 2022

St. Basil the Great in [[../Maps/Osinovaya Roshcha, Pargolovo, Saint Petersburg, Northwestern Federal District, 194902, Russia|Osinovaya Roshcha]] ([[../Maps/Osinovaya Roshcha, Pargolovo, Saint Petersburg, Northwestern Federal District, 194902, Russia|Aspen Grove]]) is on [[../fire|fire]].

[bb-cntv.com/news/fire-in-t…](https://bb-cntv.com/news/fire-in-the-church-in-aspen-grove-details-of-the-russian-orthodox-church-told-june-26-2022-company-news-st-petersburg-news-79004/)

June 26, 2022

Orthodox church in the [[../Maps/Vyborgsky District, Saint Petersburg, Northwestern Federal District, Russia|Vyborgsky]] district of St. Petersburg is on [[../fire|fire]].

[apolline-petit.com/in-st-petersbu…](https://apolline-petit.com/in-st-petersburg-eliminated-the-fire-in-the-orthodox-church)

April 19, 2022  
Not in Russia but on this day a Russian Orthodox Church, Saint-Seraphin-de-Sarov in Paris's 15th arrondissement (district) was on [[../fire|fire]].

[reuters.com/world/europe/p…](https://www.reuters.com/world/europe/police-investigating-russian-orthodox-church-fire-paris-2022-04-19/)

June 10, 2022:  
Belarusian MAZ bus caught on [[../fire|fire]] on Vitebsk Ave in St Petersburg

[charter97.org/en/news/2022/6…](https://charter97.org/en/news/2022/6/23/503601/)

June 23, 2022

Second Belarusian MAZ bus catches [[../fire|fire]] in St Petersburg

[charter97.org/en/news/2022/6…](https://charter97.org/en/news/2022/6/23/503601/)

Russia has seen a 4.7% decrease in bus registrations in January 2022.

Russia removed all MAZ buses after explosions & [[../fire|fire]] in the above two to "inspect" them.

[motolko.help/en-news/maz-be…](https://motolko.help/en-news/maz-became-the-fourth-in-the-russian-bus-market-in-january/)

27 June 2022

Lukashenko meets with Alexander Beglov to discuss exploding & [[../fire|burning]] MAZ buses in St Petersburg.

Russia ordered 1,000 MAZ buses.

Putin approved 15 Belarusian "substitution" projects…this is what a country's honor costs.

[president.gov.by/en/events/vstr…](https://president.gov.by/en/events/vstrecha-s-gubernatorom-samarskoy-oblasti-dmitriem-azarovym-1656326969)

Lukashenko makes veiled threat regarding delay of $1.5 billion in Russian contracts, mostly in Samara Oblast, to Belarus.

…delay may lead to staple shortfalls & discontent similar to the fall of the Soviet Union.

[president.gov.by/en/events/vstr…](https://president.gov.by/en/events/vstrecha-s-gubernatorom-samarskoy-oblasti-dmitriem-azarovym-1656326969)

Russia is unique in rail logistics.

66,000 flatbed [[../railway car|railcars]] are available to move Russian military forces - enough to move the entirety of Russia’s ground forces simultaneously.

This is why the work of [@cpartisans](https://twitter.com/cpartisans) & the railway workers is so effective.

[fpri.org/article/2022/0…](https://www.fpri.org/article/2022/06/two-less-obvious-lessons-for-baltic-defense-from-russias-invasion-of-ukraine/)

Russian math

-20k = no individual mobilization
-500k = unfit for duty papers

[wartranslated.com/intercepted-ca…](https://wartranslated.com/intercepted-call-20000-to-demobilise/)

June 2, 2022

[[../fire|Fire]] in village of Lyubensk, Plyussky district, Pskovskaya at museum of the estate of composer N. A. Rimsky-Korsakov.

Official cause: negligence of builders who blocked the roof of the estate using open [[../fire|fire]]. < translation??

H/t [@TWMCLtd](https://twitter.com/TWMCLtd)

[russia.postsen.com/news/60494/Mus…](https://russia.postsen.com/news/60494/Museum-workers-saved-original-exhibits-of-the-estate-of-N-A-Rimsky-Korsakov-from-fire.html)

Update on above:  
[[../fire|Fire]] damage to the memorial museum of composer Nikolai Rimsky-Korsakov deemed "significant" by the governor of Pskov region.

[then24.com/2022/07/02/the…](https://then24.com/2022/07/02/the-estate-of-rimsky-korsakov-caught-fire-in-the-pskov-region/)

June 2, 2022 (article says June 3)

A 3 story private drug center on [[../fire|fire]] in NE [[../Maps/Moscow, Central Federal District, Russia|Moscow]], Chersky passage, 13, building 4, Altufyevsky district.

TY [@NelsonSkeels](https://twitter.com/NelsonSkeels)

[vm.ru/news/978509-bo…](https://vm.ru/news/978509-bolnica-zagorelas-na-severo-vostoke-moskvy)

June 2, 2022

Posting this because the Russian Duma never heard the internet law of "Don't F*ck With [[../animals|Cats]]"

in "low [[../animals|animal]] culture" regions, repressive measures are introduced against [[../animals|pet]] owners

-quite contrary to the [[../animals|animal]] ❤️ we see in war torn Ukraine

[vm.ru/society/978467…](https://vm.ru/society/978467-koshka-gulyala-prava-poteryala-kak-novyj-zakonoproekt-skazhetsya-na-vladelcah-domashnih-zhivotnyh)

Amazing thread about Putin's special connection to the composer, Nikolai Rimsky-Korsakov, whose museum just [[../fire|burned]]. [twitter.com/HarladF/status…](https://twitter.com/HarladF/status/1543696505101508610)

> ![[assets/1497578431915167744-qnRNZ3Je_normal.jpg]]  
> Harlad Farhage - Indexing incidents in Russia ([@HarladF](https://twitter.com/HarladF)) - 2022-07-03
>
>
> The title of the music is ”Scheherazade”.  
> Some of you also know that it is also the name of Putins yacht that was seized in Italy in may - that is what caught my attention.  
> Obviously Scheherazade means so much to Putin that he names his precious 700 MUSD superyacht after her

since 24 February, Anastasia has started her day by composing an [[../anti-war|anti-war]] message and posting it on the wall at the entrance of her apartment block in the industrial city of [[../Maps/Perm, Perm Krai, Volga Federal District, Russia|Perm]] in the Ural Mountains.

[euronews.com/2022/07/06/rus…](https://www.euronews.com/2022/07/06/russians-defy-crackdown-to-find-small-ways-of-protesting-ukraine-war)

Sergei Besov, a [[../Maps/Moscow, Central Federal District, Russia|Moscow]]-based printer and artist, also felt he could not stay silent. Even before the invasion, the 45-year-old was making posters reflecting on the political scene and plastering them around the capital.

[euronews.com/2022/07/06/rus…](https://www.euronews.com/2022/07/06/russians-defy-crackdown-to-find-small-ways-of-protesting-ukraine-war)

Sasha Skochilenko, a 31 yr old artist & musician in St Petersburg, was [[../arrested|detained]] & is facing up to 10 yrs in prison for replacing 5 price tags in a supermarket with tiny ones containing [[../anti-war|anti-war]] slogans.

[euronews.com/2022/07/06/rus…](https://www.euronews.com/2022/07/06/russians-defy-crackdown-to-find-small-ways-of-protesting-ukraine-war)

Check out this amazing tool. Easily visualize Russian losses in multiple ways.

Insanely useful.

[@walterlekh](https://twitter.com/walterlekh) [twitter.com/ragnarbjartur/…](https://twitter.com/ragnarbjartur/status/1545777798085808130)

> ![[assets/1482945426-3d1107f330cb3ff2b2e494e5c3767f8e_normal.jpeg]]  
> Ragnar Gudmundsson 🇮🇸🇺🇦 ([@ragnarbjartur](https://twitter.com/ragnarbjartur)) - 2022-07-09
>
>
> ⚡️ UKRAINE DASHBOARDS MILESTONE
>
> I'll not confirm that the people below are among regular users, but my dashboards on the war in Ukraine have now been viewed 100,000 times. 🍻
>
> 📈[datastudio.google.com/s/oNFEC_k7sVM](https://datastudio.google.com/s/oNFEC_k7sVM) [pic.twitter.com/MsbOJPc6jP](https://twitter.com/ragnarbjartur/status/1545777798085808130/photo/1)

July 11, 2022  
A new Russian cartoon series, St. Marybourg, airs an episode where a [[../animals|Piglet]] must flee because China invades Russia to denazify it with a "special military operation".

Art as protest is in our blood. Art can change the world.

 [ruprop.live/forwarded-from…](https://ruprop.live/forwarded-from-voice-of-mordor-theres-a-new-fetish-for-opposition-russia-the-one-that-changed-the-flag-to-white-and-blue-that-all-these-amazing-people-are-raving-and-tapping-their-tongues-abou-18/)

June 28, 2022  
The wives of soldiers in the autonomous Russian Buryatia region video a plea to release their husbands from military service.

About 500 Buryatia soldiers have refused to fight in Ukraine.

Buryatia has the 2nd highest casualty rate.

[rferl.org/a/russia-ukrai…](https://www.rferl.org/a/russia-ukraine-war-buryatia-wives-officers/31919996.html)

July 9, 2022  
150 Buryatia soldiers returned home after refusing to fight in Ukraine.

Significantly the leader, Vladimir Anatolyevich Pavlov, was originally appointed by Putin as head & United Russia holds the most gov seats in Buryatia.

[themoscowtimes.com/2022/07/12/150…](https://www.themoscowtimes.com/2022/07/12/150-siberian-soldiers-refuse-ukraine-deployment-activist-says-a78267)

[Thread link](https://twitter.com/VelvetBlade/status/1518494756623765504)
