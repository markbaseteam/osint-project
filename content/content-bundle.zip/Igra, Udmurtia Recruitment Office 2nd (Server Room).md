---
locations:
aliases: 
location:
title: 'Igra, Udmurtia Recruitment Office 2nd (Server Room)'
tag: molotov, recruitment
date:
---

# Igra, Udmurtia Recruitment Office 2nd (Server Room)

2022-05-23  
Molotov  
Recruitment  
https://libcom.org/article/arise-ukrainian-comrades-anti-war-direct-actions-russia-and-its-9th-review  
On the night of May 21, a Molotov cocktail was thrown into the recruiting station of Igra in Udmurtia Republic. As we can see on the title photo, the entire reserve room [[fire|burned]] out (a little over 9 square meters). Unfortunately, there were no documents in the room, only personal belongings of the employees. A couple of days later, another enlistment center of this village also was attacked with such bottle - then the [[fire]] spread through the server room, where official documentation and a card file of veterans of the Second World War were stored.  
Igra, Udmurtia Republic

A few days later, the FSB [[arrested|detained]] a suspect: 48-year-old Ilya Farber, who came to visit relatives living in Igra. The man has been searched, during it two canisters of gasoline, wire, potassium permanganate, funnels, five bank cards and three iPhones were seized. Farber is a painter and former director of a rural house of [[civilizations|culture]] in the Tver region. In 2013, he was convicted of abuse of office and taking a bribe. The case had clear signs of falsification and got a wide resonance. Even Putin called his sentence "outrageous"! Video of interrogation https://t.me/bazabazon/11799

~+~  
155
