---
locations:
aliases: ['[[Maps/Homyel, Homyel Region, Belarus|Gomel]] railway signaling control cabinets destroyed']
location:
title: '[[Maps/Homyel, Homyel Region, Belarus|Gomel]] railway signaling control cabinets destroyed'
tag: 
date:
linter-yaml-title-alias: '[[Maps/Homyel, Homyel Region, Belarus|Gomel]] railway signaling control cabinets destroyed'
---

# [[OSINT Project/Maps/Homyel, Homyel Region, Belarus|Gomel]] railway signaling control cabinets destroyed

2022-03-01  
[[fire]]  
Railway,Infrastructure  
https://ru.wikipedia.org/wiki/Рельсовая_война_в_Белоруссии_(2022)# 30_марта  
Two signaling control cabinets (alarm, centralization and locking device) at the service areas of the Baranovichi and [[OSINT Project/Maps/Homyel, Homyel Region, Belarus|Gomel]] branches of Belarusian Railway were also destroyed by [[fire|arson]], which disrupted the [[operations|operation]] of traffic lights and switches and blocked traffic on these sections of the railway.  
[[OSINT Project/Maps/Homyel, Homyel Region, Belarus|Gomel]], Belarus

~+~  
127
