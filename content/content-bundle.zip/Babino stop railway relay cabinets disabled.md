---
aliases: 
locations:
tag: 
date:
title: Babino stop railway relay cabinets disabled
---
**NOTE TO SELF LEFT OFF HERE - ADD DATE, TAGS ETC**
---
locations:
aliases: Babino Stop, Babino railway, Babino stopping point, Babino
location:
title: Babino stop railway relay cabinets disabled
tag: Railway, Infrastructure
date:
---

# Babino stop railway relay cabinets disabled

2022-03-30  
[[fire]]  
Railway, Infrastructure  
https://nashaniva.com/?c=ar&i=287393&lang=ru  
Group of railway workers of Belarus: Last night near Bobruisk, a security patrol opened [[fire]] on the partisans who opened the relay cabinet. On the night of March 30, 2022, 2 relay cabinets were opened on the Savichi-Berezina section (Osipovichi-[[OSINT Project/Maps/Homyel, Homyel Region, Belarus|Gomel]] section), near the Babino stop (one of them was set on [[fire]]). At that time, there was a patrol group from the Internal Troops in the forest belt. Patrolmen opened [[fire]] with combat weapons at the partisans. The guerrillas managed to escape from persecution  
Bobruisk, Belarus

~+~  
40
