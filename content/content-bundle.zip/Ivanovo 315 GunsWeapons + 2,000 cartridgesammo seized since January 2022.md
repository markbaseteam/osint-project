---
locations:
aliases:
  - '[[Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] 315 Guns Weapons + 2,000 cartridges ammo seized since January 2022'
location:
title: '[[Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] 315 Guns Weapons + 2,000 cartridges ammo seized since January 2022'
tag: event, weapons, guns, ammo, ammunition
date: 2022-07-05  
linter-yaml-title-alias: '[[Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] 315 Guns Weapons + 2,000 cartridges ammo seized since January 2022'
---

# [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] 315 Guns Weapons + 2,000 cartridges ammo seized since January 2022

2022-07-05  
Other  
Weapons,Other  
https://www.ivanovonews.ru/news/1152674/  
Comprehensive inspections of civilian firearms owners will continue in the [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] region. According to the Department of Rosgvardia for the [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] region, in total, since the beginning of 2022, more than 13,000 inspections of the conditions of the preservation of weapons have been carried out in the region, according to the results of which 493 violations were identified, 316 weapons and more than 2 thousand cartridges have been seized. 12 facts of gross violations of the law were also revealed - permits for weapons of these citizens were canceled. More than 22 thousand owners of civilian weapons are registered in the region, in use of which there are about 34 thousand weapons. For 6 months of this year, the Licensing and Licensing and its structural subdivisions received more than 7.3 thousand applications from individuals and legal entities. Thanks to the compensation program for the population in the reporting period, 9 weapons were handed over voluntarily, about 30 thousand rubles were paid to citizens from the regional budget. "Each owner should understand that the conditions for the safety of weapons and ammunition and the safety of their storage must be observed not only at the place of residence. Also, security measures are necessary for [[transportation]], on small arms and in hunting grounds, because lost weapons can become an instrument of crime," the Office of Rosgvardia notes.  
[[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]]

Not sabotage, but shows line of previously undisclosed concern by authorities. Employees of Rosgvardia remind that in all cases of voluntary surrender of weapons, ammunition and explosives, a citizen in accordance with the current legislation is exempt from criminal liability for their illegal possession. Weapons and ammunition are handed over to the licensing and permitting units of Rosgvardia in the [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] region or to territorial police units. https://www.ivanovonews.ru/news/1152362/

~+~  
183
