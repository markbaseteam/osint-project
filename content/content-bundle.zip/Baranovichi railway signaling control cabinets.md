---
locations:
aliases: Baranovichi stop, Baranovichi stopping point, Baranovichi branch, Gomel stop, Gomel stopping point, Gomel branch, Homyel stop, Homyel stopping point, Homyel branch
location:
title: Baranovichi railway signaling control cabinets
tag: Fire, Railway, Infrastructure
date: 2022-03-01 
---

# Baranovichi railway signaling control cabinets

2022-03-01  
[[fire]]  
Railway,Infrastructure  
https://ru.wikipedia.org/wiki/Рельсовая_война_в_Белоруссии_(2022)# 30_марта  
Two signaling control cabinets (alarm, centralization and locking device) at the service areas of the Baranovichi and [[OSINT Project/Maps/Homyel, Homyel Region, Belarus|Gomel]] branches of Belarusian Railway were also destroyed by [[fire|arson]], which disrupted the [[operations|operation]] of traffic lights and switches and blocked traffic on these sections of the railway.  
Baranovichi, Belarus

~+~  
126
