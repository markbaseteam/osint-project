---
locations:
aliases: Dmitrievsky
location:
title: Dmitrievsky Chemical Plant
tag:
date:
---

# Dmitrievsky Chemical Plant

2022-04-21  
[[fire]]  
Chemical  
https://www.rferl.org/a/russia-fires-mystery-ukraine-conflict/31884503.html  
[[fire]] engulfs a building of the Dmitrievsky Chemical Plant near [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]], around 240 kilometers northeast of [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]], on April 21. Today, June 28, the governor of the [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] region visited "Dmitrievsky Chemical Plant - Production" in Kineshma as part of his working trip. First of all, Stanislav Voskresensky discussed with the management of the enterprise the consequences of the [[fire]] in the workshop under construction, which occurred on April 21 this year. Development Director Evgeny Usov said that the workshop was built for the production of household chemicals and bottling of products for supply to the domestic market. In connection with the incident, the company's plans were revised, but the head of the region was informed that they would return to the topic within a year or two. https://www.ivanovonews.ru/news/1152381/  
Kineshma, [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]]

The largest producer of butyl acetate and industrial solvents in eastern Europe. Speculation on [[aircraft|jet]] propulsion, parts cleaning & rubber production. === the products of Kineshma DHZ are in demand in more than 100 countries on all continents. Customers do not refuse to supply. However, there are problems with logistics and calculations. As a result, exports decreased by more than 50%. However, they are also trying to solve this problem. The governor promised support "manually", as this situation takes place not only in relation to this enterprise. https://www.ivanovonews.ru/news/1152381/ See also https://www.washingtonexaminer.com/news/russian-chemical-plant-burns-down-hours-after-deadly-fire-at-military-facility

~+~  
113
