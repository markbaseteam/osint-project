---
locations:
aliases: ['Belgorod Railway Station [[Fire]]']
location:
title: 'Belgorod Railway Station [[Fire]]'
tag: 
date:
linter-yaml-title-alias: 'Belgorod Railway Station [[Fire]]'
---

# Belgorod Railway Station [[fire]]

2022-05-14  
[[fire]]  
Railway,Infrastructure  
https://twitter.com/lilygrutcher/status/1525518245150826496  
Maybe? Dubovoye, Belgorod Oblast  
Belgorod Oblast  
50.593006, 36.602231

~+~  
26
