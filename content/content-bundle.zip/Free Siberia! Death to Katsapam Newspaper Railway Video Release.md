---
locations:
aliases: ['Free [[Siberian Federal District|Siberia]]! Death to Katsapam Newspaper Railway Video Release']
location:
title: 'Free [[Siberian Federal District|Siberia]]! Death to Katsapam Newspaper Railway Video Release'
tag: 
date:
linter-yaml-title-alias: 'Free [[Siberian Federal District|Siberia]]! Death to Katsapam Newspaper Railway Video Release'
---

# Free [[Siberian Federal District|Siberia]]! Death to Katsapam Newspaper Railway Video Release

2022-05-11  
Mechanical  
Railway,Infrastructure  
https://twitter.com/i/status/1525177964526182400  
FIRST REPORTED ON RUSSIAN INTELLIGENCE AND PROPAGANDA TELEGRAM CHANNELS: Reported in Irkutsk - underground partisan paper "Free [[Siberian Federal District|Siberia]]! Death to Katsapam" (anti-Russian slur) claims partisans disrupted a railway track by cutting circuit wires or jumping wires. Unclear if [[Siberian Federal District|Siberian]] tracks are electrified. Videos did not circulate on Twitter until May 13th, it was reported verbatim twice on Telegram May 11 (RU Propaganda dashboard) Flyers left at scene. Still trying to establish if this is legit or Russian [[operations|op]]. https://ruprop.live/source-seek-your-owntranslation-❗%EF%B8%8Fsiberian-partisans-in-the-irkutsk-region-they-stopped-a-train-with-the-help-of-wire-the-method-is-called-a-shorting-of-the-rail-circuit-the-2/  
Irkutsk

"free [[Siberian Federal District|Siberia]]! Death to Katsapam" may be a Russian info [[operations|op]] to promote the narrative that Ukrainians murder Russians & justifying the war in a region not very supportive. Katsapam=Ukrainian slur for Russians. Partisan papers generally call for solidarity.

~+~  
22
