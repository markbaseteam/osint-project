---
locations:
aliases:
  - '[[Moscow]] Police Station'
location:
title: '[[Moscow]] Police Station'
tag: fire, government, police station
date: 2022-04-25  
linter-yaml-title-alias: '[[Moscow]] Police Station'
---

# [[Moscow]] Police Station

2022-04-25  
[[fire]]  
Government  
https://news.storyua.com/news/14107.html  
In addition, for unknown reasons, [[fire]] broke out in one of the houses in St. Petersburg, the [[air base]] in Ussuriysk, as well as in police stations in [[Moscow]], Irkutsk and [[OSINT Project/Maps/Novosibirsk, Novosibirsk Oblast, Siberian Federal District, 630000, Russia|Novosibirsk]].  
[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

~+~  
167

# [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]] Police Station

2022-04-25  
[[fire]]  
Government  
https://news.storyua.com/news/14107.html  
In addition, for unknown reasons, [[fire]] broke out in one of the houses in St. Petersburg, the [[air base]] in Ussuriysk, as well as in police stations in [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]], Irkutsk and [[OSINT Project/Maps/Novosibirsk, Novosibirsk Oblast, Siberian Federal District, 630000, Russia|Novosibirsk]].  
[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

~+~  
167  
[[Irkutsk Police Station]]  
[[Novosibirsk Police Station]]  
[[St Petersburg Residence]]  
[[State Security Committee Building Transnistria]]  
[[Mayak Radio Transmitter Transnistria]]  
[[Bryansk Railway Inert Demolition Bomb]]  
[[Staraya Nelidovka Belgorod Ammunition Depot]]  
[[Kustanayskaya Street, Moscow Cars]]  
[[Tver Fuck War Posters]]  
[[Tver Surveillance Camera Outage]]  
[[Perm Banner Peace to huts, war to palacesZ Billboards]]  
[[Kuril Islands, Ilyinskoye Sakhalinskaya GRES-2 Power Plant]]  
[[FKP or PPZ Gunpowder Plant - Perm]]  
[[Belgorod Oblast Defense Ministry Facility]]  
[[Sudzha—Sosnovy Bor Railway Bridge Collapse]]  
[[Remotely locked John Deere Farm Equipment]]  
[[Moscow Paddy Wagon]]  
[[Moscow Molotov at riot police bus]]  
[[Alcohol Distribution Disruption]]  
[[Mytishchi Fuel Depot]]  
[[Bogorodskoye, Atlant Park industrial and warehouse complex]]  
[[Nizhnevartovsk Recruitment Office]]

# Kudinovskoye Paper Warehouse

2022-05-03  
[[fire]]  
Other  
https://www.world-today-news.com/in-the-suburbs-a-strong-fire-broke-out-in-a-huge-warehouse-mir-tsn-ua/  
The area of ​​ignition is more than 25 thousand square meters. paper warehouse. On the night of May 3, a [[fire]] broke out in a warehouse on Kudinovskoye highway in the [[OSINT Project/Maps/Bogorodsky city district, Moscow Oblast, Central Federal District, Russia|Bogorodsky]] urban district of the [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]] region, the building is [[fire|burning]] throughout the area. According to propaganda media, the [[fire]] started on the territory of the Atlant Park industrial and warehouse complex in [[OSINT Project/Maps/Bogorodsky city district, Moscow Oblast, Central Federal District, Russia|Bogorodskoye]]  
Kudinovskoye highway, [[OSINT Project/Maps/Bogorodsky city district, Moscow Oblast, Central Federal District, Russia|Bogorodsky]], [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

The warehouse is located in a section dedicated to logistics and distribution. https://www.express.co.uk/news/world/1604413/russia-fire-vladimir-putin-news-industrial-building-Bogorodsky-moscow-oblast-latest == Reported elsewhere in channels that the company had contracts for government paper supplies including conscript offices. This is not confirmed.

~+~  
65

# Prosveshchenie Text Book Printer Warehouse

2022-05-03  
[[fire]]  
Education,Cultural  
https://www.themoscowtimes.com/2022/05/03/fire-hits-russian-publisher-embroiled-in-ukraine-textbook-controversy-a77563  
[[fire]] has ripped through a warehouse storing Russian schoolbooks, days after reports that publishers would remove mentions of Ukraine from the nation’s textbooks. textbooks and other printing materials had been stored in the warehouse  
Svetofor Warehouse, Prosveshchenie publishing house, [[OSINT Project/Maps/Bogorodsky city district, Moscow Oblast, Central Federal District, Russia|Bogorodsky]], [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

The [[fire]] follows reports that Prosveshchenie, one of Russia’s largest and oldest educational publishers, had ordered staff to remove "inappropriate" references to Ukraine and Kyiv from textbooks. == Svetofor Warehouse. A number of [[fire|fires]] were active at this warehouse per FIRMS

~+~  
104

# FSB [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]] Special Ops Center Vehicles

2022-05-03  
[[fire]]  
Military,Government  
https://darknights.noblogs.org/post/2022/04/12/russia-military-cars-on-fire/  
At night on 03.04.22 there was an [[fire|arson]] in Russia–cars belonging to the staff of the FSB Special Operations Center (military unit 35690, Balashikha, [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]] region) [[fire|burned]] down. At least four cars were [[fire|burned]]. According to Ukrainian intelligence, the owners of the cars were representatives of the executive staff of the Federal Security Service’s Central Intelligence Service.  
military unit 35690, Balashikha, [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]] region - FSB Special Ops Center

cases of deliberate [[fire|arson]] of cars of Russian military and officials are becoming more frequent. In particular, cars of servicemen of the [[95th Brigade Vehicles|95th Brigade]] (Gorelovo, St Petersburg Region) and the [[82nd Radio Technical Brigade Vehicles|82nd Radio]] Technical Brigade (Vyazma, Smolensk Region) have recently been set on [[fire]]. Russian servicemen speak of threats of physical reprisals if they agree to participate in the war against Ukraine.

~+~  
165

# [[38 Trucks in Parking Lot]]

2022-05-03  
[[fire]]  
Other Defence  
https://twitter.com/nexta_tv/status/1521416166786404354?s=20&t=TFVdFJgzVYdoZacC9SRyGA  
38 trucks [[fire|burned]] overnight at the parking lot. Identified elsewhere as moving goods for military.  
Tver

~+~  
3

# Igumnovo Station Railway Tanks

2022-05-04  
[[fire]]  
Infrastructure,Railway,Gas/Oil,Other Defence  
https://eprimefeed.com/latest-news/the-fire-area-in-the-dzerzhinsk-industrial-zone-has-reached-2000-square-meters/78082/  
The [[fire]] area in the Dzerzhinsk industrial zone, according to preliminary information, reached 2,000 square meters. [[fire|Burning]] railway tanks in the open area of ​​Igumnovo station. Cause being clarified  
​Igumnovo station, Dzerzhinsk, Nizhny Novgorod

These tanks are linked to several military and defence companies/providers

~+~  
66

# Dzerzhinsk, Nizhny Novgorod Industrial Zone

2022-05-04  
[[fire]]  
Infrastructure,Other Defence  
https://eprimefeed.com/latest-news/the-fire-area-in-the-dzerzhinsk-industrial-zone-has-reached-2000-square-meters/78082/  
The [[fire]] area in the Dzerzhinsk industrial zone, according to preliminary information, reached 2,000 square meters. [[fire|Burning]] railway tanks in the open area of ​​Igumnovo station. [[fire]] in the Dzerzhinsk industrial zone started today around 11 o’clock. The causes of the incident are being clarified.  
Dzerzhinsk, Nizhny Novgorod

This industrial complex has several military support activities and companies

~+~  
145

# [[OSINT Project/Maps/Khanty-Mansiysk, Khanty-Mansiysk Urban Okrug, Khanty-Mansiysk Autonomous Okrug – Ugra, Ural Federal District, 628000, Russia|Khanty-Mansi]] Autonomous Okrug Recruitment office

2022-05-04  
Molotov  
Recruitment  
https://nz.topnews.media/ukraine/city-ivano-frankivsk-russia-tried-to-burn-the-military-enlistment-office-with-molotov-cocktails-video/  
Tonight, May 4, in the Russian city of [[OSINT Project/Maps/Nizhnevartovsk, городской округ Нижневартовск, Khanty-Mansiysk Autonomous Okrug – Ugra, Ural Federal District, Russia|Nizhnevartovsk]], a group of unknown individuals pelted the premises of the local military enlistment office with bottles of incendiary mixture. Video of the incident published Telegram channel Base. A [[fire]] broke out in the military registration and enlistment office of the city of [[OSINT Project/Maps/Nizhnevartovsk, городской округ Нижневартовск, Khanty-Mansiysk Autonomous Okrug – Ugra, Ural Federal District, Russia|Nizhnevartovsk]] in the [[OSINT Project/Maps/Khanty-Mansiysk, Khanty-Mansiysk Urban Okrug, Khanty-Mansiysk Autonomous Okrug – Ugra, Ural Federal District, 628000, Russia|Khanty-Mansi Autonomous Okrug]] of the Russian Federation. Surveillance cameras recorded that unknown people threw several bottles of incendiary mixture into the building. As can be seen in the published footage, at least seven “Molotov cocktails” flew into the building. Although the first one went out at once, all the others reached the goal and caused the wood paneling to catch [[fire]].  
[[OSINT Project/Maps/Nizhnevartovsk, городской округ Нижневартовск, Khanty-Mansiysk Autonomous Okrug – Ugra, Ural Federal District, Russia|Nizhnevartovsk]], [[OSINT Project/Maps/Khanty-Mansiysk, Khanty-Mansiysk Urban Okrug, Khanty-Mansiysk Autonomous Okrug – Ugra, Ural Federal District, 628000, Russia|Khanty-Mansi Autonomous Okrug]]

This may be the May 11 event referenced although this seems to have more details.

~+~  
67

# Dzerzhinsk Chemical Weapons Factory and Railway Tankers Explode

2022-05-06  
Explosion  
Railway,Chemical,Infrastructure,Other Defence  
https://www.express.co.uk/news/world/1606228/Russia-chemical-plant-fire-explosion-Dzerzhinsk-factory-Ukraine-war-attack-latest-Putin  
Multiple rail tankers containing solvents exploded at a factory in Dzerzhinsk. The [[fire]], which occurred at around 11am on Wednesday, was spread across 2,500 square metres. This comes as numerous facilities across Russia, many with military links, have been hit by mystery [[fire|fires]]. It was a railway tanker containing unspecified solvents on the territory of the former chemical weapons factory Kaprolaktam, in Dzerzhinsk. See also https://www.express.co.uk/news/world/1611630/mystery-fire-russia-claims-ukraine-sabotage  
Kaprolaktam Chemical Weapons Factory, Dzerzhinsk

~+~  
160

# Vicalina Market Vladikavkaz

2022-05-06  
[[fire]]  
Other  
https://twitter.com/nexta_tv/status/1522507766165913602?s=20&t=rAnAi9isgrntoVpJvQiHsw  
Vicalina market in Vladikavkaz is on [[fire]] This is very close to Georgia - North Ossetia-Alania & a major transport hub with the North Caucus railway. South Ossetia is the lands Russia invaded in Georgia much like Crimea & Donsk.  
Vladikavkaz, North Ossetia-Alania

~+~  
30

# Cherepovets Recruitment Office

2022-05-08  
Molotov  
Recruitment  
https://newsbeezer.com/swedeneng/wave-of-molotov-attacks-on-russian-recruiting-offices/  
Another conscription office is pelted with Molotov cocktails in Cherepovets. May 8, 2022 at about 1 am in Cherepovets. The [[fire]] site had an area of one square meter. The flames damaged two window frames and smoked the facade of the building. Seven people were engaged in extinguishing the [[fire]]. On May 11, 2022, the arsonist* were [[arrested]]. They were two 16-year-olds who testified that they had committed the crime “on orders” and received 30,000 rubles for their deed. Criminal proceedings were initiated against the youths for property damage. Video https://t.me/truexanewsua/45920  
Cherepovets

People are [[fire|burning]] their military registration documents in order not to go to war,” said journalist Andrei Tsaplienko. https://amplifyukraine.eu/military-enlistment-offices-are-on-fire-in-russia-details-last-night-several-molotov-cocktails-were-thrown-at-the-cherepovets-station-pravda-gerashchenko-2/ Nearby is the Cherepovets Higher Military Engineering College of Radio Electronics. On another occasion, two 16-year-old boys who said they carried out the attack on the recruitment office in Cherepovets on May 8 on orders and received 30,000 rubles (equivalent to 4,500 SEK) were [[arrested]]. Also see https://enoughisenough14.org/2022/06/26/shortly-after-the-longest-night-of-the-year-two-recruiting-offices-burned-at-once-chronicle-of-arson-attacks-until-june-25-2022-russia/  
~+~  
68

# [[OSINT Project/Maps/Perm, Perm Krai, Volga Federal District, Russia|Perm]] Aviation Technical College

2022-05-08  
[[fire]]  
Aerospace/Aviation,Education  
https://twitter.com/antiputler_news/status/1523279184369381378  
Construction site for the aviation technical school in [[OSINT Project/Maps/Perm, Perm Krai, Volga Federal District, Russia|Perm]] is [[fire|burning]]  
[[OSINT Project/Maps/Perm, Perm Krai, Volga Federal District, Russia|Perm]]

~+~  
17

# [[Balashikha Recruitment Office]]

2022-05-09  
Molotov  
Recruitment  
https://enoughisenough14.org/2022/06/26/shortly-after-the-longest-night-of-the-year-two-recruiting-offices-burned-at-once-chronicle-of-arson-attacks-until-june-25-2022-russia/  
[[fire]] at [[Balashikha Recruitment Office]]. evening of [[All Satellite TV Channels Hacked|May 9]], 2022 in Balashikha in the [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]] region. An unknown person threw a Molotov cocktail through the window. A [[fire]] broke out in the corridor of the building on an area of one square meter, which the security guard managed to extinguish. The suspects were not found.  
Balashikha, Moscow

~+~  
176

# [[All Satellite TV Channels Hacked]]

2022-05-09  
Mechanical  
Hearts & Minds  
https://amplifyukraine.eu/you-have-the-blood-of-ukrainian-children-on-your-hands-russians-were-forced-to-face-the-truth-on-may-9-details-in-russia-this-line-ap-pravda-gerashchenko-2/  
You have the blood of Ukrainian children on your hands–Russians were forced to face the truth on [[All Satellite TV Channels Hacked|May 9]] Details: In Russia, this line appeared on all satellite [[All Satellite TV Channels Hacked|TV]] channels. Instead of the usual Rashist victory speech on [[All Satellite TV Channels Hacked|May 9]], they had to read the truth about the “deeds” of Putin’s army of murderers and looters.  
Russia

In addition Smart [[All Satellite TV Channels Hacked|TVs]], Internet Companies like Yandex and Rutube (Russia's YouTube) not using satellite [[All Satellite TV Channels Hacked|TV]] also received this message https://finance.yahoo.com/news/russia-smart-tv-hack-202422488.html  
~+~  
159

# [[Balashikha Recruitment Office]]

2022-05-10  
Molotov  
Recruitment  
https://libcom.org/article/emancipative-fire-and-call-solidarity-persecuted-comrades-8th-review-anti-war-sabotage  
On the evening of May 10, a Molotov cocktail flew into the window of a similar facility in Balashikha. A [[fire]] started in the corridor, the [[fire]] was unfortunately extinguished by a guard who came to the rescue, but the arsonist was not captured. In addition to Balashikha, this office is also responsible for conscription in the neighboring town of Reutov.  
Balashikha

~+~  
37

# Free [[Siberian Federal District|Siberia]]! Death to Katsapam Newspaper Railway Video Release

2022-05-11  
Mechanical  
Railway,Infrastructure  
https://twitter.com/i/status/1525177964526182400  
FIRST REPORTED ON RUSSIAN INTELLIGENCE AND PROPAGANDA TELEGRAM CHANNELS: Reported in Irkutsk - underground partisan paper "Free [[Siberian Federal District|Siberia]]! Death to Katsapam" (anti-Russian slur) claims partisans disrupted a railway track by cutting circuit wires or jumping wires. Unclear if [[Siberian Federal District|Siberian]] tracks are electrified. Videos did not circulate on Twitter until May 13th, it was reported verbatim twice on Telegram May 11 (RU Propaganda dashboard) Flyers left at scene. Still trying to establish if this is legit or Russian op. https://ruprop.live/source-seek-your-owntranslation-❗%EF%B8%8Fsiberian-partisans-in-the-irkutsk-region-they-stopped-a-train-with-the-help-of-wire-the-method-is-called-a-shorting-of-the-rail-circuit-the-2/  
Irkutsk

"free [[Siberian Federal District|Siberia]]! Death to Katsapam" may be a Russian info op to promote the narrative that Ukrainians murder Russians & justifying the war in a region not very supportive. Katsapam=Ukrainian slur for Russians. Partisan papers generally call for solidarity.

~+~  
22

# Khabarovsk Krai Teysin Military Base Powder Warehouse

2022-05-12  
Explosion  
Military  
https://ria.ru/20220512/vzryv-1788053221.html  
Explosion in a powder warehouse in Khabarovsk Krai. Russian sources state this was due to "mishandling explosives". Warehouse located at a military base in Teysin, Khabarovsk. There are four military bases in this area. Explosion happened during unloading munitions & sparked a large blaze. Soldiers killed & injured. https://tifnews.com/world/russia/1-dead-7-injured-in-russia-military-base-explosion-the-moscow-times/  
Teysin, Amursky district, Khabarovsk Krai

Located in Russia's subarctic far east & shared border with China. Industry: military [[aircraft]], shipbuilding & oil refining

~+~  
35

# Russian Recruitment Office in Transnistria

2022-05-12  
Molotov  
Recruitment

Occupied Transnistria - molotov attacks on Russian registration/enlistment office & an oil depot.  
Transnistria

Suspected false flag

~+~  
36

# Russian Oil Depot in Transnistria

2022-05-12  
[[fire]]  
Gas/Oil

Occupied Transnistria - molotov attacks on Russian registration/enlistment office & an oil depot  
Transnistria

Suspected False Flag

~+~  
70

# SinTZ, Sinarsky Pipe Works

2022-05-12  
[[fire]]  
Other  
https://twitter.com/TolomeoNews/status/1525139692815011844  
[[fire]] at SinTZ, Sinarsky Pipe Works in [[OSINT Project/Maps/Kamensk-Uralsky, городской округ Каменск-Уральский, Sverdlovsk Oblast, Ural Federal District, 623428, Russia|Kamensk-Uralsky]], Sverdlovsk Oblast a [[fire]] on Sinarsky pipeline plant. According to the Ministry of Emergency Situations, the building and the roof of the factory are on [[fire]]. The [[fire]] area reached 800 square meters.  
[[OSINT Project/Maps/Kamensk-Uralsky, городской округ Каменск-Уральский, Sverdlovsk Oblast, Ural Federal District, 623428, Russia|Kamensk-Uralsky]], Sverdlovsk Oblast

One of the biggest specialty producers in Russia, SinTZ manufactures steel & cast iron pipes w/ 3,000+ contracts per yr. Sverdlovsk elsewhere produces semi-conductors.

~+~  
16

# [[OSINT Project/Maps/Omsk, Omsk Oblast, Siberian Federal District, 644000, Russia|Omsk]] Recruitment office

2022-05-13  
Molotov  
Recruitment  
https://enoughisenough14.org/2022/06/26/shortly-after-the-longest-night-of-the-year-two-recruiting-offices-burned-at-once-chronicle-of-arson-attacks-until-june-25-2022-russia/  
[[OSINT Project/Maps/Omsk, Omsk Oblast, Siberian Federal District, 644000, Russia|Omsk]] Molotov [[fire]] at Russian enlistment office in [[OSINT Project/Maps/Omsk, Omsk Oblast, Siberian Federal District, 644000, Russia|Omsk]] on Pushkin Street, 78. night of May 13, 2022 in [[OSINT Project/Maps/Omsk, Omsk Oblast, Siberian Federal District, 644000, Russia|Omsk]]. Two windows of the building were destroyed and traces of [[fire]] were found, but the [[fire]] was quickly extinguished. The suspects were not found. At least two windows were broken. A [[fire]] caught an area of 30 square meters and some archival documents were damaged.  
[[OSINT Project/Maps/Omsk, Omsk Oblast, Siberian Federal District, 644000, Russia|Omsk]] on Pushkin Street, 78

On the night of May 13, 2022 in [[OSINT Project/Maps/Omsk, Omsk Oblast, Siberian Federal District, 644000, Russia|Omsk]], [[Siberian Federal District|Siberia]], unknown individuals threw several molotovs through the windows of the Central District military registration and enlistment office at 74 Pushkin Street. At least two windows were broken. One of the premises of the military registration and enlistment office caught [[fire]] and an area of 30 square meters [[fire|burned]]. It is also reported that “some archive documents were damaged”. https://darknights.noblogs.org/post/2022/06/01/omsk-cherepovets-russia-two-new-recruitement-offices-hit-with-molotovs/

~+~  
24

# [[OSINT Project/Maps/Khanty-Mansiysk, Khanty-Mansiysk Urban Okrug, Khanty-Mansiysk Autonomous Okrug – Ugra, Ural Federal District, 628000, Russia|Khanty-Mansi Autonomous Okrug]] Recruitment office

2022-05-13  
Molotov  
Recruitment  
https://www.rferl.org/a/russia-enlistment-offices-arson/31851677.html

[[OSINT Project/Maps/Khanty-Mansiysk, Khanty-Mansiysk Urban Okrug, Khanty-Mansiysk Autonomous Okrug – Ugra, Ural Federal District, 628000, Russia|Khanty-Mansi]], Tyumen Oblast  
62°15′N 70°10′E  
[[OSINT Project/Maps/Khanty-Mansiysk, Khanty-Mansiysk Urban Okrug, Khanty-Mansiysk Autonomous Okrug – Ugra, Ural Federal District, 628000, Russia|Khanty-Mansi]]/Khanty-Mansiysky Autonomous Okrug-Yugra - Autonomous Okrug of Tyumen Oblast In 2012, the majority (51%) of the oil produced in Russia came from [[OSINT Project/Maps/Khanty-Mansiysk, Khanty-Mansiysk Urban Okrug, Khanty-Mansiysk Autonomous Okrug – Ugra, Ural Federal District, 628000, Russia|Khanty-Mansi Autonomous Okrug]] It borders Yamalo-Nenets Autonomous Okrug to the north, Komi Republic to the northwest, Sverdlovsk Oblast to the west, Tyumen Oblast to the south, Tomsk Oblast to the south and southeast and [[OSINT Project/Maps/Krasnoyarsk, Krasnoyarsk Urban Okrug, Krasnoyarsk Krai, Siberian Federal District, 660000, Russia|Krasnoyarsk]] Krai in the east. In [[OSINT Project/Maps/Khanty-Mansiysk, Khanty-Mansiysk Urban Okrug, Khanty-Mansiysk Autonomous Okrug – Ugra, Ural Federal District, 628000, Russia|Khanty-Mansi Autonomous Okrug]], the primary transport of goods is by water and railway transport; 29% is transported by road, and 2% by aviation. The total length of railway tracks is 1,106 km. The length of roads is more than 18,000 km.

~+~  
39

# Gukovo Recruitment Office

2022-05-13  
Molotov  
Recruitment  
https://www.rferl.org/a/russia-enlistment-offices-arson/31851677.html  
On May 13, a military enlistment office in the town of Gukovo in the southern Rostov region was partially [[fire|burned]]. A Molotov cocktail is also believed to be the cause of that [[fire]], which was quickly put out. night of May 13, this time in the town of Gukovo in the Rostov region. The attack took place at about 02:05 in the morning. The [[fire]] was extinguished by the employees of the Registration and Recruitment Office themselves, and there was no property damage. The suspects were not found. https://enoughisenough14.org/2022/06/26/shortly-after-the-longest-night-of-the-year-two-recruiting-offices-burned-at-once-chronicle-of-arson-attacks-until-june-25-2022-russia/  
Gukovo, Rostov

Gukovo (Rostov) On May 13, at about 2:00 a.m., an attempt was made to set [[fire]] to the military registration and enlistment office in Gukovo, near Rostov. A flaming molotov hit the wall of the building. According to the state media, the perpetrator “disappeared in an unknown direction”. https://darknights.noblogs.org/post/tag/khanty-nansi/

~+~  
79

# Irkutsk Young Viewer Theatre

2022-05-13  
[[fire]]  
Cultural  
https://twitter.com/TWMCLtd/status/1525123225218342912  
2-story cultural building in Irkutsk at Krasnoarmejska 4B is ablaze & spread to Young Viewer Theatre. Building was empty & [[fire]] is difficult to contain.  
Krasnoarmejska 4B, Irkutsk

May be faulty wiring, but the area has had significant partisan chatter and actions

~+~  
69

# Belgorod Railway Station [[fire]]

2022-05-14  
[[fire]]  
Railway,Infrastructure  
https://twitter.com/lilygrutcher/status/1525518245150826496  
Maybe? Dubovoye, Belgorod Oblast  
Belgorod Oblast  
50.593006, 36.602231

~+~  
26

# Volgograd Recruitment Office

2022-05-15  
Molotov  
Recruitment  
https://www.rferl.org/a/russia-enlistment-offices-arson/31851677.html  
At about the same time, a [[fire]] broke out in a similar center in Volgograd, formerly Stalngrad, in [[OSINT Project/Maps/Southern Russia, улица Степана Разина, Ворошиловский район, Volgograd, Volgograd Oblast, Southern Federal District, 400001, Russia]]. According to police, the culprits used a Molotov cocktail. Police believe a Molotov cocktail was tossed through the window. The [[fire]] damaged about 20 square meters.  
Volgograd

Volgograd On May 15, unknown individuals targeted the military registration office in Volgograd. At least one “molotov” flew into the basement of a recruitment center, where a [[fire]] broke out consuming the 20 square meter room. No one was [[arrested]]. https://darknights.noblogs.org/post/tag/khanty-nansi/ 30 year old Denis Serdyuk, suspected of an [[fire|arson]] attack against amilitary call-up center in Volgograd, is being held in remand prison # 1 of his town. He is being charged with ”destruction of property” and ”[[hooliganism]]”, and may be sentenced to 10 years in prison. https://avtonom.org/en/news/support-suspected-arsonists-against-military-call-ups-and-other-russian-anti-war-prisoners

~+~  
34

# [[OSINT Project/Maps/Pronsk, Пронское городское поселение, Pronsky District, Ryazan Oblast, Central Federal District, Russia|Pronsk]] Recruitment Office

2022-05-15  
Molotov  
Recruitment  
https://newsfounded.com/czechrepubliceng/the-russian-recruit-went-to-molotov-and-did-not-return-to-the-front-from-vacation/  
Molotov at enlistment registration office near [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]] in [[OSINT Project/Maps/Pronsk, Пронское городское поселение, Pronsky District, Ryazan Oblast, Central Federal District, Russia|Pronsk]], Ryazan. Attempt is reported as unsuccessful. On Sunday, two unknown people unsuccessfully tried to set [[fire]] to a recruitment office in the village of [[OSINT Project/Maps/Pronsk, Пронское городское поселение, Pronsky District, Ryazan Oblast, Central Federal District, Russia|Pronsk]] in the Ryazan region, located about 270 kilometers southeast of [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]. See also https://westobserver.com/news/europe/in-the-ryazan-region-they-tried-to-set-fire-to-the-military-enlistment-office/  
[[OSINT Project/Maps/Pronsk, Пронское городское поселение, Pronsky District, Ryazan Oblast, Central Federal District, Russia|Pronsk]], Ryazan

Date discrepancy - May 14 or 15, 2022. Used later date as it is also described as "a few hours later" after an action on 15 May [[OSINT Project/Maps/Pronsk, Пронское городское поселение, Pronsky District, Ryazan Oblast, Central Federal District, Russia|Pronsk]] (Ryazan) Barely an hour later (after Volgorad), a message arrived about a [[fire]] in the door and window frame of the military registration and enlistment office in the village of [[OSINT Project/Maps/Pronsk, Пронское городское поселение, Pronsky District, Ryazan Oblast, Central Federal District, Russia|Pronsk]], Ryazan region. No one was [[arrested]]. https://darknights.noblogs.org/post/tag/khanty-nansi/

~+~  
184

# Gloria Jeans/Gloriya/Gee Jay factory

2022-05-15  
[[fire]]  
Political,Elite,Other  
https://bykvu.com/eng/thoughts/645/  
Gloria Jeans/Gloriya/Gee Jay factory in Rostov-on-Don is on [[fire]]. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]] based but profiteered off Donbas to avoid paying Ukraine taxes. ‘Gloria Jeans’ apparel is found to be made in Russia-occupied territories of Ukraine’s Donbas.  
Rostov-on-Don

Separatist Profiteering - Gloria ran 2 stores in Crimea & 5-7 factories in Russian-occupied DNR/LNR, paying almost half the wages in Russia or China. Gloria paid DNR/LNR taxes but not Ukrainian taxes.

~+~  
185

# DM Tower Business Center on [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]'s Novodanilovskaya embankment

2022-05-16  
[[fire]]  
Elite  
https://news.italy-24.com/world/452031.html  
DM Tower Business Center on [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]'s Novodanilovskaya embankment is on [[fire]]. 18-stories & under construction. [[fire]] on the top floor according to a construction worker.  
Novodanilovskaya embankment, [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

~+~  
186

# Stroitel, Belgorod Laquer and Varnish Shop

2022-05-16  
[[fire]]  
Chemical  
https://thenewsglory.com/the-ministry-of-emergency-situations-spoke-about-the-fire-in-the-lacquer-production-shop-near-belgorod/  
In the city of Stroitel, Belgorod Region, a lacquer production shop caught [[fire]]. This was announced on Monday, May 16, in the regional Ministry of Emergency Situations. It is noted that a message about a [[fire]] on 3rd Zavodskaya Street in the Yakovlevsky city district was received at 1:36 a.m., the [[fire]] broke out in an unused varnish production workshop. On Monday night, the BelPlus Telegram channel published footage showing pillars of black smoke from a brick factory in the town of Stroitel, Belgorod Region. Local residents reported a [[fire|burning]] smell in the area.  
3rd Zavodskaya Street, Yakovlevsky, Belgorod

This may not be partisan activity, but it was shared on direct action channels which lends itself to potentially being an act of defiance.

~+~  
71

# Berdsk Chemical Plant

2022-05-17  
[[fire]]  
Chemical  
https://www.newsweek.com/russia-fire-berdsk-emergency-ministry-siberia-novosibirsk-1707193  
Industrial building with office space at Khimzavodskaya Street, Berdsk near [[OSINT Project/Maps/Novosibirsk, Novosibirsk Oblast, Siberian Federal District, 630000, Russia|Novosibirsk]] in [[Siberian Federal District|Siberia]] is on [[fire]] & damaged equipment. State emergency services says polyethylene (very common plastic) is the source. Unclear of origin. [[fire]] broke out in an industrial building. 22,000 square feet in a building with office space in Berdsk, near [[Siberian Federal District|Siberia]]'s largest city of [[OSINT Project/Maps/Novosibirsk, Novosibirsk Oblast, Siberian Federal District, 630000, Russia|Novosibirsk]] The regional department of Russia's emergency ministry said in a post on social media that the source of the [[fire]] were polyethylene products on the first floor of the building which was located on Khimzavodskaya Street.  
Khimzavodskaya Street, Berdsk

~+~  
103

# Shchelkovsky, [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]] Recruitment Office

2022-05-18  
Molotov  
Recruitment  
https://darknights.noblogs.org/post/tag/khanty-nansi/  
Shchelkovsky ([[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]) On May 18, two molotovs flew inside the military commissariat in Shchelkovsky, near [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]. Both offices were damaged by the flames, including the archives of the military registration and enlistment office == Two offices are seriously damaged, including the archive with the data of conscripts. On this video we see smashing of its windows, after which the partisan pours incendiary mixture inside. Then comes the [[fire|arson]]. In all this cases, the punishers did not seize anyone. == Two offices of the building, including the archive, were damaged by the [[fire|arson]] attack. The arsonists have not been found yet. https://enoughisenough14.org/2022/06/26/shortly-after-the-longest-night-of-the-year-two-recruiting-offices-burned-at-once-chronicle-of-arson-attacks-until-june-25-2022-russia/  
Shchelkovsky, [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

AKA Shchelkovo or Shchyolkovo video https://t.me/live_corr/1831 See also https://meduza.io/news/2022/05/18/v-rossii-vnov-popytalis-podzhech-voenkomat-kokteylyami-molotova-zabrosali-zdanie-schelkovskogo-voennogo-komissariata-v-podmoskovie

~+~  
187

# Lukashenko Death Penalty for "terrorist attacks"

2022-05-18

https://www.dw.com/en/belarus-attempted-terrorism-to-be-punishable-by-death/a-61837461  
Not an act of defiance, but important in the time line. Belarus has introduced the death penalty for attempted terrorist attacks. The move could affect opposition [[activism|activists]] who are currently on trial. a "terrorist act" being a fluid definition.

~+~  
13

# Zheleznogorsk-Ilimsky Recruitment Office

2022-05-19  
Other  
Recruitment  
https://enoughisenough14.org/2022/06/26/shortly-after-the-longest-night-of-the-year-two-recruiting-offices-burned-at-once-chronicle-of-arson-attacks-until-june-25-2022-russia/  
military enlistment office - shot at with pneumatic weapons in Zheleznogorsk-Ilimsky in [[OSINT Project/Maps/Irkutsk Oblast, Siberian Federal District, Russia|Irkutsk Region]] In the city of Zheleznogorsk-Ilimsky on the night of May 19-20, an army recruiting office was shot at with a BB gun.  
Zheleznogorsk-Ilimsky, [[OSINT Project/Maps/Irkutsk Oblast, Siberian Federal District, Russia|Irkutsk Region]]

See also https://theins.ru/news/251440

~+~  
179

# [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] 3 Cars

2022-05-19  
[[fire]]  
Other  
https://ivteleradio.ru/news/2022/05/19/tri_avtomobilya_sgoreli_utrom_v_ivanove  
3 cars on [[fire]].  
[[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]]

Note - [[fire|Burning]] cars does not seem to be rare in Russia. These cars were said elsewhere to have had Z iconography. It is also possible they were [[fire|burned]] as part of the Heavy Machine Tool Plant [[fire]] in the same area on the same day.

~+~  
180

# [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] Heavy Machine Tool Plant

2022-05-19  
[[fire]]  
Other Defence  
https://www.dailykos.com/stories/2022/5/19/2098927/-Ivanovo-Heavy-Machine-Tool-Plant-is-the-Latest-Suspicious-Fire-at-a-Strategic-Site-in-Russia  
The [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] Heavy Machine Tool Plant is allegedly critical to several defense related products. A major [[fire]] at this plant was [[fire|burning]] for hours today.  
[[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]]

The chemical plant [[fire]] from April 21 in Kinishma & a conscript registration office hit April 22 are nearby.

~+~  
48

# Igra, Udmurtia Recruitment Office

2022-05-21  
Molotov  
Recruitment  
https://theins.ru/news/251473  
in Udmurtia (Russia) on the night of May 22, there was a [[fire]] in the military registration and enlistment office, fragments of a Molotov cocktail were found at the scene. In Russia, such cases have become more frequent due to mobilization. https://globalhappenings.com/top-global-news/196541.html = the entire reserve room [[fire|burned]] out (a little over 9 square meters). Unfortunately, there were no documents in the room, only personal belongings of the employees. = On the night of May 21, unknown persons set [[fire]] to the military registration and conscription office in the settlement of Igra in Udmurtia by throwing a “Molotov cocktail” into the building. In a successful action, the room for reservists in the building went completely up in flames during the [[fire]]. https://enoughisenough14.org/2022/06/26/shortly-after-the-longest-night-of-the-year-two-recruiting-offices-burned-at-once-chronicle-of-arson-attacks-until-june-25-2022-russia/  
Igra, Udmurtia

Date discrepancy - 21 & 22 May. Used earliest date. AKA Udmurtskaya Rural teacher Ilya Farber, who is suspected of an [[fire|arson]] attack against a military call-up center in Udmirtiya is being held in remand prison # 1 in the city if Izhevsk. He is accused of ”destruction of property”. https://avtonom.org/en/news/support-suspected-arsonists-against-military-call-ups-and-other-russian-anti-war-prisoners A few days later, the FSB [[arrested|detained]] a suspect: 48-year-old Ilya Farber, who came to visit relatives living in Igra. The man has been searched, during it two canisters of gasoline, wire, potassium permanganate, funnels, five bank cards and three iPhones were seized. Farber is a painter and former director of a rural house of culture in the Tver region. In 2013, he was convicted of abuse of office and taking a bribe. The case had clear signs of falsification and got a wide resonance. Even Putin called his sentence "outrageous"! https://libcom.org/article/arise-ukrainian-comrades-anti-war-direct-actions-russia-and-its-9th-review Video of interrogation https://t.me/bazabazon/11799

~+~  
49

# [[OSINT Project/Maps/Central Aerohydrodynamic Institute, 1, ul. Zhukovskogo, Центр, Zhukovsky, Moscow Oblast, Central Federal District, 140181, Russia|TsAGI]] (Aviation)

2022-05-21  
[[fire]]  
Aerospace/Aviation,Other Defence  
https://globalhappenings.com/top-global-news/196541.html  
On May 21, the famous [[OSINT Project/Maps/Central Aerohydrodynamic Institute, 1, ul. Zhukovskogo, Центр, Zhukovsky, Moscow Oblast, Central Federal District, 140181, Russia|TsAGI]] [[fire|burned]] in the [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]] region. It is the largest research center in the field of aviation and astronautics. Also reported elsewhere - [[fire]] at the substation in [[OSINT Project/Maps/Central Aerohydrodynamic Institute, 1, ul. Zhukovskogo, Центр, Zhukovsky, Moscow Oblast, Central Federal District, 140181, Russia|TsAGI]] (aviation institute)  
[[OSINT Project/Maps/Central Aerohydrodynamic Institute, 1, ul. Zhukovskogo, Центр, Zhukovsky, Moscow Oblast, Central Federal District, 140181, Russia|Zhukovsky]]

~+~  
72

# Igra, Udmurtia Recruitment Office 2nd (Server Room)

2022-05-23  
Molotov  
Recruitment  
https://libcom.org/article/arise-ukrainian-comrades-anti-war-direct-actions-russia-and-its-9th-review  
On the night of May 21, a Molotov cocktail was thrown into the recruiting station of Igra in Udmurtia Republic. As we can see on the title photo, the entire reserve room [[fire|burned]] out (a little over 9 square meters). Unfortunately, there were no documents in the room, only personal belongings of the employees. A couple of days later, another enlistment center of this village also was attacked with such bottle - then the [[fire]] spread through the server room, where official documentation and a card file of veterans of the Second World War were stored.  
Igra, Udmurtia Republic

A few days later, the FSB [[arrested|detained]] a suspect: 48-year-old Ilya Farber, who came to visit relatives living in Igra. The man has been searched, during it two canisters of gasoline, wire, potassium permanganate, funnels, five bank cards and three iPhones were seized. Farber is a painter and former director of a rural house of culture in the Tver region. In 2013, he was convicted of abuse of office and taking a bribe. The case had clear signs of falsification and got a wide resonance. Even Putin called his sentence "outrageous"! Video of interrogation https://t.me/bazabazon/11799

~+~  
155

# Sergiyevo-Posadsky [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]] District Railway Track

2022-05-23  
Mechanical  
Infrastructure,Railway  
https://a2day.org/ot-boevoj-gruppy-anarho-kommunistov/  
Sergiyevo-Posadsky District, [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]] Oblast, Russia We, the Militant Anarcho-Communist Organization, have carried out a sabotage operation on the railroad track at coordinates 56 16’44″N 38 12’40.5″E on a sidetrack leading to a military facility of the 12th Main Directorate of the Russian Ministry of Defense. The rail junction was dismantled and the rail tracks were partially disconnected. It must be emphasized that we are not sure that this disconnection was sufficient to free the train from the tracks. But it was a test sabotage, if you will, where we tested the feasibility with the help of tools. We also wanted the sabotage to be as inconspicuous as possible so that the train would not have time to come to a stop. Moreover, it is not sure that a derailment in such a deserted area will reach the media, and we have no possibility to observe it with our own eyes. Therefore, it was decided to publish the result of the attack “as it was” to share the experience with other guerrillas.  
Sergiyevo-Posadsky District [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]] Oblast, Russia  
56 16’44″N 38 12’40.5″E, 56.278889, 38.211111  
Date discrepancy - 23 or 26 May, 2022. Used earliest date. Earliest date confirmed. This section of the road leads to 14258 military unit. It's a secret training and tactical center of the 12th Main Directorate of the Ministry of Defense, which is responsible for Russian nuclear security: Some important aspects of this action are: 1) A track was chosen that leads to a military unit where no civilian trains operate in order to avoid innocent victims. We recommend using wikimapia.org for the search. There, military installations are marked that are not visible on conventional maps. You can also use satellite maps to judge whether a facility is “in operation.” For example, on the base to which the attacked sidetrack leads, you can see a collection of military equipment in open areas. 2) This immediately led to restrictions in the possible actions: On these lines, the wagons are pulled by diesel locomotives, so there are no signal cabinets and no power lines. The main point of attack is therefore the tracks themselves 3) We dismantled the rail connection part and unscrewed the screw nuts holding the rail to the railway sleepers. Normal construction tools, adjustable wrenches with a length of > 0.5 m, proved to be sufficient for this. An adjustable wrench is also required because the rail is fastened with 2 types of screw nuts. We recommend the use of a lubricant to make it easier to unscrew the nuts, as many of them are rusty and hardened. 4) Then the track can be lifted with levers and moved to the side. The more nuts that are used to fasten the rail to the sleepers are unscrewed, the easier it is to move it. The method has proven to be quite feasible and safe, although it could cause serious damage to the armed forces of the Russian Federation. We recommend it to all to use it. Source: tg channel Militant Anarcho-Communist Organization

~+~  
73

# Saint Peter and Paul Church

2022-05-24  
[[fire]]  
Cultural

??  
[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

~+~  
14

# Simferopol, Crimea Recruitment Office

2022-05-28  
Molotov  
Recruitment  
https://enoughisenough14.org/2022/06/26/shortly-after-the-longest-night-of-the-year-two-recruiting-offices-burned-at-once-chronicle-of-arson-attacks-until-june-25-2022-russia/  
On May 28, there was an unsuccessful attempt to set [[fire]] to a military recruiting office in Simferopol. On the night of May 28, there was an attack in Crimea. An unidentified one climbed over the fence and entered the territory of the military enlistment office on Selvinsky str. in Simferopol, after which he threw a Molotov cocktail through the basement window. The bottle broke on the window bars and caused no damage to the building. The watchman on duty tried to [[arrested|detain]] the attacker, but he broke free and fled before the police arrived. Bottle fragments are seized. The place is symbolic: this street bears the name of a famous Soviet writer, however in his youth he was a Black Guard fighter in the squad of Maria Nikiforova.  
Simferopol, Crimea

See also https://libcom.org/article/arise-ukrainian-comrades-anti-war-direct-actions-russia-and-its-9th-review

~+~  
150

# Yasnogorsk Recruitment Office

2022-05-30  
[[fire]]  
Recruitment  
https://enoughisenough14.org/2022/06/02/attack-on-military-recruitement-and-enlistment-office-with-an-axe-russia/  
Yasnogorsk. Russia. In the night from May 30 to 31 the building of military recruitement and enlistment office on Shcherbina street in Yasnogorsk (Tula region) was attacked. An unknown person smashed the window with an axe in order to [[fire|burn]] the enlistment office from inside. Usually such tactics (first break the window, then pour the flammable mixture and set it on [[fire]]) prove to be the most effective, but in this case, unfortunately, the staff of the institution managed to quickly put out the flames before the EMERCOM officers arrived to help. The attacker managed to escape, but he left an axe at the scene outside the military registration and enlistment office. We hope he will remain free and able to continue his fight.  
Shcherbina street, Yasnogorsk, Tula region

Date range May 30-31. Used earliest date. Yasnogorsk also is a notable place for ex-USSR revolutionary history: in 1999, in this town was а strike of machine-building plant's workers with the takeover of the enterprise…Other source https://newsbeezer.com/swedeneng/wave-of-molotov-attacks-on-russian-recruiting-offices/ 31-year-old Denis Arbarov was [[arrested|detained]] by the FSB as a suspect in this case. He's already confessed to everything. https://libcom.org/article/arise-ukrainian-comrades-anti-war-direct-actions-russia-and-its-9th-review

~+~  
148

# Prometeya calls for direct action other than words

2022-05-31  
Other  
Other  
https://a2day.org/obrashhenie-administraczii-prometeya/  
However, we must point out that in a war where the Russian state is killing people in Ukraine, graffiti and leaflets are hardly a sufficient means to stop the killing. A word will not stop a bullet. If you really want to make a difference, you should look for other ways to fight dictatorship and war. Some of these measures are already relatively widespread and popular in Russia–for example, there are regular reports of incendiary attacks on military recruitment centers or acts of sabotage on railroad tracks that can disrupt the Russian army’s infrastructure and supply logistics. We would like to call on all sincere people not to limit themselves to expressing their discontent with the war and the dictatorship, whether on the Internet or in the streets. Words without actions are empty, and the dictatorship has reached the point where it is now or never to act.

prometeya is an [[activism|anarchist]]/community direct action group - The admins of Prometeya have been part of the [[activism|anarchist]] movement for many years and over the years we have directly participated in [[activism|anarchist]] activities, taking part in actions with varying degrees of radicalism and putting ourselves at risk. We have been persecuted and tortured, suffered many deprivations and had to leave the country because of our activities. In Russia, we face severe punishment and torture, and we live with the reality that this will happen to us if we are getting deported. “Narodnaya Samooborona” (People’s Self-Defense), our movement, was destroyed due to repression and has suspended its activities for several years now. To a large extent, this also applies to Prometeya–it has practically stopped working as a media source. Nevertheless, the [[activism|activists]] of the former People’s Self-Defense and the admins of Prometeya are still active. Some are fighting against the Russian army in Ukraine, putting themselves in great danger. Others are organizing fundraising events for [[activism|anarchists]] who are fighting in Ukraine. We will not stay inactive.

~+~  
46

# [[OSINT Project/Maps/Naberezhnye Chelny, Tatarstan, Volga Federal District, Russia|Naberezhnye Chelny]] warehouse

2022-06-03  
[[fire]]

https://globalhappenings.com/top-global-news/195845.html  
[[OSINT Project/Maps/Naberezhnye Chelny, Tatarstan, Volga Federal District, Russia|Naberezhnye Chelny]], a warehouse with rubber and plastic [[fire|burned]] epic.  
[[OSINT Project/Maps/Naberezhnye Chelny, Tatarstan, Volga Federal District, Russia|Naberezhnye Chelny]]

~+~  
47

# Grand Setun Plaza Business Center

2022-06-03  
[[fire]]  
Elite,Government  
https://globalhappenings.com/top-global-news/195845.html  
Grand Setun Plaza business center caught [[fire]]. There were about 15 people inside. Propaganda media have already reported that the cause was a short circuit due to improper installation of lighting on the facade.

Building includes the offices of Pension Fund of Russia

~+~  
45

# Rogvardia - National Guard Building

2022-06-04  
[[fire]]  
Military  
https://globalhappenings.com/top-global-news/196541.html  
In Russia, the building of the Rogvardia was on [[fire]]. It is reported that it was set on [[fire]] by an unknown person in [[OSINT Project/Maps/Komsomolsk-on-Amur, Khabarovsk Krai, Far Eastern Federal District, Russia430.3526436163887|Komsomolsk-on-Amur]]. The Telegram channel “Ukraine 24” writes about this. The man approached the building with a canister. According to some reports, he was able to enter the lobby and spilled fuel there, according to others, he simply put the canister on the porch and set it on [[fire]].  
[[OSINT Project/Maps/Komsomolsk-on-Amur, Khabarovsk Krai, Far Eastern Federal District, Russia430.3526436163887|Komsomolsk-on-Amur]], in the Far East

Later, a 50-year-old local resident was [[arrested|detained]].

~+~  
154

# [[OSINT Project/Maps/Komsomolsk-on-Amur, Khabarovsk Krai, Far Eastern Federal District, Russia430.3526436163887|Komsomolsk-on-Amur]] Rosgvardia Office

2022-06-04  
Molotov  
Military  
https://t.me/BO_AK_reborn/1735  
a guerrilla attack was launched against the Rosgvardia office in [[OSINT Project/Maps/Komsomolsk-on-Amur, Khabarovsk Krai, Far Eastern Federal District, Russia430.3526436163887|Komsomolsk-on-Amur]]. The plan by the guerrilla militant was ambitious: as Baza reports, the daredevil wanted to get into the Rosgvardiya [1] building itself in order to ignite a canister with flammable liquid inside. The door was closed, so the guerrilla fighter set the canister on [[fire]] on the porch. A [[fire]] broke out. one partisan was [[arrested]]. His name is Vladimir Zolotorev and he is 50 years old. [[activism|Anarchist]] Fighter added “Note that a canister with a flammable liquid burns just as well as a Molotov. In addition, a fuse or simple detonator can be attached to a canister (or even several canisters tied together), which delays the moment of ignition for some time and thus greatly increases the chances of a safe getaway for the guerrillas,” in their Telegram post.  
[[OSINT Project/Maps/Komsomolsk-on-Amur, Khabarovsk Krai, Far Eastern Federal District, Russia430.3526436163887|Komsomolsk-on-Amur]]

Date discrepancy 4 or 5 June, 2022. Used earliest date. Also see BAZA https://t.me/bazabazon/11889 Rosgvardia = National Guard

~+~  
75

# Vladivostok Recruitment Office

2022-06-06  
[[fire]]  
Recruitment  
https://darknights.noblogs.org/post/2022/06/13/vladivostok-russia-military-recruitment-center-set-on-fire/  
Vladivostok. Russia. In the early morning hours of June 6, 2022, another office for military call-ups and recruitment was set on [[fire]], this time in the wooden building at 23 Uborevicha Street in Vladivostok. The facade of the building was damaged as a result of the [[fire]]. There is conflicting information about how exactly the attack was carried out. Komsomolskaya Pravda”, referring to the police, reports about two suspects who threw a bottle with a flammable liquid against the front wall of the building. Passers-by scared away the arsonists, so that the building did not completely went up in flames, the cladding boards [[fire|burned]]. The Telegram channel Shot reports about an arsonist who used a rag prepared with a flammable substance. The arsonists were able to escape. This is the 18th [[fire|arson]] attack on an enlistment office that has occurred in recent times. This does not even include the [[fire|arson]] attacks on other military and industrial facilities, which the authorities are trying to dismiss as accidents. the military had already begun replacing damaged wooden boards and the head of the regional [[OSINT Project/Maps/Primorsky Krai, Far Eastern Federal District, Russia|Primorsky Krai]] police, Maj. Gen. Oleg Stefankov, had registered the [[fire|arson]] incident and put the building "under control."  
23 Uborevicha Street, Vladivostok, [[OSINT Project/Maps/Primorsky Krai, Far Eastern Federal District, Russia|Primorsky Krai]]

Contrary dates. Used the earliest 6 or 8 June. Also see https://www.newsweek.com/military-enlistment-office-set-fire-russia-1713838

~+~  
59

# Zagorsk Optical and Mechanical Plant

2022-06-08  
[[fire]]  
Other Defence  
https://globalhappenings.com/top-global-news/200735.html  
a warehouse of the Zagorsk Optical and Mechanical Plant [[fire|burned]], which produces military optics for the Russian army–from binoculars to optical sights. According to preliminary information, the flames engulfed warehouses next to the administrative building. At first it was reported that the [[fire]] area was only 30 square meters. m., but the [[fire]] spread very quickly throughout the territory, covering 700 square meters of area.  
Sergiev Posad

military optics for the Russian army–from binoculars to optical sights. Zagorsk Optical & Mechanical Plant warehouse (optical, thermal & night-vision sighting systems)[33]

~+~  
74

# Rosatom (Nuclear) Institute of Digital Technologies

2022-06-08  
[[fire]]  
Education,Other Defence  
https://en.m.wikipedia.org/wiki/2022_Russian_mystery_fires  
??  
Sarov, Nizhny Novgorod

~+~  
58

# [[Armored Personnel Carrier in Transit]]

2022-06-10  
[[fire]]  
Military,Ammunition Depot  
https://globalhappenings.com/top-global-news/202406.html  
In the Rostov region of Russia on June 10, an armored [[Armored Personnel Carrier in Transit|personnel carrier]] with ammunition caught [[fire]] on the highway. Ammunition detonated in Russian vehicles after a [[fire]]. An eyewitness to the incident said that the accident occurred near the village of Cossack camps. The scene was blocked by Russian police. After the [[fire]], he heard the sounds of explosions–detonated ammunition. Due to an accident, a traffic jam formed on the highway. Drivers were not allowed to enter the scene of the accident.  
Kazachy Camps, Cossack, Rostov region

Some bloggers, spreading the video, erroneously indicated that the [[Armored Personnel Carrier in Transit|APC]] exploded in the Kuban, but this is not so.

~+~  
76

# Factor timber terminal

2022-06-10  
[[fire]]

"Factor" timber terminal owned by oligarch Ramis Deberdeyev  
Ust-Luga

~+~  
152

# Nizhny Novgorod Natalya Abieva Vehicle

2022-06-10  
[[fire]]  
Elite  
https://t.me/theblackheadquarter/238  
Toyota (Р561ХТ152) which belonged to Natalya Abieva, the sponsor of Putinist occupiers, was [[fire|burned]] down in Nizhny Novgorod on 10.06.2022. It happened at 3 a.m., by the address Krasnykh Zor street, 24. Abieva is organizer of the foundation in support of Putin’s army, convinced supporter of ruling regime and of war. People like her don’t care about deaths of tens of thousands of people in Ukraine, millions of broken lifes. Abieva is interested just in artificial “greatness of Russia”. But is it possible to gain greatness, while you cover yourself with blood? We believe that this war brings death not only for Ukraine but for Russia as well. We must do all we can to stop it. There are no more means for peaceful protest in our country. We hope, that this clear message will be heared. Now we actively collect data base on regime supporters in our region. The struggle will continue. Dictatorship should be replaced by the society based on freedom, equality and solidarity. See you! Revolutionary cell of Volga region  
Krasnykh Zor street, 24, Nizhny Novgorod, Volga

Claimed by Revolutionary cell of Volga region English coverage https://enoughisenough14.org/2022/06/13/car-of-natalya-abieva-sponsor-of-the-russian-army-torched-in-nizhny-novgorod-russia/

~+~  
192

# Belarusian MAZ Buses in Vitebsk, St Petersburg

2022-06-10  
[[fire]]  
Infrastructure  
https://charter97.org/en/news/2022/6/23/503601/  
Belarusian made MAZ bus caught on [[fire]] on Vitebsk Ave in St Petersburg. June 10, MAZ caught [[fire]] on Vitebsk Ave. According to the Ministry of Emergency Situations, the bus "burnt out parts". There were no casualties. There have been two accidents with Belarusian buses in a month in the Russian city. Russian transport company Domtransavto, serving several routes in St. Petersburg, will remove MAZ buses from the routes and send the entire batch for examination. The decision was made after the second [[fire]] in June  
Vitebsk Ave, St Petersburg

27 June 2022 Lukashenko meets with Alexander Beglov to discuss exploding & [[fire|burning]] MAZ buses in St Petersburg. Russia ordered 1,000 MAZ buses. Putin approved 15 Belarusian "substitution" projects…https://president.gov.by/en/events/vstrecha-s-gubernatorom-samarskoy-oblasti-dmitriem-azarovym-1656326969?TSPD_101_R0=08eaf62760ab20006371f9c526d3d319651ab964247994a4f1bfd0c756cde197e0d3d7f441c36dd408e75b61f214300084f02b2acbeebc7e5843aa2aa9675eecce27d1b81c6b0e84116e0fed59779d84fef6ae197f348d01a07206c8d22e8c78

~+~  
57

# Military Unit Equipment Cotton Karma

2022-06-11  
[[fire]]  
Military  
https://globalhappenings.com/top-global-news/202641.html  
COTTON KARMA. A MILITARY UNIT BURNS WITH A BLUE FLAME IN THE BRYANSK REGION. In Russia, a military unit with the equipment of the invaders caught [[fire]]. a large-scale [[fire]] broke out on the territory of a military unit. It is located about 50 kilometers from the border with Ukraine. The local military unit heard one strong explosion and three less loud ones. They say that military equipment that was used in Ukraine was damaged.  
[[OSINT Project/Maps/Klintsy, городской округ Клинцы, Bryansk Oblast, Central Federal District, 243140, Russia|Klintsy]], Bryansk Region

Military equipment used in Ukraine was damaged. The city where the explosions took place, near the border with the Chernihiv region

~+~  
77

# Bryansk Druzhba pipeline signal loss 3 explosions

2022-06-11  
Explosion  
Gas/Oil  
https://news.yahoo.com/russia-tried-blow-druzhba-pipeline-103804242.html?guccounter=1  
Druzhba pipeline near Gulevka - means friendship Russian media write that on 11 June, three explosions took place near the village of Gulivka in the Bryansk region (40 km to the border with Ukraine). At the same time a signal indicated loss of communication with the latch of the Druzhba pipeline. It is reported that one of the explosions damaged the transformer substation with the power unit of the pipeline latch. Another explosion occurred in the place where the cable was laid. There was a shell hole [measuring] 40 by 20 cm. The third explosion damaged the anti-dig pipe (an additional means of protection which is in the ground at the regime facilities), leaving a shell-hole [measuring] 40 by 60 centimetres. It is noted that the Druzhba pipeline itself was not damaged, but the anti-dig pipe and the substation were damaged, and power was lost to the latch control unit.  
Gulevka or Gulivka, Bryansk

Gulivka AKA Gulevka it was possible to avoid an oil spill [as] the pipeline has been closed since 24 February, but there is diesel fuel inside. Druzhba is the world's largest network of main oil pipelines. It was built in the 1960s to supply oil to Eastern Europe to socialist countries that were at that time friendly to the Soviet Union.

~+~  
143

# [[OSINT Project/Maps/Krasnoyarsk, Krasnoyarsk Urban Okrug, Krasnoyarsk Krai, Siberian Federal District, 660000, Russia|Krasnoyarsk]] 24 [[railway car|railway cars]] derailed

2022-06-11  
Mechanical  
Railway,Infrastructure  
https://enoughisenough14.org/2022/07/04/rail-war-belarusians-face-the-death-penalty-the-blocked-trans-sib-anarchists-work-around-moscow-belarus-russia/  
incident on the [[OSINT Project/Maps/Monument to the 170th anniversary of the Trans-Siberian Railway, улица Леконта, Привокзальный, Ленинский административный округ, Omsk, Omsk Oblast, Siberian Federal District, 644000, Russia|Trans-Siberian Railway]] involving freight trains: on June 11, another 24 freight wagons overturned on the [[OSINT Project/Maps/Krasnoyarsk, Krasnoyarsk Urban Okrug, Krasnoyarsk Krai, Siberian Federal District, 660000, Russia|Krasnoyarsk]] section of the road, the cause of the incident was not stated.  
[[OSINT Project/Maps/Krasnoyarsk, Krasnoyarsk Urban Okrug, Krasnoyarsk Krai, Siberian Federal District, 660000, Russia|Krasnoyarsk]]

~+~  
19

# [[OSINT Project/Maps/Krasnodar, Krasnodar Municipality, Krasnodar Krai, Southern Federal District, 350000, Russia|Krasnodar]] FSB Building

2022-06-15  
Molotov  
Government  
https://enoughisenough14.org/2022/06/26/shortly-after-the-longest-night-of-the-year-two-recruiting-offices-burned-at-once-chronicle-of-arson-attacks-until-june-25-2022-russia/  
On June 15, an attempt was made to set [[fire]] to the FSB building in [[OSINT Project/Maps/Krasnodar, Krasnodar Municipality, Krasnodar Krai, Southern Federal District, 350000, Russia|Krasnodar]].  
[[OSINT Project/Maps/Krasnodar, Krasnodar Municipality, Krasnodar Krai, Southern Federal District, 350000, Russia|Krasnodar]]

~+~  
78

# Urengoy Gas Field

2022-06-16  
[[fire]]  
Gas/Oil  
https://en.m.wikipedia.org/wiki/2022_Russian_mystery_fires  
The largest natural gas field in Russia Urengoy gas field [[OSINT Project/Maps/Novy Urengoy, городской округ Новый Уренгой, Yamalo-Nenets Autonomous Okrug, Ural Federal District, 629300, Russia|Novy Urengoy]], lies in Yamalo-Nenets Autonomous Okrug in Tyumen Oblast of Russia, just south of the Arctic circle and named after the settlement of Urengoy  
[[OSINT Project/Maps/Novy Urengoy, городской округ Новый Уренгой, Yamalo-Nenets Autonomous Okrug, Ural Federal District, 629300, Russia|Novy Urengoy]]

~+~  
53

# Barsovo Ammunition Depot - military unit 55443

2022-06-22  
[[fire]]  
Military,Ammunition Depot  
https://globalhappenings.com/top-global-news/218355.html  
on June 22, in the village of Barsovo (Vladimir region), a [[fire]] broke out in the arsenal for the complex storage of missiles, ammunition and explosive materials (military unit 55443) of the main rocket and artillery department of the RF Ministry of Defense.  
Barsovo, Vladimir region

DURING THE [[fire]], AMMUNITION DETONATED, WHICH LED TO THE DESTRUCTION OF MORE THAN 400 9M113 (9M113K) KONKURS ANTI-TANK MISSILE SYSTEMS AND SHELLS FOR THEM, AS WELL AS TO THE DEATH OF MORE THAN 3 SERVICEMEN OF THE RF ARMED FORCES,

~+~  
54

# Novoshakhtinsky oil refinery

2022-06-22  
[[fire]]  
Gas/Oil  
https://globalhappenings.com/top-global-news/211867.html  
Earlier in the Rostov region, after the “cotton”, the Novoshakhtinsky oil refinery caught [[fire]]. The area of ​​the [[fire]] was 50 square meters. Russian Telegram channels claim that a Ukrainian drone allegedly caused the “clap”. The Novoshakhtinsky Oil Refinery is located 150 kilometers from Donetsk and even further from the line where the fighting is taking place. === Russia claims it was hit by a Ukraine drone, but direct action groups have taken credit. https://www.themoscowtimes.com/2022/06/22/major-russian-oil-refinery-says-struck-by-ukrainian-drone-a78069  
Novoshakhtinsky, Rostov

This refinery is the largest supplier of petroleum products in the [[OSINT Project/Maps/Southern Russia, улица Степана Разина, Ворошиловский район, Volgograd, Volgograd Oblast, Southern Federal District, 400001, Russia|south of Russia]]. It specializes in the production of fuel oil, heating oil, marine and diesel fuel, straight-run gasoline. In April 2021, a large construction contractor of the Russian Federation PETON became the owner of the Novoshakhtinsk oil products plant, before that The refinery was registered to the wives of Viktor Medvedchuk and Taras Kozak.

~+~  
11

# [[OSINT Project/Maps/Kirovsky District, Stavropol Krai, North Caucasian Federal District, Russia|Kirovsky District]], [[OSINT Project/Maps/Perm, Perm Krai, Volga Federal District, Russia|Perm]], Military Commissariat

2022-06-23  
Molotov  
Recruitment  
https://www.newsweek.com/russia-dissent-putin-ukraine-war-man-molotov-cocktail-fsb-government-building-fire-1720900  
4 Molotov cocktails thrown at the office of the Military Commissariat for [[OSINT Project/Maps/Kirovsky District, Stavropol Krai, North Caucasian Federal District, Russia|Kirovsky District]] in Zakamskaya Street in [[OSINT Project/Maps/Perm, Perm Krai, Volga Federal District, Russia|Perm]]. Baza reported that last week in the city of [[OSINT Project/Maps/Perm, Perm Krai, Volga Federal District, Russia|Perm]], more than 700 miles east of [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]], four bottles filled with inflammable liquid were thrown into the office of the Military Commissariat for [[OSINT Project/Maps/Kirovsky District, Stavropol Krai, North Caucasian Federal District, Russia|Kirovsky District]]. There was no [[fire]], and the attackers fled the scene See also https://theins.ru/en/news/252560  
Zakamskaya Street, [[OSINT Project/Maps/Kirovsky District, Stavropol Krai, North Caucasian Federal District, Russia|Kirovsky District]], [[OSINT Project/Maps/Perm, Perm Krai, Volga Federal District, Russia|Perm]]

June 23/24, 2022: 4 Molotov cocktails thrown at the office of the Military Commissariat for [[OSINT Project/Maps/Kirovsky District, Stavropol Krai, North Caucasian Federal District, Russia|Kirovsky District]] in Zakamskaya Street in [[OSINT Project/Maps/Perm, Perm Krai, Volga Federal District, Russia|Perm]].

~+~  
193

# Belarusian MAZ Buses Svetlanovsky St Petersburg

2022-06-23  
[[fire]]  
Infrastructure  
https://charter97.org/en/news/2022/6/23/503601/  
Another bus caught [[fire]] this morning on Svetlanovsky Avenue. The [[fire]] extinguishing system went off in the bus, the driver took the passengers out of the salon; no one was injured. Russian transport company Domtransavto, serving several routes in St. Petersburg, will remove MAZ buses from the routes and send the entire batch for examination. The decision was made after the second [[fire]] in June on buses of this model  
Svetlanovsky Avenue, St Petersburg

27 June 2022 Lukashenko meets with Alexander Beglov to discuss exploding & [[fire|burning]] MAZ buses in St Petersburg. Russia ordered 1,000 MAZ buses. Putin approved 15 Belarusian "substitution" projects…https://president.gov.by/en/events/vstrecha-s-gubernatorom-samarskoy-oblasti-dmitriem-azarovym-1656326969?TSPD_101_R0=08eaf62760ab20006371f9c526d3d319651ab964247994a4f1bfd0c756cde197e0d3d7f441c36dd408e75b61f214300084f02b2acbeebc7e5843aa2aa9675eecce27d1b81c6b0e84116e0fed59779d84fef6ae197f348d01a07206c8d22e8c78

~+~  
87

# [[OSINT Project/Maps/Novy Urengoy, городской округ Новый Уренгой, Yamalo-Nenets Autonomous Okrug, Ural Federal District, 629300, Russia|Novy Urengoy]]-Orenburg [[railway car|Train Car]] [[fire]]

2022-06-24  
[[fire]]  
Infrastructure,Railway  
https://ura.news/news/1052564729  
The emergency on the train occurred early in the morning of June 24. On the Hanymey - Noyabrsk-2 section in the Yamalo-Nenets Autonomous District, the 13th car of the [[OSINT Project/Maps/Novy Urengoy, городской округ Новый Уренгой, Yamalo-Nenets Autonomous Okrug, Ural Federal District, 629300, Russia|Novy Urengoy]]-Orenburg passenger train caught [[fire]]. According to the preliminary version, the cause of the [[fire]] is [[fire|arson]].  
Hanymey - Noyabrsk-2 section in the Yamalo-Nenets Autonomous District - [[OSINT Project/Maps/Novy Urengoy, городской округ Новый Уренгой, Yamalo-Nenets Autonomous Okrug, Ural Federal District, 629300, Russia|Novy Urengoy]]-Orenburg

Residents of [[OSINT Project/Maps/Nizhnevartovsk, городской округ Нижневартовск, Khanty-Mansiysk Autonomous Okrug – Ugra, Ural Federal District, Russia|Nizhnevartovsk]] helped [[arrested|detain]] a man suspected of setting [[fire]] to a [[railway car|train car]]. This was reported to URA.RU by Anna Skala, who works together with Ugra residents.

~+~  
88

# Belgorod Recruitment Office

2022-06-24  
Molotov  
Recruitment  
https://news.bigmir.net/world/6330781-v-belgorode-i-permi-podozhgli-voenkomaty  
In Belgorod, a [[fire]] broke out on the first floor. An unidentified person broke a window of the building on the first floor and threw two Molotov cocktails into room 106. It is reported that a desk went up in flames. See also https://theins.ru/en/news/252560  
Belgorod

Also see https://www.newsweek.com/russia-dissent-putin-ukraine-war-man-molotov-cocktail-fsb-government-building-fire-1720900

~+~  
89

# [[OSINT Project/Maps/Perm, Perm Krai, Volga Federal District, Russia|Perm]] Recruitment Office

2022-06-24  
Molotov  
Recruitment  
https://news.bigmir.net/world/6330781-v-belgorode-i-permi-podozhgli-voenkomaty  
In [[OSINT Project/Maps/Perm, Perm Krai, Volga Federal District, Russia|Perm]], unknown persons also tried to set [[fire]] to the army recruitment office. Around 4 a.m. several Molotov cocktails flew into the recruitment office in the [[OSINT Project/Maps/Kirovsky District, Stavropol Krai, North Caucasian Federal District, Russia|Kirovsky district]] on Zakamskaya Street. Four bottles were found on the spot–two broke, two remained in their original state, no [[fire]] broke out.  
Zakamskaya Street, [[OSINT Project/Maps/Kirovsky District, Stavropol Krai, North Caucasian Federal District, Russia|Kirovsky district]], [[OSINT Project/Maps/Perm, Perm Krai, Volga Federal District, Russia|Perm]]

Also see https://enoughisenough14.org/2022/06/26/shortly-after-the-longest-night-of-the-year-two-recruiting-offices-burned-at-once-chronicle-of-arson-attacks-until-june-25-2022-russia/

~+~  
109

# Luveno-Porkhov, Pskov Railway Derailment

2022-06-24  
Mechanical  
Railway,Infrastructure  
https://libcom.org/article/rail-war-belarusians-face-death-penalty-blocked-trans-sib-anarchists-work-around-moscow  
Lunevo-Porkhov stretch in the Pskov region, where 13 wagons reportedly carrying explosives were derailed on June 24 (the brake did not work at the right time)  
Lunevo-Porkhov Rail, Pskov region

~+~  
189

# Mystery Cargo [[aircraft|Plane]]

2022-06-24  
[[fire]]  
Military  
https://www.reuters.com/world/europe/cargo-plane-crash-lands-near-russias-ryazan-seven-injured-ifax-2022-06-24/  
Mystery military cargo [[aircraft|plane]] - no one knows which organization runs the [[aircraft|plane]] - crash lands in Ryazan & catches [[fire]] killing 3, injuring 6. Video shows [[aircraft|plane]] on [[fire]] before landing. Later this was identified as military related. Ilyushin Il-76 military cargo [[aircraft|plane]] crashed and caught [[fire]] while landing near Russia's western city of Ryazan on Friday, killing four of the nine people on board. Russia's defence ministry as saying the [[aircraft|plane]] had suffered an engine malfunction while on a training flight. (This appears to be in dispute)  
Ryazan

~+~  
190

# St. Basil the Great [[OSINT Project/Maps/Osinovaya Roshcha, Pargolovo, Saint Petersburg, Northwestern Federal District, 194902, Russia|Aspen Grove]]

2022-06-26  
[[fire]]  
Cultural  
https://bb-cntv.com/news/fire-in-the-church-in-aspen-grove-details-of-the-russian-orthodox-church-told-june-26-2022-company-news-st-petersburg-news-79004/  
St. Basil the Great in [[OSINT Project/Maps/Osinovaya Roshcha, Pargolovo, Saint Petersburg, Northwestern Federal District, 194902, Russia|Osinovaya Roshcha]] ([[OSINT Project/Maps/Osinovaya Roshcha, Pargolovo, Saint Petersburg, Northwestern Federal District, 194902, Russia|Aspen Grove]]) is on [[fire]]. St. Petersburg Metropolis said that the church of St. Basil the Great in [[OSINT Project/Maps/Osinovaya Roshcha, Pargolovo, Saint Petersburg, Northwestern Federal District, 194902, Russia|Osinovaya Roshcha]], which caught [[fire]] on the morning of June 26 “The temple inside was not damaged. The iconostasis, throne, all liturgical items and vestments have been preserved,” Rodomanova wrote. She clarified that the [[fire]] was discovered at about 6 am by a priest who came to prepare for the early liturgy. As a result, the rector of the temple, Father Anatoly Pershin, served the Sunday Liturgy together with the parishioners in the open [[air]]. “There were 60 communicants. The parishioners expressed their readiness to participate in the restoration of their beloved temple, which has been active in educational, creative and social activities for 8 years now,”  
[[OSINT Project/Maps/Osinovaya Roshcha, Pargolovo, Saint Petersburg, Northwestern Federal District, 194902, Russia|Osinovaya Roshcha]], St Petersburg

"for 8 years now" - since 2014. Interesting statement. Photos shown by official Telegram channels show extensive damage.

~+~  
191

# Vyborgsky Orthodox Church St Petersburg

2022-06-26  
[[fire]]  
Cultural  
https://apolline-petit.com/in-st-petersburg-eliminated-the-fire-in-the-orthodox-church  
Same church? Does not seem so. [[fire]] in an Orthodox church in the Vyborgsky district of St. Petersburg has been extinguished. This was reported on June 26 by the press service of the Main Directorate of the Ministry of Emergency Situations in the city. It is noted that the message about the [[fire]] at the address: Vyborgsky district, Priozerskoye highway, house 12, building 1 was received at 06:05. “In a brick, sheathed with wood, measuring 33 × 6 meters, built in 2016, the building of the church, the roof is on [[fire]] throughout the area”the message says.  
Vyborgsky district, Priozerskoye highway, house 12, building 1, St Petersburg

~+~  
101

# [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] Out of Area Cars [[fire|Burn]]

2022-06-27  
[[fire]]  
Other  
https://www.ivanovonews.ru/news/1152365/  
The message about the ignition of cars near house No. 16 on Paris Commune Street in [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] arrived on June 27 at about 5 p.m. As IvanovoNews was informed in the press service of the Ministry of Emergency Situations for the [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] region, at first Volkswagen Golf caught [[fire]], from it the flame spread to the nearby Nissan Almera [[Ivanovo Out of Area Cars Burn|foreign car]]. The total area of the [[fire]] was 12 square meters. The cars [[fire|burned]] almost to the ground. According to the [[fire]] department, no one was injured. The preliminary cause of the [[fire]] is a malfunction of electrical wiring.  
No. 16, Paris Commune Street, [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]]

The two cars were identified as "foreign" which may mean not registered, out of area or out of country. This may or may not be related to other activities. Adding to see if there is a discernible pattern. There have been other reports in [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] of car burnings & also "foreign" cars having been used as "escape" for unmentioned activities. Highly Likely this has nothing to do with anything.

~+~  
25

# Call to Arms - Revolutionary cell of the Volga region

2022-06-28  
Protest  
Other,Hearts & Minds  
https://t.me/bnkbel/89545  
Russian anti-military arsonists: "There are more of us every day". Not everyone is tough enough to go with Molotov to the enlistment office or [[fire|burn]] a vehicle to the beasts guarding the regime. But everyone can take a photo and anonymously send along with the coordinates to the right people. Or collect information about beasts, print out leaflets, stick stickers, draw graffiti, supporting resistance. Sabotage at work in the relevant structures is no less important. It is not necessary to refuse military service if you can learn a lot of valuable information through this. It is not necessary to resign from law enforcement bodies if you can sabotage new cases to capture [[activism|activists]]. Or leave the railway, seeing trains of equipment going to kill people in a neighboring country. Everyone must find their place in the Russia of the future, become this future today, and not leave Russian hopelessness as a legacy to children military recruitment centers [[fire|burn]] every week, trains derail from the Kuban to the Far East, cables from zombieboxes are cut at the entrances. The geography of resistance will only expand, because everyone has just begun to taste the delights of life in a new reality: total lack of freedom, a swooping economy, an Iron Curtain. The [[fire]] of the revolution will spread throughout the cities of Russia. The future of Russia will be decided in Russia. This is our land, we have nowhere to run, let the scum be afraid and hide in their palaces. The future belongs to us!  
Volga

Also see https://libcom.org/article/russian-anti-military-arsonists-there-are-more-us-every-day

~+~  
144

# Kirzhach railway track sabotage by BOAK

2022-06-28  
Mechanical  
Railway,Infrastructure  
https://t.me/boakom/34  
Anarcho-Communists Combat Organisation (BOAK) reported on June 28 in own Telegram channel about their second act of railway blocking to the military objects after such action a month ago near Sergiyev Posad: “The BOAK-Vladimir cell takes responsibility for the sabotage on the railway line leading to military unit 55443 VD Barsovo (the 51st arsenal of the Main Rocket and Artillery Directorate of the Ministry of Defense of the RF) near Kirzhach. Unlike the previous attack, where we took responsibility without waiting for the result (decided to publish the information to show all the guerrillas how accessible the target was), for subsequent actions we chose the strategy of waiting for the result, not publishing the report until either success was achieved or the facts that the sabotage was discovered will not be received. Unfortunately, in this case, we received reliable information (a video in the offer from a subscriber, apparently, a driver who was driving along this branch) that the sabotage was discovered on the evening of June 25. However, even in this form, the sabotage caused harm to the enemy, delaying the movement of trains with military equipment, and causing economic damage due to the need to restore the railway lines. What has been done:–34 nuts (17 on each side) holding the rail are unscrewed–4 nuts connecting the joint are unscrewed–The rail at the junction is raised, laid on the connecting plate (so as not to fall into place) and set aside.–The rails were connected to each other with a wire, in case a signal current is transmitted along the rail, to detect an open (thanks to the advice from subscribers). We call on everyone to join the rail war! Each stopped train is a minus of shells and rockets that could fly into peaceful Ukrainian cities”.  
Sergiyev Posad near Kirzhach

See also https://enoughisenough14.org/2022/07/04/rail-war-belarusians-face-the-death-penalty-the-blocked-trans-sib-anarchists-work-around-moscow-belarus-russia/

~+~  
52

# Garbage Dump & Warehouses

2022-06-29  
[[fire]]  
Other  
https://globalhappenings.com/top-global-news/217932.html  
In the capital of Russia, a garbage dump caught [[fire]], and then the [[fire]] spread to a hangar where car tires were stored. Strong smoke appeared at the site of the [[fire]], its column rose high into the [[air|sky]], which can be seen for several kilometers. It is noted that the [[fire]] area is about 500 square meters. There is also a threat that the [[fire]] will spread to other buildings nearby.  
[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

~+~  
141

# Amur 19 railway cars derail

2022-06-29  
Mechanical  
Railway,Infrastructure  
https://og.ru/ru/news/126845  
In the Amur region, 19 cars of a freight train derailed on the Sgibeevo - Bolshaya [[OSINT Project/Maps/Omutnaya, городское поселение Ерофей Павлович, Skovorodinsky District, Amur Oblast, Far Eastern Federal District, Russia|Omutnaya]] section. Due to the accident that occurred on June 29, the size of the neighboring track was broken and the support of the contact network was damaged.  
Amur, Russia

as a result of the incident, traffic on the [[OSINT Project/Maps/Monument to the 170th anniversary of the Trans-Siberian Railway, улица Леконта, Привокзальный, Ленинский административный округ, Omsk, Omsk Oblast, Siberian Federal District, 644000, Russia|Trans-Siberian Railway]] had to be temporarily stopped. A group of [[anti-war]] [[activism|activists]] "Stop the Cars" claimed responsibility for the derailment of the train. "If this goes wrong, the military supply from the Far East will soon be covered with a copper basin," they said in their telegram channel. Earlier, participants of this movement hinted at their involvement in accidents on railway routes in Pskov, Rostov, Orenburg, Chelyabinsk regions, [[OSINT Project/Maps/Krasnoyarsk, Krasnoyarsk Urban Okrug, Krasnoyarsk Krai, Siberian Federal District, 660000, Russia|Krasnoyarsk]] Krai and other regions. The [[activism|activists]] call their goal to delay railway communication to stop Russian military supplies to Ukraine.

~+~  
99

# Shuya, [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] Car [[fire|Burning]]

2022-06-30  
[[fire]]  
Other  
https://www.ivanovonews.ru/news/1152522/  
The [[fire]] on Vasilyevsky Trakt in Shuya occurred on June 30 around 19.20. A Ford Fiera car broke out. According to the Ministry of Emergency Situations for the [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] region, by 19.34 the open [[fire|burning]] had been eliminated by [[fire]] and rescue units. As a result of the [[fire]], the car [[fire|burned]] to the ground. No one was hurt. The cause of the [[fire]] is being established.  
Vasilyevsky Trakt, Shuya, [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]]

When cars are identified as "foreign" which may mean not registered, out of area or out of country. This may or may not be related to other activities. Adding to see if there is a discernible pattern. There have been other reports in [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] of car burnings & also "foreign" cars having been used as "escape" for unmentioned activities. Highly Likely this has nothing to do with anything.

~+~  
100

# [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] Textile Shop [[fire]]

2022-06-30  
[[fire]]

https://www.ivanovonews.ru/news/1152464/  
The message about the [[fire]] in building No. 70 on Okulova Street in [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] was received by the Crisis Management Center on June 30 at 01.58. At the time of arrival of the first [[fire]] and rescue units, there was a [[fire|burning]] inside the workshop. According to the Ministry of Emergency Situations for the [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] region, at 03.04 the open [[fire|burning]] was liquidated. As a result of the [[fire]], textile waste on an area of 30 square meters was damaged. No one was hurt. 42 people and 14 pieces of equipment were involved in extinguishing.  
building No. 70 on Okulova Street, [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]]

Although [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Иваново]] ([[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]]) is not as prestigious as other cities of Золотое кольцо (the Golden Ring), it is still worth a stop. [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] is шутливо называют городом невест (jokingly called the “City of the brides”). The reason of such a nickname come from the fact that [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] is the leading national producer of cotton fabrics, and textile workers are mainly women. Thus, the main population of the city are women. https://ruslanguage.ru/blog/ivanovo-the-textile-capital-of-russia/

~+~  
146

# Nizhny Novgorod FSB Office Molotov

2022-06-30  
Molotov  
Government  
https://www.newsweek.com/russia-dissent-putin-ukraine-war-man-molotov-cocktail-fsb-government-building-fire-1720900  
Thursday afternoon an unknown man hurled the [[fire]] bomb at a local office of Russia's Federal Security Service (FSB) in Nizhny Novgorod before fleeing the scene. According to the Russian language news agency, there was no [[fire]], and law enforcement officers are now searching for the man.  
Nizhny Novgorod

~+~  
98

# Kharinka, [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] Soviet Art Clock

2022-07-01  
Other  
Cultural  
https://www.ivanovonews.ru/news/1152528/  
Another Soviet Art Object was dismantled in [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]]. In [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] publics there were reports that an art object was dismantled on Kharinka - a clock installed on the wall of house 54 on 2nd Camp Street. The metal watch was also illuminated, locals remember that on New Year's Eve it was included until the 90s. Why the design was decided to be removed is still unknown.  
54, 2nd Camp Street, Kharinka, [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]]

Reference to "another Soviet art object" indicates there are more mystery dismantlings.  
~+~

142

# [[Amur 14 railcars derailed]]

2022-07-02  
Mechanical  
Railway,Infrastructure  
https://t.me/ostanovivagonyy/114  
the supply of occupiers troops from the Far East is getting more and more difficult. Two days ago, 14 wagons of a freight train derailed on the Sgibeevo–Bolshaya [[OSINT Project/Maps/Omutnaya, городское поселение Ерофей Павлович, Skovorodinsky District, Amur Oblast, Far Eastern Federal District, Russia|Omutnaya]] section in the Amur region. Due to the incident, the dimensions of the adjacent track were violated and the contact network support was damaged. The movement on this section was stopped, passenger train [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]-Vladivostok was delayed. Thus, the [[OSINT Project/Maps/Monument to the 170th anniversary of the Trans-Siberian Railway, улица Леконта, Привокзальный, Ленинский административный округ, Omsk, Omsk Oblast, Siberian Federal District, 644000, Russia|Trans-Siberian Railway]]–the largest railroad in the world and one of the most important transport routes between Russia and China–was temporarily stopped! 330 employees of the line and a lot of equipment, arrived from three other stations, were involved in the elimination of the consequences.  
Sgibeevo–Bolshaya, [[OSINT Project/Maps/Omutnaya, городское поселение Ерофей Павлович, Skovorodinsky District, Amur Oblast, Far Eastern Federal District, Russia|Omutnaya]] section, Amur region

Also see https://enoughisenough14.org/2022/07/04/rail-war-belarusians-face-the-death-penalty-the-blocked-trans-sib-anarchists-work-around-moscow-belarus-russia/

~+~  
194

# Nikolai Rimsky-Korsakov Estate Museum

2022-07-02  
[[fire]]  
Cultural  
https://www.classicfm.com/composers/rimsky-korsakov/fire-memorial-museum-russia/  
Over half of the exhibits have been destroyed in the blaze, which has devastated more than 1,000 artefacts. Reports of the [[fire]] originally emerged from the governor of the district, Mikhail Vedernikov who posted a photo of the [[fire]] on his Telegram [social media] account, saying the damage was “significant”. The [[fire]] is said to have been started due to “the negligence of builders” who were repairing the roof of the museum using a ‘hot work’ technique–construction that uses open flames. Starting on the roof, the [[fire]] spread “very quickly” throughout the building according to Vedernikov, engulfing the estate before firefighters were able to arrive  
Lyubensk, Plyussky district, Pskovskaya, Paskov

Putin named his mega yacht Sherezade, an opera written by Rimsky-Korsakov. https://www.zyri.net/2022/03/09/a-mysterious-and-gigantic-yacht-is-disturbing-in-italy-is-it-putins/ Also see https://en.newizv.ru/news/incident/04-07-2022/the-fire-destroyed-over-a-thousand-exhibits-in-the-rimsky-korsakov-museum

~+~  
51

# Capital Towers Complex

2022-07-03  
[[fire]]  
Elite,Other  
https://globalhappenings.com/top-global-news/221879.html  
In the capital of Russia, [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]], on the evening of July 3, a [[fire]] broke out in one of the towers of the Capital Towers complex. According to the Telegram channel “Ukraine 24”, preliminary, the [[fire]] occurred on the 55th floor. Firefighters are on the scene. according to preliminary data, scaffolding was on [[fire]] on the roof of one of the Capital Towers in the center of [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]].  
[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

THE HIGHEST REGISTRATION IN [[OSINT Project/Maps/Moscow, Central Federal District, Russia|MOSCOW]] IS ON [[fire]]–THIS IS WHAT THE CAPITAL TOWERS RESIDENTIAL COMPLEX IS CALLED. SMOKE IS COMING FROM THE ROOF OF ONE OF THE UNFINISHED SKYSCRAPERS. THERE ARE NO ACCIDENTS, THERE ARE PATTERNS. MORDOR MUST [[fire|BURN]] IN HELL,” ANTON GERASHCHENKO, ADVISER TO THE HEAD OF THE MINISTRY OF INTERNAL AFFAIRS OF UKRAINE, COMMENTED ON THE [[fire]].

~+~  
50

# [[OSINT Project/Maps/Kyzyl, Kyzyl City, Tuva Republic, Siberian Federal District, Russia|Kyzyl]] Warehouses

2022-07-04  
[[fire]]

https://globalhappenings.com/top-global-news/221879.html  
A massive [[fire]] broke out on Monday, July 4. The [[fire]] engulfed the warehouses of building materials. It spread to 2.8 thousand square meters. 2 am The [[fire]] spread throughout the warehouses of building materials.  
[[OSINT Project/Maps/Kyzyl, Kyzyl City, Tuva Republic, Siberian Federal District, Russia|Kyzyl]], Republic of Tuva

~+~  
95

# [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] 315 Guns/Weapons + 2,000 cartridges/ammo seized since January 2022

2022-07-05  
Other  
Weapons,Other  
https://www.ivanovonews.ru/news/1152674/  
Comprehensive inspections of civilian firearms owners will continue in the [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] region. According to the Department of Rosgvardia for the [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] region, in total, since the beginning of 2022, more than 13,000 inspections of the conditions of the preservation of weapons have been carried out in the region, according to the results of which 493 violations were identified, 316 weapons and more than 2 thousand cartridges have been seized. 12 facts of gross violations of the law were also revealed - permits for weapons of these citizens were canceled. More than 22 thousand owners of civilian weapons are registered in the region, in use of which there are about 34 thousand weapons. For 6 months of this year, the Licensing and Licensing and its structural subdivisions received more than 7.3 thousand applications from individuals and legal entities. Thanks to the compensation program for the population in the reporting period, 9 weapons were handed over voluntarily, about 30 thousand rubles were paid to citizens from the regional budget. "Each owner should understand that the conditions for the safety of weapons and ammunition and the safety of their storage must be observed not only at the place of residence. Also, security measures are necessary for transportation, on small arms and in hunting grounds, because lost weapons can become an instrument of crime," the Office of Rosgvardia notes.  
[[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]]

Not sabotage, but shows line of previously undisclosed concern by authorities. Employees of Rosgvardia remind that in all cases of voluntary surrender of weapons, ammunition and explosives, a citizen in accordance with the current legislation is exempt from criminal liability for their illegal possession. Weapons and ammunition are handed over to the licensing and permitting units of Rosgvardia in the [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] region or to territorial police units. https://www.ivanovonews.ru/news/1152362/

~+~  
183

# Cyber Partisans Release Belarus Passports - Zhara (Heat)

2022-07-26  
Mechanical  
Elite,Hearts & Minds  
https://en.currenttime.tv/a/seeking-change-anti-lukashenka-hackers-seize-senior-belarusian-officials-personal-data-/31392092.html  
July 26, the group’s Telegram channel teased passport data for KGB Chairman Ivan Tertel; Central Election Commission Chairwoman Lidiya Yermoshina; the chairwoman of the upper house of parliament, Natallya Kachanova; and ex-Kyrgyz President Kurmanbek Bakiyev, who has lived in Belarus since his 2010 overthrow from power. Belarusian passports are used both as a domestic identity document and for external travel. Each individual’s dossier, the hackers claim, contains passport photos and data; his or her residence permit; the name of the government body or military unit for which the person works; the names of family members, “and so on.” “Will many KGB agents be ready to operate abroad, knowing that data about them has already leaked?” Aside from passport data, the Cyberpartisans claim to have accessed the records of the Belarusian traffic police, which the hackers say include information on registered cars for the KGB, the anti-corruption police, and tsikhary (“silent men”), masked muscle men in plainclothes known for brutally rounding up suspected protesters.Information was also seized about the KGB’s housing assignments, Cyber-Partisan added, which means “they’ll have to change all the apartments.” “Intelligence, counterintelligence, and KGB employees who have special notes (indicating their occupations) in their passports are completely compromised,” said Andriy Baranovych. “And [[activism|activists]], partisans got the data, not the special services. And now the people who are the backbone of the Lukashenka regime will not feel safe.”  
Belarus

This material is from a 2021 hack that penetrated every government agency, including [[air]] gapped intelligence. They have been very careful to release only the material that does not harm ordinary citizens. CP, BYPOL, Flying Storks work with Railway Workers to cyber attack the Belarusian railway system in an effort to slow Russia's advances. This was instrumental in the early days of the war to give Ukraine time to organize and prepare.

~+~

# [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]] Police Station

2022-04-25  
[[fire]]  
Government  
https://news.storyua.com/news/14107.html  
In addition, for unknown reasons, [[fire]] broke out in one of the houses in St. Petersburg, the [[air base]] in Ussuriysk, as well as in police stations in [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]], Irkutsk and [[OSINT Project/Maps/Novosibirsk, Novosibirsk Oblast, Siberian Federal District, 630000, Russia|Novosibirsk]].  
[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

# [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]] Police Station

2022-04-25  
Fire  
Government  
https://news.storyua.com/news/14107.html  
In addition, for unknown reasons, fire broke out in one of the houses in St. Petersburg, the [[air base]] in Ussuriysk, as well as in police stations in [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]], Irkutsk and [[OSINT Project/Maps/Novosibirsk, Novosibirsk Oblast, Siberian Federal District, 630000, Russia|Novosibirsk]].  
[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

~+~  
167

# [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]] Police Station

2022-04-25  
Fire  
Government  
https://news.storyua.com/news/14107.html  
In addition, for unknown reasons, fire broke out in one of the houses in St. Petersburg, the [[air base]] in Ussuriysk, as well as in police stations in [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]], Irkutsk and [[OSINT Project/Maps/Novosibirsk, Novosibirsk Oblast, Siberian Federal District, 630000, Russia|Novosibirsk]].  
[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

~+~  
167  
[[Irkutsk Police Station]]  
[[Novosibirsk Police Station]]  
[[St Petersburg Residence]]  
[[State Security Committee Building Transnistria]]  
[[Mayak Radio Transmitter Transnistria]]  
[[Bryansk Railway Inert Demolition Bomb]]  
[[Staraya Nelidovka Belgorod Ammunition Depot]]  
[[Kustanayskaya Street, Moscow Cars]]  
[[Tver Fuck War Posters]]  
[[Tver Surveillance Camera Outage]]  
[[Perm Banner Peace to huts, war to palacesZ Billboards]]  
[[Kuril Islands, Ilyinskoye Sakhalinskaya GRES-2 Power Plant]]  
[[FKP or PPZ Gunpowder Plant - Perm]]  
[[Belgorod Oblast Defense Ministry Facility]]  
[[Sudzha—Sosnovy Bor Railway Bridge Collapse]]  
[[Remotely locked John Deere Farm Equipment]]  
[[Moscow Paddy Wagon]]  
[[Moscow Molotov at riot police bus]]  
[[Alcohol Distribution Disruption]]  
[[Mytishchi Fuel Depot]]  
[[Bogorodskoye, Atlant Park industrial and warehouse complex]]  
[[Nizhnevartovsk Recruitment Office]]

# Kudinovskoye Paper Warehouse

2022-05-03  
Fire  
Other  
https://www.world-today-news.com/in-the-suburbs-a-strong-fire-broke-out-in-a-huge-warehouse-mir-tsn-ua/  
The area of ​​ignition is more than 25 thousand square meters. paper warehouse. On the night of May 3, a fire broke out in a warehouse on Kudinovskoye highway in the [[OSINT Project/Maps/Bogorodsky city district, Moscow Oblast, Central Federal District, Russia|Bogorodsky]] urban district of the [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]] region, the building is burning throughout the area. According to propaganda media, the fire started on the territory of the Atlant Park industrial and warehouse complex in [[OSINT Project/Maps/Bogorodsky city district, Moscow Oblast, Central Federal District, Russia|Bogorodskoye]]  
Kudinovskoye highway, [[OSINT Project/Maps/Bogorodsky city district, Moscow Oblast, Central Federal District, Russia|Bogorodsky]], [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

The warehouse is located in a section dedicated to logistics and distribution. https://www.express.co.uk/news/world/1604413/russia-fire-vladimir-putin-news-industrial-building-Bogorodsky-moscow-oblast-latest == Reported elsewhere in channels that the company had contracts for government paper supplies including conscript offices. This is not confirmed.

~+~  
65

# Prosveshchenie Text Book Printer Warehouse

2022-05-03  
Fire  
Education,Cultural  
https://www.themoscowtimes.com/2022/05/03/fire-hits-russian-publisher-embroiled-in-ukraine-textbook-controversy-a77563  
Fire has ripped through a warehouse storing Russian schoolbooks, days after reports that publishers would remove mentions of Ukraine from the nation’s textbooks. textbooks and other printing materials had been stored in the warehouse  
Svetofor Warehouse, Prosveshchenie publishing house, [[OSINT Project/Maps/Bogorodsky city district, Moscow Oblast, Central Federal District, Russia|Bogorodsky]], [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

The fire follows reports that Prosveshchenie, one of Russia’s largest and oldest educational publishers, had ordered staff to remove "inappropriate" references to Ukraine and Kyiv from textbooks. == Svetofor Warehouse. A number of fires were active at this warehouse per FIRMS

~+~  
104

# FSB [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]] Special Ops Center Vehicles

2022-05-03  
Fire  
Military,Government  
https://darknights.noblogs.org/post/2022/04/12/russia-military-cars-on-fire/  
At night on 03.04.22 there was an arson in Russia–cars belonging to the staff of the FSB Special Operations Center (military unit 35690, Balashikha, [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]] region) burned down. At least four cars were burned. According to Ukrainian intelligence, the owners of the cars were representatives of the executive staff of the Federal Security Service’s Central Intelligence Service.  
military unit 35690, Balashikha, [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]] region - FSB Special Ops Center

cases of deliberate arson of cars of Russian military and officials are becoming more frequent. In particular, cars of servicemen of the [[95th Brigade Vehicles|95th Brigade]] (Gorelovo, St Petersburg Region) and the [[82nd Radio Technical Brigade Vehicles|82nd Radio]] Technical Brigade (Vyazma, Smolensk Region) have recently been set on fire. Russian servicemen speak of threats of physical reprisals if they agree to participate in the war against Ukraine.

~+~  
165

# [[38 Trucks in Parking Lot]]

2022-05-03  
Fire  
Other Defence  
https://twitter.com/nexta_tv/status/1521416166786404354?s=20&t=TFVdFJgzVYdoZacC9SRyGA  
38 trucks burned overnight at the parking lot. Identified elsewhere as moving goods for military.  
Tver

~+~  
3

# Igumnovo Station Railway Tanks

2022-05-04  
Fire  
Infrastructure,Railway,Gas/Oil,Other Defence  
https://eprimefeed.com/latest-news/the-fire-area-in-the-dzerzhinsk-industrial-zone-has-reached-2000-square-meters/78082/  
The fire area in the Dzerzhinsk industrial zone, according to preliminary information, reached 2,000 square meters. Burning railway tanks in the open area of ​​Igumnovo station. Cause being clarified  
​Igumnovo station, Dzerzhinsk, Nizhny Novgorod

These tanks are linked to several military and defence companies/providers

~+~  
66

# Dzerzhinsk, Nizhny Novgorod Industrial Zone

2022-05-04  
Fire  
Infrastructure,Other Defence  
https://eprimefeed.com/latest-news/the-fire-area-in-the-dzerzhinsk-industrial-zone-has-reached-2000-square-meters/78082/  
The fire area in the Dzerzhinsk industrial zone, according to preliminary information, reached 2,000 square meters. Burning railway tanks in the open area of ​​Igumnovo station. fire in the Dzerzhinsk industrial zone started today around 11 o’clock. The causes of the incident are being clarified.  
Dzerzhinsk, Nizhny Novgorod

This industrial complex has several military support activities and companies

~+~  
145

# [[OSINT Project/Maps/Khanty-Mansiysk, Khanty-Mansiysk Urban Okrug, Khanty-Mansiysk Autonomous Okrug – Ugra, Ural Federal District, 628000, Russia|Khanty-Mansi Autonomous Okrug]] Recruitment office

2022-05-04  
Molotov  
Recruitment  
https://nz.topnews.media/ukraine/city-ivano-frankivsk-russia-tried-to-burn-the-military-enlistment-office-with-molotov-cocktails-video/  
Tonight, May 4, in the Russian city of [[OSINT Project/Maps/Nizhnevartovsk, городской округ Нижневартовск, Khanty-Mansiysk Autonomous Okrug – Ugra, Ural Federal District, Russia|Nizhnevartovsk]], a group of unknown individuals pelted the premises of the local military enlistment office with bottles of incendiary mixture. Video of the incident published Telegram channel Base. A fire broke out in the military registration and enlistment office of the city of [[OSINT Project/Maps/Nizhnevartovsk, городской округ Нижневартовск, Khanty-Mansiysk Autonomous Okrug – Ugra, Ural Federal District, Russia|Nizhnevartovsk]] in the [[OSINT Project/Maps/Khanty-Mansiysk, Khanty-Mansiysk Urban Okrug, Khanty-Mansiysk Autonomous Okrug – Ugra, Ural Federal District, 628000, Russia|Khanty-Mansi Autonomous Okrug]] of the Russian Federation. Surveillance cameras recorded that unknown people threw several bottles of incendiary mixture into the building. As can be seen in the published footage, at least seven “Molotov cocktails” flew into the building. Although the first one went out at once, all the others reached the goal and caused the wood paneling to catch fire.  
[[OSINT Project/Maps/Nizhnevartovsk, городской округ Нижневартовск, Khanty-Mansiysk Autonomous Okrug – Ugra, Ural Federal District, Russia|Nizhnevartovsk]], [[OSINT Project/Maps/Khanty-Mansiysk, Khanty-Mansiysk Urban Okrug, Khanty-Mansiysk Autonomous Okrug – Ugra, Ural Federal District, 628000, Russia|Khanty-Mansi Autonomous Okrug]]

This may be the May 11 event referenced although this seems to have more details.

~+~  
67

# Dzerzhinsk Chemical Weapons Factory and Railway Tankers Explode

2022-05-06  
Explosion  
Railway,Chemical,Infrastructure,Other Defence  
https://www.express.co.uk/news/world/1606228/Russia-chemical-plant-fire-explosion-Dzerzhinsk-factory-Ukraine-war-attack-latest-Putin  
Multiple rail tankers containing solvents exploded at a factory in Dzerzhinsk. The fire, which occurred at around 11am on Wednesday, was spread across 2,500 square metres. This comes as numerous facilities across Russia, many with military links, have been hit by mystery fires. It was a railway tanker containing unspecified solvents on the territory of the former chemical weapons factory Kaprolaktam, in Dzerzhinsk. See also https://www.express.co.uk/news/world/1611630/mystery-fire-russia-claims-ukraine-sabotage  
Kaprolaktam Chemical Weapons Factory, Dzerzhinsk

~+~  
160

# Vicalina Market Vladikavkaz

2022-05-06  
Fire  
Other  
https://twitter.com/nexta_tv/status/1522507766165913602?s=20&t=rAnAi9isgrntoVpJvQiHsw  
Vicalina market in Vladikavkaz is on fire This is very close to Georgia - North Ossetia-Alania & a major transport hub with the North Caucus railway. South Ossetia is the lands Russia invaded in Georgia much like Crimea & Donsk.  
Vladikavkaz, North Ossetia-Alania

~+~  
30

# Cherepovets Recruitment Office

2022-05-08  
Molotov  
Recruitment  
https://newsbeezer.com/swedeneng/wave-of-molotov-attacks-on-russian-recruiting-offices/  
Another conscription office is pelted with Molotov cocktails in Cherepovets. May 8, 2022 at about 1 am in Cherepovets. The fire site had an area of one square meter. The flames damaged two window frames and smoked the facade of the building. Seven people were engaged in extinguishing the fire. On May 11, 2022, the arsonist* were [[arrested]]. They were two 16-year-olds who testified that they had committed the crime “on orders” and received 30,000 rubles for their deed. Criminal proceedings were initiated against the youths for property damage. Video https://t.me/truexanewsua/45920  
Cherepovets

People are burning their military registration documents in order not to go to war,” said journalist Andrei Tsaplienko. https://amplifyukraine.eu/military-enlistment-offices-are-on-fire-in-russia-details-last-night-several-molotov-cocktails-were-thrown-at-the-cherepovets-station-pravda-gerashchenko-2/ Nearby is the Cherepovets Higher Military Engineering College of Radio Electronics. On another occasion, two 16-year-old boys who said they carried out the attack on the recruitment office in Cherepovets on May 8 on orders and received 30,000 rubles (equivalent to 4,500 SEK) were [[arrested]]. Also see https://enoughisenough14.org/2022/06/26/shortly-after-the-longest-night-of-the-year-two-recruiting-offices-burned-at-once-chronicle-of-arson-attacks-until-june-25-2022-russia/  
~+~  
68

# [[OSINT Project/Maps/Perm, Perm Krai, Volga Federal District, Russia|Perm]] Aviation Technical College

2022-05-08  
Fire  
Aerospace/Aviation,Education  
https://twitter.com/antiputler_news/status/1523279184369381378  
Construction site for the aviation technical school in [[OSINT Project/Maps/Perm, Perm Krai, Volga Federal District, Russia|Perm]] is burning  
[[OSINT Project/Maps/Perm, Perm Krai, Volga Federal District, Russia|Perm]]

~+~  
17

# [[Balashikha Recruitment Office]]

2022-05-09  
Molotov  
Recruitment  
https://enoughisenough14.org/2022/06/26/shortly-after-the-longest-night-of-the-year-two-recruiting-offices-burned-at-once-chronicle-of-arson-attacks-until-june-25-2022-russia/  
Fire at [[Balashikha Recruitment Office]]. evening of [[All Satellite TV Channels Hacked|May 9]], 2022 in Balashikha in the [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]] region. An unknown person threw a Molotov cocktail through the window. A fire broke out in the corridor of the building on an area of one square meter, which the security guard managed to extinguish. The suspects were not found.  
Balashikha, [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

~+~  
176

# [[All Satellite TV Channels Hacked]]

2022-05-09  
Mechanical  
Hearts & Minds  
https://amplifyukraine.eu/you-have-the-blood-of-ukrainian-children-on-your-hands-russians-were-forced-to-face-the-truth-on-may-9-details-in-russia-this-line-ap-pravda-gerashchenko-2/  
You have the blood of Ukrainian children on your hands–Russians were forced to face the truth on [[All Satellite TV Channels Hacked|May 9]] Details: In Russia, this line appeared on all satellite [[All Satellite TV Channels Hacked|TV]] channels. Instead of the usual Rashist victory speech on [[All Satellite TV Channels Hacked|May 9]], they had to read the truth about the “deeds” of Putin’s army of murderers and looters.  
Russia

In addition Smart [[All Satellite TV Channels Hacked|TVs]], Internet Companies like Yandex and Rutube (Russia's YouTube) not using satellite [[All Satellite TV Channels Hacked|TV]] also received this message https://finance.yahoo.com/news/russia-smart-tv-hack-202422488.html  
~+~  
159

# [[Balashikha Recruitment Office]]

2022-05-10  
Molotov  
Recruitment  
https://libcom.org/article/emancipative-fire-and-call-solidarity-persecuted-comrades-8th-review-anti-war-sabotage  
On the evening of May 10, a Molotov cocktail flew into the window of a similar facility in Balashikha. A fire started in the corridor, the fire was unfortunately extinguished by a guard who came to the rescue, but the arsonist was not captured. In addition to Balashikha, this office is also responsible for conscription in the neighboring town of Reutov.  
Balashikha

~+~  
37

# Free [[Siberian Federal District|Siberia]]! Death to Katsapam Newspaper Railway Video Release

2022-05-11  
Mechanical  
Railway,Infrastructure  
https://twitter.com/i/status/1525177964526182400  
FIRST REPORTED ON RUSSIAN INTELLIGENCE AND PROPAGANDA TELEGRAM CHANNELS: Reported in Irkutsk - underground partisan paper "Free [[Siberian Federal District|Siberia]]! Death to Katsapam" (anti-Russian slur) claims partisans disrupted a railway track by cutting circuit wires or jumping wires. Unclear if [[Siberian Federal District|Siberian]] tracks are electrified. Videos did not circulate on Twitter until May 13th, it was reported verbatim twice on Telegram May 11 (RU Propaganda dashboard) Flyers left at scene. Still trying to establish if this is legit or Russian op. https://ruprop.live/source-seek-your-owntranslation-❗%EF%B8%8Fsiberian-partisans-in-the-irkutsk-region-they-stopped-a-train-with-the-help-of-wire-the-method-is-called-a-shorting-of-the-rail-circuit-the-2/  
Irkutsk

"free [[Siberian Federal District|Siberia]]! Death to Katsapam" may be a Russian info op to promote the narrative that Ukrainians murder Russians & justifying the war in a region not very supportive. Katsapam=Ukrainian slur for Russians. Partisan papers generally call for solidarity.

~+~  
22

# Khabarovsk Krai Teysin Military Base Powder Warehouse

2022-05-12  
Explosion  
Military  
https://ria.ru/20220512/vzryv-1788053221.html  
Explosion in a powder warehouse in Khabarovsk Krai. Russian sources state this was due to "mishandling explosives". Warehouse located at a military base in Teysin, Khabarovsk. There are four military bases in this area. Explosion happened during unloading munitions & sparked a large blaze. Soldiers killed & injured. https://tifnews.com/world/russia/1-dead-7-injured-in-russia-military-base-explosion-the-moscow-times/  
Teysin, Amursky district, Khabarovsk Krai

Located in Russia's subarctic far east & shared border with China. Industry: military [[aircraft]], shipbuilding & oil refining

~+~  
35

# Russian Recruitment Office in Transnistria

2022-05-12  
Molotov  
Recruitment

Occupied Transnistria - molotov attacks on Russian registration/enlistment office & an oil depot.  
Transnistria

Suspected false flag

~+~  
36

# Russian Oil Depot in Transnistria

2022-05-12  
Fire  
Gas/Oil

Occupied Transnistria - molotov attacks on Russian registration/enlistment office & an oil depot  
Transnistria

Suspected False Flag

~+~  
70

# SinTZ, Sinarsky Pipe Works

2022-05-12  
Fire  
Other  
https://twitter.com/TolomeoNews/status/1525139692815011844  
Fire at SinTZ, Sinarsky Pipe Works in [[OSINT Project/Maps/Kamensk-Uralsky, городской округ Каменск-Уральский, Sverdlovsk Oblast, Ural Federal District, 623428, Russia|Kamensk-Uralsky]], Sverdlovsk Oblast a fire on Sinarsky pipeline plant. According to the Ministry of Emergency Situations, the building and the roof of the factory are on fire. The fire area reached 800 square meters.  
[[OSINT Project/Maps/Kamensk-Uralsky, городской округ Каменск-Уральский, Sverdlovsk Oblast, Ural Federal District, 623428, Russia|Kamensk-Uralsky]], Sverdlovsk Oblast

One of the biggest specialty producers in Russia, SinTZ manufactures steel & cast iron pipes w/ 3,000+ contracts per yr. Sverdlovsk elsewhere produces semi-conductors.

~+~  
16

# [[OSINT Project/Maps/Omsk, Omsk Oblast, Siberian Federal District, 644000, Russia|Omsk]] Recruitment office

2022-05-13  
Molotov  
Recruitment  
https://enoughisenough14.org/2022/06/26/shortly-after-the-longest-night-of-the-year-two-recruiting-offices-burned-at-once-chronicle-of-arson-attacks-until-june-25-2022-russia/  
[[OSINT Project/Maps/Omsk, Omsk Oblast, Siberian Federal District, 644000, Russia|Omsk]] Molotov Fire at Russian enlistment office in [[OSINT Project/Maps/Omsk, Omsk Oblast, Siberian Federal District, 644000, Russia|Omsk]] on Pushkin Street, 78. night of May 13, 2022 in [[OSINT Project/Maps/Omsk, Omsk Oblast, Siberian Federal District, 644000, Russia|Omsk]]. Two windows of the building were destroyed and traces of fire were found, but the fire was quickly extinguished. The suspects were not found. At least two windows were broken. A fire caught an area of 30 square meters and some archival documents were damaged.  
[[OSINT Project/Maps/Omsk, Omsk Oblast, Siberian Federal District, 644000, Russia|Omsk]] on Pushkin Street, 78

On the night of May 13, 2022 in [[OSINT Project/Maps/Omsk, Omsk Oblast, Siberian Federal District, 644000, Russia|Omsk]], [[Siberian Federal District|Siberia]], unknown individuals threw several molotovs through the windows of the Central District military registration and enlistment office at 74 Pushkin Street. At least two windows were broken. One of the premises of the military registration and enlistment office caught fire and an area of 30 square meters burned. It is also reported that “some archive documents were damaged”. https://darknights.noblogs.org/post/2022/06/01/omsk-cherepovets-russia-two-new-recruitement-offices-hit-with-molotovs/

~+~  
24

# [[OSINT Project/Maps/Khanty-Mansiysk, Khanty-Mansiysk Urban Okrug, Khanty-Mansiysk Autonomous Okrug – Ugra, Ural Federal District, 628000, Russia|Khanty-Mansi Autonomous Okrug]] Recruitment office

2022-05-13  
Molotov  
Recruitment  
https://www.rferl.org/a/russia-enlistment-offices-arson/31851677.html

[[OSINT Project/Maps/Khanty-Mansiysk, Khanty-Mansiysk Urban Okrug, Khanty-Mansiysk Autonomous Okrug – Ugra, Ural Federal District, 628000, Russia|Khanty-Mansi]], Tyumen Oblast  
62°15′N 70°10′E  
[[OSINT Project/Maps/Khanty-Mansiysk, Khanty-Mansiysk Urban Okrug, Khanty-Mansiysk Autonomous Okrug – Ugra, Ural Federal District, 628000, Russia|Khanty-Mansi]]/Khanty-Mansiysky Autonomous Okrug-Yugra - Autonomous Okrug of Tyumen Oblast In 2012, the majority (51%) of the oil produced in Russia came from [[OSINT Project/Maps/Khanty-Mansiysk, Khanty-Mansiysk Urban Okrug, Khanty-Mansiysk Autonomous Okrug – Ugra, Ural Federal District, 628000, Russia|Khanty-Mansi Autonomous Okrug]] It borders Yamalo-Nenets Autonomous Okrug to the north, Komi Republic to the northwest, Sverdlovsk Oblast to the west, Tyumen Oblast to the south, Tomsk Oblast to the south and southeast and [[OSINT Project/Maps/Krasnoyarsk Krai, Siberian Federal District, Russia|Krasnoyarsk Krai]] in the east. In [[OSINT Project/Maps/Khanty-Mansiysk, Khanty-Mansiysk Urban Okrug, Khanty-Mansiysk Autonomous Okrug – Ugra, Ural Federal District, 628000, Russia|Khanty-Mansi Autonomous Okrug]], the primary transport of goods is by water and railway transport; 29% is transported by road, and 2% by aviation. The total length of railway tracks is 1,106 km. The length of roads is more than 18,000 km.

~+~  
39

# Gukovo Recruitment Office

2022-05-13  
Molotov  
Recruitment  
https://www.rferl.org/a/russia-enlistment-offices-arson/31851677.html  
On May 13, a military enlistment office in the town of Gukovo in the southern Rostov region was partially burned. A Molotov cocktail is also believed to be the cause of that fire, which was quickly put out. night of May 13, this time in the town of Gukovo in the Rostov region. The attack took place at about 02:05 in the morning. The fire was extinguished by the employees of the Registration and Recruitment Office themselves, and there was no property damage. The suspects were not found. https://enoughisenough14.org/2022/06/26/shortly-after-the-longest-night-of-the-year-two-recruiting-offices-burned-at-once-chronicle-of-arson-attacks-until-june-25-2022-russia/  
Gukovo, Rostov

Gukovo (Rostov) On May 13, at about 2:00 a.m., an attempt was made to set fire to the military registration and enlistment office in Gukovo, near Rostov. A flaming molotov hit the wall of the building. According to the state media, the perpetrator “disappeared in an unknown direction”. https://darknights.noblogs.org/post/tag/khanty-nansi/

~+~  
79

# Irkutsk Young Viewer Theatre

2022-05-13  
Fire  
Cultural  
https://twitter.com/TWMCLtd/status/1525123225218342912  
2-story cultural building in Irkutsk at Krasnoarmejska 4B is ablaze & spread to Young Viewer Theatre. Building was empty & fire is difficult to contain.  
Krasnoarmejska 4B, Irkutsk

May be faulty wiring, but the area has had significant partisan chatter and actions

~+~  
69

# Belgorod Railway Station Fire

2022-05-14  
Fire  
Railway,Infrastructure  
https://twitter.com/lilygrutcher/status/1525518245150826496  
Maybe? Dubovoye, Belgorod Oblast  
Belgorod Oblast  
50.593006, 36.602231

~+~  
26

# Volgograd Recruitment Office

2022-05-15  
Molotov  
Recruitment  
https://www.rferl.org/a/russia-enlistment-offices-arson/31851677.html  
At about the same time, a fire broke out in a similar center in Volgograd, formerly Stalngrad, in [[OSINT Project/Maps/Southern Russia, улица Степана Разина, Ворошиловский район, Volgograd, Volgograd Oblast, Southern Federal District, 400001, Russia]]. According to police, the culprits used a Molotov cocktail. Police believe a Molotov cocktail was tossed through the window. The fire damaged about 20 square meters.  
Volgograd

Volgograd On May 15, unknown individuals targeted the military registration office in Volgograd. At least one “molotov” flew into the basement of a recruitment center, where a fire broke out consuming the 20 square meter room. No one was [[arrested]]. https://darknights.noblogs.org/post/tag/khanty-nansi/ 30 year old Denis Serdyuk, suspected of an arson attack against amilitary call-up center in Volgograd, is being held in remand prison # 1 of his town. He is being charged with ”destruction of property” and ”hooliganism”, and may be sentenced to 10 years in prison. https://avtonom.org/en/news/support-suspected-arsonists-against-military-call-ups-and-other-russian-anti-war-prisoners

~+~  
34

# [[OSINT Project/Maps/Pronsk, Пронское городское поселение, Pronsky District, Ryazan Oblast, Central Federal District, Russia|Pronsk]] Recruitment Office

2022-05-15  
Molotov  
Recruitment  
https://newsfounded.com/czechrepubliceng/the-russian-recruit-went-to-molotov-and-did-not-return-to-the-front-from-vacation/  
Molotov at enlistment registration office near [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]] in [[OSINT Project/Maps/Pronsk, Пронское городское поселение, Pronsky District, Ryazan Oblast, Central Federal District, Russia|Pronsk]], Ryazan. Attempt is reported as unsuccessful. On Sunday, two unknown people unsuccessfully tried to set fire to a recruitment office in the village of [[OSINT Project/Maps/Pronsk, Пронское городское поселение, Pronsky District, Ryazan Oblast, Central Federal District, Russia|Pronsk]] in the Ryazan region, located about 270 kilometers southeast of [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]. See also https://westobserver.com/news/europe/in-the-ryazan-region-they-tried-to-set-fire-to-the-military-enlistment-office/  
[[OSINT Project/Maps/Pronsk, Пронское городское поселение, Pronsky District, Ryazan Oblast, Central Federal District, Russia|Pronsk]], Ryazan

Date discrepancy - May 14 or 15, 2022. Used later date as it is also described as "a few hours later" after an action on 15 May [[OSINT Project/Maps/Pronsk, Пронское городское поселение, Pronsky District, Ryazan Oblast, Central Federal District, Russia|Pronsk]] (Ryazan) Barely an hour later (after Volgorad), a message arrived about a fire in the door and window frame of the military registration and enlistment office in the village of [[OSINT Project/Maps/Pronsk, Пронское городское поселение, Pronsky District, Ryazan Oblast, Central Federal District, Russia|Pronsk]], Ryazan region. No one was [[arrested]]. https://darknights.noblogs.org/post/tag/khanty-nansi/

~+~  
184

# Gloria Jeans/Gloriya/Gee Jay factory

2022-05-15  
Fire  
Political,Elite,Other  
https://bykvu.com/eng/thoughts/645/  
Gloria Jeans/Gloriya/Gee Jay factory in Rostov-on-Don is on fire. [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]] based but profiteered off Donbas to avoid paying Ukraine taxes. ‘Gloria Jeans’ apparel is found to be made in Russia-occupied territories of Ukraine’s Donbas.  
Rostov-on-Don

Separatist Profiteering - Gloria ran 2 stores in Crimea & 5-7 factories in Russian-occupied DNR/LNR, paying almost half the wages in Russia or China. Gloria paid DNR/LNR taxes but not Ukrainian taxes.

~+~  
185

# DM Tower Business Center on [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]'s Novodanilovskaya embankment

2022-05-16  
Fire  
Elite  
https://news.italy-24.com/world/452031.html  
DM Tower Business Center on [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]'s Novodanilovskaya embankment is on fire. 18-stories & under construction. Fire on the top floor according to a construction worker.  
Novodanilovskaya embankment, [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

~+~  
186

# Stroitel, Belgorod Laquer and Varnish Shop

2022-05-16  
Fire  
Chemical  
https://thenewsglory.com/the-ministry-of-emergency-situations-spoke-about-the-fire-in-the-lacquer-production-shop-near-belgorod/  
In the city of Stroitel, Belgorod Region, a lacquer production shop caught fire. This was announced on Monday, May 16, in the regional Ministry of Emergency Situations. It is noted that a message about a fire on 3rd Zavodskaya Street in the Yakovlevsky city district was received at 1:36 a.m., the fire broke out in an unused varnish production workshop. On Monday night, the BelPlus Telegram channel published footage showing pillars of black smoke from a brick factory in the town of Stroitel, Belgorod Region. Local residents reported a burning smell in the area.  
3rd Zavodskaya Street, Yakovlevsky, Belgorod

This may not be partisan activity, but it was shared on direct action channels which lends itself to potentially being an act of defiance.

~+~  
71

# Berdsk Chemical Plant

2022-05-17  
Fire  
Chemical  
https://www.newsweek.com/russia-fire-berdsk-emergency-ministry-siberia-novosibirsk-1707193  
Industrial building with office space at Khimzavodskaya Street, Berdsk near [[OSINT Project/Maps/Novosibirsk, Novosibirsk Oblast, Siberian Federal District, 630000, Russia|Novosibirsk]] in [[Siberian Federal District|Siberia]] is on fire & damaged equipment. State emergency services says polyethylene (very common plastic) is the source. Unclear of origin. fire broke out in an industrial building. 22,000 square feet in a building with office space in Berdsk, near [[Siberian Federal District|Siberia]]'s largest city of [[OSINT Project/Maps/Novosibirsk, Novosibirsk Oblast, Siberian Federal District, 630000, Russia|Novosibirsk]] The regional department of Russia's emergency ministry said in a post on social media that the source of the fire were polyethylene products on the first floor of the building which was located on Khimzavodskaya Street.  
Khimzavodskaya Street, Berdsk

~+~  
103

# Shchelkovsky, [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]] Recruitment Office

2022-05-18  
Molotov  
Recruitment  
https://darknights.noblogs.org/post/tag/khanty-nansi/  
Shchelkovsky ([[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]) On May 18, two molotovs flew inside the military commissariat in Shchelkovsky, near [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]. Both offices were damaged by the flames, including the archives of the military registration and enlistment office == Two offices are seriously damaged, including the archive with the data of conscripts. On this video we see smashing of its windows, after which the partisan pours incendiary mixture inside. Then comes the arson. In all this cases, the punishers did not seize anyone. == Two offices of the building, including the archive, were damaged by the arson attack. The arsonists have not been found yet. https://enoughisenough14.org/2022/06/26/shortly-after-the-longest-night-of-the-year-two-recruiting-offices-burned-at-once-chronicle-of-arson-attacks-until-june-25-2022-russia/  
Shchelkovsky, [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

AKA Shchelkovo or Shchyolkovo video https://t.me/live_corr/1831 See also https://meduza.io/news/2022/05/18/v-rossii-vnov-popytalis-podzhech-voenkomat-kokteylyami-molotova-zabrosali-zdanie-schelkovskogo-voennogo-komissariata-v-podmoskovie

~+~  
187

# Lukashenko Death Penalty for "terrorist attacks"

2022-05-18

https://www.dw.com/en/belarus-attempted-terrorism-to-be-punishable-by-death/a-61837461  
Not an act of defiance, but important in the time line. Belarus has introduced the death penalty for attempted terrorist attacks. The move could affect opposition [[activism|activists]] who are currently on trial. a "terrorist act" being a fluid definition.

~+~  
13

# Zheleznogorsk-Ilimsky Recruitment Office

2022-05-19  
Other  
Recruitment  
https://enoughisenough14.org/2022/06/26/shortly-after-the-longest-night-of-the-year-two-recruiting-offices-burned-at-once-chronicle-of-arson-attacks-until-june-25-2022-russia/  
military enlistment office - shot at with pneumatic weapons in Zheleznogorsk-Ilimsky in [[OSINT Project/Maps/Irkutsk Oblast, Siberian Federal District, Russia|Irkutsk Region]] In the city of Zheleznogorsk-Ilimsky on the night of May 19-20, an army recruiting office was shot at with a BB gun.  
Zheleznogorsk-Ilimsky, [[OSINT Project/Maps/Irkutsk Oblast, Siberian Federal District, Russia|Irkutsk Region]]

See also https://theins.ru/news/251440

~+~  
179

# [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] 3 Cars

2022-05-19  
Fire  
Other  
https://ivteleradio.ru/news/2022/05/19/tri_avtomobilya_sgoreli_utrom_v_ivanove  
3 cars on fire.  
[[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]]

Note - Burning cars does not seem to be rare in Russia. These cars were said elsewhere to have had Z iconography. It is also possible they were burned as part of the Heavy Machine Tool Plant fire in the same area on the same day.

~+~  
180

# [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] Heavy Machine Tool Plant

2022-05-19  
Fire  
Other Defence  
https://www.dailykos.com/stories/2022/5/19/2098927/-Ivanovo-Heavy-Machine-Tool-Plant-is-the-Latest-Suspicious-Fire-at-a-Strategic-Site-in-Russia  
The [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] Heavy Machine Tool Plant is allegedly critical to several defense related products. A major fire at this plant was burning for hours today.  
[[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]]

The chemical plant fire from April 21 in Kinishma & a conscript registration office hit April 22 are nearby.

~+~  
48

# Igra, Udmurtia Recruitment Office

2022-05-21  
Molotov  
Recruitment  
https://theins.ru/news/251473  
in Udmurtia (Russia) on the night of May 22, there was a fire in the military registration and enlistment office, fragments of a Molotov cocktail were found at the scene. In Russia, such cases have become more frequent due to mobilization. https://globalhappenings.com/top-global-news/196541.html = the entire reserve room burned out (a little over 9 square meters). Unfortunately, there were no documents in the room, only personal belongings of the employees. = On the night of May 21, unknown persons set fire to the military registration and conscription office in the settlement of Igra in Udmurtia by throwing a “Molotov cocktail” into the building. In a successful action, the room for reservists in the building went completely up in flames during the fire. https://enoughisenough14.org/2022/06/26/shortly-after-the-longest-night-of-the-year-two-recruiting-offices-burned-at-once-chronicle-of-arson-attacks-until-june-25-2022-russia/  
Igra, Udmurtia

Date discrepancy - 21 & 22 May. Used earliest date. AKA Udmurtskaya Rural teacher Ilya Farber, who is suspected of an arson attack against a military call-up center in Udmirtiya is being held in remand prison # 1 in the city if Izhevsk. He is accused of ”destruction of property”. https://avtonom.org/en/news/support-suspected-arsonists-against-military-call-ups-and-other-russian-anti-war-prisoners A few days later, the FSB [[arrested|detained]] a suspect: 48-year-old Ilya Farber, who came to visit relatives living in Igra. The man has been searched, during it two canisters of gasoline, wire, potassium permanganate, funnels, five bank cards and three iPhones were seized. Farber is a painter and former director of a rural house of culture in the Tver region. In 2013, he was convicted of abuse of office and taking a bribe. The case had clear signs of falsification and got a wide resonance. Even Putin called his sentence "outrageous"! https://libcom.org/article/arise-ukrainian-comrades-anti-war-direct-actions-russia-and-its-9th-review Video of interrogation https://t.me/bazabazon/11799

~+~  
49

# [[OSINT Project/Maps/Central Aerohydrodynamic Institute, 1, ul. Zhukovskogo, Центр, Zhukovsky, Moscow Oblast, Central Federal District, 140181, Russia|TsAGI]] (Aviation)

2022-05-21  
Fire  
Aerospace/Aviation,Other Defence  
https://globalhappenings.com/top-global-news/196541.html  
On May 21, the famous [[OSINT Project/Maps/Central Aerohydrodynamic Institute, 1, ul. Zhukovskogo, Центр, Zhukovsky, Moscow Oblast, Central Federal District, 140181, Russia|TsAGI]] burned in the [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]] region. It is the largest research center in the field of aviation and astronautics. Also reported elsewhere - Fire at the substation in [[OSINT Project/Maps/Central Aerohydrodynamic Institute, 1, ul. Zhukovskogo, Центр, Zhukovsky, Moscow Oblast, Central Federal District, 140181, Russia|TsAGI]] (aviation institute)  
[[OSINT Project/Maps/Central Aerohydrodynamic Institute, 1, ul. Zhukovskogo, Центр, Zhukovsky, Moscow Oblast, Central Federal District, 140181, Russia|Zhukovsky]]

~+~  
72

# Igra, Udmurtia Recruitment Office 2nd (Server Room)

2022-05-23  
Molotov  
Recruitment  
https://libcom.org/article/arise-ukrainian-comrades-anti-war-direct-actions-russia-and-its-9th-review  
On the night of May 21, a Molotov cocktail was thrown into the recruiting station of Igra in Udmurtia Republic. As we can see on the title photo, the entire reserve room burned out (a little over 9 square meters). Unfortunately, there were no documents in the room, only personal belongings of the employees. A couple of days later, another enlistment center of this village also was attacked with such bottle - then the fire spread through the server room, where official documentation and a card file of veterans of the Second World War were stored.  
Igra, Udmurtia Republic

A few days later, the FSB [[arrested|detained]] a suspect: 48-year-old Ilya Farber, who came to visit relatives living in Igra. The man has been searched, during it two canisters of gasoline, wire, potassium permanganate, funnels, five bank cards and three iPhones were seized. Farber is a painter and former director of a rural house of culture in the Tver region. In 2013, he was convicted of abuse of office and taking a bribe. The case had clear signs of falsification and got a wide resonance. Even Putin called his sentence "outrageous"! Video of interrogation https://t.me/bazabazon/11799

~+~  
155

# Sergiyevo-Posadsky [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]] District Railway Track

2022-05-23  
Mechanical  
Infrastructure,Railway  
https://a2day.org/ot-boevoj-gruppy-anarho-kommunistov/  
Sergiyevo-Posadsky District, [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]] Oblast, Russia We, the Militant Anarcho-Communist Organization, have carried out a sabotage operation on the railroad track at coordinates 56 16’44″N 38 12’40.5″E on a sidetrack leading to a military facility of the 12th Main Directorate of the Russian Ministry of Defense. The rail junction was dismantled and the rail tracks were partially disconnected. It must be emphasized that we are not sure that this disconnection was sufficient to free the train from the tracks. But it was a test sabotage, if you will, where we tested the feasibility with the help of tools. We also wanted the sabotage to be as inconspicuous as possible so that the train would not have time to come to a stop. Moreover, it is not sure that a derailment in such a deserted area will reach the media, and we have no possibility to observe it with our own eyes. Therefore, it was decided to publish the result of the attack “as it was” to share the experience with other guerrillas.  
Sergiyevo-Posadsky District [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]] Oblast, Russia  
56 16’44″N 38 12’40.5″E, 56.278889, 38.211111  
Date discrepancy - 23 or 26 May, 2022. Used earliest date. Earliest date confirmed. This section of the road leads to 14258 military unit. It's a secret training and tactical center of the 12th Main Directorate of the Ministry of Defense, which is responsible for Russian nuclear security: Some important aspects of this action are: 1) A track was chosen that leads to a military unit where no civilian trains operate in order to avoid innocent victims. We recommend using wikimapia.org for the search. There, military installations are marked that are not visible on conventional maps. You can also use satellite maps to judge whether a facility is “in operation.” For example, on the base to which the attacked sidetrack leads, you can see a collection of military equipment in open areas. 2) This immediately led to restrictions in the possible actions: On these lines, the wagons are pulled by diesel locomotives, so there are no signal cabinets and no power lines. The main point of attack is therefore the tracks themselves 3) We dismantled the rail connection part and unscrewed the screw nuts holding the rail to the railway sleepers. Normal construction tools, adjustable wrenches with a length of > 0.5 m, proved to be sufficient for this. An adjustable wrench is also required because the rail is fastened with 2 types of screw nuts. We recommend the use of a lubricant to make it easier to unscrew the nuts, as many of them are rusty and hardened. 4) Then the track can be lifted with levers and moved to the side. The more nuts that are used to fasten the rail to the sleepers are unscrewed, the easier it is to move it. The method has proven to be quite feasible and safe, although it could cause serious damage to the armed forces of the Russian Federation. We recommend it to all to use it. Source: tg channel Militant Anarcho-Communist Organization

~+~  
73

# Saint Peter and Paul Church

2022-05-24  
Fire  
Cultural

??  
[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

~+~  
14

# Simferopol, Crimea Recruitment Office

2022-05-28  
Molotov  
Recruitment  
https://enoughisenough14.org/2022/06/26/shortly-after-the-longest-night-of-the-year-two-recruiting-offices-burned-at-once-chronicle-of-arson-attacks-until-june-25-2022-russia/  
On May 28, there was an unsuccessful attempt to set fire to a military recruiting office in Simferopol. On the night of May 28, there was an attack in Crimea. An unidentified one climbed over the fence and entered the territory of the military enlistment office on Selvinsky str. in Simferopol, after which he threw a Molotov cocktail through the basement window. The bottle broke on the window bars and caused no damage to the building. The watchman on duty tried to [[arrested|detain]] the attacker, but he broke free and fled before the police arrived. Bottle fragments are seized. The place is symbolic: this street bears the name of a famous Soviet writer, however in his youth he was a Black Guard fighter in the squad of Maria Nikiforova.  
Simferopol, Crimea

See also https://libcom.org/article/arise-ukrainian-comrades-anti-war-direct-actions-russia-and-its-9th-review

~+~  
150

# Yasnogorsk Recruitment Office

2022-05-30  
Fire  
Recruitment  
https://enoughisenough14.org/2022/06/02/attack-on-military-recruitement-and-enlistment-office-with-an-axe-russia/  
Yasnogorsk. Russia. In the night from May 30 to 31 the building of military recruitement and enlistment office on Shcherbina street in Yasnogorsk (Tula region) was attacked. An unknown person smashed the window with an axe in order to burn the enlistment office from inside. Usually such tactics (first break the window, then pour the flammable mixture and set it on fire) prove to be the most effective, but in this case, unfortunately, the staff of the institution managed to quickly put out the flames before the EMERCOM officers arrived to help. The attacker managed to escape, but he left an axe at the scene outside the military registration and enlistment office. We hope he will remain free and able to continue his fight.  
Shcherbina street, Yasnogorsk, Tula region

Date range May 30-31. Used earliest date. Yasnogorsk also is a notable place for ex-USSR revolutionary history: in 1999, in this town was а strike of machine-building plant's workers with the takeover of the enterprise…Other source https://newsbeezer.com/swedeneng/wave-of-molotov-attacks-on-russian-recruiting-offices/ 31-year-old Denis Arbarov was [[arrested|detained]] by the FSB as a suspect in this case. He's already confessed to everything. https://libcom.org/article/arise-ukrainian-comrades-anti-war-direct-actions-russia-and-its-9th-review

~+~  
148

# Prometeya calls for direct action other than words

2022-05-31  
Other  
Other  
https://a2day.org/obrashhenie-administraczii-prometeya/  
However, we must point out that in a war where the Russian state is killing people in Ukraine, graffiti and leaflets are hardly a sufficient means to stop the killing. A word will not stop a bullet. If you really want to make a difference, you should look for other ways to fight dictatorship and war. Some of these measures are already relatively widespread and popular in Russia–for example, there are regular reports of incendiary attacks on military recruitment centers or acts of sabotage on railroad tracks that can disrupt the Russian army’s infrastructure and supply logistics. We would like to call on all sincere people not to limit themselves to expressing their discontent with the war and the dictatorship, whether on the Internet or in the streets. Words without actions are empty, and the dictatorship has reached the point where it is now or never to act.

prometeya is an [[activism|anarchist]]/community direct action group - The admins of Prometeya have been part of the [[activism|anarchist]] movement for many years and over the years we have directly participated in [[activism|anarchist]] activities, taking part in actions with varying degrees of radicalism and putting ourselves at risk. We have been persecuted and tortured, suffered many deprivations and had to leave the country because of our activities. In Russia, we face severe punishment and torture, and we live with the reality that this will happen to us if we are getting deported. “Narodnaya Samooborona” (People’s Self-Defense), our movement, was destroyed due to repression and has suspended its activities for several years now. To a large extent, this also applies to Prometeya–it has practically stopped working as a media source. Nevertheless, the [[activism|activists]] of the former People’s Self-Defense and the admins of Prometeya are still active. Some are fighting against the Russian army in Ukraine, putting themselves in great danger. Others are organizing fundraising events for [[activism|anarchists]] who are fighting in Ukraine. We will not stay inactive.

~+~  
46

# [[OSINT Project/Maps/Naberezhnye Chelny, Tatarstan, Volga Federal District, Russia|Naberezhnye Chelny]] warehouse

2022-06-03  
Fire

https://globalhappenings.com/top-global-news/195845.html  
[[OSINT Project/Maps/Naberezhnye Chelny, Tatarstan, Volga Federal District, Russia|Naberezhnye Chelny]], a warehouse with rubber and plastic burned epic.  
[[OSINT Project/Maps/Naberezhnye Chelny, Tatarstan, Volga Federal District, Russia|Naberezhnye Chelny]]

~+~  
47

# Grand Setun Plaza Business Center

2022-06-03  
Fire  
Elite,Government  
https://globalhappenings.com/top-global-news/195845.html  
Grand Setun Plaza business center caught fire. There were about 15 people inside. Propaganda media have already reported that the cause was a short circuit due to improper installation of lighting on the facade.

Building includes the offices of Pension Fund of Russia

~+~  
45

# Rogvardia - National Guard Building

2022-06-04  
Fire  
Military  
https://globalhappenings.com/top-global-news/196541.html  
In Russia, the building of the Rogvardia was on fire. It is reported that it was set on fire by an unknown person in [[OSINT Project/Maps/Komsomolsk-on-Amur, Khabarovsk Krai, Far Eastern Federal District, Russia430.3526436163887|Komsomolsk-on-Amur]]. The Telegram channel “Ukraine 24” writes about this. The man approached the building with a canister. According to some reports, he was able to enter the lobby and spilled fuel there, according to others, he simply put the canister on the porch and set it on fire.  
[[OSINT Project/Maps/Komsomolsk-on-Amur, Khabarovsk Krai, Far Eastern Federal District, Russia430.3526436163887|Komsomolsk-on-Amur]], in the Far East

Later, a 50-year-old local resident was [[arrested|detained]].

~+~  
154

# [[OSINT Project/Maps/Komsomolsk-on-Amur, Khabarovsk Krai, Far Eastern Federal District, Russia430.3526436163887|Komsomolsk-on-Amur]] Rosgvardia Office

2022-06-04  
Molotov  
Military  
https://t.me/BO_AK_reborn/1735  
a guerrilla attack was launched against the Rosgvardia office in [[OSINT Project/Maps/Komsomolsk-on-Amur, Khabarovsk Krai, Far Eastern Federal District, Russia430.3526436163887|Komsomolsk-on-Amur]]. The plan by the guerrilla militant was ambitious: as Baza reports, the daredevil wanted to get into the Rosgvardiya [1] building itself in order to ignite a canister with flammable liquid inside. The door was closed, so the guerrilla fighter set the canister on fire on the porch. A fire broke out. one partisan was [[arrested]]. His name is Vladimir Zolotorev and he is 50 years old. [[activism|Anarchist]] Fighter added “Note that a canister with a flammable liquid burns just as well as a Molotov. In addition, a fuse or simple detonator can be attached to a canister (or even several canisters tied together), which delays the moment of ignition for some time and thus greatly increases the chances of a safe getaway for the guerrillas,” in their Telegram post.  
[[OSINT Project/Maps/Komsomolsk-on-Amur, Khabarovsk Krai, Far Eastern Federal District, Russia430.3526436163887|Komsomolsk-on-Amur]]

Date discrepancy 4 or 5 June, 2022. Used earliest date. Also see BAZA https://t.me/bazabazon/11889 Rosgvardia = National Guard

~+~  
75

# Vladivostok Recruitment Office

2022-06-06  
Fire  
Recruitment  
https://darknights.noblogs.org/post/2022/06/13/vladivostok-russia-military-recruitment-center-set-on-fire/  
Vladivostok. Russia. In the early morning hours of June 6, 2022, another office for military call-ups and recruitment was set on fire, this time in the wooden building at 23 Uborevicha Street in Vladivostok. The facade of the building was damaged as a result of the fire. There is conflicting information about how exactly the attack was carried out. Komsomolskaya Pravda”, referring to the police, reports about two suspects who threw a bottle with a flammable liquid against the front wall of the building. Passers-by scared away the arsonists, so that the building did not completely went up in flames, the cladding boards burned. The Telegram channel Shot reports about an arsonist who used a rag prepared with a flammable substance. The arsonists were able to escape. This is the 18th arson attack on an enlistment office that has occurred in recent times. This does not even include the arson attacks on other military and industrial facilities, which the authorities are trying to dismiss as accidents. the military had already begun replacing damaged wooden boards and the head of the regional [[OSINT Project/Maps/Primorsky Krai, Far Eastern Federal District, Russia|Primorsky Krai]] police, Maj. Gen. Oleg Stefankov, had registered the arson incident and put the building "under control."  
23 Uborevicha Street, Vladivostok, [[OSINT Project/Maps/Primorsky Krai, Far Eastern Federal District, Russia|Primorsky Krai]]

Contrary dates. Used the earliest 6 or 8 June. Also see https://www.newsweek.com/military-enlistment-office-set-fire-russia-1713838

~+~  
59

# Zagorsk Optical and Mechanical Plant

2022-06-08  
Fire  
Other Defence  
https://globalhappenings.com/top-global-news/200735.html  
a warehouse of the Zagorsk Optical and Mechanical Plant burned, which produces military optics for the Russian army–from binoculars to optical sights. According to preliminary information, the flames engulfed warehouses next to the administrative building. At first it was reported that the fire area was only 30 square meters. m., but the fire spread very quickly throughout the territory, covering 700 square meters of area.  
Sergiev Posad

military optics for the Russian army–from binoculars to optical sights. Zagorsk Optical & Mechanical Plant warehouse (optical, thermal & night-vision sighting systems)[33]

~+~  
74

# Rosatom (Nuclear) Institute of Digital Technologies

2022-06-08  
Fire  
Education,Other Defence  
https://en.m.wikipedia.org/wiki/2022_Russian_mystery_fires  
??  
Sarov, Nizhny Novgorod

~+~  
58

# [[Armored Personnel Carrier in Transit]]

2022-06-10  
Fire  
Military,Ammunition Depot  
https://globalhappenings.com/top-global-news/202406.html  
In the Rostov region of Russia on June 10, an armored [[Armored Personnel Carrier in Transit|personnel carrier]] with ammunition caught fire on the highway. Ammunition detonated in Russian vehicles after a fire. An eyewitness to the incident said that the accident occurred near the village of Cossack camps. The scene was blocked by Russian police. After the fire, he heard the sounds of explosions–detonated ammunition. Due to an accident, a traffic jam formed on the highway. Drivers were not allowed to enter the scene of the accident.  
Kazachy Camps, Cossack, Rostov region

Some bloggers, spreading the video, erroneously indicated that the [[Armored Personnel Carrier in Transit|APC]] exploded in the Kuban, but this is not so.

~+~  
76

# Factor timber terminal

2022-06-10  
Fire

"Factor" timber terminal owned by oligarch Ramis Deberdeyev  
Ust-Luga

~+~  
152

# Nizhny Novgorod Natalya Abieva Vehicle

2022-06-10  
Fire  
Elite  
https://t.me/theblackheadquarter/238  
Toyota (Р561ХТ152) which belonged to Natalya Abieva, the sponsor of Putinist occupiers, was burned down in Nizhny Novgorod on 10.06.2022. It happened at 3 a.m., by the address Krasnykh Zor street, 24. Abieva is organizer of the foundation in support of Putin’s army, convinced supporter of ruling regime and of war. People like her don’t care about deaths of tens of thousands of people in Ukraine, millions of broken lifes. Abieva is interested just in artificial “greatness of Russia”. But is it possible to gain greatness, while you cover yourself with blood? We believe that this war brings death not only for Ukraine but for Russia as well. We must do all we can to stop it. There are no more means for peaceful protest in our country. We hope, that this clear message will be heared. Now we actively collect data base on regime supporters in our region. The struggle will continue. Dictatorship should be replaced by the society based on freedom, equality and solidarity. See you! Revolutionary cell of Volga region  
Krasnykh Zor street, 24, Nizhny Novgorod, Volga

Claimed by Revolutionary cell of Volga region English coverage https://enoughisenough14.org/2022/06/13/car-of-natalya-abieva-sponsor-of-the-russian-army-torched-in-nizhny-novgorod-russia/

~+~  
192

# Belarusian MAZ Buses in Vitebsk, St Petersburg

2022-06-10  
Fire  
Infrastructure  
https://charter97.org/en/news/2022/6/23/503601/  
Belarusian made MAZ bus caught on fire on Vitebsk Ave in St Petersburg. June 10, MAZ caught fire on Vitebsk Ave. According to the Ministry of Emergency Situations, the bus "burnt out parts". There were no casualties. There have been two accidents with Belarusian buses in a month in the Russian city. Russian transport company Domtransavto, serving several routes in St. Petersburg, will remove MAZ buses from the routes and send the entire batch for examination. The decision was made after the second fire in June  
Vitebsk Ave, St Petersburg

27 June 2022 Lukashenko meets with Alexander Beglov to discuss exploding & burning MAZ buses in St Petersburg. Russia ordered 1,000 MAZ buses. Putin approved 15 Belarusian "substitution" projects…https://president.gov.by/en/events/vstrecha-s-gubernatorom-samarskoy-oblasti-dmitriem-azarovym-1656326969?TSPD_101_R0=08eaf62760ab20006371f9c526d3d319651ab964247994a4f1bfd0c756cde197e0d3d7f441c36dd408e75b61f214300084f02b2acbeebc7e5843aa2aa9675eecce27d1b81c6b0e84116e0fed59779d84fef6ae197f348d01a07206c8d22e8c78

~+~  
57

# Military Unit Equipment Cotton Karma

2022-06-11  
Fire  
Military  
https://globalhappenings.com/top-global-news/202641.html  
COTTON KARMA. A MILITARY UNIT BURNS WITH A BLUE FLAME IN THE BRYANSK REGION. In Russia, a military unit with the equipment of the invaders caught fire. a large-scale fire broke out on the territory of a military unit. It is located about 50 kilometers from the border with Ukraine. The local military unit heard one strong explosion and three less loud ones. They say that military equipment that was used in Ukraine was damaged.  
[[OSINT Project/Maps/Klintsy, городской округ Клинцы, Bryansk Oblast, Central Federal District, 243140, Russia|Klintsy]], Bryansk Region

Military equipment used in Ukraine was damaged. The city where the explosions took place, near the border with the Chernihiv region

~+~  
77

# Bryansk Druzhba pipeline signal loss 3 explosions

2022-06-11  
Explosion  
Gas/Oil  
https://news.yahoo.com/russia-tried-blow-druzhba-pipeline-103804242.html?guccounter=1  
Druzhba pipeline near Gulevka - means friendship Russian media write that on 11 June, three explosions took place near the village of Gulivka in the Bryansk region (40 km to the border with Ukraine). At the same time a signal indicated loss of communication with the latch of the Druzhba pipeline. It is reported that one of the explosions damaged the transformer substation with the power unit of the pipeline latch. Another explosion occurred in the place where the cable was laid. There was a shell hole [measuring] 40 by 20 cm. The third explosion damaged the anti-dig pipe (an additional means of protection which is in the ground at the regime facilities), leaving a shell-hole [measuring] 40 by 60 centimetres. It is noted that the Druzhba pipeline itself was not damaged, but the anti-dig pipe and the substation were damaged, and power was lost to the latch control unit.  
Gulevka or Gulivka, Bryansk

Gulivka AKA Gulevka it was possible to avoid an oil spill [as] the pipeline has been closed since 24 February, but there is diesel fuel inside. Druzhba is the world's largest network of main oil pipelines. It was built in the 1960s to supply oil to Eastern Europe to socialist countries that were at that time friendly to the Soviet Union.

~+~  
143

# [[OSINT Project/Maps/Krasnoyarsk, Krasnoyarsk Urban Okrug, Krasnoyarsk Krai, Siberian Federal District, 660000, Russia|Krasnoyarsk]] 24 [[railway car|railway cars]] derailed

2022-06-11  
Mechanical  
Railway,Infrastructure  
https://enoughisenough14.org/2022/07/04/rail-war-belarusians-face-the-death-penalty-the-blocked-trans-sib-anarchists-work-around-moscow-belarus-russia/  
incident on the [[OSINT Project/Maps/Monument to the 170th anniversary of the Trans-Siberian Railway, улица Леконта, Привокзальный, Ленинский административный округ, Omsk, Omsk Oblast, Siberian Federal District, 644000, Russia|Trans-Siberian Railway]] involving freight trains: on June 11, another 24 freight wagons overturned on the [[OSINT Project/Maps/Krasnoyarsk, Krasnoyarsk Urban Okrug, Krasnoyarsk Krai, Siberian Federal District, 660000, Russia|Krasnoyarsk]] section of the road, the cause of the incident was not stated.  
[[OSINT Project/Maps/Krasnoyarsk, Krasnoyarsk Urban Okrug, Krasnoyarsk Krai, Siberian Federal District, 660000, Russia|Krasnoyarsk]]

~+~  
19

# [[OSINT Project/Maps/Krasnodar, Krasnodar Municipality, Krasnodar Krai, Southern Federal District, 350000, Russia|Krasnodar]] FSB Building

2022-06-15  
Molotov  
Government  
https://enoughisenough14.org/2022/06/26/shortly-after-the-longest-night-of-the-year-two-recruiting-offices-burned-at-once-chronicle-of-arson-attacks-until-june-25-2022-russia/  
On June 15, an attempt was made to set fire to the FSB building in [[OSINT Project/Maps/Krasnodar, Krasnodar Municipality, Krasnodar Krai, Southern Federal District, 350000, Russia|Krasnodar]].  
[[OSINT Project/Maps/Krasnodar, Krasnodar Municipality, Krasnodar Krai, Southern Federal District, 350000, Russia|Krasnodar]]

~+~  
78

# Urengoy Gas Field

2022-06-16  
Fire  
Gas/Oil  
https://en.m.wikipedia.org/wiki/2022_Russian_mystery_fires  
The largest natural gas field in Russia Urengoy gas field [[OSINT Project/Maps/Novy Urengoy, городской округ Новый Уренгой, Yamalo-Nenets Autonomous Okrug, Ural Federal District, 629300, Russia|Novy Urengoy]], lies in Yamalo-Nenets Autonomous Okrug in Tyumen Oblast of Russia, just south of the Arctic circle and named after the settlement of Urengoy  
[[OSINT Project/Maps/Novy Urengoy, городской округ Новый Уренгой, Yamalo-Nenets Autonomous Okrug, Ural Federal District, 629300, Russia|Novy Urengoy]]

~+~  
53

# Barsovo Ammunition Depot - military unit 55443

2022-06-22  
Fire  
Military,Ammunition Depot  
https://globalhappenings.com/top-global-news/218355.html  
on June 22, in the village of Barsovo (Vladimir region), a fire broke out in the arsenal for the complex storage of missiles, ammunition and explosive materials (military unit 55443) of the main rocket and artillery department of the RF Ministry of Defense.  
Barsovo, Vladimir region

DURING THE FIRE, AMMUNITION DETONATED, WHICH LED TO THE DESTRUCTION OF MORE THAN 400 9M113 (9M113K) KONKURS ANTI-TANK MISSILE SYSTEMS AND SHELLS FOR THEM, AS WELL AS TO THE DEATH OF MORE THAN 3 SERVICEMEN OF THE RF ARMED FORCES,

~+~  
54

# Novoshakhtinsky oil refinery

2022-06-22  
Fire  
Gas/Oil  
https://globalhappenings.com/top-global-news/211867.html  
Earlier in the Rostov region, after the “cotton”, the Novoshakhtinsky oil refinery caught fire. The area of ​​the fire was 50 square meters. Russian Telegram channels claim that a Ukrainian drone allegedly caused the “clap”. The Novoshakhtinsky Oil Refinery is located 150 kilometers from Donetsk and even further from the line where the fighting is taking place. === Russia claims it was hit by a Ukraine drone, but direct action groups have taken credit. https://www.themoscowtimes.com/2022/06/22/major-russian-oil-refinery-says-struck-by-ukrainian-drone-a78069  
Novoshakhtinsky, Rostov

This refinery is the largest supplier of petroleum products in the [[OSINT Project/Maps/Southern Russia, улица Степана Разина, Ворошиловский район, Volgograd, Volgograd Oblast, Southern Federal District, 400001, Russia|south of Russia]]. It specializes in the production of fuel oil, heating oil, marine and diesel fuel, straight-run gasoline. In April 2021, a large construction contractor of the Russian Federation PETON became the owner of the Novoshakhtinsk oil products plant, before that The refinery was registered to the wives of Viktor Medvedchuk and Taras Kozak.

~+~  
11

# [[OSINT Project/Maps/Kirovsky District, Stavropol Krai, North Caucasian Federal District, Russia|Kirovsky District]], [[OSINT Project/Maps/Perm, Perm Krai, Volga Federal District, Russia|Perm]], Military Commissariat

2022-06-23  
Molotov  
Recruitment  
https://www.newsweek.com/russia-dissent-putin-ukraine-war-man-molotov-cocktail-fsb-government-building-fire-1720900  
4 Molotov cocktails thrown at the office of the Military Commissariat for [[OSINT Project/Maps/Kirovsky District, Stavropol Krai, North Caucasian Federal District, Russia|Kirovsky District]] in Zakamskaya Street in [[OSINT Project/Maps/Perm, Perm Krai, Volga Federal District, Russia|Perm]]. Baza reported that last week in the city of [[OSINT Project/Maps/Perm, Perm Krai, Volga Federal District, Russia|Perm]], more than 700 miles east of Moscow, four bottles filled with inflammable liquid were thrown into the office of the Military Commissariat for [[OSINT Project/Maps/Kirovsky District, Stavropol Krai, North Caucasian Federal District, Russia|Kirovsky District]]. There was no fire, and the attackers fled the scene See also https://theins.ru/en/news/252560  
Zakamskaya Street, [[OSINT Project/Maps/Kirovsky District, Stavropol Krai, North Caucasian Federal District, Russia|Kirovsky District]], [[OSINT Project/Maps/Perm, Perm Krai, Volga Federal District, Russia|Perm]]

June 23/24, 2022: 4 Molotov cocktails thrown at the office of the Military Commissariat for [[OSINT Project/Maps/Kirovsky District, Stavropol Krai, North Caucasian Federal District, Russia|Kirovsky District]] in Zakamskaya Street in [[OSINT Project/Maps/Perm, Perm Krai, Volga Federal District, Russia|Perm]].

~+~  
193

# Belarusian MAZ Buses Svetlanovsky St Petersburg

2022-06-23  
Fire  
Infrastructure  
https://charter97.org/en/news/2022/6/23/503601/  
Another bus caught fire this morning on Svetlanovsky Avenue. The fire extinguishing system went off in the bus, the driver took the passengers out of the salon; no one was injured. Russian transport company Domtransavto, serving several routes in St. Petersburg, will remove MAZ buses from the routes and send the entire batch for examination. The decision was made after the second fire in June on buses of this model  
Svetlanovsky Avenue, St Petersburg

27 June 2022 Lukashenko meets with Alexander Beglov to discuss exploding & burning MAZ buses in St Petersburg. Russia ordered 1,000 MAZ buses. Putin approved 15 Belarusian "substitution" projects…https://president.gov.by/en/events/vstrecha-s-gubernatorom-samarskoy-oblasti-dmitriem-azarovym-1656326969?TSPD_101_R0=08eaf62760ab20006371f9c526d3d319651ab964247994a4f1bfd0c756cde197e0d3d7f441c36dd408e75b61f214300084f02b2acbeebc7e5843aa2aa9675eecce27d1b81c6b0e84116e0fed59779d84fef6ae197f348d01a07206c8d22e8c78

~+~  
87

# [[OSINT Project/Maps/Novy Urengoy, городской округ Новый Уренгой, Yamalo-Nenets Autonomous Okrug, Ural Federal District, 629300, Russia|Novy Urengoy]]-Orenburg [[railway car|Train Car]] Fire

2022-06-24  
Fire  
Infrastructure,Railway  
https://ura.news/news/1052564729  
The emergency on the train occurred early in the morning of June 24. On the Hanymey - Noyabrsk-2 section in the Yamalo-Nenets Autonomous District, the 13th car of the [[OSINT Project/Maps/Novy Urengoy, городской округ Новый Уренгой, Yamalo-Nenets Autonomous Okrug, Ural Federal District, 629300, Russia|Novy Urengoy]]-Orenburg passenger train caught fire. According to the preliminary version, the cause of the fire is arson.  
Hanymey - Noyabrsk-2 section in the Yamalo-Nenets Autonomous District - [[OSINT Project/Maps/Novy Urengoy, городской округ Новый Уренгой, Yamalo-Nenets Autonomous Okrug, Ural Federal District, 629300, Russia|Novy Urengoy]]-Orenburg

Residents of [[OSINT Project/Maps/Nizhnevartovsk, городской округ Нижневартовск, Khanty-Mansiysk Autonomous Okrug – Ugra, Ural Federal District, Russia|Nizhnevartovsk]] helped [[arrested|detain]] a man suspected of setting fire to a [[railway car|train car]]. This was reported to URA.RU by Anna Skala, who works together with Ugra residents.

~+~  
88

# Belgorod Recruitment Office

2022-06-24  
Molotov  
Recruitment  
https://news.bigmir.net/world/6330781-v-belgorode-i-permi-podozhgli-voenkomaty  
In Belgorod, a fire broke out on the first floor. An unidentified person broke a window of the building on the first floor and threw two Molotov cocktails into room 106. It is reported that a desk went up in flames. See also https://theins.ru/en/news/252560  
Belgorod

Also see https://www.newsweek.com/russia-dissent-putin-ukraine-war-man-molotov-cocktail-fsb-government-building-fire-1720900

~+~  
89

# [[OSINT Project/Maps/Perm, Perm Krai, Volga Federal District, Russia|Perm]] Recruitment Office

2022-06-24  
Molotov  
Recruitment  
https://news.bigmir.net/world/6330781-v-belgorode-i-permi-podozhgli-voenkomaty  
In [[OSINT Project/Maps/Perm, Perm Krai, Volga Federal District, Russia|Perm]], unknown persons also tried to set fire to the army recruitment office. Around 4 a.m. several Molotov cocktails flew into the recruitment office in the [[OSINT Project/Maps/Kirovsky District, Stavropol Krai, North Caucasian Federal District, Russia|Kirovsky district]] on Zakamskaya Street. Four bottles were found on the spot–two broke, two remained in their original state, no fire broke out.  
Zakamskaya Street, [[OSINT Project/Maps/Kirovsky District, Stavropol Krai, North Caucasian Federal District, Russia|Kirovsky district]], [[OSINT Project/Maps/Perm, Perm Krai, Volga Federal District, Russia|Perm]]

Also see https://enoughisenough14.org/2022/06/26/shortly-after-the-longest-night-of-the-year-two-recruiting-offices-burned-at-once-chronicle-of-arson-attacks-until-june-25-2022-russia/

~+~  
109

# Luveno-Porkhov, Pskov Railway Derailment

2022-06-24  
Mechanical  
Railway,Infrastructure  
https://libcom.org/article/rail-war-belarusians-face-death-penalty-blocked-trans-sib-anarchists-work-around-moscow  
Lunevo-Porkhov stretch in the Pskov region, where 13 wagons reportedly carrying explosives were derailed on June 24 (the brake did not work at the right time)  
Lunevo-Porkhov Rail, Pskov region

~+~  
189

# Mystery Cargo [[aircraft|Plane]]

2022-06-24  
Fire  
Military  
https://www.reuters.com/world/europe/cargo-plane-crash-lands-near-russias-ryazan-seven-injured-ifax-2022-06-24/  
Mystery military cargo [[aircraft|plane]] - no one knows which organization runs the [[aircraft|plane]] - crash lands in Ryazan & catches fire killing 3, injuring 6. Video shows [[aircraft|plane]] on fire before landing. Later this was identified as military related. Ilyushin Il-76 military cargo [[aircraft|plane]] crashed and caught fire while landing near Russia's western city of Ryazan on Friday, killing four of the nine people on board. Russia's defence ministry as saying the [[aircraft|plane]] had suffered an engine malfunction while on a training flight. (This appears to be in dispute)  
Ryazan

~+~  
190

# St. Basil the Great [[OSINT Project/Maps/Osinovaya Roshcha, Pargolovo, Saint Petersburg, Northwestern Federal District, 194902, Russia|Aspen Grove]]

2022-06-26  
Fire  
Cultural  
https://bb-cntv.com/news/fire-in-the-church-in-aspen-grove-details-of-the-russian-orthodox-church-told-june-26-2022-company-news-st-petersburg-news-79004/  
St. Basil the Great in [[OSINT Project/Maps/Osinovaya Roshcha, Pargolovo, Saint Petersburg, Northwestern Federal District, 194902, Russia|Osinovaya Roshcha]] ([[OSINT Project/Maps/Osinovaya Roshcha, Pargolovo, Saint Petersburg, Northwestern Federal District, 194902, Russia|Aspen Grove]]) is on fire. St. Petersburg Metropolis said that the church of St. Basil the Great in [[OSINT Project/Maps/Osinovaya Roshcha, Pargolovo, Saint Petersburg, Northwestern Federal District, 194902, Russia|Osinovaya Roshcha]], which caught fire on the morning of June 26 “The temple inside was not damaged. The iconostasis, throne, all liturgical items and vestments have been preserved,” Rodomanova wrote. She clarified that the fire was discovered at about 6 am by a priest who came to prepare for the early liturgy. As a result, the rector of the temple, Father Anatoly Pershin, served the Sunday Liturgy together with the parishioners in the open [[air]]. “There were 60 communicants. The parishioners expressed their readiness to participate in the restoration of their beloved temple, which has been active in educational, creative and social activities for 8 years now,”  
[[OSINT Project/Maps/Osinovaya Roshcha, Pargolovo, Saint Petersburg, Northwestern Federal District, 194902, Russia|Osinovaya Roshcha]], St Petersburg

"for 8 years now" - since 2014. Interesting statement. Photos shown by official Telegram channels show extensive damage.

~+~  
191

# Vyborgsky Orthodox Church St Petersburg

2022-06-26  
Fire  
Cultural  
https://apolline-petit.com/in-st-petersburg-eliminated-the-fire-in-the-orthodox-church  
Same church? Does not seem so. fire in an Orthodox church in the Vyborgsky district of St. Petersburg has been extinguished. This was reported on June 26 by the press service of the Main Directorate of the Ministry of Emergency Situations in the city. It is noted that the message about the fire at the address: Vyborgsky district, Priozerskoye highway, house 12, building 1 was received at 06:05. “In a brick, sheathed with wood, measuring 33 × 6 meters, built in 2016, the building of the church, the roof is on fire throughout the area”the message says.  
Vyborgsky district, Priozerskoye highway, house 12, building 1, St Petersburg

~+~  
101

# [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] Out of Area Cars Burn

2022-06-27  
Fire  
Other  
https://www.ivanovonews.ru/news/1152365/  
The message about the ignition of cars near house No. 16 on Paris Commune Street in [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] arrived on June 27 at about 5 p.m. As IvanovoNews was informed in the press service of the Ministry of Emergency Situations for the [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] region, at first Volkswagen Golf caught fire, from it the flame spread to the nearby Nissan Almera [[Ivanovo Out of Area Cars Burn|foreign car]]. The total area of the fire was 12 square meters. The cars burned almost to the ground. According to the fire department, no one was injured. The preliminary cause of the fire is a malfunction of electrical wiring.  
No. 16, Paris Commune Street, [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]]

The two cars were identified as "foreign" which may mean not registered, out of area or out of country. This may or may not be related to other activities. Adding to see if there is a discernible pattern. There have been other reports in [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] of car burnings & also "foreign" cars having been used as "escape" for unmentioned activities. Highly Likely this has nothing to do with anything.

~+~  
25

# Call to Arms - Revolutionary cell of the Volga region

2022-06-28  
Protest  
Other,Hearts & Minds  
https://t.me/bnkbel/89545  
Russian anti-military arsonists: "There are more of us every day". Not everyone is tough enough to go with Molotov to the enlistment office or burn a vehicle to the beasts guarding the regime. But everyone can take a photo and anonymously send along with the coordinates to the right people. Or collect information about beasts, print out leaflets, stick stickers, draw graffiti, supporting resistance. Sabotage at work in the relevant structures is no less important. It is not necessary to refuse military service if you can learn a lot of valuable information through this. It is not necessary to resign from law enforcement bodies if you can sabotage new cases to capture [[activism|activists]]. Or leave the railway, seeing trains of equipment going to kill people in a neighboring country. Everyone must find their place in the Russia of the future, become this future today, and not leave Russian hopelessness as a legacy to children military recruitment centers burn every week, trains derail from the Kuban to the Far East, cables from zombieboxes are cut at the entrances. The geography of resistance will only expand, because everyone has just begun to taste the delights of life in a new reality: total lack of freedom, a swooping economy, an Iron Curtain. The fire of the revolution will spread throughout the cities of Russia. The future of Russia will be decided in Russia. This is our land, we have nowhere to run, let the scum be afraid and hide in their palaces. The future belongs to us!  
Volga

Also see https://libcom.org/article/russian-anti-military-arsonists-there-are-more-us-every-day

~+~  
144

# Kirzhach railway track sabotage by BOAK

2022-06-28  
Mechanical  
Railway,Infrastructure  
https://t.me/boakom/34  
Anarcho-Communists Combat Organisation (BOAK) reported on June 28 in own Telegram channel about their second act of railway blocking to the military objects after such action a month ago near Sergiyev Posad: “The BOAK-Vladimir cell takes responsibility for the sabotage on the railway line leading to military unit 55443 VD Barsovo (the 51st arsenal of the Main Rocket and Artillery Directorate of the Ministry of Defense of the RF) near Kirzhach. Unlike the previous attack, where we took responsibility without waiting for the result (decided to publish the information to show all the guerrillas how accessible the target was), for subsequent actions we chose the strategy of waiting for the result, not publishing the report until either success was achieved or the facts that the sabotage was discovered will not be received. Unfortunately, in this case, we received reliable information (a video in the offer from a subscriber, apparently, a driver who was driving along this branch) that the sabotage was discovered on the evening of June 25. However, even in this form, the sabotage caused harm to the enemy, delaying the movement of trains with military equipment, and causing economic damage due to the need to restore the railway lines. What has been done:–34 nuts (17 on each side) holding the rail are unscrewed–4 nuts connecting the joint are unscrewed–The rail at the junction is raised, laid on the connecting plate (so as not to fall into place) and set aside.–The rails were connected to each other with a wire, in case a signal current is transmitted along the rail, to detect an open (thanks to the advice from subscribers). We call on everyone to join the rail war! Each stopped train is a minus of shells and rockets that could fly into peaceful Ukrainian cities”.  
Sergiyev Posad near Kirzhach

See also https://enoughisenough14.org/2022/07/04/rail-war-belarusians-face-the-death-penalty-the-blocked-trans-sib-anarchists-work-around-moscow-belarus-russia/

~+~  
52

# Garbage Dump & Warehouses

2022-06-29  
Fire  
Other  
https://globalhappenings.com/top-global-news/217932.html  
In the capital of Russia, a garbage dump caught fire, and then the fire spread to a hangar where car tires were stored. Strong smoke appeared at the site of the fire, its column rose high into the [[air|sky]], which can be seen for several kilometers. It is noted that the fire area is about 500 square meters. There is also a threat that the fire will spread to other buildings nearby.  
[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

~+~  
141

# Amur 19 railway cars derail

2022-06-29  
Mechanical  
Railway,Infrastructure  
https://og.ru/ru/news/126845  
In the Amur region, 19 cars of a freight train derailed on the Sgibeevo - Bolshaya [[OSINT Project/Maps/Omutnaya, городское поселение Ерофей Павлович, Skovorodinsky District, Amur Oblast, Far Eastern Federal District, Russia|Omutnaya]] section. Due to the accident that occurred on June 29, the size of the neighboring track was broken and the support of the contact network was damaged.  
Amur, Russia

as a result of the incident, traffic on the [[OSINT Project/Maps/Monument to the 170th anniversary of the Trans-Siberian Railway, улица Леконта, Привокзальный, Ленинский административный округ, Omsk, Omsk Oblast, Siberian Federal District, 644000, Russia|Trans-Siberian Railway]] had to be temporarily stopped. A group of [[anti-war]] [[activism|activists]] "Stop the Cars" claimed responsibility for the derailment of the train. "If this goes wrong, the military supply from the Far East will soon be covered with a copper basin," they said in their telegram channel. Earlier, participants of this movement hinted at their involvement in accidents on railway routes in Pskov, Rostov, Orenburg, Chelyabinsk regions, [[OSINT Project/Maps/Krasnoyarsk Krai, Siberian Federal District, Russia|Krasnoyarsk Krai]] and other regions. The [[activism|activists]] call their goal to delay railway communication to stop Russian military supplies to Ukraine.

~+~  
99

# Shuya, [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] Car Burning

2022-06-30  
Fire  
Other  
https://www.ivanovonews.ru/news/1152522/  
The fire on Vasilyevsky Trakt in Shuya occurred on June 30 around 19.20. A Ford Fiera car broke out. According to the Ministry of Emergency Situations for the [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] region, by 19.34 the open burning had been eliminated by fire and rescue units. As a result of the fire, the car burned to the ground. No one was hurt. The cause of the fire is being established.  
Vasilyevsky Trakt, Shuya, [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]]

When cars are identified as "foreign" which may mean not registered, out of area or out of country. This may or may not be related to other activities. Adding to see if there is a discernible pattern. There have been other reports in [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] of car burnings & also "foreign" cars having been used as "escape" for unmentioned activities. Highly Likely this has nothing to do with anything.

~+~  
100

# [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] Textile Shop Fire

2022-06-30  
Fire

https://www.ivanovonews.ru/news/1152464/  
The message about the fire in building No. 70 on Okulova Street in [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] was received by the Crisis Management Center on June 30 at 01.58. At the time of arrival of the first fire and rescue units, there was a burning inside the workshop. According to the Ministry of Emergency Situations for the [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] region, at 03.04 the open burning was liquidated. As a result of the fire, textile waste on an area of 30 square meters was damaged. No one was hurt. 42 people and 14 pieces of equipment were involved in extinguishing.  
building No. 70 on Okulova Street, [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]]

Although [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Иваново]] ([[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]]) is not as prestigious as other cities of Золотое кольцо (the Golden Ring), it is still worth a stop. [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] is шутливо называют городом невест (jokingly called the “City of the brides”). The reason of such a nickname come from the fact that [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] is the leading national producer of cotton fabrics, and textile workers are mainly women. Thus, the main population of the city are women. https://ruslanguage.ru/blog/ivanovo-the-textile-capital-of-russia/

~+~  
146

# Nizhny Novgorod FSB Office Molotov

2022-06-30  
Molotov  
Government  
https://www.newsweek.com/russia-dissent-putin-ukraine-war-man-molotov-cocktail-fsb-government-building-fire-1720900  
Thursday afternoon an unknown man hurled the fire bomb at a local office of Russia's Federal Security Service (FSB) in Nizhny Novgorod before fleeing the scene. According to the Russian language news agency, there was no fire, and law enforcement officers are now searching for the man.  
Nizhny Novgorod

~+~  
98

# Kharinka, [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] Soviet Art Clock

2022-07-01  
Other  
Cultural  
https://www.ivanovonews.ru/news/1152528/  
Another Soviet Art Object was dismantled in [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]]. In [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] publics there were reports that an art object was dismantled on Kharinka - a clock installed on the wall of house 54 on 2nd Camp Street. The metal watch was also illuminated, locals remember that on New Year's Eve it was included until the 90s. Why the design was decided to be removed is still unknown.  
54, 2nd Camp Street, Kharinka, [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]]

Reference to "another Soviet art object" indicates there are more mystery dismantlings.  
~+~

142

# [[Amur 14 railcars derailed]]

2022-07-02  
Mechanical  
Railway,Infrastructure  
https://t.me/ostanovivagonyy/114  
the supply of occupiers troops from the Far East is getting more and more difficult. Two days ago, 14 wagons of a freight train derailed on the Sgibeevo–Bolshaya [[OSINT Project/Maps/Omutnaya, городское поселение Ерофей Павлович, Skovorodinsky District, Amur Oblast, Far Eastern Federal District, Russia|Omutnaya]] section in the Amur region. Due to the incident, the dimensions of the adjacent track were violated and the contact network support was damaged. The movement on this section was stopped, passenger train [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]-Vladivostok was delayed. Thus, the [[Trans-Siberian Railway]]–the largest railroad in the world and one of the most important transport routes between Russia and China–was temporarily stopped! 330 employees of the line and a lot of equipment, arrived from three other stations, were involved in the elimination of the consequences.  
Sgibeevo–Bolshaya, [[OSINT Project/Maps/Omutnaya, городское поселение Ерофей Павлович, Skovorodinsky District, Amur Oblast, Far Eastern Federal District, Russia|Omutnaya]] section, Amur region

Also see https://enoughisenough14.org/2022/07/04/rail-war-belarusians-face-the-death-penalty-the-blocked-trans-sib-anarchists-work-around-moscow-belarus-russia/

~+~  
194

# Nikolai Rimsky-Korsakov Estate Museum

2022-07-02  
Fire  
Cultural  
https://www.classicfm.com/composers/rimsky-korsakov/fire-memorial-museum-russia/  
Over half of the exhibits have been destroyed in the blaze, which has devastated more than 1,000 artefacts. Reports of the fire originally emerged from the governor of the district, Mikhail Vedernikov who posted a photo of the fire on his Telegram [social media] account, saying the damage was “significant”. The fire is said to have been started due to “the negligence of builders” who were repairing the roof of the museum using a ‘hot work’ technique–construction that uses open flames. Starting on the roof, the fire spread “very quickly” throughout the building according to Vedernikov, engulfing the estate before firefighters were able to arrive  
Lyubensk, Plyussky district, Pskovskaya, Paskov

Putin named his mega yacht Sherezade, an opera written by Rimsky-Korsakov. https://www.zyri.net/2022/03/09/a-mysterious-and-gigantic-yacht-is-disturbing-in-italy-is-it-putins/ Also see https://en.newizv.ru/news/incident/04-07-2022/the-fire-destroyed-over-a-thousand-exhibits-in-the-rimsky-korsakov-museum

~+~  
51

# Capital Towers Complex

2022-07-03  
Fire  
Elite,Other  
https://globalhappenings.com/top-global-news/221879.html  
In the capital of Russia, [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]], on the evening of July 3, a fire broke out in one of the towers of the Capital Towers complex. According to the Telegram channel “Ukraine 24”, preliminary, the fire occurred on the 55th floor. Firefighters are on the scene. according to preliminary data, scaffolding was on fire on the roof of one of the Capital Towers in the center of [[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]].  
[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

THE HIGHEST REGISTRATION IN [[OSINT Project/Maps/Moscow, Central Federal District, Russia|MOSCOW]] IS ON FIRE–THIS IS WHAT THE CAPITAL TOWERS RESIDENTIAL COMPLEX IS CALLED. SMOKE IS COMING FROM THE ROOF OF ONE OF THE UNFINISHED SKYSCRAPERS. THERE ARE NO ACCIDENTS, THERE ARE PATTERNS. MORDOR MUST BURN IN HELL,” ANTON GERASHCHENKO, ADVISER TO THE HEAD OF THE MINISTRY OF INTERNAL AFFAIRS OF UKRAINE, COMMENTED ON THE FIRE.

~+~  
50

# [[OSINT Project/Maps/Kyzyl, Kyzyl City, Tuva Republic, Siberian Federal District, Russia|Kyzyl]] Warehouses

2022-07-04  
Fire

https://globalhappenings.com/top-global-news/221879.html  
A massive fire broke out on Monday, July 4. The fire engulfed the warehouses of building materials. It spread to 2.8 thousand square meters. 2 am The fire spread throughout the warehouses of building materials.  
[[OSINT Project/Maps/Kyzyl, Kyzyl City, Tuva Republic, Siberian Federal District, Russia|Kyzyl]], Republic of Tuva

~+~  
95

# [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] 315 Guns/Weapons + 2,000 cartridges/ammo seized since January 2022

2022-07-05  
Other  
Weapons,Other  
https://www.ivanovonews.ru/news/1152674/  
Comprehensive inspections of civilian firearms owners will continue in the [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] region. According to the Department of Rosgvardia for the [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] region, in total, since the beginning of 2022, more than 13,000 inspections of the conditions of the preservation of weapons have been carried out in the region, according to the results of which 493 violations were identified, 316 weapons and more than 2 thousand cartridges have been seized. 12 facts of gross violations of the law were also revealed - permits for weapons of these citizens were canceled. More than 22 thousand owners of civilian weapons are registered in the region, in use of which there are about 34 thousand weapons. For 6 months of this year, the Licensing and Licensing and its structural subdivisions received more than 7.3 thousand applications from individuals and legal entities. Thanks to the compensation program for the population in the reporting period, 9 weapons were handed over voluntarily, about 30 thousand rubles were paid to citizens from the regional budget. "Each owner should understand that the conditions for the safety of weapons and ammunition and the safety of their storage must be observed not only at the place of residence. Also, security measures are necessary for transportation, on small arms and in hunting grounds, because lost weapons can become an instrument of crime," the Office of Rosgvardia notes.  
[[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]]

Not sabotage, but shows line of previously undisclosed concern by authorities. Employees of Rosgvardia remind that in all cases of voluntary surrender of weapons, ammunition and explosives, a citizen in accordance with the current legislation is exempt from criminal liability for their illegal possession. Weapons and ammunition are handed over to the licensing and permitting units of Rosgvardia in the [[OSINT Project/Maps/Ivanovo, Ivanovo Oblast, Central Federal District, 153000, Russia|Ivanovo]] region or to territorial police units. https://www.ivanovonews.ru/news/1152362/

~+~  
183

# Cyber Partisans Release Belarus Passports - Zhara (Heat)

2022-07-26  
Mechanical  
Elite,Hearts & Minds  
https://en.currenttime.tv/a/seeking-change-anti-lukashenka-hackers-seize-senior-belarusian-officials-personal-data-/31392092.html  
July 26, the group’s Telegram channel teased passport data for KGB Chairman Ivan Tertel; Central Election Commission Chairwoman Lidiya Yermoshina; the chairwoman of the upper house of parliament, Natallya Kachanova; and ex-Kyrgyz President Kurmanbek Bakiyev, who has lived in Belarus since his 2010 overthrow from power. Belarusian passports are used both as a domestic identity document and for external travel. Each individual’s dossier, the hackers claim, contains passport photos and data; his or her residence permit; the name of the government body or military unit for which the person works; the names of family members, “and so on.” “Will many KGB agents be ready to operate abroad, knowing that data about them has already leaked?” Aside from passport data, the Cyberpartisans claim to have accessed the records of the Belarusian traffic police, which the hackers say include information on registered cars for the KGB, the anti-corruption police, and tsikhary (“silent men”), masked muscle men in plainclothes known for brutally rounding up suspected protesters.Information was also seized about the KGB’s housing assignments, Cyber-Partisan added, which means “they’ll have to change all the apartments.” “Intelligence, counterintelligence, and KGB employees who have special notes (indicating their occupations) in their passports are completely compromised,” said Andriy Baranovych. “And [[activism|activists]], partisans got the data, not the special services. And now the people who are the backbone of the Lukashenka regime will not feel safe.”  
Belarus

This material is from a 2021 hack that penetrated every government agency, including [[air]] gapped intelligence. They have been very careful to release only the material that does not harm ordinary citizens. CP, BYPOL, Flying Storks work with Railway Workers to cyber attack the Belarusian railway system in an effort to slow Russia's advances. This was instrumental in the early days of the war to give Ukraine time to organize and prepare.

~+~
