---
locations:
aliases: 
location:
title: Bryansk Oil Depot(s) Transneft Rosneft
tag: 
date:
---

# Bryansk Oil Depot(s) Transneft Rosneft

2022-04-25  
[[fire]]  
Gas/Oil,Military  
https://www.kyivpost.com/ukraine-politics/fire-breaks-out-at-two-oil-storage-facilities-in-bryansk-where-russian-military-is-based-nearby.html  
Also see Druzhba pipeline https://news.yahoo.com/russia-tried-blow-druzhba-pipeline-103804242.html?guccounter=1 two large explosions and [[fire|fires]] occurred at two oil facilities, a civilian one and a military one Numerous videos showed an oil depot alight as well as a refinery belonging to Russian state-owned Rosneft Explosions thundered in Bryansk on the night from Sunday to Monday, April 25. After that, a [[fire]] broke out at the local oil depot, as well as on the territory of the military unit. Some time later, the press service of the government of the Bryansk region confirmed the [[fire]] at the oil depot, but did not name its cause. They reported that the tanks were on [[fire]]. There was no mention of explosions. Residents of houses near the [[fire|burning]] oil depot in Bryansk began to be evacuated by the police. == The ministry said in a statement that the [[fire]] had broken out at a facility owned by oil pipeline company Transneft (TRNF_p.MM) at 0200 [[Moscow]] time (2300 GMT), no need to evacuate any parts of Bryansk, a city of 400,000 people. Other unverified footage showed what looked like another [[fire]] [[fire|burning]] at a second location in Bryansk. https://www.reuters.com/world/europe/large-fire-oil-depot-russias-bryansk-near-ukraine-agencies-2022-04-25/  
Bryansk

**According to InformNapalm, Russia is attacking itself with false flags & is preparing to bring in wreckage of Ukrainian [[aircraft|helicopters]] and drones to place as "proof". Other claims made are that top military and families were evacuated April 19th in preparation. Focus areas Belgorod, [[OSINT Project/Maps/Kursk, Kursk Oblast, Central Federal District, 305000, Russia|Kursk]], Bryansk Oblasts especially civilian and residential areas** *Multiple explosions over the course of days. Double check the Druzhba Pipeline lists 3 explosions in the same area on a different date. *There were reports of high up military & elites being evacuated several days prior to this [[fire]]. Transneft - - at least 7 tanks damaged or destroyed A Russian military is also based near the Western Russian city located about 100 kilometers from Ukraine’s border. The city is a key transit point for Russian military armor on the way to Ukraine. Oil is also crucial for the country’s war effort. Also see https://globalhappenings.com/top-global-news/217932.html

~+~  
56
