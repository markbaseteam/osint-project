---
locations:
aliases: 
location:
title: Shebekinsky Railway Bridge Collapse
tag: mechanical, railway, infrastructure 
date: 2022-04-12 
---

# Shebekinsky Railway Bridge Collapse

2022-04-12  
Mechanical  
Railway,Infrastructure  
https://libcom.org/article/rail-war-russia-ukraine-borderland-facts-and-its-checking  
governor of the Belgorod region reported about the explosion damaged the railway bridge in the Shebekinsky urban district near occupied Volchansk. These paths were used for [[passengers|passenger]] traffic, were not guarded, and there were no victims or injured. After four days, the damage was repaired  
Shebekinsky, Bolgorod

~+~  
81
