---
aliases: 
location: 
Teysin, Khabarovsk
title:
tag: explosion, military, military base, powder
date: 2022-05-12  
---

Teysin, Khabarovsk

# Khabarovsk Krai Teysin Military Base Powder Warehouse

2022-05-12  
Explosion  
Military  
https://ria.ru/20220512/vzryv-1788053221.html  
Explosion in a powder warehouse in Khabarovsk Krai. Russian sources state this was due to "mishandling explosives". Warehouse located at a military base in Teysin, Khabarovsk. There are four military bases in this area. Explosion happened during unloading munitions & sparked a large blaze. Soldiers killed & injured. https://tifnews.com/world/russia/1-dead-7-injured-in-russia-military-base-explosion-the-moscow-times/  
Teysin, Amursky district, Khabarovsk Krai

Located in Russia's subarctic far east & shared border with China. Industry: military [[aircraft]], shipbuilding & oil refining

~+~  
35