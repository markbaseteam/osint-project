---
locations:
aliases: 
location: Sakhalinskaya, Ilyinskoye, Kuril Islands
title: 'Kuril Islands, Ilyinskoye Sakhalinskaya GRES-2 Power Plant'
tag: Japan, fire, infrastructure, power plant, energy
date: 2022-04-30  
---

# Kuril Islands, Ilyinskoye Sakhalinskaya GRES-2 Power Plant

2022-04-30  
[[fire]]  
Infrastructure  
https://twitter.com/VelvetBlade/status/1520337933831655424  
Sakhalinskaya power plant on [[fire]]. Located in the Kuril Islands - In 1944 Soviets invaded & there has been a dispute between Russia & Japan ever since. Japan particularly claims the 4 southern islands. Russia cut off treaty talks with Japan about Kuril over sanctions.  
Sakhalinskaya, Ilyinskoye, Kuril Islands

In occupied Japan. The interesting thing about this plant is it is relatively new.

~+~  
64
