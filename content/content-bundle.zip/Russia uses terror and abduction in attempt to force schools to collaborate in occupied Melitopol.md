---
aliases: 
locations:
tag: 
date:
title: Russia uses terror and abduction in attempt to force schools to collaborate in occupied Melitopol
---

Russia uses terror and abduction in attempt to force schools to collaborate in occupied Melitopol

https://khpg.org/en/1608810509
