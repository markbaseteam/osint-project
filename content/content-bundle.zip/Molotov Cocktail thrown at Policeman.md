---
locations:
aliases: Anastasia Levashova
location: Pushkin Square, Moscow
title: Molotov Cocktail thrown at Policeman
tag: molotov, government 
date: 2022-02-24  
---

# Molotov Cocktail thrown at Policeman

2022-02-24  
Molotov  
Government  
https://sofrep.com/news/we-dont-wanna-go-russian-military-recruitment-offices-attacked-with-molotov-cocktails/  
Anastasia Levashova threw a Molotov cocktail at Russian policemen during a rally in [[Moscow]], specifically at [[OSINT Project/Maps/Pushkin Square, 49, Tverskoy District, Moscow, Central Federal District, 127238, Russia|Pushkin Square]] on February 24th, the day of the invasion. She was later caught and found guilty of using violence not dangerous to life or health against a representative of the authorities.  
[[OSINT Project/Maps/Moscow, Central Federal District, Russia|Moscow]]

she was later revealed to be the daughter of one of the Russian opposition leaders, Mikhail Kirtser. She was sentenced to two years in [[prison]].  
~+~  
120
