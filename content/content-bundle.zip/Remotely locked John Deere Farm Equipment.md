---
aliases: 
locations: Melitopol, [Zakhan Yurt, Chechnya], [Grozny, Chechnya] 
title: Remotely locked John Deere Farm Equipment
tag: mechanical
date: 2022-05-02  
---

# Remotely locked John Deere Farm Equipment

2022-05-02  
Mechanical  
Other  
https://www.cnn.com/2022/05/01/europe/russia-farm-vehicles-ukraine-disabled-melitopol-intl/index.html  
Russian troops in the occupied city of [[Melitopol]] have stolen all the equipment from a farm equipment dealership ~+~ and shipped it to [[Chechnya]], according to a Ukrainian businessman in the area. But after a journey of more than 700 miles, the thieves were unable to use any of the equipment ~+~ because it had been locked remotely. equipment was removed from an [[Agrotek]] dealership in Melitopol, which has been occupied by Russian forces since early March. Altogether it's valued at nearly $5 million. The combine harvesters alone are worth $300,000 each. One of the flat-bed [[automobiles|trucks]] used, and caught on camera, had a white "Z" painted on it and appeared to be a military [[automobiles|truck]]. equipped with [[GPS]], meant that its travel could be tracked. It was last tracked to the village of [[Zakhan Yurt]] in [[Chechnya]]. The equipment now appears to be languishing at a farm near [[Grozny]].  
Zakhan Yurt, [[OSINT Project/Maps/Chechen Republic, North Caucasian Federal District, Russia|Chechnya]]

~+~  
83
