---
locations:
aliases: 
location:
title: Domanovo - Lesnaya telemechanics and automation devices disabled
tag: 
date:
---

# Domanovo - Lesnaya telemechanics and automation devices disabled

2022-03-15  
Mechanical  
Railway,Infrastructure  
https://ru.wikipedia.org/wiki/Рельсовая_война_в_Белоруссии_(2022)# 30_марта  
On the Domanovo - Lesnaya line, telemechanics and automation devices of the SCB were disabled  
Domanovo - Lesnaya line, Belarus

~+~  
134
